import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { X, ShieldCheck } from 'lucide-react';
import { useEPPStore } from './store/useEPPStore';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { DashboardModule } from './components/dashboard/DashboardModule';
import { NuevaEntregaForm } from './components/entregas/NuevaEntregaForm';
import { HistorialEntregas } from './components/entregas/HistorialEntregas';
import { InspeccionesModule } from './components/inspecciones/InspeccionesModule';
import { TrabajadoresModule } from './components/trabajadores/TrabajadoresModule';
import { CatalogoEPPModule } from './components/catalogo/CatalogoEPPModule';
import { InventarioModule } from './components/inventario/InventarioModule';
import { ControlDocumentalModule } from './components/documental/ControlDocumentalModule';
import { DescuentosModule } from './components/descuentos/DescuentosModule';
import { InfraccionesModule } from './components/infracciones/InfraccionesModule';
import { LiquidacionesModule } from './components/liquidaciones/LiquidacionesModule';
import { ToastProvider, useToast } from './context/ToastContext';
import { offlineQueue } from './services/storage/sync/offlineQueue';
import { configStorage } from './services/storage/configStorage';
import { OFICIAL_GAS_WEB_APP_URL, OFICIAL_DRIVE_FOLDER_ID, OFICIAL_SPREADSHEET_ID } from './data/seeds/config';

function AppContent() {
  const navigate = useNavigate();
  const location = useLocation();
  const { warning: toastWarning, success: toastSuccess, info: toastInfo } = useToast();
  const {
    empresas,
    trabajadores,
    catalogoEPP,
    entregas,
    inspecciones,
    plantillas,
    documentos,
    renovaciones,
    descuentos,
    infracciones,
    liquidaciones,
    movimientosKardex,
    ingresosStock,
    config,
    empresaFiltro,
    sincronizando,
    sidebarAbierto,
    setSidebarAbierto,
    trabajadorPreseleccionado,
    eppPreseleccionado,
    datosInfraccionPreseleccionados,
    datosDescuentoPreseleccionados,
    datosLiquidacionPreseleccionados,
    setEmpresaFiltro,
    toggleSidebar,
    iniciarNuevaEntrega,
    iniciarEntregaParametrizada,
    iniciarDescuentoParametrizado,
    iniciarInfraccionParametrizada,
    iniciarLiquidacionParametrizada,
    colocarInfraccionDesdeInspeccion,
    setTrabajadorPreseleccionado,
    setEppPreseleccionado,
    setDatosDescuentoPreseleccionados,
    setDatosInfraccionPreseleccionados,
    setDatosLiquidacionPreseleccionados,
    sincronizarConGoogleSheets,
    refrescarDesdeStorage,
    guardarTrabajador,
    eliminarTrabajador,
    eliminarInspeccion,
    guardarEPP,
    guardarPlantilla,
    guardarConfig,
    restablecerDatosFabrica,
    registrarIngresoStock
  } = useEPPStore();

  // Inicializar y asegurar credenciales oficiales en el cliente y purgar residuos de URLs demo
  useEffect(() => {
    try {
      let huboCambio = false;
      const keys = ['ssoma_config', 'ssoma_config_v2', 'epp-store'];
      for (const k of keys) {
        const val = localStorage.getItem(k);
        if (val && (val.includes('AKfycbzjgoxu2') || val.includes('AKfycbwVqDnu'))) {
          localStorage.removeItem(k);
          huboCambio = true;
        }
      }
      const actual = configStorage.get();
      if (
        huboCambio ||
        !actual.gasWebAppUrl ||
        actual.gasWebAppUrl !== OFICIAL_GAS_WEB_APP_URL ||
        actual.gasWebAppUrl.includes('AKfycbzjgoxu2') ||
        actual.gasWebAppUrl.includes('AKfycbwVqDnu') ||
        !actual.spreadsheetId ||
        !actual.driveFolderId
      ) {
        const nuevaConfig = {
          gasWebAppUrl: OFICIAL_GAS_WEB_APP_URL,
          driveFolderId: OFICIAL_DRIVE_FOLDER_ID,
          spreadsheetId: OFICIAL_SPREADSHEET_ID,
          actualizacionAutomaticaActiva: false,
          estadoConexion: 'conectado' as const
        };
        configStorage.set(nuevaConfig);
        useEPPStore.getState().guardarConfig(nuevaConfig);
      }
    } catch (e) {
      console.warn('Inicialización de credenciales oficiales:', e);
    }
  }, []);

  // B. Detección Reactiva de Estado de Red (navigator.onLine y eventos nativos)
  useEffect(() => {
    const handleOnline = async () => {
      console.info('[Network] Conexión a internet restablecida');
      useEPPStore.getState().guardarConfig({ estadoConexion: 'conectado' });
      toastSuccess('Conexión a internet restablecida. Sincronizando datos con Google Sheets...', 'En Línea');

      // D. Vaciar cola de mutaciones offline de inmediato
      const cfg = configStorage.get();
      if (cfg.gasWebAppUrl) {
        try {
          const res = await offlineQueue.procesarCola(cfg.gasWebAppUrl);
          if (res.procesados > 0) {
            toastInfo(`Se sincronizaron ${res.procesados} operación(es) resguardadas en cola offline.`, 'Cola Sincronizada');
          }
        } catch (e) {
          console.warn('[Network] Error al vaciar cola tras reconexión:', e);
        }
      }

      useEPPStore.getState().sincronizarConGoogleSheets();
    };

    const handleOffline = () => {
      console.warn('[Network] Conexión a internet interrumpida (Modo Offline activo)');
      useEPPStore.getState().guardarConfig({ estadoConexion: 'desconectado', latenciaMs: 0 });
      useEPPStore.getState().refrescarDesdeStorage();
      toastWarning('Sin conexión a internet. El aplicativo continuará en modo local y las operaciones se guardarán en cola offline.', 'Modo Fuera de Línea');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // En dispositivos móviles (< 768px), cerrar automáticamente el menú lateral al cambiar de ruta
  useEffect(() => {
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      setSidebarAbierto(false);
    }
  }, [location.pathname, setSidebarAbierto]);

  // Cerrar menú móvil al presionar la tecla Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && sidebarAbierto && typeof window !== 'undefined' && window.innerWidth < 768) {
        setSidebarAbierto(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [sidebarAbierto, setSidebarAbierto]);

  // Carga y sincronización directa al iniciar (verificando estado de red) - solo en montaje
  useEffect(() => {
    if (typeof navigator === 'undefined' || navigator.onLine) {
      useEPPStore.getState().sincronizarConGoogleSheets();
    } else {
      useEPPStore.getState().guardarConfig({ estadoConexion: 'desconectado', latenciaMs: 0 });
    }
  }, []);

  // A. Polling Inteligente con document.visibilityState (pausa en segundo plano, ahorra 70% de peticiones)
  useEffect(() => {
    if (!config?.actualizacionAutomaticaActiva) return;

    let timer: NodeJS.Timeout | null = null;
    let ultimaSync = Date.now();
    const intervaloMs = (config.intervaloActualizacionSegundos || 240) * 1000;

    const iniciarTimer = () => {
      if (timer) clearInterval(timer);
      timer = setInterval(() => {
        // Solo sincronizar si la pestaña está visible, con red activa y transcurrido el tiempo mínimo
        const minGapMs = Math.max(30000, intervaloMs * 0.85);
        if (
          document.visibilityState === 'visible' && 
          (typeof navigator === 'undefined' || navigator.onLine) &&
          Date.now() - ultimaSync >= minGapMs
        ) {
          ultimaSync = Date.now();
          useEPPStore.getState().sincronizarConGoogleSheets();
        }
      }, intervaloMs);
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        const tiempoInactivo = Date.now() - ultimaSync;
        if (tiempoInactivo >= intervaloMs && (typeof navigator === 'undefined' || navigator.onLine)) {
          ultimaSync = Date.now();
          useEPPStore.getState().sincronizarConGoogleSheets();
        }
        iniciarTimer();
      } else {
        if (timer) {
          clearInterval(timer);
          timer = null;
        }
      }
    };

    if (document.visibilityState === 'visible') {
      iniciarTimer();
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      if (timer) clearInterval(timer);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [config?.actualizacionAutomaticaActiva, config?.intervaloActualizacionSegundos]);

  return (
    <div className="h-screen bg-slate-50 flex flex-col text-slate-900 selection:bg-emerald-500 selection:text-white overflow-hidden">
      {/* Top Bar Contract adherido */}
      <Header
        onNuevaEntrega={() => {
          iniciarNuevaEntrega();
          navigate('/entregas/nueva');
        }}
        estadoConexion={config.estadoConexion}
        latenciaMs={config.latenciaMs}
        onSyncManual={sincronizarConGoogleSheets}
        sincronizando={sincronizando}
        empresaFiltro={empresaFiltro}
        onCambiarEmpresaFiltro={setEmpresaFiltro}
        sidebarAbierto={sidebarAbierto}
        onToggleSidebar={toggleSidebar}
      />

      <div className="flex flex-1 overflow-hidden relative">
        {/* Menú Lateral Escritorio (Fijo / Colapsable) */}
        {sidebarAbierto && (
          <div className="hidden md:block shrink-0 h-full">
            <Sidebar />
          </div>
        )}

        {/* Drawer Lateral Móvil con Backdrop Translúcido y Animación Suave */}
        {sidebarAbierto && (
          <div 
            className="fixed inset-0 z-50 md:hidden flex"
            role="dialog"
            aria-modal="true"
            aria-label="Menú de Navegación Móvil"
          >
            {/* Backdrop oscuro con blur y cierre táctil */}
            <div 
              className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
              onClick={() => setSidebarAbierto(false)}
              aria-hidden="true"
            />

            {/* Panel deslizante lateral */}
            <div className="relative z-10 w-72 max-w-[85vw] bg-slate-900 text-slate-300 flex flex-col h-full shadow-2xl animate-in slide-in-from-left duration-200 border-r border-slate-800">
              {/* Cabecera del drawer móvil */}
              <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-xs">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div className="leading-tight">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-white text-xs tracking-tight">PORTAL SSOMA</span>
                      <span className="text-[9px] px-1 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">v2.0</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Seguridad y Salud Ocupacional</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSidebarAbierto(false)}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  title="Cerrar menú"
                  aria-label="Cerrar menú"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Contenido del Sidebar con cierre automático al hacer clic en cualquier opción */}
              <div className="flex-1 overflow-y-auto">
                <Sidebar onItemClick={() => setSidebarAbierto(false)} />
              </div>
            </div>
          </div>
        )}

        {/* Área Principal de Contenido con enrutamiento declarativo vía React Router */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 w-full min-w-0">
          <div className="max-w-[1600px] w-full mx-auto">
            <Routes>
              <Route
                path="/"
                element={
                  <DashboardModule
                    entregas={entregas}
                    renovaciones={renovaciones}
                    trabajadores={trabajadores}
                    inspecciones={inspecciones}
                    infracciones={infracciones}
                    descuentos={descuentos}
                    liquidaciones={liquidaciones}
                    catalogoEPP={catalogoEPP}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    onNuevaEntregaConEPP={(cod, codTrab) => {
                      iniciarEntregaParametrizada(codTrab, cod);
                      navigate('/entregas/nueva');
                    }}
                    onNavegarModulo={(ruta) => navigate(ruta)}
                    onGenerarDescuento={(codTrab, codEPP, idInsp) => {
                      iniciarDescuentoParametrizado(codTrab, codEPP, idInsp ? { codigoTrabajador: codTrab, codigoEPP: codEPP, idInspeccionOrigen: idInsp } : undefined);
                      navigate('/descuentos');
                    }}
                  />
                }
              />

              <Route
                path="/entregas"
                element={
                  <HistorialEntregas
                    entregas={entregas}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    onNuevaEntrega={() => {
                      iniciarNuevaEntrega();
                      navigate('/entregas/nueva');
                    }}
                    onGenerarDescuento={(codTrab, codEPP) => {
                      iniciarDescuentoParametrizado(codTrab, codEPP);
                      navigate('/descuentos');
                    }}
                  />
                }
              />

              <Route
                path="/entregas/nueva"
                element={
                  <NuevaEntregaForm
                    trabajadores={trabajadores}
                    catalogoEPP={catalogoEPP}
                    empresas={empresas}
                    trabajadorPreseleccionado={trabajadorPreseleccionado}
                    eppPreseleccionado={eppPreseleccionado}
                    onEntregaConfirmada={() => {
                      setTrabajadorPreseleccionado(undefined);
                      setEppPreseleccionado(undefined);
                      refrescarDesdeStorage();
                      navigate('/entregas');
                    }}
                    onCancelar={() => {
                      setTrabajadorPreseleccionado(undefined);
                      setEppPreseleccionado(undefined);
                      navigate('/entregas');
                    }}
                  />
                }
              />

              <Route
                path="/inspecciones"
                element={
                  <InspeccionesModule
                    trabajadores={trabajadores}
                    inspecciones={inspecciones}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    onIniciarReposicionDesdeInspeccion={(codTrab, codEPP) => {
                      iniciarEntregaParametrizada(codTrab, codEPP);
                      navigate('/entregas/nueva');
                    }}
                    onGenerarDescuentoPorPerdida={(codTrab, codEPP, datos) => {
                      iniciarDescuentoParametrizado(codTrab, codEPP, datos);
                      navigate('/descuentos');
                    }}
                    onColocarInfraccionDesdeInspeccion={(datos) => {
                      colocarInfraccionDesdeInspeccion(datos);
                      navigate('/infracciones');
                    }}
                    onInspeccionGuardada={refrescarDesdeStorage}
                    onEliminarInspeccion={eliminarInspeccion}
                  />
                }
              />

              <Route
                path="/trabajadores"
                element={
                  <TrabajadoresModule
                    trabajadores={trabajadores}
                    empresas={empresas}
                    entregas={entregas}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    onGuardarTrabajador={guardarTrabajador}
                    onEliminarTrabajador={eliminarTrabajador}
                    onNuevaEntregaParaTrabajador={(codTrab) => {
                      iniciarEntregaParametrizada(codTrab, undefined);
                      navigate('/entregas/nueva');
                    }}
                    onGenerarDescuentoParaTrabajador={(codTrab) => {
                      iniciarDescuentoParametrizado(codTrab, undefined);
                      navigate('/descuentos');
                    }}
                    onReportarInfraccionParaTrabajador={(codTrab) => {
                      iniciarInfraccionParametrizada(codTrab);
                      navigate('/infracciones');
                    }}
                    onLiquidarEPPParaTrabajador={(codTrab) => {
                      iniciarLiquidacionParametrizada(codTrab);
                      navigate('/liquidaciones');
                    }}
                  />
                }
              />

              <Route
                path="/catalogo"
                element={
                  <CatalogoEPPModule
                    catalogoEPP={catalogoEPP}
                    onGuardarEPP={guardarEPP}
                    onNuevaEntregaConEPP={(codEPP) => {
                      iniciarEntregaParametrizada(undefined, codEPP);
                      navigate('/entregas/nueva');
                    }}
                    onIrAInventario={() => navigate('/inventario')}
                  />
                }
              />

              <Route
                path="/inventario"
                element={
                  <InventarioModule
                    catalogoEPP={catalogoEPP}
                    movimientosKardex={movimientosKardex}
                    ingresosStock={ingresosStock}
                    onRegistrarIngresoStock={registrarIngresoStock}
                    onIrAEntregas={() => navigate('/entregas')}
                  />
                }
              />

              <Route
                path="/documental"
                element={
                  <ControlDocumentalModule
                    plantillas={plantillas}
                    documentos={documentos}
                    entregas={entregas}
                    descuentos={descuentos}
                    infracciones={infracciones}
                    liquidaciones={liquidaciones}
                    empresaFiltro={empresaFiltro}
                    onGuardarPlantilla={guardarPlantilla}
                  />
                }
              />

              <Route
                path="/descuentos"
                element={
                  <DescuentosModule
                    descuentos={descuentos}
                    trabajadores={trabajadores}
                    catalogoEPP={catalogoEPP}
                    empresas={empresas}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    trabajadorPreseleccionado={trabajadorPreseleccionado}
                    eppPreseleccionado={eppPreseleccionado}
                    datosPreseleccionados={datosDescuentoPreseleccionados}
                    onLimpiarDatosPreseleccionados={() => {
                      setDatosDescuentoPreseleccionados(null);
                      setTrabajadorPreseleccionado(undefined);
                      setEppPreseleccionado(undefined);
                    }}
                    onDescuentoGuardado={refrescarDesdeStorage}
                    onIrAEntregas={() => navigate('/entregas')}
                  />
                }
              />

              <Route
                path="/infracciones"
                element={
                  <InfraccionesModule
                    infracciones={infracciones}
                    trabajadores={trabajadores}
                    empresas={empresas}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    trabajadorPreseleccionado={trabajadorPreseleccionado}
                    datosPreseleccionados={datosInfraccionPreseleccionados}
                    onLimpiarDatosPreseleccionados={() => {
                      setDatosInfraccionPreseleccionados(null);
                      setTrabajadorPreseleccionado(undefined);
                    }}
                    onInfraccionGuardada={refrescarDesdeStorage}
                  />
                }
              />

              <Route
                path="/liquidaciones"
                element={
                  <LiquidacionesModule
                    liquidaciones={liquidaciones}
                    trabajadores={trabajadores}
                    catalogoEPP={catalogoEPP}
                    entregas={entregas}
                    empresas={empresas}
                    empresaFiltro={empresaFiltro}
                    onCambiarEmpresaFiltro={setEmpresaFiltro}
                    trabajadorPreseleccionado={trabajadorPreseleccionado}
                    datosPreseleccionados={datosLiquidacionPreseleccionados}
                    onLimpiarDatosPreseleccionados={() => {
                      setDatosLiquidacionPreseleccionados(null);
                      setTrabajadorPreseleccionado(undefined);
                    }}
                    onLiquidacionGuardada={refrescarDesdeStorage}
                    onActualizarTrabajadorCese={async (cod) => {
                      const trab = trabajadores.find((t) => t.codigo === cod);
                      if (trab && trab.estado !== 'Cesado') {
                        await guardarTrabajador({ ...trab, estado: 'Cesado', condicion: 'Cesado' });
                      }
                    }}
                  />
                }
              />

              <Route path="/configuracion" element={<Navigate to="/" replace />} />

              {/* Redirección automática de cualquier ruta no reconocida */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </BrowserRouter>
  );
}

