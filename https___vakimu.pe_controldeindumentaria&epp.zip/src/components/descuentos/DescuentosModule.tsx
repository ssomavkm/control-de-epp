import React, { useState, useMemo, useEffect } from 'react';
import { 
  DollarSign, 
  ReceiptText, 
  Plus, 
  Search, 
  FileText, 
  CheckCircle2, 
  Clock, 
  Trash2, 
  Sparkles, 
  AlertCircle,
  Eye,
  Calendar,
  Check
} from 'lucide-react';
import { 
  DescuentoEPP, 
  Trabajador, 
  EPPItem, 
  Empresa, 
  ItemDescuentoEPP, 
  MotivoDescuento, 
  ModalidadPagoDescuento,
  DatosPreseleccionadosDescuento,
  RESPONSABLES_SST_OPCIONES
} from '../../types';
import { storageService } from '../../services/storageService';
import { PDFGeneratorService, PDFResult } from '../../services/pdfGenerator';
import { googleDriveService } from '../../services/drive/googleDriveService';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { SignaturePad } from '../common/SignaturePad';
import { TablePagination } from '../common/TablePagination';
import { ModuleHeader } from '../common/ModuleHeader';
import { ModuleFilterBar } from '../common/ModuleFilterBar';
import { TrabajadorSearchAutocomplete } from '../common/TrabajadorSearchAutocomplete';
import { compararFechasDesc } from '../../utils/formatters';

interface DescuentosModuleProps {
  descuentos: DescuentoEPP[];
  trabajadores: Trabajador[];
  catalogoEPP: EPPItem[];
  empresas: Empresa[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  trabajadorPreseleccionado?: string;
  eppPreseleccionado?: string;
  datosPreseleccionados?: DatosPreseleccionadosDescuento | null;
  onLimpiarDatosPreseleccionados?: () => void;
  onDescuentoGuardado: () => void;
  onIrAEntregas?: () => void;
}

export const DescuentosModule: React.FC<DescuentosModuleProps> = ({
  descuentos,
  trabajadores,
  catalogoEPP,
  empresas,
  empresaFiltro,
  onCambiarEmpresaFiltro,
  trabajadorPreseleccionado,
  eppPreseleccionado,
  datosPreseleccionados,
  onLimpiarDatosPreseleccionados,
  onDescuentoGuardado,
  onIrAEntregas
}) => {
  const [vistaActiva, setVistaActiva] = useState<'lista' | 'nuevo'>(() => {
    return (trabajadorPreseleccionado || datosPreseleccionados) ? 'nuevo' : 'lista';
  });

  // Filtros de listado
  const [busqueda, setBusqueda] = useState<string>('');
  const [filtroEstado, setFiltroEstado] = useState<string>('TODOS');
  const [descuentoDetalle, setDescuentoDetalle] = useState<DescuentoEPP | null>(null);

  // Visor PDF
  const [modalPDFOpen, setModalPDFOpen] = useState<boolean>(false);
  const [pdfData, setPdfData] = useState<{ url: string | null; buffer: ArrayBuffer | null; fileName: string }>({
    url: null,
    buffer: null,
    fileName: ''
  });
  const [generandoPDF, setGenerandoPDF] = useState<boolean>(false);

  // --- Formulario de Nuevo Descuento ---
  const [codigoTrabajador, setCodigoTrabajador] = useState<string>(trabajadorPreseleccionado || '');
  const [fechaSolicitud, setFechaSolicitud] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [fechaIncidente, setFechaIncidente] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [motivoDescuento, setMotivoDescuento] = useState<MotivoDescuento>('Pérdida en planta');
  const [descripcionHechos, setDescripcionHechos] = useState<string>('');
  const [itemsDescuento, setItemsDescuento] = useState<ItemDescuentoEPP[]>([]);
  const [modalidadPago, setModalidadPago] = useState<ModalidadPagoDescuento>('1 cuota fin de mes');
  const [cuotas, setCuotas] = useState<number>(1);
  const [autorizaDescuento, setAutorizaDescuento] = useState<boolean>(true);
  const [reponerInmediatamente, setReponerInmediatamente] = useState<boolean>(true);
  const [responsableSeleccionado, setResponsableSeleccionado] = useState<string>('Ing. Jhon Rojas (Supervisor SSOMA)');
  const [responsableNombre, setResponsableNombre] = useState<string>('Ing. Jhon Rojas');
  const [responsableCargo, setResponsableCargo] = useState<string>('Supervisor SSOMA');

  const handleCambiarResponsable = (valor: string) => {
    setResponsableSeleccionado(valor);
    const encontrado = RESPONSABLES_SST_OPCIONES.find(r => r.valor === valor);
    if (encontrado) {
      setResponsableNombre(encontrado.nombre);
      setResponsableCargo(encontrado.cargo);
    } else {
      const match = valor.match(/^(.*?)\s*\((.*?)\)$/);
      if (match) {
        setResponsableNombre(match[1].trim());
        setResponsableCargo(match[2].trim());
      } else {
        setResponsableNombre(valor);
      }
    }
  };
  const [firmaTrabajador, setFirmaTrabajador] = useState<string>('');
  const [firmaResponsable, setFirmaResponsable] = useState<string>('');
  const [observaciones, setObservaciones] = useState<string>('');
  const [guardando, setGuardando] = useState<boolean>(false);
  const [mensajeExito, setMensajeExito] = useState<string | null>(null);
  const [mensajeError, setMensajeError] = useState<string | null>(null);
  const [descuentoAEliminar, setDescuentoAEliminar] = useState<DescuentoEPP | null>(null);

  // Formato oficial homologado de descuento activo desde storageService
  const plantillaActiva = useMemo(() => {
    return storageService.getPlantillaActivaParaDescuento();
  }, []);

  // Trabajador seleccionado reactivo
  const trabajadorSeleccionado = useMemo(() => {
    return trabajadores.find(t => t.codigo === codigoTrabajador);
  }, [trabajadores, codigoTrabajador]);

  // Si cambia trabajador seleccionado y hay un EPP preseleccionado, inicializar
  React.useEffect(() => {
    if (trabajadorPreseleccionado && trabajadorPreseleccionado !== codigoTrabajador) {
      setCodigoTrabajador(trabajadorPreseleccionado);
      setVistaActiva('nuevo');
    }
  }, [trabajadorPreseleccionado]);

  // Si provienen datos preseleccionados desde inspecciones
  React.useEffect(() => {
    if (datosPreseleccionados) {
      if (datosPreseleccionados.codigoTrabajador) {
        setCodigoTrabajador(datosPreseleccionados.codigoTrabajador);
      }
      if (datosPreseleccionados.motivoDescuento) {
        setMotivoDescuento(datosPreseleccionados.motivoDescuento);
      }
      if (datosPreseleccionados.descripcionHechos) {
        setDescripcionHechos(datosPreseleccionados.descripcionHechos);
      }
      if (datosPreseleccionados.codigoEPP) {
        const epp = catalogoEPP.find(e => e.codigo === datosPreseleccionados.codigoEPP);
        if (epp) {
          setItemsDescuento([
            {
              idItem: `ITEM-DESC-${Date.now()}`,
              codigoEPP: epp.codigo,
              articulo: epp.articulo,
              categoria: epp.categoria,
              marca: epp.marca,
              talla: epp.talla,
              unidad: epp.unidad,
              cantidadPerdida: 1,
              costoUnitario: epp.costoUnitario,
              importeTotal: epp.costoUnitario
            }
          ]);
        }
      }
      setVistaActiva('nuevo');
    }
  }, [datosPreseleccionados, catalogoEPP]);

  React.useEffect(() => {
    if (eppPreseleccionado && itemsDescuento.length === 0) {
      const epp = catalogoEPP.find(e => e.codigo === eppPreseleccionado);
      if (epp) {
        setItemsDescuento([
          {
            idItem: `ITEM-${Date.now()}`,
            codigoEPP: epp.codigo,
            articulo: epp.articulo,
            categoria: epp.categoria,
            marca: epp.marca,
            talla: epp.talla,
            unidad: epp.unidad,
            cantidadPerdida: 1,
            costoUnitario: epp.costoUnitario,
            importeTotal: epp.costoUnitario
          }
        ]);
      }
    }
  }, [eppPreseleccionado, catalogoEPP]);

  // Total a descontar calculado
  const totalDescuentoCalculado = useMemo(() => {
    return itemsDescuento.reduce((acc, curr) => acc + curr.importeTotal, 0);
  }, [itemsDescuento]);

  const montoPorCuotaCalculado = useMemo(() => {
    if (cuotas <= 0) return totalDescuentoCalculado;
    return Number((totalDescuentoCalculado / cuotas).toFixed(2));
  }, [totalDescuentoCalculado, cuotas]);

  // Manejo de modalidad de pago
  const handleCambiarModalidad = (mod: ModalidadPagoDescuento) => {
    setModalidadPago(mod);
    if (mod === '1 cuota fin de mes' || mod === '1 cuota en quincena') {
      setCuotas(1);
    } else if (mod === '2 cuotas quincenales') {
      setCuotas(2);
    } else if (mod === '3 cuotas mensuales') {
      setCuotas(3);
    }
  };

  // Cargar EPPs previamente entregados a este trabajador para selección rápida
  const handleCargarEPPDeTrabajador = () => {
    if (!codigoTrabajador) return;
    const ultimosEPP = storageService.getUltimosEPPEntregadosPorTrabajador(codigoTrabajador) || [];
    if (!Array.isArray(ultimosEPP) || ultimosEPP.length === 0) {
      setMensajeError('El trabajador no tiene entregas previas registradas. Puede seleccionar artículos directamente del catálogo inferior.');
      return;
    }
    setMensajeError(null);

    const nuevosItems: ItemDescuentoEPP[] = ultimosEPP.map((u, idx) => {
      const catItem = (catalogoEPP || []).find(e => e.codigo === u.codigoEPP);
      const costo = catItem ? catItem.costoUnitario : 25;
      return {
        idItem: `ITEM-${Date.now()}-${idx}`,
        codigoEPP: u.codigoEPP,
        articulo: u.articulo,
        categoria: catItem?.categoria,
        marca: catItem?.marca || '3M',
        talla: u.talla,
        unidad: catItem?.unidad || 'Unidad',
        cantidadPerdida: 1,
        costoUnitario: costo,
        importeTotal: costo,
        fechaEntregaOriginal: (u as any).fechaEntrega || u.fechaRenovacion || new Date().toISOString().split('T')[0]
      };
    });

    setItemsDescuento(nuevosItems);
  };

  // Agregar artículo desde catálogo
  const handleAgregarArticuloCatalogo = (codigoEPP: string) => {
    const epp = catalogoEPP.find(e => e.codigo === codigoEPP);
    if (!epp) return;

    // Verificar si ya está en la lista
    const existe = itemsDescuento.find(i => i.codigoEPP === codigoEPP);
    if (existe) {
      setItemsDescuento(prev => prev.map(item => {
        if (item.codigoEPP === codigoEPP) {
          const nuevaCant = item.cantidadPerdida + 1;
          return {
            ...item,
            cantidadPerdida: nuevaCant,
            importeTotal: Number((nuevaCant * item.costoUnitario).toFixed(2))
          };
        }
        return item;
      }));
    } else {
      setItemsDescuento(prev => [
        ...prev,
        {
          idItem: `ITEM-${Date.now()}-${prev.length}`,
          codigoEPP: epp.codigo,
          articulo: epp.articulo,
          categoria: epp.categoria,
          marca: epp.marca,
          talla: epp.talla,
          unidad: epp.unidad,
          cantidadPerdida: 1,
          costoUnitario: epp.costoUnitario,
          importeTotal: epp.costoUnitario
        }
      ]);
    }
  };

  const handleActualizarCantidadItem = (idItem: string, cant: number) => {
    if (cant < 1) return;
    setItemsDescuento(prev => prev.map(item => {
      if (item.idItem === idItem) {
        return {
          ...item,
          cantidadPerdida: cant,
          importeTotal: Number((cant * item.costoUnitario).toFixed(2))
        };
      }
      return item;
    }));
  };

  const handleEliminarItem = (idItem: string) => {
    setItemsDescuento(prev => prev.filter(i => i.idItem !== idItem));
  };

  // Previsualizar PDF oficial
  const handlePrevisualizarPDF = async () => {
    setMensajeError(null);
    if (!trabajadorSeleccionado) {
      setMensajeError('Seleccione un trabajador para generar la previsualización.');
      return;
    }
    if (itemsDescuento.length === 0) {
      setMensajeError('Debe agregar al menos un EPP a descontar.');
      return;
    }

    setGenerandoPDF(true);
    try {
      const borrador: DescuentoEPP = {
        id: `DESC-${Date.now()}`,
        numeroRegistro: storageService.generarNuevoNumeroDescuento(),
        codigoPlantilla: plantillaActiva?.codigo || 'FO-SST-DES-001',
        versionPlantilla: plantillaActiva?.version || '01',
        fechaSolicitud,
        fechaIncidente,
        codigoTrabajador: trabajadorSeleccionado.codigo,
        dni: trabajadorSeleccionado.dni,
        trabajadorNombre: trabajadorSeleccionado.nombreCompleto,
        empresaId: trabajadorSeleccionado.empresaId,
        empresaNombre: trabajadorSeleccionado.empresaNombre,
        ruc: trabajadorSeleccionado.empresaId === 'EMP-PERPOL' ? '20392729977' : '20550842891',
        area: trabajadorSeleccionado.area,
        cargo: trabajadorSeleccionado.cargo,
        fechaIngreso: trabajadorSeleccionado.fechaIngreso,
        motivoDescuento,
        descripcionHechos: descripcionHechos || 'Extravío de equipo de protección personal reportado por el trabajador.',
        items: itemsDescuento,
        montoTotalDescuento: totalDescuentoCalculado,
        modalidadPago,
        cuotas,
        montoPorCuota: montoPorCuotaCalculado,
        autorizaDescuento,
        firmaTrabajador: firmaTrabajador || undefined,
        firmaResponsable: firmaResponsable || undefined,
        responsableNombre,
        responsableCargo,
        estado: 'Pendiente',
        reponerInmediatamente,
        fechaCreacion: new Date().toISOString(),
        observaciones
      };

      const result: PDFResult = await PDFGeneratorService.generarDocumentoDescuentoPDF(borrador, plantillaActiva);
      setPdfData({
        url: result.blobUrl,
        buffer: result.arrayBuffer,
        fileName: result.fileName
      });
      setModalPDFOpen(true);
    } catch (err: any) {
      console.error('Error al generar vista previa PDF:', err);
      setMensajeError('Error al generar PDF: ' + err.message);
    } finally {
      setGenerandoPDF(false);
    }
  };

  // Guardar documento
  const handleGuardarDescuento = async (e: React.FormEvent) => {
    e.preventDefault();
    setMensajeError(null);
    if (!trabajadorSeleccionado) {
      setMensajeError('Seleccione un trabajador válido.');
      return;
    }
    if (itemsDescuento.length === 0) {
      setMensajeError('Debe especificar al menos un artículo de EPP extraviado.');
      return;
    }
    if (!autorizaDescuento) {
      setMensajeError('Es obligatorio el consentimiento de autorización expresa para registrar el documento.');
      return;
    }

    setGuardando(true);
    try {
      const nuevoNum = storageService.generarNuevoNumeroDescuento();
      const nuevoId = storageService.generarNuevoIdDescuento();
      const ruc = trabajadorSeleccionado.empresaId === 'EMP-PERPOL' ? '20392729977' : '20550842891';

      const nuevoDescuento: DescuentoEPP = {
        id: nuevoId,
        numeroRegistro: nuevoNum,
        codigoPlantilla: plantillaActiva?.codigo || 'FO-SST-DES-001',
        versionPlantilla: plantillaActiva?.version || '01',
        fechaSolicitud,
        fechaIncidente,
        codigoTrabajador: trabajadorSeleccionado.codigo,
        dni: trabajadorSeleccionado.dni,
        trabajadorNombre: trabajadorSeleccionado.nombreCompleto,
        empresaId: trabajadorSeleccionado.empresaId,
        empresaNombre: trabajadorSeleccionado.empresaNombre,
        ruc,
        area: trabajadorSeleccionado.area,
        cargo: trabajadorSeleccionado.cargo,
        fechaIngreso: trabajadorSeleccionado.fechaIngreso,
        motivoDescuento,
        descripcionHechos: descripcionHechos || 'Extravío/deterioro no justificado de EPP.',
        items: itemsDescuento,
        montoTotalDescuento: totalDescuentoCalculado,
        modalidadPago,
        cuotas,
        montoPorCuota: montoPorCuotaCalculado,
        autorizaDescuento: true,
        firmaTrabajador: firmaTrabajador || undefined,
        firmaResponsable: firmaResponsable || undefined,
        responsableNombre,
        responsableCargo,
        estado: 'Autorizado',
        reponerInmediatamente,
        idInspeccionOrigen: datosPreseleccionados?.idInspeccionOrigen,
        numeroInspeccionOrigen: datosPreseleccionados?.numeroInspeccionOrigen,
        fechaCreacion: new Date().toISOString(),
        observaciones,
        pdfFileName: `AUT_DESCUENTO_${nuevoNum}_${ruc}_${trabajadorSeleccionado.dni}_${fechaSolicitud.replace(/-/g, '')}.pdf`
      };

      const res = await storageService.registrarDescuento(nuevoDescuento, reponerInmediatamente);

      // Respaldo automático de la autorización de descuento en Google Drive
      const plantillaAsociada = storageService.getPlantillaPorCodigo(nuevoDescuento.codigoPlantilla || 'FO-SST-DES-001') || storageService.getPlantillaActivaParaDescuento();
      PDFGeneratorService.generarDocumentoDescuentoPDF(nuevoDescuento, plantillaAsociada)
        .then(pdfRes => {
          if (pdfRes && pdfRes.blob) {
            googleDriveService.subirArchivo({
              nombreArchivo: pdfRes.fileName,
              mimeType: 'application/pdf',
              datosBlob: pdfRes.blob,
              subcarpeta: '03_Descuentos_EPP',
              claveIdentificador: nuevoDescuento.numeroRegistro,
              descripcion: `Autorización de Descuento por EPP ${nuevoDescuento.numeroRegistro} - ${nuevoDescuento.trabajadorNombre}`
            }).catch(e => console.info('Respaldo automático en Drive diferido:', e));
          }
        })
        .catch(e => console.warn('Generación de PDF de descuento para Drive:', e));

      // Notificar éxito y limpiar
      setMensajeExito(`¡Documento ${nuevoNum} registrado con éxito! ${reponerInmediatamente && res.entregaReposicionId ? `Se generó la Entrega de Reposición N° ${res.entregaReposicionId} en inventario.` : ''}`);
      onDescuentoGuardado();
      if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();

      // Resetear form
      setItemsDescuento([]);
      setDescripcionHechos('');
      setFirmaTrabajador('');
      setFirmaResponsable('');
      setObservaciones('');

      setTimeout(() => {
        setMensajeExito(null);
        setVistaActiva('lista');
      }, 2500);

    } catch (err: any) {
      console.error('Error al guardar documento de descuento:', err);
      setMensajeError('Error al registrar el descuento: ' + err.message);
    } finally {
      setGuardando(false);
    }
  };

  // Abrir visor de un descuento ya existente
  const handleVerPDFExistente = async (desc: DescuentoEPP) => {
    setGenerandoPDF(true);
    setMensajeError(null);
    try {
      const plantillaAsociada = storageService.getPlantillaPorCodigo(desc.codigoPlantilla || 'FO-SST-DES-001') || storageService.getPlantillaActivaParaDescuento();
      const result = await PDFGeneratorService.generarDocumentoDescuentoPDF(desc, plantillaAsociada);
      setPdfData({
        url: result.blobUrl,
        buffer: result.arrayBuffer,
        fileName: result.fileName
      });
      setModalPDFOpen(true);
    } catch (err: any) {
      setMensajeError('Error al generar PDF: ' + err.message);
    } finally {
      setGenerandoPDF(false);
    }
  };

  // Filtrado de lista
  const descuentosFiltrados = useMemo(() => {
    const lista = Array.isArray(descuentos) ? descuentos : [];
    return lista.filter(d => {
      if (!d) return false;

      // Filtro empresa
      if (empresaFiltro !== 'TODAS' && d.empresaId !== empresaFiltro) return false;

      // Filtro estado
      if (filtroEstado !== 'TODOS' && d.estado !== filtroEstado) return false;

      // Búsqueda
      if (busqueda.trim()) {
        const q = busqueda.toLowerCase();
        const matchReg = String(d.numeroRegistro || '').toLowerCase().includes(q);
        const matchTrab = String(d.trabajadorNombre || '').toLowerCase().includes(q);
        const matchDni = String(d.dni || '').includes(q);
        const items = Array.isArray(d.items) ? d.items : [];
        const matchArt = items.some(it => it && it.articulo && it.articulo.toLowerCase().includes(q));
        if (!matchReg && !matchTrab && !matchDni && !matchArt) return false;
      }

      return true;
    }).sort((a, b) => compararFechasDesc(a.fechaSolicitud || a.fechaIncidente, b.fechaSolicitud || b.fechaIncidente, a.numeroRegistro, b.numeroRegistro));
  }, [descuentos, empresaFiltro, filtroEstado, busqueda]);

  // Métricas
  const kpis = useMemo(() => {
    const totalDocs = descuentosFiltrados.length;
    const montoTotal = descuentosFiltrados.reduce((acc, curr) => acc + (Number(curr?.montoTotalDescuento) || 0), 0);
    const autorizados = descuentosFiltrados.filter(d => d.estado === 'Autorizado').length;
    const aplicados = descuentosFiltrados.filter(d => d.estado === 'Aplicado en Planilla').length;
    return { totalDocs, montoTotal, autorizados, aplicados };
  }, [descuentosFiltrados]);

  // Paginación para historial de autorizaciones de descuento
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, empresaFiltro, filtroEstado, descuentos.length]);

  const totalPaginas = Math.max(1, Math.ceil(descuentosFiltrados.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;

  const descuentosPaginados = useMemo(() => {
    return descuentosFiltrados.slice(indiceInicio, indiceInicio + porPagina);
  }, [descuentosFiltrados, indiceInicio, porPagina]);

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Encabezado del Módulo con Formato Aprobado Estandarizado */}
      <ModuleHeader
        icon={ReceiptText}
        title="Autorización de Descuento por Pérdida o Deterioro de EPP"
        badge={`${plantillaActiva.codigo} v${plantillaActiva.version}`}
        subtitle="Generación de documentos de deducción salarial con herencia de datos del trabajador, reposición inmediata y cláusula legal (Ley N° 29783)."
        colorTheme="amber"
        actions={
          vistaActiva === 'lista' ? (
            <button
              onClick={() => setVistaActiva('nuevo')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Emitir Nuevo Documento</span>
            </button>
          ) : null
        }
      />

      {mensajeExito && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2.5 shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{mensajeExito}</span>
        </div>
      )}

      {mensajeError && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center justify-between gap-2.5 shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{mensajeError}</span>
          </div>
          <button
            onClick={() => setMensajeError(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* VISTA 1: LISTADO DE DOCUMENTOS DE DESCUENTO */}
      {vistaActiva === 'lista' && (
        <div className="space-y-6">
          {/* Tarjetas KPI */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 font-medium">Total Documentos</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{kpis.totalDocs}</p>
                <span className="text-[11px] text-slate-400">Autorizaciones registradas</span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 font-medium">Monto Total a Deducir</p>
                <p className="text-2xl font-bold text-rose-600 mt-1">S/ {kpis.montoTotal.toFixed(2)}</p>
                <span className="text-[11px] text-slate-400">Valorización acumulada</span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 font-medium">Autorizados / Pendientes</p>
                <p className="text-2xl font-bold text-amber-600 mt-1">{kpis.autorizados}</p>
                <span className="text-[11px] text-slate-400">Por procesar en nómina</span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 font-medium">Aplicados en Planilla</p>
                <p className="text-2xl font-bold text-emerald-600 mt-1">{kpis.aplicados}</p>
                <span className="text-[11px] text-slate-400">Descuento ejecutado</span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Barra de Filtros y Búsqueda Estandarizada */}
          <ModuleFilterBar
            busqueda={busqueda}
            onBusquedaChange={setBusqueda}
            placeholder="Buscar por trabajador, DNI, N° de registro, artículo..."
            totalResultados={descuentosFiltrados.length}
            etiquetaPlural="autorizaciones de descuento"
            etiquetaSingular="autorización de descuento"
            hayFiltrosActivos={busqueda !== '' || filtroEstado !== 'TODOS'}
            onLimpiarFiltros={() => {
              setBusqueda('');
              setFiltroEstado('TODOS');
            }}
          >
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Estado:</span>
              <select
                value={filtroEstado}
                onChange={(e) => setFiltroEstado(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="TODOS">Todos los Estados</option>
                <option value="Autorizado">Autorizado</option>
                <option value="Aplicado en Planilla">Aplicado en Planilla</option>
                <option value="Pendiente">Pendiente</option>
                <option value="Anulado">Anulado</option>
              </select>
            </div>
          </ModuleFilterBar>

          {/* Tabla de Documentos Registrados */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs min-w-[950px]">
                <thead>
                  <tr className="bg-slate-50/90 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                    <th className="py-3.5 px-4 w-44">Registro / Fecha</th>
                    <th className="py-3.5 px-4 min-w-[200px]">Trabajador (Heredado)</th>
                    <th className="py-3.5 px-4 w-44">Empresa / Área</th>
                    <th className="py-3.5 px-4 min-w-[220px]">EPP(s) Extraviado(s)</th>
                    <th className="py-3.5 px-4 text-right w-32">Monto Total</th>
                    <th className="py-3.5 px-4 w-32">Modalidad</th>
                    <th className="py-3.5 px-4 text-center w-28">Estado</th>
                    <th className="py-3.5 px-4 text-center w-28">Reposición</th>
                    <th className="py-3.5 px-4 text-center w-36">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800">
                  {descuentosFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-14 text-center text-slate-500">
                        <div className="max-w-xs mx-auto space-y-2">
                          <ReceiptText className="w-8 h-8 mx-auto text-slate-400 stroke-1" />
                          <p className="font-semibold text-slate-700 text-xs">No se encontraron autorizaciones de descuento</p>
                          <p className="text-[11px] text-slate-500">Intenta con otros filtros o emite un nuevo documento.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    descuentosPaginados.map((item, idx) => {
                      const isPerpol = item.empresaId === 'EMP-PERPOL';
                      return (
                        <tr key={item.id ? `${item.id}-${idx}` : `desc-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3.5 px-4">
                            <span className="font-mono font-bold text-slate-900 block">{item.numeroRegistro}</span>
                            <span className="text-[11px] text-slate-600 font-medium flex items-center gap-1 mt-0.5">
                              <Calendar className="w-3 h-3" />
                              {item.fechaSolicitud}
                            </span>
                            {item.numeroInspeccionOrigen && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-300 mt-1" title={`Originado en Inspección ${item.numeroInspeccionOrigen}`}>
                                <Check className="w-2.5 h-2.5 text-amber-700" />
                                <span>Origen: {item.numeroInspeccionOrigen}</span>
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-bold text-slate-900 block">{item.trabajadorNombre}</span>
                            <span className="text-[11px] text-slate-600 font-medium font-mono">DNI: {item.dni} · {item.cargo}</span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold mb-0.5 border ${
                              isPerpol ? 'bg-emerald-100 text-emerald-900 border-emerald-300' : 'bg-blue-100 text-blue-900 border-blue-300'
                            }`}>
                              {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
                            </span>
                            <span className="text-[11px] text-slate-700 font-medium block">{item.area}</span>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="space-y-1">
                              {(!item.items || !Array.isArray(item.items) || item.items.length === 0) ? (
                                <span className="text-[11px] text-slate-400 italic">Sin ítems detallados</span>
                              ) : (
                                item.items.map((it, idx) => (
                                  <div key={idx} className="text-[11px] text-slate-900 flex items-center gap-1.5">
                                    <span className="font-bold text-slate-700">{it?.cantidadPerdida || 1}x</span>
                                    <span className="truncate max-w-[200px] font-medium" title={it?.articulo || 'EPP'}>{it?.articulo || 'EPP'}</span>
                                    <span className="text-[11px] text-slate-600 font-mono">({it?.talla || '-'})</span>
                                  </div>
                                ))
                              )}
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <span className="font-bold text-rose-700 block text-sm font-mono">
                              S/ {item.montoTotalDescuento.toFixed(2)}
                            </span>
                            {item.cuotas > 1 && (
                              <span className="text-[11px] text-slate-600 font-medium">
                                ({item.cuotas} cuotas de S/ {item.montoPorCuota.toFixed(2)})
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-slate-800">
                            <span className="text-[11px] font-medium block">{item.modalidadPago}</span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              item.estado === 'Aplicado en Planilla'
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : item.estado === 'Autorizado'
                                ? 'bg-blue-100 text-blue-900 border-blue-300'
                                : item.estado === 'Pendiente'
                                ? 'bg-amber-100 text-amber-900 border-amber-300'
                                : 'bg-slate-100 text-slate-700 border-slate-300'
                            }`}>
                              {item.estado}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            {item.idEntregaReposicion ? (
                              <span 
                                title={`Entrega de reposición generada: ${item.idEntregaReposicion}`}
                                className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-900 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300"
                              >
                                <Check className="w-3 h-3 text-emerald-700" />
                                {item.idEntregaReposicion}
                              </span>
                            ) : (
                              <span className="text-[11px] text-slate-600 font-medium">No solicitada</span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => setDescuentoDetalle(item)}
                                className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                                title="Ver desglose detallado del descuento"
                                aria-label={`Ver desglose detallado del descuento ${item.numeroRegistro} para ${item.trabajadorNombre}`}
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              <button
                                type="button"
                                onClick={() => handleVerPDFExistente(item)}
                                className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                                title="Ver y descargar acta oficial en PDF"
                                aria-label={`Ver y descargar acta oficial en PDF del descuento ${item.numeroRegistro} para ${item.trabajadorNombre}`}
                              >
                                <FileText className="w-4 h-4 text-emerald-600" />
                              </button>

                              {item.estado === 'Autorizado' && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    storageService.actualizarEstadoDescuento(item.id, 'Aplicado en Planilla');
                                    onDescuentoGuardado();
                                  }}
                                  className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                  title="Marcar como Aplicado en Planilla"
                                  aria-label="Marcar como Aplicado en Planilla"
                                >
                                  <CheckCircle2 className="w-4 h-4" />
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => setDescuentoAEliminar(item)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                                title="Eliminar registro"
                                aria-label="Eliminar registro"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Paginación idéntica al Padrón de Trabajadores */}
            <TablePagination
              totalRegistros={descuentosFiltrados.length}
              paginaActual={paginaActual}
              setPaginaActual={setPaginaActual}
              porPagina={porPagina}
              setPorPagina={setPorPagina}
              nombreEntidadPlural="autorizaciones de descuento"
            />
          </div>
        </div>
      )}

      {/* VISTA 2: FORMULARIO DE EMISIÓN DE NUEVO DESCUENTO */}
      {vistaActiva === 'nuevo' && (
        <form onSubmit={handleGuardarDescuento} className="space-y-6">
          {datosPreseleccionados?.numeroInspeccionOrigen && (
            <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 flex items-center justify-between shadow-2xs animate-in fade-in duration-150">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 border border-amber-200">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-bold text-amber-950">
                      Trazabilidad con Inspección Técnica:
                    </p>
                    <span className="font-mono text-xs font-bold bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded">
                      {datosPreseleccionados.numeroInspeccionOrigen}
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800 mt-0.5">
                    Trabajador, equipo extraviado y justificación técnica vinculados directamente desde la inspección de EPP.
                  </p>
                </div>
              </div>
              {onLimpiarDatosPreseleccionados && (
                <button
                  type="button"
                  onClick={onLimpiarDatosPreseleccionados}
                  className="text-xs text-amber-800 hover:text-amber-950 font-semibold underline px-2 py-1 rounded cursor-pointer"
                >
                  Desvincular
                </button>
              )}
            </div>
          )}

          {/* SECCIÓN 1: SELECCIÓN Y HERENCIA DE DATOS DEL TRABAJADOR */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center justify-center">
                  1
                </span>
                <h2 className="text-sm font-bold text-slate-900">
                  Datos del Trabajador (Herencia Automática de Perfil)
                </h2>
              </div>
              <span className="text-xs text-slate-400">Seleccione el trabajador involucrado en la pérdida</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <TrabajadorSearchAutocomplete
                  trabajadores={trabajadores}
                  valorSeleccionado={codigoTrabajador}
                  onSeleccionar={(t) => setCodigoTrabajador(t ? t.codigo : '')}
                  empresaFiltro={empresaFiltro}
                  label="Trabajador Involucrado"
                  required
                  colorTheme="amber"
                  placeholder="Escriba nombre, apellido o DNI..."
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Fecha del Incidente / Pérdida <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={fechaIncidente}
                  onChange={(e) => setFechaIncidente(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Ficha de datos heredados */}
            {trabajadorSeleccionado && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Razón Social Empleadora:</span>
                  <span className="font-semibold text-slate-800">{trabajadorSeleccionado.empresaNombre}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">DNI / Documento:</span>
                  <span className="font-semibold font-mono text-slate-800">{trabajadorSeleccionado.dni}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Área / Departamento:</span>
                  <span className="font-semibold text-slate-800">{trabajadorSeleccionado.area}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Puesto de Trabajo:</span>
                  <span className="font-semibold text-slate-800">{trabajadorSeleccionado.cargo}</span>
                </div>
              </div>
            )}
          </div>

          {/* SECCIÓN 2: EPP PERDIDO Y VALORIZACIÓN A DESCONTAR */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center justify-center">
                  2
                </span>
                <h2 className="text-sm font-bold text-slate-900">
                  Artículos de EPP Extraviados / A Descontar
                </h2>
              </div>

              {/* Botón rápido para importar EPPs entregados a este trabajador */}
              {trabajadorSeleccionado && (
                <button
                  type="button"
                  onClick={handleCargarEPPDeTrabajador}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-blue-200"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>Cargar EPPs asignados a este trabajador</span>
                </button>
              )}
            </div>

            {/* Selector de Catálogo de EPP */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Agregar del Catálogo:</span>
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    handleAgregarArticuloCatalogo(e.target.value);
                    e.target.value = '';
                  }
                }}
                defaultValue=""
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">+ Seleccionar artículo para agregar...</option>
                {(Array.isArray(catalogoEPP) ? catalogoEPP : []).map((epp, eppIdx) => (
                  <option key={epp.codigo ? `${epp.codigo}-${eppIdx}` : `epp-${eppIdx}`} value={epp.codigo}>
                    {epp.articulo} ({epp.codigo}) — Costo S/ {epp.costoUnitario.toFixed(2)} [Talla: {epp.talla}]
                  </option>
                ))}
              </select>
            </div>

            {/* Tabla de Artículos Seleccionados */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                    <th className="py-2.5 px-3">Código</th>
                    <th className="py-2.5 px-3">Descripción EPP</th>
                    <th className="py-2.5 px-3">Marca / Talla</th>
                    <th className="py-2.5 px-3 text-center">Cant. Perdida</th>
                    <th className="py-2.5 px-3 text-right">Costo Unit. (S/)</th>
                    <th className="py-2.5 px-3 text-right">Subtotal (S/)</th>
                    <th className="py-2.5 px-3 text-center">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(!itemsDescuento || itemsDescuento.length === 0) ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        No hay artículos agregados. Seleccione un artículo del catálogo o cargue los asignados al trabajador.
                      </td>
                    </tr>
                  ) : (
                    (Array.isArray(itemsDescuento) ? itemsDescuento : []).map((item, idx) => (
                      <tr key={item.idItem ? `${item.idItem}-${idx}` : `item-${idx}`} className="hover:bg-slate-50/50">
                        <td className="py-2.5 px-3 font-mono font-semibold text-slate-600">{item.codigoEPP}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-900">{item.articulo}</td>
                        <td className="py-2.5 px-3 text-slate-600">{item.marca} / {item.talla}</td>
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="number"
                            min="1"
                            max="20"
                            value={item.cantidadPerdida}
                            onChange={(e) => handleActualizarCantidadItem(item.idItem, parseInt(e.target.value) || 1)}
                            className="w-16 px-2 py-1 text-center bg-slate-50 border border-slate-200 rounded-md font-semibold text-xs"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                          S/ {item.costoUnitario.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-600">
                          S/ {item.importeTotal.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleEliminarItem(item.idItem)}
                            className="text-slate-400 hover:text-rose-600 p-1 transition-colors"
                            title="Quitar artículo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {itemsDescuento.length > 0 && (
                  <tfoot>
                    <tr className="bg-slate-50 font-bold border-t border-slate-200">
                      <td colSpan={5} className="py-3 px-3 text-right text-slate-700 uppercase tracking-wider text-[11px]">
                        Total Valorizado a Descontar:
                      </td>
                      <td className="py-3 px-3 text-right text-base text-rose-600 font-mono">
                        S/ {totalDescuentoCalculado.toFixed(2)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>

            {/* Motivo y Circunstancias */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Motivo Declarado de la Pérdida
                </label>
                <select
                  value={motivoDescuento}
                  onChange={(e) => setMotivoDescuento(e.target.value as MotivoDescuento)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Pérdida en planta">Pérdida en planta industrial</option>
                  <option value="Extravío fuera de planta">Extravío en trayecto / fuera de planta</option>
                  <option value="Deterioro por uso indebido">Deterioro injustificado / uso indebido</option>
                  <option value="Negligencia o descuido">Negligencia o descuido comprobado</option>
                  <option value="No devolución al cese">No devolución de equipo al cese</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Descripción Circunstanciada del Suceso
                </label>
                <input
                  type="text"
                  value={descripcionHechos}
                  onChange={(e) => setDescripcionHechos(e.target.value)}
                  placeholder="Detalle lugar, turno y cómo ocurrió la pérdida o deterioro..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* SECCIÓN 3: MODALIDAD DE DESCUENTO Y REPOSICIÓN INMEDIATA */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center justify-center">
                3
              </span>
              <h2 className="text-sm font-bold text-slate-900">
                Condiciones de Retención y Reposición de Equipo
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Modalidad de Pago Convenida
                </label>
                <select
                  value={modalidadPago}
                  onChange={(e) => handleCambiarModalidad(e.target.value as ModalidadPagoDescuento)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="1 cuota fin de mes">1 Cuota - Fin de mes</option>
                  <option value="2 cuotas quincenales">2 Cuotas - Quincenales</option>
                  <option value="1 cuota en quincena">1 Cuota - Quincena</option>
                  <option value="3 cuotas mensuales">3 Cuotas - Mensuales</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Número de Cuotas
                </label>
                <input
                  type="number"
                  min="1"
                  max="6"
                  value={cuotas}
                  onChange={(e) => setCuotas(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                />
              </div>

              <div className="p-3 rounded-xl bg-rose-50/70 border border-rose-200/80 flex flex-col justify-center">
                <span className="text-[11px] text-rose-700 font-semibold uppercase">Monto a Descontar por Cuota:</span>
                <span className="text-xl font-bold font-mono text-rose-800">
                  S/ {montoPorCuotaCalculado.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Checkbox de Reposición Inmediata */}
            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-start gap-3">
              <input
                type="checkbox"
                id="reponerEPP"
                checked={reponerInmediatamente}
                onChange={(e) => setReponerInmediatamente(e.target.checked)}
                className="mt-0.5 w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
              />
              <label htmlFor="reponerEPP" className="text-xs text-slate-700 cursor-pointer">
                <span className="font-bold text-emerald-900 block mb-0.5">
                  🔄 Reponer inmediatamente el EPP al trabajador (Recomendado)
                </span>
                Genera de manera automática el registro de entrega de reposición en el sistema y descuenta las unidades del inventario de almacén para que el trabajador continúe laborando protegido sin paralizar operaciones.
              </label>
            </div>

            {/* Cláusula Legal de Consentimiento */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-2">
              <div className="flex items-center gap-2 font-bold text-slate-800">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Consentimiento Expreso del Trabajador (Base Legal Art. 40 D.S. 003-97-TR)</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-500">
                El trabajador declara bajo juramento haber extraviado/deteriorado el EPP asignado y autoriza expresamente al empleador a retener de sus haberes y/o beneficios el valor de reposición según la modalidad acordada.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="autorizaCheck"
                  checked={autorizaDescuento}
                  onChange={(e) => setAutorizaDescuento(e.target.checked)}
                  required
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <label htmlFor="autorizaCheck" className="text-xs font-semibold text-slate-800 cursor-pointer">
                  Acepto y doy conformidad a la autorización de deducción salarial voluntaria.
                </label>
              </div>
            </div>
          </div>

          {/* SECCIÓN 4: FIRMAS DIGITALES */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center justify-center">
                  4
                </span>
                <h2 className="text-sm font-bold text-slate-900">
                  Firmas Digitales de Conformidad
                </h2>
              </div>

              {/* Selector de Responsable SST / Supervisor */}
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">
                  Responsable SST / Supervisor: <span className="text-rose-500">*</span>
                </label>
                <select
                  value={responsableSeleccionado}
                  onChange={(e) => handleCambiarResponsable(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  {RESPONSABLES_SST_OPCIONES.map((opc) => (
                    <option key={opc.valor} value={opc.valor}>
                      {opc.valor}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SignaturePad
                titulo="Firma del Trabajador Solicitante"
                subtitulo="Firma en pantalla táctil o con cursor de ratón"
                requerido={false}
                initialDataUrl={firmaTrabajador}
                onSave={setFirmaTrabajador}
                firmanteNombre={trabajadorSeleccionado?.nombreCompleto}
                firmanteCargo={trabajadorSeleccionado?.cargo}
                firmanteDni={trabajadorSeleccionado?.dni}
              />

              <SignaturePad
                titulo="Firma del Responsable SST / Supervisor"
                subtitulo={`Validación y conformidad técnica por: ${responsableNombre} (${responsableCargo})`}
                requerido={false}
                initialDataUrl={firmaResponsable}
                onSave={setFirmaResponsable}
                firmanteNombre={responsableNombre}
                firmanteCargo={responsableCargo}
              />
            </div>
          </div>

          {/* BOTONES DE ACCIÓN */}
          <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                setVistaActiva('lista');
                if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();
              }}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancelar
            </button>

            <button
              type="button"
              onClick={handlePrevisualizarPDF}
              disabled={generandoPDF || !trabajadorSeleccionado || itemsDescuento.length === 0}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              <Eye className="w-4 h-4" />
              <span>{generandoPDF ? 'Generando vista previa...' : 'Previsualizar PDF Oficial'}</span>
            </button>

            <button
              type="submit"
              disabled={guardando || !trabajadorSeleccionado || itemsDescuento.length === 0}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{guardando ? 'Guardando...' : 'Emitir y Autorizar Descuento'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Visor Modal de PDF Oficial */}
      {modalPDFOpen && (
        <PDFViewerModal
          isOpen={modalPDFOpen}
          onClose={() => setModalPDFOpen(false)}
          pdfBlobUrl={pdfData.url}
          pdfArrayBuffer={pdfData.buffer}
          fileName={pdfData.fileName}
          titulo="Autorización Oficial de Descuento FO-SST-DES-001"
          esBorrador={vistaActiva === 'nuevo'}
        />
      )}

      {/* Modal de Confirmación de Eliminación In-App */}
      {descuentoAEliminar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Eliminar Autorización de Descuento</h3>
                <p className="text-xs text-slate-500 font-mono">{descuentoAEliminar.numeroRegistro}</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              ¿Está seguro de que desea eliminar este registro de descuento perteneciente al trabajador <strong>{descuentoAEliminar.trabajadorNombre}</strong>? Esta acción no se puede deshacer.
            </p>
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDescuentoAEliminar(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  storageService.eliminarDescuento(descuentoAEliminar.id);
                  setDescuentoAEliminar(null);
                  onDescuentoGuardado();
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                Confirmar Eliminación
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Desglose Detallado de Autorización de Descuento */}
      {descuentoDetalle && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-100">
          <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <span>Desglose de Descuento: {descuentoDetalle.numeroRegistro}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono">
                      {descuentoDetalle.codigoPlantilla}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    {descuentoDetalle.trabajadorNombre} • DNI {descuentoDetalle.dni} • Fecha: {descuentoDetalle.fechaSolicitud || descuentoDetalle.fechaIncidente}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDescuentoDetalle(null)}
                className="w-8 h-8 rounded-lg hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
                title="Cerrar modal"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs">
              {/* Tarjetas resumen */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Monto Total</span>
                  <span className="font-extrabold text-rose-600 text-sm">
                    S/ {(Number(descuentoDetalle.montoTotalDescuento) || 0).toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Modalidad</span>
                  <span className="font-bold text-slate-800">
                    {descuentoDetalle.modalidadPago} ({descuentoDetalle.cuotas || 1} cuota{(descuentoDetalle.cuotas || 1) > 1 ? 's' : ''})
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Motivo</span>
                  <span className="font-bold text-slate-800">
                    {descuentoDetalle.motivoDescuento}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Estado</span>
                  <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                    descuentoDetalle.estado === 'Aplicado en Planilla'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {descuentoDetalle.estado}
                  </span>
                </div>
              </div>

              {/* Datos de Empresa y Puesto */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-slate-600">
                    <strong className="text-slate-800">Empresa:</strong> {descuentoDetalle.empresaNombre} (RUC: {descuentoDetalle.ruc})
                  </span>
                  <span className="text-slate-600">
                    <strong className="text-slate-800">Área / Cargo:</strong> {descuentoDetalle.area} · {descuentoDetalle.cargo}
                  </span>
                </div>
                {descuentoDetalle.idEntregaReposicion && (
                  <p className="text-emerald-700 font-semibold text-[11px] pt-1">
                    ✓ Reposición inmediata autorizada con Acta N°: {descuentoDetalle.idEntregaReposicion}
                  </p>
                )}
              </div>

              {/* Tabla de Artículos Afectados */}
              <div>
                <h4 className="font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
                  Ítems de EPP a Descontar ({descuentoDetalle.items?.length || 0})
                </h4>
                <div className="overflow-x-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase">
                        <th className="py-2 px-3 w-10 text-center">N°</th>
                        <th className="py-2 px-3">Código</th>
                        <th className="py-2 px-3">Artículo / EPP</th>
                        <th className="py-2 px-3 text-center">Cant.</th>
                        <th className="py-2 px-3 text-right">P. Unit.</th>
                        <th className="py-2 px-3 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(descuentoDetalle.items || []).map((it, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/70">
                          <td className="py-2 px-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                          <td className="py-2 px-3 font-mono font-medium text-slate-700">{it.codigoEPP}</td>
                          <td className="py-2 px-3 font-semibold text-slate-900">{it.articulo}</td>
                          <td className="py-2 px-3 text-center font-bold text-slate-800">
                            {(it as any).cantidadPerdida ?? (it as any).cantidad ?? 1} {(it as any).unidad ?? (it as any).unidadMedida ?? 'und'}
                          </td>
                          <td className="py-2 px-3 text-right font-mono text-slate-600">
                            S/ {(Number(it.costoUnitario) || 0).toFixed(2)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-rose-600">
                            S/ {(Number((it as any).importeTotal ?? (it as any).costoTotal) || 0).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Descripción de los Hechos */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Circunstancias y Hechos Constatados:
                </span>
                <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-700 leading-relaxed">
                  {descuentoDetalle.descripcionHechos || 'Sin observaciones adicionales registradas.'}
                </p>
              </div>

              {/* Responsable */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                <span>
                  <strong>Responsable SST:</strong> {descuentoDetalle.responsableNombre || 'Área de Seguridad'} ({descuentoDetalle.responsableCargo || 'Supervisor SST'})
                </span>
                <span>
                  <strong>Autorización Trabajador:</strong> {descuentoDetalle.autorizaDescuento ? 'Conforme / Firmado' : 'Pendiente'}
                </span>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 flex items-center justify-end gap-2 bg-slate-50">
              <button
                type="button"
                onClick={() => {
                  handleVerPDFExistente(descuentoDetalle);
                  setDescuentoDetalle(null);
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors shadow-2xs"
              >
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>Ver y descargar acta oficial en PDF</span>
              </button>
              <button
                type="button"
                onClick={() => setDescuentoDetalle(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
