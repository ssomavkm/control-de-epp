import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Trash2, 
  Eye, 
  CheckCircle2, 
  AlertCircle, 
  HardHat, 
  UserCheck, 
  Calendar
} from 'lucide-react';
import { 
  Trabajador, 
  EPPItem, 
  DetalleEntrega, 
  EntregaEPP, 
  MotivoEntrega, 
  Empresa
} from '../../types';
import { SignaturePad } from '../common/SignaturePad';
import { storageService } from '../../services/storageService';
import { PDFGeneratorService } from '../../services/pdfGenerator';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { TrabajadorSearchAutocomplete } from '../common/TrabajadorSearchAutocomplete';
import { useToast } from '../../context/ToastContext';
import { formatMoneda } from '../../utils/formatters';
import { EPPAutocomplete } from './components/EPPAutocomplete';
import { obtenerEmpresaCanonica } from '../../utils/empresaResolver';
import { googleDriveService } from '../../services/drive/googleDriveService';

interface NuevaEntregaFormProps {
  trabajadores: Trabajador[];
  catalogoEPP: EPPItem[];
  empresas: Empresa[];
  onEntregaConfirmada: (entrega: EntregaEPP) => void;
  onCancelar: () => void;
  trabajadorPreseleccionado?: string; // Código de trabajador si viene desde inspección o renovación
  eppPreseleccionado?: string; // Código de EPP si viene desde reposición
}

export const NuevaEntregaForm: React.FC<NuevaEntregaFormProps> = ({
  trabajadores,
  catalogoEPP,
  empresas,
  onEntregaConfirmada,
  onCancelar,
  trabajadorPreseleccionado,
  eppPreseleccionado
}) => {
  const toast = useToast();

  // Estado de cabecera
  const [numeroRegistro] = useState<string>(() => storageService.generarNuevoNumeroRegistro());
  const numRegistroSinPrefijo = useMemo(() => (numeroRegistro || '').replace(/^REG-?/i, ''), [numeroRegistro]);
  const [codigoTrabajador, setCodigoTrabajador] = useState<string>(trabajadorPreseleccionado || '');
  const [fechaEntrega, setFechaEntrega] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [responsableEntrega, setResponsableEntrega] = useState<string>('Ing. Jhon Rojas (Supervisor SSOMA)');
  const [tipoGeneral, setTipoGeneral] = useState<MotivoEntrega>('Entrega inicial');
  const [observacionesGenerales, setObservacionesGenerales] = useState<string>('Entrega de EPP reglamentario conforme al plan anual SST y norma ISO 45001.');
  
  // Firmas capturadas
  const [firmaTrabajador, setFirmaTrabajador] = useState<string>('');
  const [firmaResponsable, setFirmaResponsable] = useState<string>('');

  // Filas de detalle
  const [filas, setFilas] = useState<DetalleEntrega[]>(() => {
    const numClean = (storageService.generarNuevoNumeroRegistro() || '').replace(/^REG-?/i, '');
    if (eppPreseleccionado) {
      const art = catalogoEPP.find(e => e.codigo === eppPreseleccionado);
      if (art) {
        const fechaRenov = new Date();
        fechaRenov.setDate(fechaRenov.getDate() + (art.vidaUtilDias || 180));
        return [{
          idDetalle: `DET-${numClean}-1`,
          codigoEPP: art.codigo,
          articulo: art.articulo,
          categoria: art.categoria,
          tipo: art.tipo,
          talla: art.talla,
          unidad: art.unidad,
          cantidad: 1,
          costoUnitario: art.costoUnitario,
          importe: art.costoUnitario,
          motivo: 'Reposición',
          fechaRenovacion: fechaRenov.toISOString().slice(0, 10),
          observaciones: 'Reposición por hallazgo de inspección'
        }];
      }
    }
    return [];
  });

  // Estado del visor de PDF
  const [previewPdfUrl, setPreviewPdfUrl] = useState<string | null>(null);
  const [previewPdfArrayBuffer, setPreviewPdfArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [previewFileName, setPreviewFileName] = useState<string>('');
  const [esBorradorModal, setEsBorradorModal] = useState<boolean>(true);
  const [errorValidacion, setErrorValidacion] = useState<string | null>(null);
  const [guardando, setGuardando] = useState<boolean>(false);
  const [entregaGuardadaExitosa, setEntregaGuardadaExitosa] = useState<EntregaEPP | null>(null);

  // Formato oficial homologado activo heredado de storageService
  const plantillaActiva = useMemo(() => {
    return storageService.getPlantillaActivaParaEntrega();
  }, []);

  // Trabajador seleccionado y autocompletado (soporta match por código, DNI o ID)
  const trabajadorSeleccionado = useMemo(() => {
    if (!codigoTrabajador) return undefined;
    const target = codigoTrabajador.trim();
    return trabajadores.find(t => 
      t.codigo === target || 
      t.dni === target || 
      String(t.codigo).trim() === target ||
      String(t.dni).trim() === target
    );
  }, [trabajadores, codigoTrabajador]);

  // Empresa asociada al trabajador: resolución canónica infalible analizando ID, RUC y Razón Social
  const empresaAsociada = useMemo(() => {
    if (!trabajadorSeleccionado) return undefined;
    return obtenerEmpresaCanonica(trabajadorSeleccionado, empresas);
  }, [trabajadorSeleccionado, empresas]);

  // N° de trabajadores activos calculado de esa empresa en tiempo real
  const numTrabajadoresActivos = useMemo(() => {
    if (!trabajadorSeleccionado) return 0;
    return storageService.calcularNumTrabajadoresActivos(trabajadorSeleccionado.empresaId);
  }, [trabajadorSeleccionado]);

  // Datos del responsable SST seleccionado para firmas y acreditación
  const datosResponsable = useMemo(() => {
    const match = (responsableEntrega || '').match(/^(.*?)\s*\((.*?)\)$/);
    if (match) {
      return {
        nombre: match[1].trim(),
        cargo: match[2].trim()
      };
    }
    return {
      nombre: responsableEntrega || 'Responsable SST / Supervisor',
      cargo: 'Supervisor SSOMA'
    };
  }, [responsableEntrega]);

  // Cálculos de totales del detalle
  const totalArticulos = filas.length;
  const totalUnidades = useMemo(() => filas.reduce((s, f) => s + Number(f.cantidad || 0), 0), [filas]);
  const importeTotal = useMemo(() => filas.reduce((s, f) => s + Number(f.importe || 0), 0), [filas]);

  // Control acumulado de stock por código EPP
  const cantidadesAcumuladas = useMemo(() => {
    const map: { [codigo: string]: number } = {};
    filas.forEach(f => {
      if (f.codigoEPP) {
        map[f.codigoEPP] = (map[f.codigoEPP] || 0) + Number(f.cantidad || 0);
      }
    });
    return map;
  }, [filas]);

  // Agregar nueva fila de detalle
  const agregarFila = () => {
    // Tomar el primer artículo disponible por defecto
    const eppDefecto = catalogoEPP.find(e => e.stockActual > 0) || catalogoEPP[0];
    if (!eppDefecto) return;

    const fechaRenov = new Date(fechaEntrega || new Date());
    fechaRenov.setDate(fechaRenov.getDate() + (eppDefecto.vidaUtilDias || 180));
    const numClean = (numeroRegistro || '').replace(/^REG-?/i, '');

    const nuevaFila: DetalleEntrega = {
      idDetalle: `DET-${numClean}-${filas.length + 1}`,
      codigoEPP: eppDefecto.codigo,
      articulo: eppDefecto.articulo,
      categoria: eppDefecto.categoria,
      tipo: eppDefecto.tipo,
      talla: eppDefecto.talla,
      unidad: eppDefecto.unidad,
      cantidad: 1,
      costoUnitario: eppDefecto.costoUnitario,
      importe: eppDefecto.costoUnitario * 1,
      motivo: tipoGeneral,
      fechaRenovacion: fechaRenov.toISOString().slice(0, 10),
      observaciones: 'Conforme'
    };

    setFilas(prev => [...prev, nuevaFila]);
  };

  // Actualizar una fila de detalle
  const actualizarFila = (index: number, campo: keyof DetalleEntrega, valor: any) => {
    setFilas(prev => {
      const copia = [...prev];
      const actual = { ...copia[index] };

      if (campo === 'codigoEPP') {
        const eppEncontrado = catalogoEPP.find(e => e.codigo === valor);
        if (eppEncontrado) {
          actual.codigoEPP = eppEncontrado.codigo;
          actual.articulo = eppEncontrado.articulo;
          actual.categoria = eppEncontrado.categoria;
          actual.tipo = eppEncontrado.tipo;
          actual.talla = eppEncontrado.talla;
          actual.unidad = eppEncontrado.unidad;
          actual.costoUnitario = eppEncontrado.costoUnitario;
          actual.importe = Number((actual.cantidad * eppEncontrado.costoUnitario).toFixed(2));

          const fR = new Date(fechaEntrega || new Date());
          fR.setDate(fR.getDate() + (eppEncontrado.vidaUtilDias || 180));
          actual.fechaRenovacion = fR.toISOString().slice(0, 10);
        }
      } else if (campo === 'cantidad') {
        const cant = Math.max(1, parseInt(valor, 10) || 1);
        actual.cantidad = cant;
        actual.importe = Number((cant * actual.costoUnitario).toFixed(2));
      } else {
        (actual as any)[campo] = valor;
      }

      copia[index] = actual;
      return copia;
    });
  };

  // Autocompletar íntegramente una fila a partir del ítem seleccionado del catálogo de EPP
  const seleccionarEPPFila = (index: number, epp: EPPItem) => {
    setFilas(prev => {
      const copia = [...prev];
      const actual = { ...copia[index] };

      actual.codigoEPP = epp.codigo;
      actual.articulo = epp.articulo;
      actual.categoria = epp.categoria;
      actual.tipo = epp.tipo;
      actual.talla = epp.talla;
      actual.unidad = epp.unidad;
      actual.costoUnitario = epp.costoUnitario;
      actual.importe = Number((actual.cantidad * epp.costoUnitario).toFixed(2));

      const fR = new Date(fechaEntrega || new Date());
      fR.setDate(fR.getDate() + (epp.vidaUtilDias || 180));
      actual.fechaRenovacion = fR.toISOString().slice(0, 10);

      copia[index] = actual;
      return copia;
    });
  };

  // Eliminar fila y recalcular correlativo idDetalle
  const eliminarFila = (index: number) => {
    setFilas(prev => {
      const numClean = (numeroRegistro || '').replace(/^REG-?/i, '');
      const restantes = prev.filter((_, i) => i !== index);
      return restantes.map((f, idx) => ({
        ...f,
        idDetalle: `DET-${numClean}-${idx + 1}`
      }));
    });
  };

  // Validación estricta antes de previsualizar o guardar
  const validarFormulario = (): boolean => {
    setErrorValidacion(null);

    if (!codigoTrabajador || !trabajadorSeleccionado) {
      setErrorValidacion('Debe seleccionar un trabajador activo para registrar la entrega.');
      return false;
    }

    if (!empresaAsociada) {
      setErrorValidacion('El trabajador no tiene una razón social asignada válida (PERPOL IDEAS S.A.C. o TR3 ALIMENTOS S.A.C.).');
      return false;
    }

    if (filas.length === 0) {
      const err = 'Debe agregar al menos un artículo EPP a la lista de entrega.';
      setErrorValidacion(err);
      toast.warning(err, 'Datos Incompletos');
      return false;
    }

    // Validación acumulada de existencias de stock
    for (const [cod, cantidadSolicitada] of Object.entries(cantidadesAcumuladas)) {
      const art = catalogoEPP.find(e => e.codigo === cod);
      if (!art) {
        const err = `El artículo con código ${cod} no existe en catálogo.`;
        setErrorValidacion(err);
        toast.error(err);
        return false;
      }
      if (art.stockActual < cantidadSolicitada) {
        const err = `Stock insuficiente para "${art.articulo}". Solicitado: ${cantidadSolicitada} ${art.unidad}, Stock disponible: ${art.stockActual}`;
        setErrorValidacion(err);
        toast.warning(err, 'Stock Insuficiente');
        return false;
      }
    }

    return true;
  };

  // Construir objeto de entrega con todos los metadatos trazables
  const construirObjetoEntrega = (estado: 'Confirmada' | 'Pendiente de Firma' = 'Confirmada'): EntregaEPP => {
    const fechaHoraCalculo = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const dateCompact = fechaEntrega.replace(/-/g, '');
    const fileName = `ENTREGA_EPP_${numeroRegistro}_${empresaAsociada?.ruc}_${trabajadorSeleccionado?.dni}_${dateCompact}.pdf`;
    const numClean = (numeroRegistro || '').replace(/^REG-?/i, '');
    const anioActual = new Date().getFullYear();
    // Si numClean ya incluye el año (ej. 2024-0001), el id es ENT-2024-0001
    const idGenerado = numClean.startsWith(`${anioActual}-`)
      ? `ENT-${numClean}`
      : (numClean.match(/^\d{4}-/) ? `ENT-${numClean}` : `ENT-${anioActual}-${numClean}`);

    const detallesEstandarizados = filas.map((f, idx) => ({
      ...f,
      idDetalle: `DET-${numClean}-${idx + 1}`
    }));

    return {
      id: idGenerado,
      numeroRegistro,
      fechaEntrega,
      codigoTrabajador: trabajadorSeleccionado!.codigo,
      dni: trabajadorSeleccionado!.dni,
      trabajadorNombre: trabajadorSeleccionado!.nombreCompleto,
      empresaId: trabajadorSeleccionado!.empresaId,
      razonSocial: empresaAsociada!.razonSocial,
      ruc: empresaAsociada!.ruc,
      direccion: empresaAsociada!.direccion,
      actividadEconomica: empresaAsociada!.actividadEconomica,
      area: trabajadorSeleccionado!.area,
      cargo: trabajadorSeleccionado!.cargo,
      numTrabajadoresActivosCalculado: numTrabajadoresActivos,
      fechaHoraCalculoTrabajadores: fechaHoraCalculo,
      responsableEntrega,
      tipoEntregaGeneral: tipoGeneral,
      observacionesGenerales,
      totalUnidades,
      importeTotal: Number(importeTotal.toFixed(2)),
      detalles: detallesEstandarizados,
      firmaTrabajador: firmaTrabajador || undefined,
      firmaResponsable: firmaResponsable || undefined,
      estado: (!firmaTrabajador || !firmaResponsable) ? 'Pendiente de Firma' : estado,
      codigoPlantilla: plantillaActiva?.codigo || 'FO-SST-GEN-050',
      versionPlantilla: plantillaActiva?.version || '02',
      pdfFileName: fileName,
      fechaCreacion: fechaHoraCalculo,
      operationId: `OP-${numeroRegistro}-${Date.now()}`
    };
  };

  // Previsualizar Borrador (Sin guardar ni descontar stock)
  const handlePrevisualizarBorrador = async () => {
    if (!validarFormulario()) return;

    try {
      const entregaBorrador = construirObjetoEntrega('Pendiente de Firma');
      const resultadoPdf = await PDFGeneratorService.generarFormatoEntregaPDF(entregaBorrador, plantillaActiva);
      setPreviewPdfUrl(resultadoPdf.blobUrl);
      setPreviewPdfArrayBuffer(resultadoPdf.arrayBuffer);
      setPreviewFileName(resultadoPdf.fileName);
      setEsBorradorModal(true);
    } catch (err: any) {
      setErrorValidacion('Error al generar el PDF de previsualización: ' + err.message);
    }
  };

  // Confirmar y Guardar Entrega Oficial (Descuenta stock atómicamente)
  const handleConfirmarEntrega = async () => {
    if (!validarFormulario()) return;

    setGuardando(true);
    try {
      const entregaFinal = construirObjetoEntrega('Confirmada');
      const respuesta = await storageService.registrarEntrega(entregaFinal);

      if (respuesta.success) {
        // Generar PDF definitivo con plantilla activa homologada
        const pdfDefinitivo = await PDFGeneratorService.generarFormatoEntregaPDF(entregaFinal, plantillaActiva);
        setPreviewPdfUrl(pdfDefinitivo.blobUrl);
        setPreviewPdfArrayBuffer(pdfDefinitivo.arrayBuffer);
        setPreviewFileName(pdfDefinitivo.fileName);
        setEsBorradorModal(false);
        setEntregaGuardadaExitosa(entregaFinal);
        toast.success(`Entrega ${entregaFinal.numeroRegistro} confirmada y registrada en inventario.`, 'Acta Generada');

        // Respaldo en segundo plano en Google Drive
        if (pdfDefinitivo && pdfDefinitivo.blob) {
          googleDriveService.subirArchivo({
            nombreArchivo: pdfDefinitivo.fileName,
            mimeType: 'application/pdf',
            datosBlob: pdfDefinitivo.blob,
            subcarpeta: '01_Actas_Entrega',
            claveIdentificador: entregaFinal.numeroRegistro,
            descripcion: `Acta de Entrega ${entregaFinal.numeroRegistro} - ${entregaFinal.trabajadorNombre}`
          }).catch(e => console.info('Respaldo automático en Drive diferido:', e));
        }
      } else {
        setErrorValidacion('Error al registrar entrega: ' + respuesta.mensaje);
        toast.error(respuesta.mensaje, 'Error al Registrar');
      }
    } catch (err: any) {
      const msg = err.message || 'Error inesperado al guardar la entrega.';
      setErrorValidacion(msg);
      toast.error(msg);
    } finally {
      setGuardando(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Cinta Informativa: Formato Oficial Homologado Vinculado */}
      <div className="bg-slate-100/90 border border-slate-200/90 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 text-slate-700">
          <span className="font-bold text-slate-900 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
            Formato Oficial Vinculado:
          </span>
          <span className="font-mono font-bold text-emerald-950 bg-white px-2 py-0.5 rounded border border-slate-200 shadow-2xs">
            {plantillaActiva.codigo} v{plantillaActiva.version}
          </span>
          <span className="text-slate-500 hidden sm:inline">
            ({plantillaActiva.nombre})
          </span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-600">
          <span>Logos homologados:</span>
          <span className={`px-2 py-0.5 rounded font-semibold border ${plantillaActiva.logoPerpol ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-slate-50 text-slate-600 border-slate-200'}`}>
            PERPOL {plantillaActiva.logoPerpol ? '✓ Oficial' : 'Estándar'}
          </span>
          <span className={`px-2 py-0.5 rounded font-semibold border ${plantillaActiva.logoTr3 ? 'bg-blue-50 text-blue-800 border-blue-300' : 'bg-slate-50 text-slate-600 border-slate-200'}`}>
            TR3 {plantillaActiva.logoTr3 ? '✓ Oficial' : 'Estándar'}
          </span>
        </div>
      </div>

      {/* Banner de Entrega Exitosa */}
      {entregaGuardadaExitosa && (
        <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-emerald-900 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold">¡Entrega {entregaGuardadaExitosa.numeroRegistro} registrada y conformada con éxito!</p>
              <p className="text-[11px] text-emerald-700">Se actualizó el inventario y se emitió el documento oficial {plantillaActiva.codigo} v{plantillaActiva.version}.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={async () => {
                if (previewPdfUrl) {
                  setEsBorradorModal(false);
                } else {
                  const res = await PDFGeneratorService.generarFormatoEntregaPDF(entregaGuardadaExitosa, plantillaActiva);
                  setPreviewPdfUrl(res.blobUrl);
                  setPreviewPdfArrayBuffer(res.arrayBuffer);
                  setPreviewFileName(res.fileName);
                  setEsBorradorModal(false);
                }
              }}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Ver PDF Oficial</span>
            </button>
            <button
              type="button"
              onClick={() => onEntregaConfirmada(entregaGuardadaExitosa)}
              className="px-3 py-1.5 bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              Ir a Historial
            </button>
          </div>
        </div>
      )}

      {/* Cabecera del formulario */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
              {numeroRegistro}
            </span>
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Formato Oficial FO-SST-GEN-050 v02
            </span>
          </div>
          <h1 className="text-base sm:text-lg font-bold text-slate-900">
            Registro de Entrega y Dotación de EPP y Ropa de Trabajo
          </h1>
          <p className="text-xs text-slate-500">
            Dotación y entrega múltiple con validación de inventario y generación del acta oficial firmada
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCancelar}
            className="px-3.5 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-semibold transition-colors"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handlePrevisualizarBorrador}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Previsualizar Borrador</span>
          </button>
          <button
            type="button"
            onClick={handleConfirmarEntrega}
            disabled={guardando}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs disabled:opacity-50"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{guardando ? 'Guardando...' : 'Confirmar y Emitir PDF'}</span>
          </button>
        </div>
      </div>

      {/* Alerta de Error si hubiera */}
      {errorValidacion && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div className="font-medium">{errorValidacion}</div>
        </div>
      )}

      {/* Bloque 1: Datos del Trabajador y Detección Automática de Razón Social */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <UserCheck className="w-4 h-4 text-emerald-600" />
          <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            1. Selección de Trabajador y Razón Social Vinculada
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Selector de Trabajador con Autocompletado Estandarizado */}
          <div className="md:col-span-1">
            <TrabajadorSearchAutocomplete
              trabajadores={trabajadores}
              valorSeleccionado={codigoTrabajador}
              onSeleccionar={(t) => setCodigoTrabajador(t ? t.codigo : '')}
              label="Trabajador Destinatario"
              required
              colorTheme="emerald"
              placeholder="Buscar por nombre o DNI..."
            />
          </div>

          {/* Detección de Empresa */}
          <div className="md:col-span-2 bg-slate-50 p-3.5 rounded-lg border border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Razón Social Autocompletada del Empleador
              </span>
              {empresaAsociada ? (
                <div className="flex items-center gap-2 mt-0.5">
                  <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold border ${
                    empresaAsociada.id === 'EMP-PERPOL'
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-blue-100 text-blue-900 border-blue-300'
                  }`}>
                    {empresaAsociada.razonSocial}
                  </span>
                </div>
              ) : (
                <span className="text-sm font-bold text-slate-400 block mt-0.5">
                  Seleccione trabajador para autocompletar
                </span>
              )}
              {empresaAsociada && (
                <p className="text-[11px] text-slate-500 font-mono mt-1">
                  RUC: {empresaAsociada.ruc} · {empresaAsociada.actividadEconomica}
                </p>
              )}
            </div>

            {empresaAsociada && (
              <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg text-right shrink-0">
                <span className="text-[10px] uppercase font-bold text-emerald-800 block">
                  N° Trabajadores Activos Calculado
                </span>
                <span className="text-base font-bold text-emerald-700 font-mono">
                  {numTrabajadoresActivos} <span className="text-xs font-normal text-emerald-600">personas</span>
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Fila de Datos del Trabajador en la entrega */}
        {trabajadorSeleccionado && (
          <div className="pt-2 border-t border-slate-100 grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 text-xs bg-slate-50/80 p-3 rounded-lg border border-slate-200">
            <div>
              <span className="text-slate-600 block text-[10px] uppercase font-bold">DNI:</span>
              <span className="font-mono font-bold text-slate-900">{trabajadorSeleccionado.dni}</span>
            </div>
            <div>
              <span className="text-slate-600 block text-[10px] uppercase font-bold">Área:</span>
              <span className="font-semibold text-slate-900">{trabajadorSeleccionado.area}</span>
            </div>
            <div>
              <span className="text-slate-600 block text-[10px] uppercase font-bold">Cargo:</span>
              <span className="font-semibold text-slate-900">{trabajadorSeleccionado.cargo}</span>
            </div>
            <div>
              <span className="text-slate-600 block text-[10px] uppercase font-bold">Estado:</span>
              <span className="font-bold text-emerald-800">{trabajadorSeleccionado.estado}</span>
            </div>
          </div>
        )}
      </div>

      {/* Bloque 2: Parámetros Generales de la Entrega */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Calendar className="w-4 h-4 text-emerald-600" />
          <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            2. Datos y Condiciones de Entrega SST
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Fecha de Entrega <span className="text-rose-500">*</span>
            </label>
            <input
              type="date"
              value={fechaEntrega}
              onChange={(e) => setFechaEntrega(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Responsable de Entrega (SST) <span className="text-rose-500">*</span>
            </label>
            <select
              value={responsableEntrega}
              onChange={(e) => setResponsableEntrega(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 cursor-pointer"
            >
              <option value="Ing. Jhon Rojas (Supervisor SSOMA)">Ing. Jhon Rojas (Supervisor SSOMA)</option>
              <option value="Ronny Revollas (Auxiliar SSOMA)">Ronny Revollas (Auxiliar SSOMA)</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Motivo General de Entrega
            </label>
            <select
              value={tipoGeneral}
              onChange={(e) => setTipoGeneral(e.target.value as MotivoEntrega)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600"
            >
              <option value="Entrega inicial">Entrega inicial</option>
              <option value="Reposición">Reposición</option>
              <option value="Desgaste">Desgaste</option>
              <option value="Deterioro">Deterioro</option>
              <option value="Pérdida">Pérdida</option>
              <option value="Nuevo ingreso">Nuevo ingreso</option>
              <option value="Renovación">Renovación</option>
            </select>
          </div>

          <div className="sm:col-span-3">
            <label className="font-semibold text-slate-700 block mb-1">
              Observaciones Generales de la Entrega
            </label>
            <input
              type="text"
              value={observacionesGenerales}
              onChange={(e) => setObservacionesGenerales(e.target.value)}
              placeholder="Detalle condiciones de entrega, estado de inducción o capacitación impartida..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600"
            />
          </div>
        </div>
      </div>

      {/* Bloque 3: Detalle de Artículos EPP */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <HardHat className="w-4 h-4 text-emerald-600" />
            <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              3. Detalle de Equipos de Protección Personal (Varios EPP en una sola acta)
            </h2>
          </div>

          <button
            type="button"
            onClick={agregarFila}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Agregar EPP</span>
          </button>
        </div>

        {filas.length === 0 ? (
          <div className="py-10 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
            <HardHat className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-xs font-semibold text-slate-700">No ha agregado ningún equipo EPP a la entrega</p>
            <p className="text-[11px] text-slate-500 mb-3">Haga clic en el botón para agregar el primer artículo</p>
            <button
              type="button"
              onClick={agregarFila}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium inline-flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Agregar Primer EPP
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto min-h-[380px] pb-36">
            <table className="w-full text-left border-collapse text-xs min-w-[980px]">
              <thead>
                <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-3 w-10 text-center">#</th>
                  <th className="py-3 px-3 min-w-[320px]">Artículo EPP / Talla</th>
                  <th className="py-3 px-3 w-28 text-center">Stock Disp.</th>
                  <th className="py-3 px-3 w-24 text-center">Cantidad</th>
                  <th className="py-3 px-3 w-28 text-right">P. Unit (S/.)</th>
                  <th className="py-3 px-3 w-28 text-right">Total (S/.)</th>
                  <th className="py-3 px-3 min-w-[140px]">Motivo</th>
                  <th className="py-3 px-3 min-w-[130px]">F. Renovación</th>
                  <th className="py-3 px-3 w-12 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filas.map((fila, idx) => {
                  const eppCatalogo = catalogoEPP.find(e => e.codigo === fila.codigoEPP);
                  const stockDisponible = eppCatalogo ? eppCatalogo.stockActual : 0;
                  const totalPedidoParaEsteCodigo = cantidadesAcumuladas[fila.codigoEPP] || 0;
                  const sinStockSuficiente = totalPedidoParaEsteCodigo > stockDisponible;

                  return (
                    <tr key={fila.idDetalle ? `${fila.idDetalle}-${idx}` : `fila-${idx}`} className={`hover:bg-slate-50/80 transition-colors ${sinStockSuficiente ? 'bg-rose-50/50' : ''}`}>
                      <td className="py-3 px-3 font-mono text-slate-600 font-bold text-center">
                        {idx + 1}
                      </td>

                      {/* Autocompletado reactivo de Artículo EPP / Talla */}
                      <td className="py-3 px-3 min-w-[320px]">
                        <EPPAutocomplete
                          codigoSeleccionado={fila.codigoEPP}
                          articuloSeleccionado={fila.articulo}
                          tallaSeleccionada={fila.talla}
                          catalogoEPP={catalogoEPP}
                          onSeleccionarEPP={(epp) => seleccionarEPPFila(idx, epp)}
                          onCambiarTextoManual={(texto) => actualizarFila(idx, 'articulo', texto)}
                        />
                        <div className="flex items-center gap-1.5 mt-1.5 text-[10px] text-slate-500 font-mono flex-wrap">
                          <span className="font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200" title="Código de detalle del ítem">
                            {fila.idDetalle || `DET-${numRegistroSinPrefijo}-${idx + 1}`}
                          </span>
                          <span>·</span>
                          <span className="font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            Cód: {fila.codigoEPP}
                          </span>
                          <span>·</span>
                          <span className="text-slate-600 font-sans">{fila.categoria || 'EPP'}</span>
                          <span>·</span>
                          <span className="flex items-center gap-1 font-sans">
                            Talla:
                            <input
                              type="text"
                              value={fila.talla || ''}
                              onChange={(e) => actualizarFila(idx, 'talla', e.target.value)}
                              placeholder="Talla"
                              className="w-14 px-1 py-0.5 bg-slate-50 border border-slate-200 rounded text-[10px] font-mono text-slate-800 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                              title="Talla de EPP (editable)"
                            />
                          </span>
                          {eppCatalogo?.norma && (
                            <>
                              <span>·</span>
                              <span className="text-slate-400 truncate max-w-[130px]" title={eppCatalogo.norma}>
                                {eppCatalogo.norma}
                              </span>
                            </>
                          )}
                        </div>
                      </td>

                      {/* Stock Disponible */}
                      <td className="py-3 px-3 text-center">
                        {stockDisponible === 0 ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            Agotado (0)
                          </span>
                        ) : sinStockSuficiente ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-300">
                            Faltan {totalPedidoParaEsteCodigo - stockDisponible} uds
                          </span>
                        ) : stockDisponible <= (eppCatalogo?.stockMinimo || 5) ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-300">
                            Crítico ({stockDisponible})
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono">
                            {stockDisponible} disp.
                          </span>
                        )}
                      </td>

                      {/* Cantidad */}
                      <td className="py-3 px-3 text-center">
                        <input
                          type="number"
                          min={1}
                          max={stockDisponible}
                          value={fila.cantidad}
                          onChange={(e) => actualizarFila(idx, 'cantidad', e.target.value)}
                          className={`w-16 border rounded-lg p-1.5 text-center font-mono font-bold text-xs focus:outline-hidden focus:ring-1 ${
                            sinStockSuficiente 
                              ? 'bg-rose-50 border-rose-400 text-rose-700 focus:ring-rose-500' 
                              : 'bg-white border-slate-200 text-slate-900 focus:ring-emerald-600'
                          }`}
                          title={sinStockSuficiente ? `Stock insuficiente: Solo hay ${stockDisponible} unidades en almacén` : undefined}
                        />
                      </td>

                      {/* Costo Unitario */}
                      <td className="py-3 px-3 text-right font-mono text-slate-600 whitespace-nowrap">
                        {formatMoneda(fila.costoUnitario)}
                      </td>

                      {/* Importe Fila */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                        {formatMoneda(fila.importe)}
                      </td>

                      {/* Motivo de fila */}
                      <td className="py-3 px-3">
                        <select
                          value={fila.motivo}
                          onChange={(e) => actualizarFila(idx, 'motivo', e.target.value as MotivoEntrega)}
                          className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-[11px] text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 cursor-pointer"
                        >
                          <option value="Entrega inicial">Entrega inicial</option>
                          <option value="Reposición">Reposición</option>
                          <option value="Desgaste">Desgaste</option>
                          <option value="Deterioro">Deterioro</option>
                          <option value="Pérdida">Pérdida</option>
                          <option value="Nuevo ingreso">Nuevo ingreso</option>
                          <option value="Renovación">Renovación</option>
                        </select>
                      </td>

                      {/* Fecha Renovación Calculada */}
                      <td className="py-3 px-3">
                        <input
                          type="date"
                          value={fila.fechaRenovacion}
                          onChange={(e) => actualizarFila(idx, 'fechaRenovacion', e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg p-1.5 font-mono text-[11px] text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600"
                        />
                      </td>

                      {/* Eliminar Fila */}
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => eliminarFila(idx)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="Quitar artículo"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Resumen de Totales */}
        {filas.length > 0 && (
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-6">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-semibold">Artículos Distintos:</span>
                <span className="text-sm font-bold text-slate-900 font-mono-numbers">{totalArticulos} ítems</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-semibold">Total Unidades EPP:</span>
                <span className="text-sm font-bold text-emerald-700 font-mono-numbers">{totalUnidades} unidades</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Importe Total Acumulado:</span>
              <span className="text-lg font-bold text-slate-900 font-mono-numbers">
                S/. {importeTotal.toFixed(2)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Bloque 4: Firmas y Conformidad SST */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <UserCheck className="w-4 h-4 text-emerald-600" />
          <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            4. Firmas Digitales y Conformidad del Formato FO-SST-GEN-050
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SignaturePad
            titulo="Firma del Trabajador Destinatario"
            subtitulo="Aceptación de compromiso de uso obligatorio y capacitación recibida"
            firmanteNombre={trabajadorSeleccionado?.nombreCompleto}
            firmanteCargo={trabajadorSeleccionado?.cargo}
            firmanteDni={trabajadorSeleccionado?.dni}
            onSave={setFirmaTrabajador}
            initialDataUrl={firmaTrabajador}
            requerido
          />
          <SignaturePad
            titulo="Firma del Responsable SST / Supervisor"
            subtitulo={`Validación técnica de entrega y conformidad por: ${responsableEntrega}`}
            firmanteNombre={datosResponsable.nombre}
            firmanteCargo={datosResponsable.cargo}
            onSave={setFirmaResponsable}
            initialDataUrl={firmaResponsable}
            requerido
          />
        </div>
      </div>

      {/* Botones de acción inferiores con apilamiento flexible y accesibilidad táctil para móviles y zoom alto */}
      <div className="flex flex-col-reverse sm:flex-row sm:items-center justify-end gap-2.5 sm:gap-3 pt-2">
        <button
          type="button"
          onClick={onCancelar}
          className="w-full sm:w-auto min-h-[44px] px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer shadow-2xs transition-colors flex items-center justify-center"
        >
          Cancelar
        </button>
        <button
          type="button"
          onClick={handlePrevisualizarBorrador}
          className="w-full sm:w-auto min-h-[44px] px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs text-center"
        >
          <Eye className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>Previsualizar Borrador (Sin Descontar Stock)</span>
        </button>
        <button
          type="button"
          onClick={handleConfirmarEntrega}
          disabled={guardando}
          className="w-full sm:w-auto min-h-[44px] px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs cursor-pointer disabled:opacity-50 text-center"
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{guardando ? 'Procesando Guardado...' : 'Confirmar Entrega y Descontar Stock'}</span>
        </button>
      </div>

      {/* Modal Visor de PDF Integrado */}
      <PDFViewerModal
        isOpen={Boolean(previewPdfUrl)}
        onClose={() => {
          setPreviewPdfUrl(null);
          if (entregaGuardadaExitosa) {
            onEntregaConfirmada(entregaGuardadaExitosa);
          }
        }}
        pdfBlobUrl={previewPdfUrl}
        pdfArrayBuffer={previewPdfArrayBuffer}
        fileName={previewFileName}
        esBorrador={esBorradorModal}
        onConfirmarEntrega={handleConfirmarEntrega}
        guardandoEntrega={guardando}
      />
    </div>
  );
};
