import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Search, ChevronDown, X, Package, Check, AlertTriangle } from 'lucide-react';
import { EPPItem } from '../../../types';

interface EPPAutocompleteProps {
  codigoSeleccionado: string;
  articuloSeleccionado: string;
  tallaSeleccionada?: string;
  catalogoEPP: EPPItem[];
  onSeleccionarEPP: (epp: EPPItem) => void;
  onCambiarTextoManual?: (nuevoTexto: string) => void;
  disabled?: boolean;
}

export const EPPAutocomplete: React.FC<EPPAutocompleteProps> = ({
  codigoSeleccionado,
  articuloSeleccionado,
  tallaSeleccionada,
  catalogoEPP = [],
  onSeleccionarEPP,
  onCambiarTextoManual,
  disabled = false
}) => {
  const [abierto, setAbierto] = useState(false);
  const [textoBusqueda, setTextoBusqueda] = useState('');
  const [indiceResaltado, setIndiceResaltado] = useState(0);
  const [abrirHaciaArriba, setAbrirHaciaArriba] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listaRef = useRef<HTMLUListElement>(null);

  // Texto que representa el ítem actualmente seleccionado
  const textoItemActual = useMemo(() => {
    if (!articuloSeleccionado) return '';
    return tallaSeleccionada && tallaSeleccionada !== 'Estándar' && tallaSeleccionada !== '-'
      ? `${articuloSeleccionado} [${tallaSeleccionada}]`
      : articuloSeleccionado;
  }, [articuloSeleccionado, tallaSeleccionada]);

  // Sincronizar texto cuando cambia la selección externa
  useEffect(() => {
    if (!abierto) {
      setTextoBusqueda(textoItemActual);
    }
  }, [textoItemActual, abierto]);

  // Cerrar al hacer clic fuera
  useEffect(() => {
    const handleClickFuera = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setAbierto(false);
        setTextoBusqueda(textoItemActual);
      }
    };

    document.addEventListener('mousedown', handleClickFuera);
    return () => document.removeEventListener('mousedown', handleClickFuera);
  }, [textoItemActual]);

  // Detectar si debe abrirse hacia arriba por falta de espacio en pantalla
  useEffect(() => {
    if (abierto && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const espacioAbajo = window.innerHeight - rect.bottom;
      if (espacioAbajo < 260 && rect.top > 260) {
        setAbrirHaciaArriba(true);
      } else {
        setAbrirHaciaArriba(false);
      }
    }
  }, [abierto]);

  // Normalizador de búsqueda insensible a acentos y mayúsculas
  const normalizar = (str: string): string => {
    return (str || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim();
  };

  // Filtrado reactivo en tiempo real con ponderación inteligente
  const itemsFiltrados = useMemo(() => {
    if (!catalogoEPP || catalogoEPP.length === 0) return [];

    const queryNorm = normalizar(textoBusqueda);
    const itemActualNorm = normalizar(textoItemActual);

    // Si el texto es igual al ítem seleccionado o está vacío, mostrar catálogo completo (priorizando con stock)
    if (!queryNorm || queryNorm === itemActualNorm) {
      return [...catalogoEPP].sort((a, b) => {
        // Primero los que tienen stock
        if (a.stockActual > 0 && b.stockActual <= 0) return -1;
        if (a.stockActual <= 0 && b.stockActual > 0) return 1;
        return a.articulo.localeCompare(b.articulo);
      });
    }

    const terminos = queryNorm.split(/\s+/).filter(Boolean);

    return catalogoEPP
      .filter((epp) => {
        const bolsaTexto = normalizar(
          `${epp.articulo} ${epp.codigo} ${epp.talla} ${epp.categoria} ${epp.marca} ${epp.modelo} ${epp.tipo}`
        );
        // Cada término debe coincidir
        return terminos.every((termino) => bolsaTexto.includes(termino));
      })
      .sort((a, b) => {
        const aArticuloNorm = normalizar(a.articulo);
        const bArticuloNorm = normalizar(b.articulo);
        const aEmpieza = aArticuloNorm.startsWith(queryNorm);
        const bEmpieza = bArticuloNorm.startsWith(queryNorm);

        if (aEmpieza && !bEmpieza) return -1;
        if (!aEmpieza && bEmpieza) return 1;

        if (a.stockActual > 0 && b.stockActual <= 0) return -1;
        if (a.stockActual <= 0 && b.stockActual > 0) return 1;

        return a.articulo.localeCompare(b.articulo);
      });
  }, [catalogoEPP, textoBusqueda, textoItemActual]);

  // Auto-scroll para navegación por teclado
  useEffect(() => {
    if (abierto && listaRef.current && indiceResaltado >= 0) {
      const elemento = listaRef.current.children[indiceResaltado] as HTMLElement;
      if (elemento && typeof elemento.scrollIntoView === 'function') {
        elemento.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [indiceResaltado, abierto]);

  // Manejar selección de ítem
  const handleSeleccionar = (epp: EPPItem) => {
    onSeleccionarEPP(epp);
    const nuevoTexto = epp.talla && epp.talla !== 'Estándar' && epp.talla !== '-'
      ? `${epp.articulo} [${epp.talla}]`
      : epp.articulo;
    setTextoBusqueda(nuevoTexto);
    setAbierto(false);
  };

  // Manejador de teclado
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!abierto) {
      if (e.key === 'ArrowDown' || e.key === 'Enter') {
        e.preventDefault();
        setAbierto(true);
        setIndiceResaltado(0);
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setIndiceResaltado((prev) => (prev < itemsFiltrados.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setIndiceResaltado((prev) => (prev > 0 ? prev - 1 : itemsFiltrados.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (itemsFiltrados.length > 0 && indiceResaltado >= 0 && indiceResaltado < itemsFiltrados.length) {
        handleSeleccionar(itemsFiltrados[indiceResaltado]);
      } else if (onCambiarTextoManual && textoBusqueda.trim()) {
        onCambiarTextoManual(textoBusqueda.trim());
        setAbierto(false);
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setAbierto(false);
      setTextoBusqueda(textoItemActual);
    } else if (e.key === 'Tab') {
      if (itemsFiltrados.length > 0 && indiceResaltado >= 0 && indiceResaltado < itemsFiltrados.length) {
        handleSeleccionar(itemsFiltrados[indiceResaltado]);
      }
      setAbierto(false);
    }
  };

  // Limpiar texto para buscar de cero
  const handleLimpiar = (e: React.MouseEvent) => {
    e.stopPropagation();
    setTextoBusqueda('');
    setIndiceResaltado(0);
    setAbierto(true);
    inputRef.current?.focus();
  };

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Contenedor del Input de Búsqueda y Autocompletado */}
      <div className="relative flex items-center">
        <div className="absolute left-2.5 pointer-events-none text-slate-400">
          <Search className="w-3.5 h-3.5" />
        </div>

        <input
          ref={inputRef}
          type="text"
          aria-expanded={abierto}
          aria-autocomplete="list"
          aria-label="Buscar artículo de EPP o indumentaria en catálogo"
          disabled={disabled}
          value={textoBusqueda}
          placeholder="Escriba artículo, talla, casco, casaca..."
          onFocus={() => {
            setAbierto(true);
            setIndiceResaltado(0);
          }}
          onChange={(e) => {
            setTextoBusqueda(e.target.value);
            setAbierto(true);
            setIndiceResaltado(0);
            if (onCambiarTextoManual) {
              onCambiarTextoManual(e.target.value);
            }
          }}
          onKeyDown={handleKeyDown}
          className={`w-full pl-8 pr-14 py-2 bg-white border rounded-lg text-xs font-semibold text-slate-900 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
            abierto
              ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
              : 'border-slate-200 hover:border-slate-300'
          } ${disabled ? 'bg-slate-100 cursor-not-allowed text-slate-400' : 'cursor-text'}`}
        />

        {/* Acciones a la derecha: Botón Limpiar (X) y Desplegable */}
        <div className="absolute right-1.5 flex items-center gap-0.5">
          {textoBusqueda && !disabled && (
            <button
              type="button"
              onClick={handleLimpiar}
              aria-label="Borrar texto de búsqueda de equipo"
              className="p-1 rounded text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              title="Borrar texto para buscar otro equipo"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            type="button"
            disabled={disabled}
            aria-expanded={abierto}
            aria-label={abierto ? "Cerrar listado del catálogo" : "Desplegar opciones del catálogo"}
            onClick={() => {
              if (!abierto) {
                setAbierto(true);
                inputRef.current?.focus();
              } else {
                setAbierto(false);
              }
            }}
            className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            title="Ver catálogo de EPP"
          >
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-150 ${abierto ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </div>

      {/* Menú Desplegable con Sugerencias Autocompletadas */}
      {abierto && (
        <div
          className={`absolute left-0 right-0 z-50 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden animate-in fade-in duration-100 ${
            abrirHaciaArriba ? 'bottom-full mb-1.5' : 'top-full mt-1.5'
          }`}
          style={{ minWidth: '320px', maxWidth: '440px' }}
        >
          {/* Cabecera del desplegable con contador */}
          <div className="px-3 py-1.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span className="font-semibold text-slate-700 flex items-center gap-1.5">
              <Package className="w-3 h-3 text-emerald-600" />
              Catálogo de EPP / Indumentaria
            </span>
            <span className="font-mono text-[10px]">
              {itemsFiltrados.length} {itemsFiltrados.length === 1 ? 'resultado' : 'resultados'}
            </span>
          </div>

          {/* Lista de sugerencias */}
          <ul
            ref={listaRef}
            role="listbox"
            aria-label="Artículos encontrados en catálogo"
            className="max-h-60 overflow-y-auto divide-y divide-slate-100 text-xs focus:outline-hidden"
          >
            {itemsFiltrados.length === 0 ? (
              <li className="p-4 text-center text-slate-400 space-y-1">
                <AlertTriangle className="w-5 h-5 mx-auto text-amber-500" />
                <p className="font-semibold text-slate-700 text-xs">No se encontró "{textoBusqueda}"</p>
                <p className="text-[11px] text-slate-500">Pruebe buscando por palabra clave (ej: casco, lentes, casaca, bota, talla).</p>
              </li>
            ) : (
              itemsFiltrados.map((item, idx) => {
                const esSeleccionado = item.codigo === codigoSeleccionado;
                const esResaltado = idx === indiceResaltado;
                const sinStock = item.stockActual <= 0;
                const stockCritico = !sinStock && item.stockActual <= (item.stockMinimo || 5);

                return (
                  <li
                    key={item.codigo ? `${item.codigo}-${idx}` : `sug-${idx}`}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      handleSeleccionar(item);
                    }}
                    onMouseEnter={() => setIndiceResaltado(idx)}
                    className={`px-3 py-2.5 cursor-pointer transition-colors flex items-start justify-between gap-2.5 ${
                      esResaltado
                        ? 'bg-emerald-50/90 text-emerald-950'
                        : esSeleccionado
                        ? 'bg-slate-50 text-slate-900 font-semibold'
                        : 'hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      {/* Título de Artículo y Talla */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-slate-900 text-xs leading-tight">
                          {item.articulo}
                        </span>
                        {item.talla && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 text-slate-700 border border-slate-200 shrink-0">
                            Talla: {item.talla}
                          </span>
                        )}
                        {esSeleccionado && (
                          <span className="text-emerald-600 inline-flex items-center" title="Seleccionado actualmente">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>

                      {/* Metadatos: Código, Categoría y Marca */}
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500 font-medium">
                        <span className="font-mono text-emerald-800 font-bold bg-emerald-100/70 px-1 py-0.2 rounded">
                          {item.codigo}
                        </span>
                        <span>·</span>
                        <span className="truncate">{item.categoria || item.tipo}</span>
                        {item.marca && (
                          <>
                            <span>·</span>
                            <span className="truncate">{item.marca}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Stock y Precio */}
                    <div className="text-right shrink-0 flex flex-col items-end gap-1">
                      {sinStock ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                          Agotado (0)
                        </span>
                      ) : stockCritico ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                          {item.stockActual} disp.
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200 font-mono">
                          {item.stockActual} disp.
                        </span>
                      )}

                      <span className="font-mono text-[11px] font-bold text-slate-700">
                        S/. {Number(item.costoUnitario || 0).toFixed(2)}
                      </span>
                    </div>
                  </li>
                );
              })
            )}
          </ul>

          {/* Pie informativo del desplegable */}
          <div className="px-3 py-1.5 bg-slate-50/80 border-t border-slate-100 text-[10px] text-slate-400 flex items-center justify-between">
            <span>Use ↑ ↓ para navegar · Enter para elegir</span>
            <span>ESC para cerrar</span>
          </div>
        </div>
      )}
    </div>
  );
};
