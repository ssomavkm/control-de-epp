import React from 'react';
import {
  Layers,
  CheckCircle2,
  Clock,
  FileText,
  ChevronDown,
  ChevronUp,
  ReceiptText
} from 'lucide-react';
import { EntregaEPP } from '../../../types';
import { formatFecha } from '../../../utils/formatters';
import { TablePagination } from '../../common/TablePagination';

interface EntregasTableProps {
  entregasFiltradas: EntregaEPP[];
  entregasPaginadas: EntregaEPP[];
  filaExpandida: string | null;
  toggleExpandir: (id: string) => void;
  abrirPdfEntrega: (entrega: EntregaEPP) => void;
  cargandoPdf: boolean;
  paginaActual: number;
  setPaginaActual: React.Dispatch<React.SetStateAction<number>>;
  filasPorPagina: number;
  setFilasPorPagina: (n: number) => void;
  paginasTotales: number;
  onGenerarDescuento?: (codigoTrabajador: string, codigoEPP?: string) => void;
}

export const EntregasTable: React.FC<EntregasTableProps> = ({
  entregasFiltradas,
  entregasPaginadas,
  filaExpandida,
  toggleExpandir,
  abrirPdfEntrega,
  cargandoPdf,
  paginaActual,
  setPaginaActual,
  filasPorPagina,
  setFilasPorPagina,
  paginasTotales,
  onGenerarDescuento
}) => {
  // Mapa de acumulados por trabajador para trabajadores con múltiples actas de entrega
  const acumuladosPorTrabajador = React.useMemo(() => {
    const map = new Map<string, { totalEntregas: number; totalImporte: number; totalUnidades: number }>();
    entregasFiltradas.forEach(e => {
      const key = String(e.dni || e.codigoTrabajador || '').trim();
      if (!key) return;
      const actual = map.get(key) || { totalEntregas: 0, totalImporte: 0, totalUnidades: 0 };
      actual.totalEntregas += 1;
      actual.totalImporte += (Number(e.importeTotal) || 0);
      actual.totalUnidades += (Number(e.totalUnidades) || 0);
      map.set(key, actual);
    });
    return map;
  }, [entregasFiltradas]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs min-w-[900px]">
          <thead>
            <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
              <th className="py-3.5 px-4 w-44">Acta / Registro</th>
              <th className="py-3.5 px-3 w-28">Fecha</th>
              <th className="py-3.5 px-4 min-w-[200px]">Trabajador Destinatario</th>
              <th className="py-3.5 px-3 w-36">Empresa</th>
              <th className="py-3.5 px-3 min-w-[150px]">Área y Cargo</th>
              <th className="py-3.5 px-3 text-center w-28">Artículos</th>
              <th className="py-3.5 px-3 text-right w-28">Importe</th>
              <th className="py-3.5 px-3 text-center w-28">Estado</th>
              <th className="py-3.5 px-4 text-center w-28">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {entregasFiltradas.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-14 text-center">
                  <div className="max-w-xs mx-auto text-slate-500 space-y-2">
                    <Layers className="w-8 h-8 mx-auto text-slate-400 stroke-1" />
                    <p className="font-semibold text-slate-700 text-xs">No se encontraron entregas</p>
                    <p className="text-[11px] text-slate-500">Intenta con otros criterios de búsqueda o registra una nueva entrega.</p>
                  </div>
                </td>
              </tr>
            ) : (
              entregasPaginadas.map((e, eIdx) => {
                const expandida = filaExpandida === e.id;
                const isPerpol = e.empresaId === 'EMP-PERPOL';
                const trabKey = String(e.dni || e.codigoTrabajador || '').trim();
                const resumenTrab = acumuladosPorTrabajador.get(trabKey);
                const tieneMultiples = resumenTrab && resumenTrab.totalEntregas > 1;

                return (
                  <React.Fragment key={e.id ? `${e.id}-${eIdx}` : `entrega-${eIdx}`}>
                    <tr 
                      tabIndex={0}
                      role="button"
                      aria-expanded={expandida}
                      aria-controls={`detalles-entrega-${e.id}`}
                      onKeyDown={(ev) => {
                        if (ev.key === 'Enter' || ev.key === ' ') {
                          ev.preventDefault();
                          toggleExpandir(e.id);
                        }
                      }}
                      className={`transition-colors hover:bg-slate-50/80 cursor-pointer focus-visible:outline-none focus-visible:bg-slate-100 ${expandida ? 'bg-slate-50/60' : ''}`}
                      onClick={() => toggleExpandir(e.id)}
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-slate-900 hover:text-emerald-700 transition-colors">
                            {e.numeroRegistro}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-600 font-medium font-mono block mt-0.5">
                          {e.codigoPlantilla} v{e.versionPlantilla}
                        </span>
                      </td>

                      <td className="py-3.5 px-3 font-mono font-medium text-slate-800 whitespace-nowrap">
                        {formatFecha(e.fechaEntrega)}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 tracking-tight">
                          {e.trabajadorNombre}
                        </div>
                        <div className="text-[11px] text-slate-600 font-medium font-mono mt-0.5">
                          DNI: {e.dni} <span className="text-slate-400">|</span> Cód: {e.codigoTrabajador}
                        </div>
                        {tieneMultiples && (
                          <div className="mt-1">
                            <span 
                              className="inline-flex items-center gap-1 text-[10px] font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"
                              title={`Este trabajador registra ${resumenTrab.totalEntregas} entregas en total por un importe acumulado de S/. ${resumenTrab.totalImporte.toFixed(2)}`}
                            >
                              <span>{resumenTrab.totalEntregas} actas</span>
                              <span className="text-emerald-400">·</span>
                              <span className="font-semibold">Acum: S/. {resumenTrab.totalImporte.toFixed(2)}</span>
                            </span>
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold border ${
                          isPerpol 
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300' 
                            : 'bg-blue-100 text-blue-900 border-blue-300'
                        }`}>
                          {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
                        </span>
                      </td>

                      <td className="py-3.5 px-3">
                        <div className="font-semibold text-slate-900 tracking-tight">{e.area}</div>
                        <div className="text-[11px] text-slate-600 font-medium mt-0.5">{e.cargo}</div>
                      </td>

                      <td className="py-3.5 px-3 text-center">
                        <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 rounded text-slate-800 font-mono font-medium text-[11px]">
                          <span>{(e.detalles || []).length} epp</span>
                          <span className="text-slate-400">·</span>
                          <span className="font-bold text-slate-900">{e.totalUnidades} uds</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                        <div>S/. {Number(e.importeTotal).toFixed(2)}</div>
                        {(e.detalles || []).length > 1 && (
                          <div className="text-[10px] text-slate-500 font-normal font-sans">
                            {(e.detalles || []).length} ítems sumados
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                          e.estado === 'Confirmada'
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : 'bg-amber-100 text-amber-900 border-amber-300'
                        }`}>
                          {e.estado === 'Confirmada' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                          {e.estado}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center whitespace-nowrap" onClick={(ev) => ev.stopPropagation()}>
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => abrirPdfEntrega(e)}
                            disabled={cargandoPdf}
                            className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                            title="Visualizar acta oficial en PDF"
                            aria-label={`Visualizar acta oficial en PDF de entrega ${e.numeroRegistro} para ${e.trabajadorNombre}`}
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-400" />
                            <span>PDF</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => toggleExpandir(e.id)}
                            aria-expanded={expandida}
                            aria-controls={`detalles-entrega-${e.id}`}
                            aria-label={expandida ? `Ocultar desglose de ítems del acta ${e.numeroRegistro}` : `Ver desglose de ítems del acta ${e.numeroRegistro}`}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500"
                            title={expandida ? 'Ocultar detalles' : 'Ver detalle de ítems'}
                          >
                            {expandida ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        </div>
                      </td>
                    </tr>

                    {/* Desglose Completo de Artículos */}
                    {expandida && (
                      <tr id={`detalles-entrega-${e.id}`} className="bg-slate-50/70 border-y border-slate-200">
                        <td colSpan={9} className="p-4 sm:p-5">
                          <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 space-y-4 shadow-xs">
                            <div className="flex flex-wrap items-center justify-between text-xs pb-3 border-b border-slate-100 gap-2">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-900 text-sm">
                                    Desglose de EPP ({(e.detalles || []).length} artículo{(e.detalles || []).length === 1 ? '' : 's'}, {e.totalUnidades} unidades)
                                  </span>
                                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                                    Acta FO-SST-GEN-050
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-500">
                                  <span className="font-medium text-slate-700">Responsable SST:</span> {e.responsableEntrega} 
                                  <span className="mx-2 text-slate-300">|</span> 
                                  <span className="font-medium text-slate-700">Motivo:</span> {e.tipoEntregaGeneral}
                                </p>
                              </div>
                              <div className="text-[11px] font-mono text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200/80">
                                Archivo: <span className="text-slate-800 font-semibold">{e.pdfFileName}</span>
                              </div>
                            </div>

                            <div className="overflow-x-auto rounded-lg border border-slate-100">
                              <table className="w-full text-left text-xs border-collapse">
                                <thead>
                                  <tr className="bg-slate-50 text-slate-700 font-bold text-[11px] border-b border-slate-200 uppercase tracking-wider">
                                    <th className="py-2.5 px-3">Ítem Detalle / Cód.</th>
                                    <th className="py-2.5 px-3">Artículo EPP</th>
                                    <th className="py-2.5 px-3">Talla</th>
                                    <th className="py-2.5 px-3 text-center">Cantidad</th>
                                    <th className="py-2.5 px-3 text-right">Precio Unit.</th>
                                    <th className="py-2.5 px-3 text-right">Subtotal</th>
                                    <th className="py-2.5 px-3">F. Renovación</th>
                                    <th className="py-2.5 px-3">Observaciones</th>
                                    {onGenerarDescuento && <th className="py-2.5 px-3 text-center">Acción</th>}
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {(e.detalles || []).map((det, idx) => (
                                    <tr key={det.idDetalle ? `${det.idDetalle}-${idx}` : `det-${idx}`} className="hover:bg-slate-50/60">
                                      <td className="py-2.5 px-3 font-mono text-[11px]">
                                        <span className="font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200 block w-fit mb-0.5">
                                          {det.idDetalle}
                                        </span>
                                        <span className="text-slate-500 text-[10px]">EPP: {det.codigoEPP}</span>
                                      </td>
                                      <td className="py-2.5 px-3 font-bold text-slate-900">{det.articulo}</td>
                                      <td className="py-2.5 px-3 text-slate-700 font-medium">{det.talla || 'Estándar'}</td>
                                      <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-900">{det.cantidad} {det.unidad}</td>
                                      <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-800">S/. {Number(det.costoUnitario).toFixed(2)}</td>
                                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">S/. {Number(det.importe).toFixed(2)}</td>
                                      <td className="py-2.5 px-3 font-mono font-medium text-[11px] text-slate-800">{det.fechaRenovacion}</td>
                                      <td className="py-2.5 px-3 text-slate-600 text-[11px]">{det.observaciones || '-'}</td>
                                      {onGenerarDescuento && (
                                        <td className="py-2.5 px-3 text-center">
                                          <button
                                            type="button"
                                            onClick={() => onGenerarDescuento(e.codigoTrabajador, det.codigoEPP)}
                                            className="px-2.5 py-1 rounded bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 text-[11px] font-bold flex items-center gap-1 mx-auto transition-colors cursor-pointer shadow-2xs"
                                            title="Generar autorización de descuento por pérdida de este EPP"
                                          >
                                            <ReceiptText className="w-3.5 h-3.5 text-amber-700" />
                                            <span>Pérdida</span>
                                          </button>
                                        </td>
                                      )}
                                    </tr>
                                  ))}
                                </tbody>
                                <tfoot>
                                  <tr className="bg-slate-50/90 font-bold border-t-2 border-slate-200 text-slate-800">
                                    <td colSpan={3} className="py-2.5 px-3 uppercase tracking-wider text-[10px] text-slate-600">
                                      Total del Acta ({(e.detalles || []).length} ítem{(e.detalles || []).length === 1 ? '' : 's'})
                                    </td>
                                    <td className="py-2.5 px-3 text-center font-mono text-slate-900 font-bold">
                                      {e.totalUnidades} uds
                                    </td>
                                    <td className="py-2.5 px-3"></td>
                                    <td className="py-2.5 px-3 text-right font-mono text-emerald-800 font-bold text-xs whitespace-nowrap">
                                      S/. {Number(e.importeTotal).toFixed(2)}
                                    </td>
                                    <td colSpan={onGenerarDescuento ? 3 : 2} className="py-2.5 px-3 text-[10px] text-slate-500 font-normal">
                                      Suma de importes confirmada
                                    </td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>

                            {e.observacionesGenerales && (
                              <div className="text-[11px] text-slate-600 pt-2 border-t border-slate-100 flex items-start gap-1.5">
                                <span className="font-semibold text-slate-800">Observaciones Generales:</span>
                                <span>{e.observacionesGenerales}</span>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Barra de Paginación */}
      <TablePagination
        totalRegistros={entregasFiltradas.length}
        paginaActual={paginaActual}
        setPaginaActual={setPaginaActual}
        porPagina={filasPorPagina}
        setPorPagina={setFilasPorPagina}
        nombreEntidadPlural="entregas"
      />
    </div>
  );
};
