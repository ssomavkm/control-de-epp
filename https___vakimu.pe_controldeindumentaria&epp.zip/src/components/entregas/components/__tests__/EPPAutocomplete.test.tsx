import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { EPPAutocomplete } from '../EPPAutocomplete';
import { EPPItem } from '../../../../types';

const mockCatalogo: EPPItem[] = [
  {
    codigo: 'EPP-CAS-01',
    articulo: 'Casco de Seguridad Industrial Tipo I',
    categoria: 'Protección Craneal',
    tipo: 'EPP',
    marca: '3M',
    modelo: 'H-700',
    norma: 'ANSI Z89.1',
    talla: 'Ajustable',
    unidad: 'Unidad',
    vidaUtilDias: 365,
    costoUnitario: 48.5,
    stockActual: 20,
    stockMinimo: 5,
    estado: 'Disponible'
  },
  {
    codigo: 'EPP-LEN-01',
    articulo: 'Lentes de Seguridad Claros',
    categoria: 'Protección Ocular y Facial',
    tipo: 'EPP',
    marca: 'Steelpro',
    modelo: 'Nitro',
    norma: 'ANSI Z87.1',
    talla: 'Estándar',
    unidad: 'Unidad',
    vidaUtilDias: 90,
    costoUnitario: 14.2,
    stockActual: 50,
    stockMinimo: 10,
    estado: 'Disponible'
  },
  {
    codigo: 'UNI-CAS-01',
    articulo: 'Casaca térmica color azul',
    categoria: 'Ropa de Trabajo y Uniforme',
    tipo: 'Uniforme',
    marca: 'Nacional',
    modelo: 'Térmico',
    norma: 'NTP',
    talla: 'L',
    unidad: 'Unidad',
    vidaUtilDias: 360,
    costoUnitario: 97.35,
    stockActual: 15,
    stockMinimo: 3,
    estado: 'Disponible'
  }
];

describe('EPPAutocomplete Component', () => {
  it('debería renderizar con el texto del artículo seleccionado', () => {
    render(
      <EPPAutocomplete
        codigoSeleccionado="EPP-CAS-01"
        articuloSeleccionado="Casco de Seguridad Industrial Tipo I"
        tallaSeleccionada="Ajustable"
        catalogoEPP={mockCatalogo}
        onSeleccionarEPP={vi.fn()}
      />
    );

    const input = screen.getByRole('textbox') as HTMLInputElement;
    expect(input.value).toContain('Casco de Seguridad Industrial Tipo I');
  });

  it('debería permitir escribir texto y filtrar el catálogo autocompletando al seleccionar', () => {
    const handleSeleccionar = vi.fn();

    render(
      <EPPAutocomplete
        codigoSeleccionado=""
        articuloSeleccionado=""
        catalogoEPP={mockCatalogo}
        onSeleccionarEPP={handleSeleccionar}
      />
    );

    const input = screen.getByRole('textbox');
    
    // Escribir "casaca"
    fireEvent.change(input, { target: { value: 'casaca' } });

    // La sugerencia debe aparecer en el dropdown
    expect(screen.getByText(/Casaca térmica color azul/i)).toBeInTheDocument();

    // Hacer clic en la sugerencia
    fireEvent.mouseDown(screen.getByText(/Casaca térmica color azul/i));

    // Debe llamar a onSeleccionarEPP con el objeto completo
    expect(handleSeleccionar).toHaveBeenCalledWith(
      expect.objectContaining({
        codigo: 'UNI-CAS-01',
        articulo: 'Casaca térmica color azul',
        costoUnitario: 97.35
      })
    );
  });

  it('debería permitir limpiar el texto y mostrar todo el catálogo', () => {
    render(
      <EPPAutocomplete
        codigoSeleccionado="EPP-LEN-01"
        articuloSeleccionado="Lentes de Seguridad Claros"
        catalogoEPP={mockCatalogo}
        onSeleccionarEPP={vi.fn()}
      />
    );

    const botonLimpiar = screen.getByTitle(/Borrar texto para buscar otro equipo/i);
    fireEvent.click(botonLimpiar);

    const input = screen.getByRole('textbox') as HTMLInputElement;
    expect(input.value).toBe('');
  });
});
