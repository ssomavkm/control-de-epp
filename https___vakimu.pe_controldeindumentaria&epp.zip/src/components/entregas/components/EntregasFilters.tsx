import React from 'react';
import { Search, X, Filter } from 'lucide-react';

export type FiltroPeriodo = 'TODOS' | 'HOY' | '7DIAS' | '30DIAS';

interface EntregasFiltersProps {
  busqueda: string;
  setBusqueda: (q: string) => void;
  estadoFiltro: string;
  setEstadoFiltro: (e: string) => void;
  filtroPeriodo: FiltroPeriodo;
  setFiltroPeriodo: (p: FiltroPeriodo) => void;
  filasPorPagina: number;
  setFilasPorPagina: (n: number) => void;
  totalFiltradas: number;
  onExportarCSV?: () => void;
  onNuevaEntrega?: () => void;
}

export const EntregasFilters: React.FC<EntregasFiltersProps> = ({
  busqueda,
  setBusqueda,
  estadoFiltro,
  setEstadoFiltro,
  filtroPeriodo,
  setFiltroPeriodo,
  filasPorPagina,
  setFilasPorPagina,
  totalFiltradas
}) => {
  return (
    <div className="space-y-3">
      {/* Barra de Filtros y Búsqueda */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <label htmlFor="busqueda-entregas-input" className="sr-only">
              Buscar actas por código, trabajador, DNI o área
            </label>
            <input
              id="busqueda-entregas-input"
              type="text"
              placeholder="Buscar por acta, trabajador, DNI o área..."
              aria-label="Buscar actas por código, trabajador, DNI o área"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:bg-white transition-all"
            />
            {busqueda && (
              <button 
                type="button"
                onClick={() => setBusqueda('')}
                aria-label="Limpiar término de búsqueda"
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <label htmlFor="select-estado-entrega" className="sr-only">
            Filtrar por estado de entrega
          </label>
          <select
            id="select-estado-entrega"
            value={estadoFiltro}
            onChange={(e) => setEstadoFiltro(e.target.value)}
            aria-label="Filtrar por estado de entrega"
            className="text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100/80 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-emerald-600 cursor-pointer"
          >
            <option value="TODOS">Todos los Estados</option>
            <option value="Confirmada">Confirmadas</option>
            <option value="Borrador">Pendientes</option>
          </select>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-slate-500 font-mono-numbers mr-1">
            {totalFiltradas} registro{totalFiltradas === 1 ? '' : 's'}
          </span>
        </div>
      </div>

      {/* Píldoras de Filtro Rápido y Selector de Filas */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 bg-white p-3 rounded-xl border border-slate-200 shadow-2xs text-xs">
        <div 
          role="group" 
          aria-label="Filtrar por período de emisión"
          className="flex flex-wrap items-center gap-1.5"
        >
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3 text-slate-400" /> Período:
          </span>
          <button
            type="button"
            onClick={() => setFiltroPeriodo('TODOS')}
            aria-pressed={filtroPeriodo === 'TODOS'}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-700 ${
              filtroPeriodo === 'TODOS'
                ? 'bg-slate-900 text-white font-semibold shadow-2xs'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            Todo el Histórico
          </button>
          <button
            type="button"
            onClick={() => setFiltroPeriodo('HOY')}
            aria-pressed={filtroPeriodo === 'HOY'}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
              filtroPeriodo === 'HOY'
                ? 'bg-emerald-600 text-white font-semibold shadow-2xs'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            Emitidas Hoy
          </button>
          <button
            type="button"
            onClick={() => setFiltroPeriodo('7DIAS')}
            aria-pressed={filtroPeriodo === '7DIAS'}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
              filtroPeriodo === '7DIAS'
                ? 'bg-emerald-600 text-white font-semibold shadow-2xs'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            Últimos 7 días
          </button>
          <button
            type="button"
            onClick={() => setFiltroPeriodo('30DIAS')}
            aria-pressed={filtroPeriodo === '30DIAS'}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${
              filtroPeriodo === '30DIAS'
                ? 'bg-emerald-600 text-white font-semibold shadow-2xs'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            Últimos 30 días
          </button>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="select-filas-por-pagina" className="text-[11px] text-slate-500 font-medium">Mostrar:</label>
          <select
            id="select-filas-por-pagina"
            value={filasPorPagina}
            onChange={(e) => setFilasPorPagina(Number(e.target.value))}
            aria-label="Filas por página"
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-700 font-medium focus:outline-hidden focus-visible:ring-2 focus-visible:ring-emerald-600 cursor-pointer"
          >
            <option value={10}>10 por página</option>
            <option value={25}>25 por página</option>
            <option value={50}>50 por página</option>
          </select>
        </div>
      </div>
    </div>
  );
};
