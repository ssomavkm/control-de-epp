import React from 'react';
import { FileCheck2, HardHat, DollarSign, BadgePercent } from 'lucide-react';

export interface MetricasEntregas {
  totalEntregas: number;
  totalUnidades: number;
  importeTotal: number;
  tasaConformidad: number;
}

interface EntregasStatsProps {
  metricas: MetricasEntregas;
}

export const EntregasStats: React.FC<EntregasStatsProps> = ({ metricas }) => {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
          <FileCheck2 className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Actas Emitidas</p>
          <p className="text-xl font-bold text-slate-900 font-mono-numbers">{metricas.totalEntregas}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
          <HardHat className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">EPP Suministrados</p>
          <p className="text-xl font-bold text-slate-900 font-mono-numbers">
            {metricas.totalUnidades} <span className="text-xs font-normal text-slate-400 font-sans">uds</span>
          </p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
          <DollarSign className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Inversión Total</p>
          <p className="text-xl font-bold text-slate-900 font-mono-numbers">S/. {metricas.importeTotal.toFixed(2)}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
          <BadgePercent className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Conformidad Legal</p>
          <p className="text-xl font-bold text-emerald-700 font-mono-numbers">
            {metricas.tasaConformidad}% <span className="text-xs font-normal text-slate-400 font-sans">FO-SST</span>
          </p>
        </div>
      </div>
    </div>
  );
};
