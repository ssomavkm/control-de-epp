import React, { useState, useMemo, useEffect } from 'react';
import { X, ClipboardList, Plus } from 'lucide-react';
import { EntregaEPP } from '../../types';
import { storageService } from '../../services/storageService';
import { PDFGeneratorService } from '../../services/pdfGenerator';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { ModuleHeader } from '../common/ModuleHeader';
import { useToast } from '../../context/ToastContext';
import { EntregasStats, MetricasEntregas } from './components/EntregasStats';
import { EntregasFilters, FiltroPeriodo } from './components/EntregasFilters';
import { EntregasTable } from './components/EntregasTable';
import { compararFechasDesc } from '../../utils/formatters';

interface HistorialEntregasProps {
  entregas: EntregaEPP[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  onNuevaEntrega: () => void;
  onGenerarDescuento?: (codigoTrabajador: string, codigoEPP?: string) => void;
}

export const HistorialEntregas: React.FC<HistorialEntregasProps> = ({
  entregas,
  empresaFiltro,
  onNuevaEntrega,
  onGenerarDescuento
}) => {
  const toast = useToast();
  const [busqueda, setBusqueda] = useState<string>('');
  const [estadoFiltro, setEstadoFiltro] = useState<string>('TODOS');
  const [filtroPeriodo, setFiltroPeriodo] = useState<FiltroPeriodo>('TODOS');
  const [filaExpandida, setFilaExpandida] = useState<string | null>(null);

  // Paginación
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [filasPorPagina, setFilasPorPagina] = useState<number>(10);

  // Visor PDF
  const [viewerUrl, setViewerUrl] = useState<string | null>(null);
  const [viewerArrayBuffer, setViewerArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [viewerFileName, setViewerFileName] = useState<string>('');
  const [cargandoPdf, setCargandoPdf] = useState<boolean>(false);
  const [errorPdf, setErrorPdf] = useState<string | null>(null);

  // Reset de página al cambiar filtros
  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, estadoFiltro, filtroPeriodo, empresaFiltro, filasPorPagina]);

  // Filtrado de entregas
  const entregasFiltradas = useMemo(() => {
    const hoy = new Date();
    const hoyStr = hoy.toISOString().slice(0, 10);

    return entregas.filter(e => {
      if (empresaFiltro !== 'TODAS' && e.empresaId !== empresaFiltro) return false;
      if (estadoFiltro !== 'TODOS' && e.estado !== estadoFiltro) return false;

      if (filtroPeriodo === 'HOY' && e.fechaEntrega !== hoyStr) return false;
      if (filtroPeriodo === '7DIAS') {
        const limite7 = new Date(hoy.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
        if (e.fechaEntrega < limite7) return false;
      }
      if (filtroPeriodo === '30DIAS') {
        const limite30 = new Date(hoy.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
        if (e.fechaEntrega < limite30) return false;
      }

      if (busqueda.trim()) {
        const q = busqueda.toLowerCase().trim();
        const coincide =
          String(e.numeroRegistro || '').toLowerCase().includes(q) ||
          String(e.trabajadorNombre || '').toLowerCase().includes(q) ||
          String(e.dni || '').includes(q) ||
          String(e.codigoTrabajador || '').toLowerCase().includes(q) ||
          String(e.area || '').toLowerCase().includes(q) ||
          String(e.cargo || '').toLowerCase().includes(q) ||
          String(e.razonSocial || '').toLowerCase().includes(q) ||
          String(e.responsableEntrega || '').toLowerCase().includes(q);
        if (!coincide) return false;
      }
      return true;
    }).sort((a, b) => compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro));
  }, [entregas, empresaFiltro, estadoFiltro, filtroPeriodo, busqueda]);

  // Entregas paginadas
  const paginasTotales = Math.max(1, Math.ceil(entregasFiltradas.length / (filasPorPagina || 10)));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), paginasTotales);
  const entregasPaginadas = useMemo(() => {
    const inicio = (paginaAjustada - 1) * (filasPorPagina || 10);
    return entregasFiltradas.slice(inicio, inicio + (filasPorPagina || 10));
  }, [entregasFiltradas, paginaAjustada, filasPorPagina]);

  // Métricas
  const metricas = useMemo<MetricasEntregas>(() => {
    const totalEntregas = entregasFiltradas.length;
    let totalUnidades = 0;
    let importeTotal = 0;
    let confirmadas = 0;

    entregasFiltradas.forEach(e => {
      const sumDetsImporte = (e.detalles && e.detalles.length > 0)
        ? e.detalles.reduce((acc, d) => acc + (Number(d.importe) || ((Number(d.cantidad) || 1) * (Number(d.costoUnitario) || 0))), 0)
        : (Number(e.importeTotal) || 0);

      const sumDetsUnidades = (e.detalles && e.detalles.length > 0)
        ? e.detalles.reduce((acc, d) => acc + (Number(d.cantidad) || 0), 0)
        : (Number(e.totalUnidades) || 0);

      totalUnidades += sumDetsUnidades;
      importeTotal += sumDetsImporte;
      if (e.estado === 'Confirmada') confirmadas++;
    });

    return {
      totalEntregas,
      totalUnidades,
      importeTotal,
      tasaConformidad: totalEntregas > 0 ? Math.round((confirmadas / totalEntregas) * 100) : 100
    };
  }, [entregasFiltradas]);

  const toggleExpandir = (id: string) => {
    setFilaExpandida(prev => prev === id ? null : id);
  };

  const abrirPdfEntrega = async (entrega: EntregaEPP) => {
    setCargandoPdf(true);
    setErrorPdf(null);
    toast.show(`Cargando documento ${entrega.numeroRegistro}...`, 'info');
    try {
      const plantillaAsociada = storageService.getPlantillaPorCodigo(entrega.codigoPlantilla || 'FO-SST-GEN-050') || storageService.getPlantillaActivaParaEntrega();
      const pdf = await PDFGeneratorService.generarFormatoEntregaPDF(entrega, plantillaAsociada);
      setViewerUrl(pdf.blobUrl);
      setViewerArrayBuffer(pdf.arrayBuffer);
      setViewerFileName(pdf.fileName);
    } catch (e: any) {
      const msg = 'Error al generar PDF: ' + (e.message || 'Error desconocido');
      setErrorPdf(msg);
      toast.show(msg, 'error');
    } finally {
      setCargandoPdf(false);
    }
  };

  const exportarCSV = () => {
    const encabezados = ['Registro,Fecha,DNI,Trabajador,Empresa,RUC,Área,Cargo,Responsable SST,Total Uds,Total Importe,Estado'];
    const filas = entregasFiltradas.map(e => 
      `"${e.numeroRegistro}","${e.fechaEntrega}","${e.dni}","${e.trabajadorNombre}","${e.razonSocial}","${e.ruc}","${e.area}","${e.cargo}","${e.responsableEntrega}","${e.totalUnidades}","${e.importeTotal}","${e.estado}"`
    );
    const contenido = encabezados.concat(filas).join('\n');
    const blob = new Blob([contenido], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HISTORIAL_ENTREGAS_EPP_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.show(`Se exportaron ${entregasFiltradas.length} registros a archivo CSV.`, 'success');
  };

  return (
    <div className="space-y-6">
      {/* Encabezado del Módulo Oficial FO-SST-GEN-050 Estandarizado */}
      <ModuleHeader
        icon={ClipboardList}
        title="Entrega y Dotación de EPP"
        badge="FO-SST-GEN-050 v02"
        subtitle="Control integral de dotaciones, historial de actas emitidas y cumplimiento normativo (Ley N° 29783 y D.S. 005-2012-TR)."
        colorTheme="emerald"
        actions={
          <button
            type="button"
            onClick={onNuevaEntrega}
            className="h-9 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-2 shadow-xs transition-colors cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Nueva Entrega</span>
          </button>
        }
      />

      {/* Alerta de error en generación de PDF */}
      {errorPdf && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="font-bold">Error:</span>
            <span>{errorPdf}</span>
          </div>
          <button
            onClick={() => setErrorPdf(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Tarjetas KPI de Resumen */}
      <EntregasStats metricas={metricas} />

      {/* Filtros */}
      <EntregasFilters
        busqueda={busqueda}
        setBusqueda={setBusqueda}
        estadoFiltro={estadoFiltro}
        setEstadoFiltro={setEstadoFiltro}
        filtroPeriodo={filtroPeriodo}
        setFiltroPeriodo={setFiltroPeriodo}
        filasPorPagina={filasPorPagina}
        setFilasPorPagina={setFilasPorPagina}
        totalFiltradas={entregasFiltradas.length}
        onExportarCSV={exportarCSV}
        onNuevaEntrega={onNuevaEntrega}
      />

      {/* Tabla de Entregas */}
      <EntregasTable
        entregasFiltradas={entregasFiltradas}
        entregasPaginadas={entregasPaginadas}
        filaExpandida={filaExpandida}
        toggleExpandir={toggleExpandir}
        abrirPdfEntrega={abrirPdfEntrega}
        cargandoPdf={cargandoPdf}
        paginaActual={paginaActual}
        setPaginaActual={setPaginaActual}
        filasPorPagina={filasPorPagina}
        setFilasPorPagina={setFilasPorPagina}
        paginasTotales={paginasTotales}
        onGenerarDescuento={onGenerarDescuento}
      />

      {/* Visor Modal de PDF */}
      <PDFViewerModal
        isOpen={Boolean(viewerUrl)}
        onClose={() => setViewerUrl(null)}
        pdfBlobUrl={viewerUrl}
        pdfArrayBuffer={viewerArrayBuffer}
        fileName={viewerFileName}
        titulo="Documento Oficial FO-SST-GEN-050 v02"
        esBorrador={false}
      />
    </div>
  );
};
