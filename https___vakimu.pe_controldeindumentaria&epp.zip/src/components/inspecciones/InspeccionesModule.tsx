import React, { useState, useMemo, useEffect } from 'react';
import { 
  ShieldAlert, 
  Search, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  UserCheck, 
  HardHat, 
  X, 
  ReceiptText, 
  AlertTriangle,
  Filter,
  Trash2,
  RefreshCw
} from 'lucide-react';
import { 
  Trabajador, 
  InspeccionEPP, 
  DetalleInspeccion, 
  ResultadoInspeccion, 
  AccionInspeccion, 
  EstadoAccionInspeccion,
  DatosPreseleccionadosInfraccion,
  DatosPreseleccionadosDescuento,
  RESPONSABLES_SST_OPCIONES
} from '../../types';
import { storageService } from '../../services/storageService';
import { PDFGeneratorService } from '../../services/pdfGenerator';
import { googleDriveService } from '../../services/drive/googleDriveService';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { TablePagination } from '../common/TablePagination';
import { TrabajadorSearchAutocomplete } from '../common/TrabajadorSearchAutocomplete';
import { ZonaPlantaAutocomplete } from '../common/ZonaPlantaAutocomplete';
import { InspeccionDeleteModal } from './components/InspeccionDeleteModal';
import { ModuleHeader } from '../common/ModuleHeader';
import { useToast } from '../../context/ToastContext';
import { compararFechasDesc, parseFechaMs } from '../../utils/formatters';

interface InspeccionesModuleProps {
  trabajadores: Trabajador[];
  inspecciones: InspeccionEPP[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro?: (empresaId: string) => void;
  onIniciarReposicionDesdeInspeccion: (codigoTrabajador: string, codigoEPP: string) => void;
  onGenerarDescuentoPorPerdida?: (codigoTrabajador: string, codigoEPP?: string, datos?: DatosPreseleccionadosDescuento) => void;
  onColocarInfraccionDesdeInspeccion?: (datos: DatosPreseleccionadosInfraccion) => void;
  onInspeccionGuardada: () => void;
  onEliminarInspeccion?: (idOrNumero: string) => Promise<{ success: boolean; mensaje: string }> | void;
}

export const InspeccionesModule: React.FC<InspeccionesModuleProps> = ({
  trabajadores,
  inspecciones,
  empresaFiltro,
  onCambiarEmpresaFiltro,
  onIniciarReposicionDesdeInspeccion,
  onGenerarDescuentoPorPerdida,
  onColocarInfraccionDesdeInspeccion,
  onInspeccionGuardada,
  onEliminarInspeccion
}) => {
  let toastContext: ReturnType<typeof useToast> | null = null;
  try {
    toastContext = useToast();
  } catch {
    toastContext = null;
  }

  // Estado para modal de confirmación de eliminación de inspección
  const [inspeccionAEliminar, setInspeccionAEliminar] = useState<InspeccionEPP | null>(null);
  const [eliminandoInspeccion, setEliminandoInspeccion] = useState<boolean>(false);

  const handleConfirmarEliminarInspeccion = async () => {
    if (!inspeccionAEliminar) return;
    const target = inspeccionAEliminar;
    setEliminandoInspeccion(true);
    try {
      if (onEliminarInspeccion) {
        await onEliminarInspeccion(target.id || target.numeroInspeccion);
      } else {
        await storageService.eliminarInspeccion(target.id || target.numeroInspeccion);
        onInspeccionGuardada();
      }
      toastContext?.success?.(`Inspección ${target.numeroInspeccion} eliminada con éxito.`, 'Registro Actualizado');
      setInspeccionAEliminar(null);
    } catch (err: any) {
      toastContext?.error?.('Error al borrar la inspección: ' + (err.message || 'Error desconocido'), 'Error');
    } finally {
      setEliminandoInspeccion(false);
    }
  };

  const [modoCreacion, setModoCreacion] = useState<boolean>(false);
  const [busqueda, setBusqueda] = useState<string>('');

  // Código correlativo pre-estructurado para la inspección
  const [numeroInspeccion, setNumeroInspeccion] = useState<string>(() => storageService.generarNuevoNumeroInspeccion());

  // Estados del formulario de nueva inspección
  const [codigoTrabajador, setCodigoTrabajador] = useState<string>('');
  const [inspectorResponsable, setInspectorResponsable] = useState<string>('Ing. Jhon Rojas (Supervisor SSOMA)');
  const [lugarInspeccion, setLugarInspeccion] = useState<string>('Planta de Producción / Puesto Operativo');
  const [observacionesGenerales, setObservacionesGenerales] = useState<string>('Inspección periódica in-situ conforme a la norma ISO 45001 y procedimiento PR-SST-012.');
  const [detallesInspeccion, setDetallesInspeccion] = useState<DetalleInspeccion[]>([]);
  const [errorForm, setErrorForm] = useState<string | null>(null);
  const [guardando, setGuardando] = useState<boolean>(false);

  // Estados para lista compacta de EPP entregados y selección
  interface EPPParaInspeccion {
    uniqueKey: string;
    codigoEPP: string;
    articulo: string;
    talla: string;
    idEntregaOrigen: string;
    idDetalleEntregaOrigen: string;
    fechaEntregaReferencia: string;
    cantidadReferencia: number;
    fechaRenovacionReferencia: string;
    diasRestantes: number;
    esVigente: boolean;
    estadoVigencia: 'Vigente' | 'Próximo a vencer' | 'Vencido';
  }

  const [eppsEntregados, setEppsEntregados] = useState<EPPParaInspeccion[]>([]);
  const [eppSeleccionados, setEppSeleccionados] = useState<Set<string>>(new Set());
  const [soloVigentes, setSoloVigentes] = useState<boolean>(true);
  const [eppExpandido, setEppExpandido] = useState<string | null>(null);
  const [evaluaciones, setEvaluaciones] = useState<Record<string, {
    resultado: ResultadoInspeccion;
    accion: AccionInspeccion;
    estadoAccion: EstadoAccionInspeccion;
    hallazgo: string;
  }>>({});

  // Modal para proceder a colocar infracción tras detectar equipos no presentados
  const [inspeccionParaInfraccion, setInspeccionParaInfraccion] = useState<{
    insp: InspeccionEPP;
    itemsNoPresentados: DetalleInspeccion[];
  } | null>(null);

  // Modal para proceder a autorizar descuento de nómina tras detectar equipos extraviados
  const [inspeccionParaDescuento, setInspeccionParaDescuento] = useState<{
    insp: InspeccionEPP;
    itemsExtraviados: DetalleInspeccion[];
  } | null>(null);

  // Visor PDF para actas de inspección
  const [viewerPdfUrl, setViewerPdfUrl] = useState<string | null>(null);
  const [viewerPdfArrayBuffer, setViewerPdfArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [viewerPdfName, setViewerPdfName] = useState<string>('');
  const [errorPdf, setErrorPdf] = useState<string | null>(null);
  const [itemsExtraviadosPendientes, setItemsExtraviadosPendientes] = useState<{
    insp: InspeccionEPP;
    items: DetalleInspeccion[];
  } | null>(null);

  const handleCerrarCreacion = () => {
    setModoCreacion(false);
    setCodigoTrabajador('');
    setEppsEntregados([]);
    setEppSeleccionados(new Set());
    setEvaluaciones({});
    setEppExpandido(null);
    setDetallesInspeccion([]);
    setErrorForm(null);
  };

  const handleAbrirCreacion = () => {
    const nuevoCodigo = storageService.generarNuevoNumeroInspeccion();
    setNumeroInspeccion(nuevoCodigo);
    setCodigoTrabajador('');
    setEppsEntregados([]);
    setEppSeleccionados(new Set());
    setEvaluaciones({});
    setEppExpandido(null);
    setSoloVigentes(true);
    setDetallesInspeccion([]);
    setErrorForm(null);
    setModoCreacion(true);
  };

  // Trabajador seleccionado en el formulario (por código o DNI)
  const trabajadorSeleccionado = useMemo(() => {
    if (!codigoTrabajador) return undefined;
    const target = codigoTrabajador.trim();
    return trabajadores.find(t => 
      t.codigo === target || 
      t.dni === target || 
      String(t.codigo).trim() === target || 
      String(t.dni).trim() === target
    );
  }, [trabajadores, codigoTrabajador]);

  // Función para calcular vigencia según fecha de renovación / vida útil con parseo multiformato tolerante
  const calcularVigencia = (fechaRenovacion?: string) => {
    if (!fechaRenovacion) {
      return { diasRestantes: 999, esVigente: true, estadoVigencia: 'Vigente' as const };
    }
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    const fRenovMs = parseFechaMs(fechaRenovacion);
    if (!fRenovMs) {
      return { diasRestantes: 999, esVigente: true, estadoVigencia: 'Vigente' as const };
    }

    const fRenov = new Date(fRenovMs);
    fRenov.setHours(0, 0, 0, 0);
    const diffTiempo = fRenov.getTime() - hoy.getTime();
    const diasRestantes = Math.ceil(diffTiempo / (1000 * 60 * 60 * 24));

    if (diasRestantes < 0) {
      return { diasRestantes, esVigente: false, estadoVigencia: 'Vencido' as const };
    } else if (diasRestantes <= 15) {
      return { diasRestantes, esVigente: true, estadoVigencia: 'Próximo a vencer' as const };
    } else {
      return { diasRestantes, esVigente: true, estadoVigencia: 'Vigente' as const };
    }
  };

  // Sincroniza detallesInspeccion con los EPP seleccionados y sus evaluaciones
  const sincronizarDetalles = (
    lista: EPPParaInspeccion[],
    selected: Set<string>,
    evals: Record<string, any>,
    numInsp: string
  ) => {
    const idInspActual = `INSP-${new Date().getFullYear()}-${numInsp.replace('INS-', '')}`;
    const seleccionados = lista.filter(item => selected.has(item.uniqueKey));
    const filas: DetalleInspeccion[] = seleccionados.map((epp, idx) => {
      const evalItem = evals[epp.uniqueKey] || {
        resultado: 'Buen estado' as ResultadoInspeccion,
        accion: 'Sin acción requerida' as AccionInspeccion,
        estadoAccion: 'No aplica' as EstadoAccionInspeccion,
        hallazgo: 'Equipo en condiciones óptimas de operatividad y limpieza.'
      };
      return {
        idDetalle: `DET-INS-${numInsp.replace('INS-', '')}-${idx + 1}`,
        idInspeccion: idInspActual,
        codigoEPP: epp.codigoEPP,
        articulo: epp.articulo,
        talla: epp.talla,
        idEntregaOrigen: epp.idEntregaOrigen,
        idDetalleEntregaOrigen: epp.idDetalleEntregaOrigen,
        fechaEntregaReferencia: epp.fechaEntregaReferencia,
        cantidadReferencia: epp.cantidadReferencia,
        fechaRenovacionReferencia: epp.fechaRenovacionReferencia,
        resultado: evalItem.resultado,
        hallazgo: evalItem.hallazgo,
        accion: evalItem.accion,
        estadoAccion: evalItem.estadoAccion,
        observaciones: ''
      };
    });
    setDetallesInspeccion(filas);
  };

  // Al seleccionar trabajador, cargar todos sus EPP entregados (regla de unicidad eliminada)
  const handleSeleccionarTrabajador = (cod: string, dni?: string) => {
    setCodigoTrabajador(cod);
    setErrorForm(null);

    if (!cod && !dni) {
      setEppsEntregados([]);
      setEppSeleccionados(new Set());
      setEvaluaciones({});
      setDetallesInspeccion([]);
      return;
    }

    const tObj = trabajadores.find(t => 
      (cod && (t.codigo === cod || t.dni === cod)) ||
      (dni && (t.codigo === dni || t.dni === dni))
    );

    const codEfectivo = cod || tObj?.codigo || '';
    const dniEfectivo = dni || tObj?.dni;

    const ultimosEPP = storageService.getUltimosEPPEntregadosPorTrabajador(codEfectivo, dniEfectivo);
    if (ultimosEPP.length === 0) {
      setEppsEntregados([]);
      setEppSeleccionados(new Set());
      setEvaluaciones({});
      setDetallesInspeccion([]);
      return;
    }

    const lista: EPPParaInspeccion[] = ultimosEPP.map((epp, idx) => {
      const vig = calcularVigencia(epp.fechaRenovacion);
      const uniqueKey = epp.idDetalle 
        ? `${epp.idDetalle}-${idx}` 
        : `${epp.idEntrega || 'ENT'}-${epp.codigoEPP}-${idx}`;
      return {
        uniqueKey,
        codigoEPP: epp.codigoEPP,
        articulo: epp.articulo,
        talla: epp.talla || '',
        idEntregaOrigen: epp.idEntrega || '',
        idDetalleEntregaOrigen: epp.idDetalle || '',
        fechaEntregaReferencia: (epp as any).fechaEntrega || epp.fechaRenovacion || '',
        cantidadReferencia: epp.cantidad,
        fechaRenovacionReferencia: epp.fechaRenovacion || '',
        diasRestantes: vig.diasRestantes,
        esVigente: vig.esVigente,
        estadoVigencia: vig.estadoVigencia
      };
    });

    setEppsEntregados(lista);

    // Inicializar mapa de evaluaciones y selección por defecto
    const initialEvals: Record<string, any> = {};
    const initialSelected = new Set<string>();

    lista.forEach(item => {
      initialEvals[item.uniqueKey] = {
        resultado: 'Buen estado' as ResultadoInspeccion,
        accion: 'Sin acción requerida' as AccionInspeccion,
        estadoAccion: 'No aplica' as EstadoAccionInspeccion,
        hallazgo: 'Equipo en condiciones óptimas de operatividad y limpieza.'
      };
      if (item.esVigente) {
        initialSelected.add(item.uniqueKey);
      }
    });

    // Si no hubiera vigentes pero hay entregados, incluir todos
    if (initialSelected.size === 0 && lista.length > 0) {
      lista.forEach(i => initialSelected.add(i.uniqueKey));
    }

    setEvaluaciones(initialEvals);
    setEppSeleccionados(initialSelected);

    // Expandir el primer seleccionado para comodidad
    const primerId = Array.from(initialSelected)[0];
    setEppExpandido(primerId || null);

    sincronizarDetalles(lista, initialSelected, initialEvals, numeroInspeccion);
  };

  // Toggle para seleccionar / deseleccionar un EPP específico
  const handleToggleSeleccion = (uniqueKey: string) => {
    setEppSeleccionados(prev => {
      const nuevo = new Set(prev);
      if (nuevo.has(uniqueKey)) {
        nuevo.delete(uniqueKey);
        if (eppExpandido === uniqueKey) {
          setEppExpandido(null);
        }
      } else {
        nuevo.add(uniqueKey);
        setEppExpandido(uniqueKey);
      }
      sincronizarDetalles(eppsEntregados, nuevo, evaluaciones, numeroInspeccion);
      return nuevo;
    });
  };

  const handleSeleccionarTodos = (soloLosVigentes: boolean) => {
    const nuevo = new Set<string>();
    eppsEntregados.forEach(item => {
      if (!soloLosVigentes || item.esVigente) {
        nuevo.add(item.uniqueKey);
      }
    });
    setEppSeleccionados(nuevo);
    sincronizarDetalles(eppsEntregados, nuevo, evaluaciones, numeroInspeccion);
  };

  const handleDeseleccionarTodos = () => {
    const nuevo = new Set<string>();
    setEppSeleccionados(nuevo);
    setEppExpandido(null);
    sincronizarDetalles(eppsEntregados, nuevo, evaluaciones, numeroInspeccion);
  };

  // Actualiza los parámetros de evaluación de un EPP seleccionado
  const actualizarEvaluacionEPP = (uniqueKey: string, campo: string, valor: any) => {
    setEvaluaciones(prev => {
      const anterior = prev[uniqueKey] || {
        resultado: 'Buen estado',
        accion: 'Sin acción requerida',
        estadoAccion: 'No aplica',
        hallazgo: 'Equipo en condiciones óptimas de operatividad y limpieza.'
      };
      const actualizado = { ...anterior, [campo]: valor };

      if (campo === 'resultado') {
        if (valor === 'Buen estado') {
          actualizado.hallazgo = 'Equipo en condiciones óptimas de operatividad y limpieza.';
          actualizado.accion = 'Sin acción requerida';
          actualizado.estadoAccion = 'No aplica';
        } else if (valor === 'Desgastado') {
          actualizado.hallazgo = 'Desgaste superficial por uso habitual.';
          actualizado.accion = 'Reposición';
          actualizado.estadoAccion = 'Pendiente';
        } else if (valor === 'Deteriorado o dañado') {
          actualizado.hallazgo = 'Daño físico visible que compromete el nivel de protección.';
          actualizado.accion = 'Retiro de uso';
          actualizado.estadoAccion = 'Pendiente';
        } else if (valor === 'No presentado') {
          actualizado.hallazgo = 'El trabajador no presentó el equipo durante la inspección técnica.';
          actualizado.accion = 'Evaluación adicional';
          actualizado.estadoAccion = 'Pendiente';
        } else if (valor === 'EPP Extraviado/ A Descontar') {
          actualizado.hallazgo = 'El trabajador reportó extraviado / perdido el equipo; procede trámite de descuento salarial y reposición.';
          actualizado.accion = 'Reposición';
          actualizado.estadoAccion = 'Pendiente';
        }
      }

      const nuevoMapa = { ...prev, [uniqueKey]: actualizado };
      sincronizarDetalles(eppsEntregados, eppSeleccionados, nuevoMapa, numeroInspeccion);
      return nuevoMapa;
    });
  };

  // Lista filtrada de EPP según toggle de vigencia
  const eppsFiltrados = useMemo(() => {
    if (soloVigentes) {
      return eppsEntregados.filter(item => item.esVigente);
    }
    return eppsEntregados;
  }, [eppsEntregados, soloVigentes]);

  // Guardar Inspección
  const handleGuardarInspeccion = async () => {
    setErrorForm(null);

    if (!codigoTrabajador || !trabajadorSeleccionado) {
      setErrorForm('Seleccione un trabajador para realizar la inspección.');
      return;
    }

    if (eppSeleccionados.size === 0 || detallesInspeccion.length === 0) {
      setErrorForm('Seleccione al menos un EPP entregado para registrar la inspección.');
      return;
    }

    setGuardando(true);
    try {
      const numInsp = numeroInspeccion || storageService.generarNuevoNumeroInspeccion();
      const idInsp = `INSP-${new Date().getFullYear()}-${numInsp.replace('INS-', '')}`;
      const detallesFinales: DetalleInspeccion[] = detallesInspeccion.map((d, idx) => ({
        ...d,
        idInspeccion: idInsp,
        idDetalle: `DET-INS-${numInsp.replace('INS-', '')}-${idx + 1}`
      }));

      const nuevaInsp: InspeccionEPP = {
        id: idInsp,
        numeroInspeccion: numInsp,
        fechaHora: new Date().toISOString().replace('T', ' ').slice(0, 19),
        codigoTrabajador: trabajadorSeleccionado.codigo,
        dni: trabajadorSeleccionado.dni,
        trabajadorNombre: trabajadorSeleccionado.nombreCompleto,
        empresaId: trabajadorSeleccionado.empresaId,
        empresaNombre: trabajadorSeleccionado.empresaNombre,
        area: trabajadorSeleccionado.area,
        cargo: trabajadorSeleccionado.cargo,
        inspectorResponsable,
        lugarInspeccion,
        observacionesGenerales,
        estado: 'Confirmado',
        detalles: detallesFinales,
        fechaCreacion: new Date().toISOString().replace('T', ' ').slice(0, 19),
        operationId: `OP-INSP-${Date.now()}`
      };

      const itemsNoPres = detallesFinales.filter(d => d.resultado === 'No presentado');
      const itemsExtraviados = detallesFinales.filter(d => d.resultado === 'EPP Extraviado/ A Descontar');
      const res = await storageService.registrarInspeccion(nuevaInsp);
      if (res.success) {
        onInspeccionGuardada();

        // Respaldo automático del acta PDF de inspección en Google Drive
        PDFGeneratorService.generarActaInspeccionPDF(nuevaInsp)
          .then(pdfRes => {
            if (pdfRes && pdfRes.blob) {
              googleDriveService.subirArchivo({
                nombreArchivo: pdfRes.fileName,
                mimeType: 'application/pdf',
                datosBlob: pdfRes.blob,
                subcarpeta: '02_Inspecciones_EPP',
                claveIdentificador: nuevaInsp.numeroInspeccion,
                descripcion: `Acta de Inspección de EPP ${nuevaInsp.numeroInspeccion} - ${nuevaInsp.trabajadorNombre}`
              }).catch(e => console.info('Respaldo automático en Drive diferido:', e));
            }
          })
          .catch(e => console.warn('Generación de PDF de inspección para Drive:', e));
        if (itemsNoPres.length > 0 && onColocarInfraccionDesdeInspeccion) {
          // Si hubo equipos no presentados, abrir modal de confirmación para proceder con la infracción
          setInspeccionParaInfraccion({
            insp: nuevaInsp,
            itemsNoPresentados: itemsNoPres
          });
          if (itemsExtraviados.length > 0 && onGenerarDescuentoPorPerdida) {
            setItemsExtraviadosPendientes({
              insp: nuevaInsp,
              items: itemsExtraviados
            });
          }
        } else if (itemsExtraviados.length > 0 && onGenerarDescuentoPorPerdida) {
          // Si hubo equipos extraviados a descontar, abrir modal para gestionar el descuento
          setInspeccionParaDescuento({
            insp: nuevaInsp,
            itemsExtraviados: itemsExtraviados
          });
        } else {
          setModoCreacion(false);
          setCodigoTrabajador('');
          setDetallesInspeccion([]);
        }
      } else {
        setErrorForm(res.mensaje);
      }
    } catch (e: any) {
      setErrorForm(e.message || 'Error al guardar la inspección');
    } finally {
      setGuardando(false);
    }
  };

  // Ver acta PDF de inspección
  const verActaInspeccion = async (insp: InspeccionEPP) => {
    setErrorPdf(null);
    try {
      const res = await PDFGeneratorService.generarActaInspeccionPDF(insp);
      setViewerPdfUrl(res.blobUrl);
      setViewerPdfArrayBuffer(res.arrayBuffer);
      setViewerPdfName(res.fileName);
    } catch (e: any) {
      setErrorPdf('Error al generar informe PDF de inspección: ' + (e.message || 'Error desconocido'));
    }
  };

  const inspeccionesFiltradas = useMemo(() => {
    return inspecciones.filter(i => {
      if (empresaFiltro !== 'TODAS' && i.empresaId !== empresaFiltro) return false;
      if (busqueda) {
        const q = busqueda.toLowerCase();
        return (
          String(i.numeroInspeccion || '').toLowerCase().includes(q) ||
          String(i.trabajadorNombre || '').toLowerCase().includes(q) ||
          String(i.dni || '').includes(q) ||
          String(i.area || '').toLowerCase().includes(q)
        );
      }
      return true;
    }).sort((a, b) => compararFechasDesc(a.fechaHora || a.fechaCreacion, b.fechaHora || b.fechaCreacion, a.numeroInspeccion, b.numeroInspeccion));
  }, [inspecciones, empresaFiltro, busqueda]);

  // Paginación para historial de inspecciones
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, empresaFiltro, inspecciones.length]);

  const totalPaginas = Math.max(1, Math.ceil(inspeccionesFiltradas.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;

  const inspeccionesPaginadas = useMemo(() => {
    return inspeccionesFiltradas.slice(indiceInicio, indiceInicio + porPagina);
  }, [inspeccionesFiltradas, indiceInicio, porPagina]);

  return (
    <div className="space-y-6">
      {/* Alerta de error en generación de PDF */}
      {errorPdf && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="font-bold">Error:</span>
            <span>{errorPdf}</span>
          </div>
          <button
            onClick={() => setErrorPdf(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Cabecera Estandarizada */}
      <ModuleHeader
        icon={ShieldAlert}
        title="Inspecciones de Equipos de Protección Personal (EPP)"
        subtitle="Evaluación técnica del estado físico de los EPP asignados por puesto de trabajo (Regla de última entrega de referencia)"
        colorTheme="teal"
        actions={
          !modoCreacion ? (
            <button
              type="button"
              onClick={handleAbrirCreacion}
              className="h-9 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-2 shadow-xs transition-colors cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Nueva Inspección</span>
            </button>
          ) : null
        }
      />

      {!modoCreacion && (
        /* Tarjetas KPI de Resumen de Inspecciones */
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Inspecciones</p>
              <p className="text-xl font-bold text-slate-900 font-mono-numbers">{inspeccionesFiltradas.length}</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">EPP Auditados</p>
              <p className="text-xl font-bold text-slate-900 font-mono-numbers">
                {inspeccionesFiltradas.reduce((acc, i) => acc + (i.detalles || []).length, 0)} <span className="text-xs font-normal text-slate-400 font-sans">ítems</span>
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Con Reposición / Incidencias</p>
              <p className="text-xl font-bold text-amber-700 font-mono-numbers">
                {inspeccionesFiltradas.filter(i => (i.detalles || []).some(d => d.resultado === 'Deteriorado o dañado' || d.resultado === 'Desgastado' || d.resultado === 'EPP Extraviado/ A Descontar')).length}
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Operatividad</p>
              <p className="text-xl font-bold text-emerald-700 font-mono-numbers">
                {inspeccionesFiltradas.length > 0 
                  ? Math.round((inspeccionesFiltradas.filter(i => !(i.detalles || []).some(d => d.resultado === 'Deteriorado o dañado' || d.resultado === 'EPP Extraviado/ A Descontar')).length / inspeccionesFiltradas.length) * 100) 
                  : 100}%
              </p>
            </div>
          </div>
        </div>
      )}

      {modoCreacion ? (
        /* FORMULARIO DE NUEVA INSPECCIÓN */
        <div className="space-y-6">
          {errorForm && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorForm}</span>
            </div>
          )}

          {/* Bloque Selección de Trabajador */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                1. Trabajador a Inspeccionar
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div>
                <TrabajadorSearchAutocomplete
                  trabajadores={trabajadores}
                  valorSeleccionado={codigoTrabajador}
                  onSeleccionar={(t) => handleSeleccionarTrabajador(t ? t.codigo : '', t ? t.dni : undefined)}
                  label="Seleccione Trabajador"
                  required
                  colorTheme="emerald"
                  placeholder="Escriba nombre, apellido o DNI..."
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Inspector Responsable (SST)
                </label>
                <select
                  value={inspectorResponsable}
                  onChange={(e) => setInspectorResponsable(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800 font-medium focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all cursor-pointer"
                >
                  {RESPONSABLES_SST_OPCIONES.map((opc) => (
                    <option key={opc.valor} value={opc.valor}>
                      {opc.valor}
                    </option>
                  ))}
                </select>
              </div>

              <ZonaPlantaAutocomplete
                valor={lugarInspeccion}
                onChange={setLugarInspeccion}
                colorTheme="emerald"
                label="Lugar de Inspección"
                placeholder="Seleccione o busque una zona de la planta..."
              />
            </div>

            {trabajadorSeleccionado && (
              <div className="pt-2 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50/60 p-3 rounded-lg">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Empresa:</span>
                  <span className="font-semibold text-slate-800">{trabajadorSeleccionado.empresaNombre}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Área:</span>
                  <span className="font-medium text-slate-800">{trabajadorSeleccionado.area}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Cargo:</span>
                  <span className="font-medium text-slate-800">{trabajadorSeleccionado.cargo}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">DNI:</span>
                  <span className="font-mono font-bold text-slate-800">{trabajadorSeleccionado.dni}</span>
                </div>
              </div>
            )}
          </div>

          {/* Bloque Detalle EPP Elegibles según Regla Determinista y Vigencia */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <HardHat className="w-4 h-4 text-emerald-600" />
                <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  2. Equipos de Protección Entregados (Inspección N° <span className="font-mono text-emerald-700 font-bold">{numeroInspeccion}</span>)
                </h2>
              </div>

              {codigoTrabajador && eppsEntregados.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    {eppSeleccionados.size} de {eppsFiltrados.length} seleccionados para inspeccionar
                  </span>

                  <button
                    type="button"
                    onClick={() => setSoloVigentes(!soloVigentes)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border ${
                      soloVigentes 
                        ? 'bg-blue-50 border-blue-200 text-blue-700' 
                        : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                    }`}
                    title="Alternar entre ver solo EPP con vida útil vigente o ver todo el historial"
                  >
                    <Filter className="w-3 h-3" />
                    <span>{soloVigentes ? 'Solo EPP Vigentes' : 'Todos los EPP'}</span>
                  </button>

                  <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-[11px]">
                    <button
                      type="button"
                      onClick={() => handleSeleccionarTodos(soloVigentes)}
                      className="px-2 py-0.5 font-medium text-slate-700 hover:text-emerald-700 hover:bg-white rounded transition-colors cursor-pointer"
                    >
                      Marcar todos
                    </button>
                    <span className="text-slate-300">|</span>
                    <button
                      type="button"
                      onClick={handleDeseleccionarTodos}
                      className="px-2 py-0.5 font-medium text-slate-700 hover:text-rose-700 hover:bg-white rounded transition-colors cursor-pointer"
                    >
                      Desmarcar todos
                    </button>
                  </div>
                </div>
              )}
            </div>

            {!codigoTrabajador ? (
              <div className="py-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-400 text-xs">
                Seleccione un trabajador para cargar automáticamente sus EPP vigentes.
              </div>
            ) : eppsEntregados.length === 0 ? (
              <div className="py-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs">
                El trabajador no tiene registros de EPP entregados previamente.
              </div>
            ) : eppsFiltrados.length === 0 ? (
              <div className="py-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs space-y-2">
                <p>No se encontraron EPP con vida útil vigente para este trabajador.</p>
                <button
                  type="button"
                  onClick={() => setSoloVigentes(false)}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Ver todos los EPP entregados ({eppsEntregados.length})
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-2xs">
                <table className="w-full text-left border-collapse text-xs min-w-[950px]">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                      <th className="py-2.5 px-3 w-14 text-center">N°</th>
                      <th className="py-2.5 px-3 whitespace-nowrap">F. Entrega</th>
                      <th className="py-2.5 px-3">Artículo / EPP</th>
                      <th className="py-2.5 px-3 text-center">Cant.</th>
                      <th className="py-2.5 px-3 whitespace-nowrap">F. Vencimiento</th>
                      <th className="py-2.5 px-3 min-w-[170px]">Resultado Inspección</th>
                      <th className="py-2.5 px-3 min-w-[160px]">Acción Requerida</th>
                      <th className="py-2.5 px-3 min-w-[125px]">Estado Acción</th>
                      <th className="py-2.5 px-3 min-w-[180px]">Observación</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {eppsFiltrados.map((item, idx) => {
                      const isSelected = eppSeleccionados.has(item.uniqueKey);
                      const evalItem = evaluaciones[item.uniqueKey] || {
                        resultado: 'Buen estado',
                        accion: 'Sin acción requerida',
                        estadoAccion: 'No aplica',
                        hallazgo: ''
                      };
                      const esVencido = item.estadoVigencia === 'Vencido';

                      return (
                        <React.Fragment key={item.uniqueKey}>
                          <tr
                            className={`transition-colors ${
                              !isSelected
                                ? 'bg-slate-50/50 opacity-60 hover:opacity-90'
                                : evalItem.resultado === 'No presentado'
                                ? 'bg-rose-50/20 hover:bg-rose-50/40'
                                : evalItem.resultado === 'EPP Extraviado/ A Descontar'
                                ? 'bg-amber-50/20 hover:bg-amber-50/40'
                                : 'hover:bg-slate-50/70'
                            }`}
                          >
                            <td className="py-2.5 px-3 text-center text-slate-500 font-mono text-[11px] whitespace-nowrap">
                              <div className="flex items-center justify-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() => handleToggleSeleccion(item.uniqueKey)}
                                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer"
                                  title={isSelected ? 'Desmarcar de la inspección' : 'Marcar para inspeccionar'}
                                />
                                <span className="text-slate-400 font-mono text-[11px]">{idx + 1}</span>
                              </div>
                            </td>

                            <td className="py-2.5 px-3 font-mono text-slate-600 whitespace-nowrap">
                              <div className="font-medium text-slate-800">{item.fechaEntregaReferencia || '-'}</div>
                              <div className="text-[10px] text-slate-400">{item.idEntregaOrigen || 'REG-ORIGEN'}</div>
                            </td>

                            <td className="py-2.5 px-3 min-w-[190px]">
                              <div className="font-semibold text-slate-900">{item.articulo}</div>
                              <div className="text-[10px] text-slate-500 flex items-center gap-2">
                                <span>Talla: {item.talla || 'Estándar'}</span>
                                <span>•</span>
                                <span>Código: {item.codigoEPP}</span>
                              </div>
                            </td>

                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <span className="font-bold text-slate-900">{item.cantidadReferencia}</span>{' '}
                              <span className="text-[11px] text-slate-600 font-medium">Unidad</span>
                            </td>

                            <td className="py-2.5 px-3 whitespace-nowrap">
                              <div
                                className={`font-mono text-xs flex items-center gap-1 ${
                                  esVencido ? 'text-emerald-700 font-bold' : 'text-slate-600'
                                }`}
                              >
                                {item.fechaRenovacionReferencia || '-'}
                              </div>
                              <span
                                className={`text-[10px] inline-block px-1.5 py-0.2 rounded font-semibold ${
                                  esVencido
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {esVencido ? 'Vida Útil Cumplida' : 'Vigente al Cese'}
                              </span>
                            </td>

                            <td className="py-2.5 px-3">
                              <select
                                value={evalItem.resultado}
                                disabled={!isSelected}
                                onChange={(e) =>
                                  actualizarEvaluacionEPP(
                                    item.uniqueKey,
                                    'resultado',
                                    e.target.value as ResultadoInspeccion
                                  )
                                }
                                className={`h-8 px-2 rounded-lg text-xs font-semibold border cursor-pointer transition-colors w-full ${
                                  !isSelected
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                                    : evalItem.resultado === 'Buen estado'
                                    ? 'bg-blue-50 text-blue-800 border-blue-200'
                                    : evalItem.resultado === 'Desgastado'
                                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                                    : evalItem.resultado === 'Deteriorado o dañado'
                                    ? 'bg-orange-50 text-orange-800 border-orange-200'
                                    : evalItem.resultado === 'No presentado'
                                    ? 'bg-rose-50 text-rose-800 border-rose-300 font-bold'
                                    : 'bg-amber-50 text-amber-800 border-amber-300 font-bold'
                                }`}
                              >
                                <option value="Buen estado">✓ Buen estado</option>
                                <option value="Desgastado">⚠ Desgastado</option>
                                <option value="Deteriorado o dañado">✕ Deteriorado o dañado</option>
                                <option value="No presentado">✕ No presentado</option>
                                <option value="EPP Extraviado/ A Descontar">✕ EPP Extraviado/ A Descontar</option>
                              </select>
                            </td>

                            <td className="py-2.5 px-3">
                              <select
                                value={evalItem.accion}
                                disabled={!isSelected}
                                onChange={(e) =>
                                  actualizarEvaluacionEPP(
                                    item.uniqueKey,
                                    'accion',
                                    e.target.value as AccionInspeccion
                                  )
                                }
                                className={`h-8 px-2 rounded-lg text-xs font-medium border cursor-pointer transition-colors w-full ${
                                  !isSelected
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                                    : 'bg-white text-slate-800 border-slate-200'
                                }`}
                              >
                                <option value="Sin acción requerida">Sin acción requerida</option>
                                <option value="Limpieza o mantenimiento">Limpieza o mantenimiento</option>
                                <option value="Evaluación adicional">Evaluación adicional</option>
                                <option value="Reposición">Reposición</option>
                                <option value="Retiro de uso">Retiro de uso</option>
                              </select>
                            </td>

                            <td className="py-2.5 px-3">
                              <select
                                value={evalItem.estadoAccion}
                                disabled={!isSelected}
                                onChange={(e) =>
                                  actualizarEvaluacionEPP(
                                    item.uniqueKey,
                                    'estadoAccion',
                                    e.target.value as EstadoAccionInspeccion
                                  )
                                }
                                className={`h-8 px-2 rounded-lg text-xs font-medium border cursor-pointer transition-colors w-full ${
                                  !isSelected
                                    ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                                    : 'bg-white text-slate-800 border-slate-200'
                                }`}
                              >
                                <option value="No aplica">No aplica</option>
                                <option value="Pendiente">Pendiente</option>
                                <option value="En proceso">En proceso</option>
                                <option value="Cerrada">Cerrada</option>
                              </select>
                            </td>

                            <td className="py-2.5 px-3 min-w-[160px]">
                              <input
                                type="text"
                                value={evalItem.hallazgo || ''}
                                disabled={!isSelected}
                                onChange={(e) =>
                                  actualizarEvaluacionEPP(item.uniqueKey, 'hallazgo', e.target.value)
                                }
                                placeholder="Observación..."
                                className="w-full h-8 px-2 rounded border border-slate-200 text-[11px] text-slate-700 focus:bg-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 disabled:bg-slate-100 disabled:text-slate-400"
                              />
                            </td>
                          </tr>

                          {/* Quick action bar for Extraviado / Descuento */}
                          {isSelected && evalItem.resultado === 'EPP Extraviado/ A Descontar' && (
                            <tr className="bg-amber-50/80 border-b border-amber-200">
                              <td colSpan={9} className="py-2.5 px-4">
                                <div className="flex flex-wrap items-center justify-between gap-3 text-amber-950 text-xs">
                                  <div className="flex items-center gap-2">
                                    <ReceiptText className="w-4 h-4 text-amber-600 shrink-0" />
                                    <span>
                                      <strong>EPP Extraviado / A Descontar:</strong> Pérdida o extravío de {item.articulo} ({item.codigoEPP}). Corresponde autorizar descuento por nómina y reposición.
                                    </span>
                                  </div>
                                  {onGenerarDescuentoPorPerdida && trabajadorSeleccionado && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        onGenerarDescuentoPorPerdida(trabajadorSeleccionado.codigo, item.codigoEPP, {
                                          codigoTrabajador: trabajadorSeleccionado.codigo,
                                          codigoEPP: item.codigoEPP,
                                          idInspeccionOrigen: `INSP-${new Date().getFullYear()}-${numeroInspeccion.replace('INS-', '')}`,
                                          numeroInspeccionOrigen: numeroInspeccion,
                                          motivoDescuento: 'Pérdida en planta',
                                          descripcionHechos: `Detectado durante inspección técnica (${numeroInspeccion}) en ${lugarInspeccion}. El trabajador reportó como extraviado / a descontar el equipo ${item.articulo} (${item.codigoEPP}) entregado el ${item.fechaEntregaReferencia}. Se procede a emitir la autorización de descuento para su reposición inmediata.`
                                        });
                                      }}
                                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer shrink-0"
                                    >
                                      <ReceiptText className="w-3.5 h-3.5" />
                                      <span>Generar Descuento Directo</span>
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          )}

                          {/* Quick action bar for No presentado */}
                          {isSelected && evalItem.resultado === 'No presentado' && (
                            <tr className="bg-rose-50/80 border-b border-rose-200">
                              <td colSpan={9} className="py-2.5 px-4">
                                <div className="flex flex-wrap items-center justify-between gap-3 text-rose-900 text-xs">
                                  <div className="flex items-center gap-2">
                                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                                    <span>
                                      <strong>Equipo No Presentado:</strong> El trabajador no presentó {item.articulo} ({item.codigoEPP}) durante la inspección técnica.
                                    </span>
                                  </div>
                                  {onColocarInfraccionDesdeInspeccion && trabajadorSeleccionado && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        onColocarInfraccionDesdeInspeccion({
                                          codigoTrabajador: trabajadorSeleccionado.codigo,
                                          eppsOmitidos: [item.articulo],
                                          lugarZona: lugarInspeccion,
                                          supervisorReporta: inspectorResponsable,
                                          fechaHora: new Date().toISOString().slice(0, 16),
                                          idInspeccionOrigen: `INSP-${new Date().getFullYear()}-${numeroInspeccion.replace('INS-', '')}`,
                                          numeroInspeccionOrigen: numeroInspeccion,
                                          descripcionHechos: `Durante la inspección técnica de EPP (${numeroInspeccion}) en ${lugarInspeccion}, el trabajador no presentó el siguiente equipo obligatorio: ${item.articulo} (${item.codigoEPP}). Condición observada: el trabajador no portaba ni exhibió el equipo reglamentario.`
                                        });
                                      }}
                                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer shrink-0"
                                    >
                                      <AlertTriangle className="w-3.5 h-3.5" />
                                      <span>Colocar Infracción Directa</span>
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Botones formulario */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={() => setModoCreacion(false)}
              className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-semibold cursor-pointer shadow-2xs transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleGuardarInspeccion}
              disabled={guardando || detallesInspeccion.length === 0}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 disabled:opacity-50 shadow-xs cursor-pointer transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{guardando ? 'Guardando Inspección...' : 'Guardar y Confirmar Inspección'}</span>
            </button>
          </div>
        </div>
      ) : (
        /* HISTORIAL DE INSPECCIONES REALIZADAS */
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[220px] max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="Buscar por n° inspección, trabajador, DNI..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
              {busqueda && (
                <button 
                  onClick={() => setBusqueda('')}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <span className="text-xs text-slate-500 font-mono-numbers">
              {inspeccionesFiltradas.length} inspección{inspeccionesFiltradas.length === 1 ? '' : 'es'} registrada{inspeccionesFiltradas.length === 1 ? '' : 's'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs min-w-[950px]">
              <thead>
                <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                  <th className="py-3.5 px-4 w-40">N° Inspección</th>
                  <th className="py-3.5 px-3 w-32">Fecha y Hora</th>
                  <th className="py-3.5 px-4 min-w-[200px]">Trabajador Evaluado</th>
                  <th className="py-3.5 px-3 w-36">Empresa</th>
                  <th className="py-3.5 px-3 min-w-[150px]">Inspector SST</th>
                  <th className="py-3.5 px-3 text-center w-24">EPP</th>
                  <th className="py-3.5 px-4 min-w-[180px]">Diagnóstico / Hallazgos</th>
                  <th className="py-3.5 px-3 text-center w-28 sm:w-32">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {inspeccionesFiltradas.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-14 text-center text-slate-500">
                      <div className="max-w-xs mx-auto space-y-2">
                        <ShieldAlert className="w-8 h-8 mx-auto text-slate-400 stroke-1" />
                        <p className="font-semibold text-slate-700 text-xs">No se encontraron registros de inspecciones</p>
                        <p className="text-[11px] text-slate-500">Registra una nueva evaluación técnica pulsando en "+ Nueva Inspección".</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  inspeccionesPaginadas.map((insp, idx) => {
                    const detallesSeguros = Array.isArray(insp.detalles) ? insp.detalles : [];
                    const noPresentados = detallesSeguros.filter(d => d.resultado === 'No presentado');
                    const extraviados = detallesSeguros.filter(d => d.resultado === 'EPP Extraviado/ A Descontar');
                    const tieneNoPresentados = noPresentados.length > 0;
                    const tieneExtraviados = extraviados.length > 0;
                    const tieneHallazgosCriticos = detallesSeguros.some(d => d.resultado === 'Deteriorado o dañado' || d.resultado === 'Desgastado');
                    const isPerpol = insp.empresaId === 'EMP-PERPOL';

                    return (
                      <tr key={insp.id ? `${insp.id}-${idx}` : `insp-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                          {insp.numeroInspeccion}
                        </td>
                        <td className="py-3.5 px-3 font-mono font-medium text-slate-800 whitespace-nowrap">
                          {insp.fechaHora}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 tracking-tight">{insp.trabajadorNombre}</div>
                          <div className="text-[11px] font-mono text-slate-600 font-medium mt-0.5">
                            DNI: {insp.dni} <span className="text-slate-400">|</span> {insp.area}
                          </div>
                        </td>
                        <td className="py-3.5 px-3 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold border ${
                            isPerpol 
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-300' 
                              : 'bg-blue-100 text-blue-900 border-blue-300'
                          }`}>
                            {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-slate-800">
                          <div className="font-semibold text-slate-900 text-[11px]">{insp.inspectorResponsable}</div>
                          <div className="text-[11px] text-slate-600 font-medium mt-0.5">{insp.lugarInspeccion || 'En Planta'}</div>
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <span className="inline-flex items-center px-2.5 py-1 bg-slate-100 rounded text-slate-900 font-mono font-bold text-xs">
                            {detallesSeguros.length} epp
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="flex flex-col gap-1">
                            {tieneExtraviados && (
                              <span className="inline-flex items-center gap-1.5 text-[11px] text-amber-950 font-bold bg-amber-100 px-2 py-0.5 rounded-lg border border-amber-300">
                                <ReceiptText className="w-3.5 h-3.5 text-amber-800 shrink-0" />
                                <span>Extraviado / Descuento ({extraviados.length})</span>
                              </span>
                            )}
                            {tieneNoPresentados && (
                              <span className="inline-flex items-center gap-1.5 text-[11px] text-rose-950 font-bold bg-rose-100 px-2 py-0.5 rounded-lg border border-rose-300">
                                <AlertTriangle className="w-3.5 h-3.5 text-rose-700 shrink-0" />
                                <span>No Presentó ({noPresentados.length})</span>
                              </span>
                            )}
                            {tieneHallazgosCriticos && (
                              <span className="inline-flex items-center gap-1.5 text-[11px] text-amber-950 font-bold bg-amber-100 px-2.5 py-1 rounded-lg border border-amber-300">
                                <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                                <span>Requiere Reposición</span>
                              </span>
                            )}
                            {!tieneHallazgosCriticos && !tieneNoPresentados && !tieneExtraviados && (
                              <span className="inline-flex items-center gap-1.5 text-[11px] text-emerald-950 font-bold bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-300">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                                <span>Todos en Buen Estado</span>
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-center align-middle">
                          <div className="flex flex-col items-center justify-center gap-1.5 w-full max-w-[105px] mx-auto">
                            <button
                              type="button"
                              onClick={() => verActaInspeccion(insp)}
                              className="w-full px-2 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-md text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500"
                              title="Ver Acta Oficial de Inspección en PDF"
                            >
                              <FileText className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>Informe</span>
                            </button>

                            {tieneNoPresentados && onColocarInfraccionDesdeInspeccion && (
                              <button
                                type="button"
                                onClick={() => {
                                  const eppsOmitidos = noPresentados.map(d => d.articulo);
                                  onColocarInfraccionDesdeInspeccion({
                                    codigoTrabajador: insp.codigoTrabajador,
                                    eppsOmitidos,
                                    lugarZona: insp.lugarInspeccion || 'Planta de Producción',
                                    supervisorReporta: insp.inspectorResponsable,
                                    fechaHora: insp.fechaHora.includes('T') ? insp.fechaHora.slice(0, 16) : insp.fechaHora.replace(' ', 'T').slice(0, 16),
                                    idInspeccionOrigen: insp.id,
                                    numeroInspeccionOrigen: insp.numeroInspeccion,
                                    descripcionHechos: `Durante la inspección técnica de EPP (${insp.numeroInspeccion}) realizada el ${insp.fechaHora} en ${insp.lugarInspeccion || 'planta industrial'}, el trabajador no presentó los siguientes equipos reglamentarios de protección personal: ${eppsOmitidos.join(', ')}. Condición observada: el trabajador no portaba ni exhibió los EPP asignados durante la fiscalización de SST.`
                                  });
                                }}
                                className="w-full px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                                title="Proceder a Colocar Infracción de EPP con Datos Heredados"
                              >
                                <AlertTriangle className="w-3.5 h-3.5 text-white shrink-0" />
                                <span>Infracción</span>
                              </button>
                            )}

                            {tieneExtraviados && onGenerarDescuentoPorPerdida && (
                              <button
                                type="button"
                                onClick={() => {
                                  const eppExtr = extraviados[0];
                                  onGenerarDescuentoPorPerdida(insp.codigoTrabajador, eppExtr?.codigoEPP, {
                                    codigoTrabajador: insp.codigoTrabajador,
                                    codigoEPP: eppExtr?.codigoEPP,
                                    idInspeccionOrigen: insp.id,
                                    numeroInspeccionOrigen: insp.numeroInspeccion,
                                    motivoDescuento: 'Pérdida en planta',
                                    descripcionHechos: `Durante la inspección técnica de EPP (${insp.numeroInspeccion}) realizada el ${insp.fechaHora} en ${insp.lugarInspeccion || 'planta industrial'}, el trabajador reportó como extraviado / a descontar el equipo ${eppExtr?.articulo} [${eppExtr?.codigoEPP}]. Se procede a generar la autorización de descuento para su reposición inmediata.`
                                  });
                                }}
                                className="w-full px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-md text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                                title="Generar Autorización de Descuento por EPP Extraviado"
                              >
                                <ReceiptText className="w-3.5 h-3.5 text-white shrink-0" />
                                <span>Descontar</span>
                              </button>
                            )}

                            {(tieneHallazgosCriticos || tieneExtraviados) && (
                              <button
                                type="button"
                                onClick={() => {
                                  const eppHallazgo = detallesSeguros.find(d => d.resultado === 'EPP Extraviado/ A Descontar' || d.accion === 'Reposición' || d.resultado === 'Deteriorado o dañado');
                                  if (eppHallazgo) {
                                    onIniciarReposicionDesdeInspeccion(insp.codigoTrabajador, eppHallazgo.codigoEPP);
                                  }
                                }}
                                className="w-full px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                                title="Iniciar Entrega de Reposición Directa"
                              >
                                <RefreshCw className="w-3.5 h-3.5 text-white shrink-0" />
                                <span>Reponer</span>
                              </button>
                            )}

                            {tieneHallazgosCriticos && !tieneExtraviados && onGenerarDescuentoPorPerdida && (
                              <button
                                type="button"
                                onClick={() => {
                                  const eppHallazgo = detallesSeguros.find(d => d.accion === 'Reposición' || d.resultado === 'Deteriorado o dañado');
                                  onGenerarDescuentoPorPerdida(insp.codigoTrabajador, eppHallazgo?.codigoEPP, {
                                    codigoTrabajador: insp.codigoTrabajador,
                                    codigoEPP: eppHallazgo?.codigoEPP,
                                    idInspeccionOrigen: insp.id,
                                    numeroInspeccionOrigen: insp.numeroInspeccion,
                                    motivoDescuento: 'Deterioro por uso indebido',
                                    descripcionHechos: `Detectado en inspección técnica de EPP (${insp.numeroInspeccion}) el ${insp.fechaHora}. Equipo ${eppHallazgo?.articulo} [${eppHallazgo?.codigoEPP}] presentó deterioro que amerita descuento de reposición.`
                                  });
                                }}
                                className="w-full px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-md text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                                title="Generar Autorización de Descuento por Pérdida / Deterioro"
                              >
                                <ReceiptText className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                                <span>Descuento</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => setInspeccionAEliminar(insp)}
                              aria-label={`Borrar inspección ${insp.numeroInspeccion}`}
                              className="w-full px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-md text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                              title={`Borrar inspección ${insp.numeroInspeccion}`}
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                              <span>Borrar</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Paginación idéntica al Padrón de Trabajadores */}
          <TablePagination
            totalRegistros={inspeccionesFiltradas.length}
            paginaActual={paginaActual}
            setPaginaActual={setPaginaActual}
            porPagina={porPagina}
            setPorPagina={setPorPagina}
            nombreEntidadPlural="inspecciones"
          />
        </div>
      )}

      {/* Visor Modal de Informe de Inspección */}
      <PDFViewerModal
        isOpen={Boolean(viewerPdfUrl)}
        onClose={() => setViewerPdfUrl(null)}
        pdfBlobUrl={viewerPdfUrl}
        pdfArrayBuffer={viewerPdfArrayBuffer}
        fileName={viewerPdfName}
        titulo="Informe de Inspección Periódica de EPP"
        esBorrador={false}
      />

      {/* Modal de Herencia: Proceder a Colocar Infracción tras Guardar Inspección */}
      {inspeccionParaInfraccion && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-rose-200 space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto my-auto flex flex-col">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto shadow-inner">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center space-y-2">
              <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200">
                Infracción Disciplinaria Detectada
              </span>
              <h3 className="text-base font-bold text-slate-900">
                ¿Proceder a Colocar Infracción de EPP?
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                La inspección <strong className="font-mono text-slate-900 font-bold">{inspeccionParaInfraccion.insp.numeroInspeccion}</strong> se registró correctamente. Sin embargo, el trabajador <strong className="text-slate-900">{inspeccionParaInfraccion.insp.trabajadorNombre}</strong> <strong>no presentó</strong> los siguientes equipos reglamentarios:
              </p>
              <div className="p-3 bg-rose-50/80 rounded-xl text-left border border-rose-200">
                <ul className="text-xs text-rose-950 space-y-1.5 font-medium">
                  {inspeccionParaInfraccion.itemsNoPresentados.map((d, dIdx) => (
                    <li key={d.idDetalle ? `${d.idDetalle}-${dIdx}` : `nopres-${dIdx}`} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0"></span>
                      <span>
                        <strong className="font-semibold text-rose-900">{d.articulo}</strong>{' '}
                        <span className="font-mono text-[11px] text-rose-700">[{d.codigoEPP}]</span>
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <p className="text-[11px] text-slate-500">
                Al proceder, el sistema transferirá automáticamente los datos del trabajador, lugar de inspección, supervisor y EPP no presentados al módulo de infracciones.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setInspeccionParaInfraccion(null);
                  if (itemsExtraviadosPendientes) {
                    setInspeccionParaDescuento({
                      insp: itemsExtraviadosPendientes.insp,
                      itemsExtraviados: itemsExtraviadosPendientes.items
                    });
                    setItemsExtraviadosPendientes(null);
                  } else {
                    setModoCreacion(false);
                    setCodigoTrabajador('');
                    setDetallesInspeccion([]);
                  }
                }}
                className="px-4 py-2.5 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Omitir por ahora
              </button>
              <button
                type="button"
                onClick={() => {
                  const insp = inspeccionParaInfraccion.insp;
                  const epps = inspeccionParaInfraccion.itemsNoPresentados.map(d => d.articulo);
                  setInspeccionParaInfraccion(null);
                  setModoCreacion(false);
                  setCodigoTrabajador('');
                  setDetallesInspeccion([]);
                  if (onColocarInfraccionDesdeInspeccion) {
                    onColocarInfraccionDesdeInspeccion({
                      codigoTrabajador: insp.codigoTrabajador,
                      eppsOmitidos: epps,
                      lugarZona: insp.lugarInspeccion || 'Planta de Producción',
                      supervisorReporta: insp.inspectorResponsable,
                      fechaHora: insp.fechaHora.includes('T') ? insp.fechaHora.slice(0, 16) : insp.fechaHora.replace(' ', 'T').slice(0, 16),
                      idInspeccionOrigen: insp.id,
                      numeroInspeccionOrigen: insp.numeroInspeccion,
                      descripcionHechos: `Durante la inspección técnica de EPP (${insp.numeroInspeccion}) realizada el ${insp.fechaHora} en ${insp.lugarInspeccion || 'planta industrial'}, el trabajador no presentó los siguientes equipos reglamentarios de protección personal: ${epps.join(', ')}. Condición observada: no portaba ni exhibió los EPP asignados durante la fiscalización de SST.`
                    });
                  }
                }}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm cursor-pointer transition-colors"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Colocar Infracción</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Descuento: Proceder a Generar Autorización tras Guardar Inspección con EPP Extraviado */}
      {inspeccionParaDescuento && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-amber-200 space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto my-auto flex flex-col">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto shadow-inner">
              <ReceiptText className="w-6 h-6" />
            </div>
            <div className="text-center space-y-2">
              <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                EPP Extraviado Detectado
              </span>
              <h3 className="text-base font-bold text-slate-900">
                ¿Proceder a Generar Descuento de Nómina?
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                La inspección <strong className="font-mono text-slate-900 font-bold">{inspeccionParaDescuento.insp.numeroInspeccion}</strong> se registró correctamente. El trabajador <strong className="text-slate-900">{inspeccionParaDescuento.insp.trabajadorNombre}</strong> declaró <strong>extraviado / a descontar</strong> el siguiente equipo:
              </p>
              <div className="p-3 bg-amber-50/80 rounded-xl text-left border border-amber-200">
                <ul className="text-xs text-amber-950 space-y-1.5 font-medium">
                  {inspeccionParaDescuento.itemsExtraviados.map((d, dIdx) => (
                    <li key={d.idDetalle ? `${d.idDetalle}-${dIdx}` : `extrav-${dIdx}`} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
                      <span>
                        <strong className="font-semibold text-amber-900">{d.articulo}</strong>{' '}
                        <span className="font-mono text-[11px] text-amber-700">[{d.codigoEPP}]</span>
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <p className="text-[11px] text-slate-500">
                Al proceder, el sistema abrirá el módulo de descuentos con el trabajador y el EPP precargados para emitir la autorización oficial.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setInspeccionParaDescuento(null);
                  setModoCreacion(false);
                  setCodigoTrabajador('');
                  setDetallesInspeccion([]);
                }}
                className="px-4 py-2.5 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Omitir por ahora
              </button>
              <button
                type="button"
                onClick={() => {
                  const insp = inspeccionParaDescuento.insp;
                  const epp = inspeccionParaDescuento.itemsExtraviados[0]?.codigoEPP;
                  setInspeccionParaDescuento(null);
                  setModoCreacion(false);
                  setCodigoTrabajador('');
                  setDetallesInspeccion([]);
                  if (onGenerarDescuentoPorPerdida) {
                    onGenerarDescuentoPorPerdida(insp.codigoTrabajador, epp, {
                      codigoTrabajador: insp.codigoTrabajador,
                      codigoEPP: epp,
                      idInspeccionOrigen: insp.id,
                      numeroInspeccionOrigen: insp.numeroInspeccion,
                      motivoDescuento: 'Pérdida en planta',
                      descripcionHechos: `Inspección técnica de EPP (${insp.numeroInspeccion}) realizada el ${insp.fechaHora}. El trabajador reportó como extraviado / a descontar el equipo [${epp}]. Se procede con la emisión de la autorización de descuento para su reposición inmediata.`
                    });
                  }
                }}
                className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm cursor-pointer transition-colors"
              >
                <ReceiptText className="w-4 h-4" />
                <span>Generar Descuento</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmación para Borrar Inspección */}
      <InspeccionDeleteModal
        inspeccion={inspeccionAEliminar}
        onClose={() => !eliminandoInspeccion && setInspeccionAEliminar(null)}
        onConfirmar={handleConfirmarEliminarInspeccion}
        eliminando={eliminandoInspeccion}
      />
    </div>
  );
};
