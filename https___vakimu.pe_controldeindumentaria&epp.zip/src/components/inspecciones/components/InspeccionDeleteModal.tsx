import React, { useEffect } from 'react';
import { Trash2, AlertTriangle } from 'lucide-react';
import { InspeccionEPP } from '../../../types';

interface InspeccionDeleteModalProps {
  inspeccion: InspeccionEPP | null;
  onClose: () => void;
  onConfirmar: () => void;
  eliminando?: boolean;
}

export const InspeccionDeleteModal: React.FC<InspeccionDeleteModalProps> = ({
  inspeccion,
  onClose,
  onConfirmar,
  eliminando = false
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !eliminando) onClose();
    };
    if (inspeccion) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [inspeccion, onClose, eliminando]);

  if (!inspeccion) return null;

  const isPerpol = inspeccion.empresaId === 'EMP-PERPOL' || inspeccion.empresaId === 'PERPOL';
  const detallesCount = Array.isArray(inspeccion.detalles) ? inspeccion.detalles.length : 0;

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="titulo-eliminar-inspeccion"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 p-6 space-y-4">
        {/* Cabecera del diálogo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 border border-rose-200">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h3 id="titulo-eliminar-inspeccion" className="text-sm font-bold text-slate-900">
              Eliminar Registro de Inspección
            </h3>
            <p className="text-xs text-slate-500">
              Formato Oficial FO-SST-EPP-003 v02
            </p>
          </div>
        </div>

        {/* Resumen del registro a eliminar */}
        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-mono font-bold text-slate-900 bg-slate-200/80 px-2 py-0.5 rounded text-[11px]">
              {inspeccion.numeroInspeccion}
            </span>
            <span className="text-[11px] font-mono text-slate-600">
              {inspeccion.fechaHora}
            </span>
          </div>

          <div className="border-t border-slate-200/60 pt-2 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Trabajador:</span>
              <span className="font-bold text-slate-800 text-right">{inspeccion.trabajadorNombre}</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500">DNI / Área:</span>
              <span className="text-slate-700 font-mono">{inspeccion.dni} · {inspeccion.area}</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500">Empresa:</span>
              <span className={`font-semibold px-1.5 py-0.5 rounded text-[10px] ${
                isPerpol ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
              }`}>
                {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500">EPPs Evaluados:</span>
              <span className="font-semibold text-slate-800">{detallesCount} ítem{detallesCount === 1 ? '' : 's'}</span>
            </div>
          </div>
        </div>

        {/* Advertencia */}
        <div className="p-3 bg-rose-50/70 rounded-xl border border-rose-200 text-xs text-rose-800 flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            ¿Está seguro de que desea borrar este registro de inspección? Esta acción eliminará el informe técnico de la base de datos local y de la sincronización en Google Sheets.
          </p>
        </div>

        {/* Botones de acción */}
        <div className="flex items-center justify-end gap-2.5 pt-2">
          <button
            type="button"
            onClick={onClose}
            disabled={eliminando}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer shadow-2xs transition-colors disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirmar}
            disabled={eliminando}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{eliminando ? 'Borrando...' : 'Confirmar Eliminación'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
