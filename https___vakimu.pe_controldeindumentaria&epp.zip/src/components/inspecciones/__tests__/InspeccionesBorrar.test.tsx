import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react';
import React from 'react';
import { InspeccionesModule } from '../InspeccionesModule';
import { InspeccionDeleteModal } from '../components/InspeccionDeleteModal';
import { InspeccionEPP, Trabajador } from '../../../types';
import { inspeccionesStorage } from '../../../services/storage/inspeccionesStorage';

const mockInspecciones: InspeccionEPP[] = [
  {
    id: 'INSP-2026-0001',
    numeroInspeccion: 'INS-0001',
    fechaHora: '2026-10-25 10:30',
    codigoTrabajador: 'TRAB-001',
    trabajadorNombre: 'JUAN CARLOS PEREZ',
    dni: '45728823',
    area: 'OPERACIONES',
    empresaId: 'EMP-PERPOL',
    empresaNombre: 'PERPOL IDEAS S.A.C.',
    cargo: 'OPERARIO',
    inspectorResponsable: 'Ing. Supervisor SSOMA',
    lugarInspeccion: 'Planta Principal',
    observacionesGenerales: 'Inspección de rutina',
    estado: 'Confirmado',
    fechaCreacion: '2026-10-25 10:30:00',
    operationId: 'OP-INSP-001',
    detalles: [
      {
        idDetalle: 'DET-1',
        idInspeccion: 'INSP-2026-0001',
        codigoEPP: 'CASCO-01',
        articulo: 'Casco de Seguridad',
        talla: 'Estándar',
        idEntregaOrigen: 'ENT-001',
        idDetalleEntregaOrigen: 'DET-001-1',
        fechaEntregaReferencia: '2026-01-15',
        cantidadReferencia: 1,
        fechaRenovacionReferencia: '2027-01-15',
        resultado: 'Buen estado',
        accion: 'Sin acción requerida',
        estadoAccion: 'No aplica',
        hallazgo: 'En buen estado'
      }
    ]
  }
];

const mockTrabajadores: Trabajador[] = [
  {
    codigo: 'TRAB-001',
    dni: '45728823',
    nombreCompleto: 'JUAN CARLOS PEREZ',
    area: 'OPERACIONES',
    cargo: 'OPERARIO',
    empresaId: 'EMP-PERPOL',
    empresaNombre: 'PERPOL IDEAS S.A.C.',
    fechaIngreso: '2024-01-10',
    estado: 'Activo'
  }
];

describe('InspeccionesModule - Botón de acción para borrar inspección', () => {
  it('renderiza el botón "Borrar" en la columna de Acciones del registro de inspecciones', () => {
    render(
      <InspeccionesModule
        trabajadores={mockTrabajadores}
        inspecciones={mockInspecciones}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={vi.fn()}
        onIniciarReposicionDesdeInspeccion={vi.fn()}
        onInspeccionGuardada={vi.fn()}
      />
    );

    const btnBorrar = screen.getByRole('button', { name: /Borrar inspección INS-0001/i });
    expect(btnBorrar).toBeInTheDocument();
    expect(btnBorrar).toHaveTextContent('Borrar');
  });

  it('abre el modal de confirmación al hacer clic en "Borrar" con los datos del registro', () => {
    render(
      <InspeccionesModule
        trabajadores={mockTrabajadores}
        inspecciones={mockInspecciones}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={vi.fn()}
        onIniciarReposicionDesdeInspeccion={vi.fn()}
        onInspeccionGuardada={vi.fn()}
      />
    );

    const btnBorrar = screen.getByRole('button', { name: /Borrar inspección INS-0001/i });
    fireEvent.click(btnBorrar);

    const modal = screen.getByRole('alertdialog');
    expect(modal).toBeInTheDocument();
    expect(within(modal).getByText('Eliminar Registro de Inspección')).toBeInTheDocument();
    expect(within(modal).getByText('INS-0001')).toBeInTheDocument();
    expect(within(modal).getByText('JUAN CARLOS PEREZ')).toBeInTheDocument();
    expect(within(modal).getByText(/45728823/)).toBeInTheDocument();
  });

  it('permite cancelar la eliminación cerrando el modal', () => {
    render(
      <InspeccionesModule
        trabajadores={mockTrabajadores}
        inspecciones={mockInspecciones}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={vi.fn()}
        onIniciarReposicionDesdeInspeccion={vi.fn()}
        onInspeccionGuardada={vi.fn()}
      />
    );

    fireEvent.click(screen.getByRole('button', { name: /Borrar inspección INS-0001/i }));
    expect(screen.getByRole('alertdialog')).toBeInTheDocument();

    const btnCancelar = screen.getByRole('button', { name: /Cancelar/i });
    fireEvent.click(btnCancelar);

    expect(screen.queryByRole('alertdialog')).not.toBeInTheDocument();
  });

  it('ejecuta onEliminarInspeccion al confirmar la eliminación', async () => {
    const onEliminarInspeccionMock = vi.fn().mockResolvedValue({ success: true, mensaje: 'Eliminado' });
    const onInspeccionGuardadaMock = vi.fn();

    render(
      <InspeccionesModule
        trabajadores={mockTrabajadores}
        inspecciones={mockInspecciones}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={vi.fn()}
        onIniciarReposicionDesdeInspeccion={vi.fn()}
        onInspeccionGuardada={onInspeccionGuardadaMock}
        onEliminarInspeccion={onEliminarInspeccionMock}
      />
    );

    fireEvent.click(screen.getByRole('button', { name: /Borrar inspección INS-0001/i }));
    const btnConfirmar = screen.getByRole('button', { name: /Confirmar Eliminación/i });
    fireEvent.click(btnConfirmar);

    await waitFor(() => {
      expect(onEliminarInspeccionMock).toHaveBeenCalledWith('INSP-2026-0001');
    });
  });
});

describe('inspeccionesStorage - Eliminación en storage', () => {
  beforeEach(() => {
    inspeccionesStorage.reset();
    inspeccionesStorage.setAll([mockInspecciones[0]]);
  });

  it('elimina la inspección por ID o por número correlativo', async () => {
    const totalInicial = inspeccionesStorage.getAll().length;
    const primera = inspeccionesStorage.getAll()[0];

    const res = await inspeccionesStorage.delete(primera.id);
    expect(res.success).toBe(true);

    const trasEliminar = inspeccionesStorage.getAll();
    expect(trasEliminar.length).toBe(totalInicial - 1);
    expect(trasEliminar.find(i => i.id === primera.id)).toBeUndefined();
  }, 15000);

  it('retorna error amigable si la inspección no existe', async () => {
    const res = await inspeccionesStorage.delete('INSP-NO-EXISTE-9999');
    expect(res.success).toBe(false);
    expect(res.mensaje).toContain('no encontrada');
  });
});
