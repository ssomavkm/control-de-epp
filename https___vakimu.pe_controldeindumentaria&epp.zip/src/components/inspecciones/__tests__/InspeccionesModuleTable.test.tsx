import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { InspeccionesModule } from '../InspeccionesModule';
import { storageService } from '../../../services/storageService';
import { Trabajador } from '../../../types';

vi.mock('../../../services/storageService', () => ({
  storageService: {
    getUltimosEPPEntregadosPorTrabajador: vi.fn(),
    generarNuevoNumeroInspeccion: vi.fn().mockReturnValue('INS-0003'),
    registrarInspeccion: vi.fn().mockResolvedValue({ success: true }),
    getZonasSST: vi.fn().mockReturnValue([])
  }
}));

const mockTrabajadores: Trabajador[] = [
  {
    codigo: 'TRAB-001',
    dni: '70105321',
    nombreCompleto: 'ROJAS ALDERETE JHON PIERO',
    area: 'PRODUCCION',
    cargo: 'SUPERVISOR DE SSOMA',
    empresaId: 'EMP-TR3',
    empresaNombre: 'TR3 ALIMENTOS S.A.C.',
    fechaIngreso: '2024-11-18',
    estado: 'Activo'
  }
];

describe('InspeccionesModule - Tabla Sección 2', () => {
  it('renderiza la lista de EPPs en formato tabla con las columnas solicitadas', () => {
    vi.mocked(storageService.getUltimosEPPEntregadosPorTrabajador).mockReturnValue([
      {
        idDetalle: 'DET-01',
        idEntrega: 'REG-2026-0884',
        codigoEPP: 'UNI-IND-31-TM',
        articulo: 'Pantalon blanco sin bolsillo',
        talla: 'M',
        cantidad: 1,
        fechaRenovacion: '2027-04-13',
        fechaEntrega: '2026-10-15',
        unidad: 'Unidad'
      } as any
    ]);

    render(
      <InspeccionesModule
        trabajadores={mockTrabajadores}
        inspecciones={[]}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={vi.fn()}
        onIniciarReposicionDesdeInspeccion={vi.fn()}
        onInspeccionGuardada={vi.fn()}
      />
    );

    // Clic en Nueva Inspección
    const btnNueva = screen.getAllByRole('button', { name: /Nueva Inspección/i })[0];
    fireEvent.click(btnNueva);

    // Simular selección de trabajador
    const searchInput = screen.getByPlaceholderText(/Escriba nombre, apellido o DNI/i);
    fireEvent.change(searchInput, { target: { value: 'ROJAS' } });

    const suggestion = screen.getByText(/ROJAS ALDERETE JHON PIERO/i);
    fireEvent.click(suggestion);

    // Verificar que la tabla se renderiza
    expect(screen.getByRole('table')).toBeInTheDocument();

    // Verificar encabezados de la tabla
    expect(screen.getByText('N°')).toBeInTheDocument();
    expect(screen.getByText('F. Entrega')).toBeInTheDocument();
    expect(screen.getByText('Artículo / EPP')).toBeInTheDocument();
    expect(screen.getByText('Cant.')).toBeInTheDocument();
    expect(screen.getByText('F. Vencimiento')).toBeInTheDocument();
    expect(screen.getByText('Resultado Inspección')).toBeInTheDocument();
    expect(screen.getByText('Acción Requerida')).toBeInTheDocument();
    expect(screen.getByText('Estado Acción')).toBeInTheDocument();
    expect(screen.getByText('Observación')).toBeInTheDocument();

    // Verificar contenido de fila
    expect(screen.getByText('Pantalon blanco sin bolsillo')).toBeInTheDocument();
    expect(screen.getByText('REG-2026-0884')).toBeInTheDocument();
    expect(screen.getByText('2026-10-15')).toBeInTheDocument();
    expect(screen.getByText('2027-04-13')).toBeInTheDocument();
    expect(screen.getByText('Vigente al Cese')).toBeInTheDocument();
  });
});
