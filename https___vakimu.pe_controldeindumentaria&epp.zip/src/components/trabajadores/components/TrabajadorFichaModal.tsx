import React from 'react';
import { Users, X, QrCode, ReceiptText, AlertTriangle, HardHat, Edit3 } from 'lucide-react';
import { Trabajador, EntregaEPP } from '../../../types';
import { StatusBadge } from '../../common/StatusBadge';
import { calcularEdad, getTipoDocumento, compararFechasDesc } from '../../../utils/formatters';

interface TrabajadorFichaModalProps {
  fichaTrabajador: Trabajador | null;
  entregas: EntregaEPP[];
  onClose: () => void;
  onVerQR: (t: Trabajador) => void;
  onEditar: (t: Trabajador) => void;
  onNuevaEntrega: (codigo: string) => void;
  onGenerarDescuento?: (codigo: string) => void;
  onReportarInfraccion?: (codigo: string) => void;
}

export const TrabajadorFichaModal: React.FC<TrabajadorFichaModalProps> = ({
  fichaTrabajador,
  entregas,
  onClose,
  onVerQR,
  onEditar,
  onNuevaEntrega,
  onGenerarDescuento,
  onReportarInfraccion
}) => {
  // Soporte para cerrar con tecla Escape
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (fichaTrabajador) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [fichaTrabajador, onClose]);

  if (!fichaTrabajador) return null;

  const entregasAsociadas = entregas
    .filter(e => e.codigoTrabajador === fichaTrabajador.codigo)
    .sort((a, b) => compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro));
  const edadCalculada = calcularEdad(fichaTrabajador.fechaNacimiento);

  return (
    <div 
      role="dialog"
      aria-modal="true"
      aria-labelledby="titulo-ficha-trabajador"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 id="titulo-ficha-trabajador" className="text-base font-bold text-white flex items-center gap-2">
                <span>Ficha del Trabajador — {fichaTrabajador.dni}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    getTipoDocumento(fichaTrabajador.dni) === 'C.E.'
                      ? 'bg-amber-950 text-amber-300 border-amber-800'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {getTipoDocumento(fichaTrabajador.dni) === 'C.E.' ? 'Carné de Extranjería' : 'DNI'}
                </span>
              </h3>
              <p className="text-xs text-slate-300">{fichaTrabajador.nombreCompleto}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={`Cerrar ficha de ${fichaTrabajador.nombreCompleto}`}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs overflow-y-auto flex-1">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Empresa</span>
              <span className="text-slate-900 font-semibold">{fichaTrabajador.empresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold mb-1">Condición</span>
              <StatusBadge condicion={fichaTrabajador.estado} size="sm" />
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Sexo</span>
              <span className="text-slate-800">{fichaTrabajador.sexo === 'F' ? 'Femenino' : 'Masculino'}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Fecha Ingreso</span>
              <span className="text-slate-900 font-mono">{fichaTrabajador.fechaIngreso || 'No registrada'}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-2">
              <h4 className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Datos Personales y Nacimiento</h4>
              <div>
                <span className="text-slate-400 text-[10px] block">Fecha de Nacimiento:</span>
                <span className="text-slate-800 font-mono font-medium">
                  {fichaTrabajador.fechaNacimiento || 'No registrada'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Edad Actual:</span>
                <span className="text-emerald-700 font-semibold font-mono">
                  {edadCalculada !== null
                    ? `${edadCalculada} años`
                    : 'No calculada'}
                </span>
              </div>
            </div>

            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-2">
              <h4 className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Puesto y Ubicación Operativa</h4>
              <div>
                <span className="text-slate-400 text-[10px] block">Puesto / Cargo:</span>
                <span className="text-slate-900 font-medium">{fichaTrabajador.cargo || 'Sin puesto'}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Área Asignada:</span>
                <span className="text-slate-800">{fichaTrabajador.area || 'Sin área'}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Información de Contacto</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <span className="text-slate-400 text-[10px] block">Teléfono / Celular:</span>
                <span className="text-slate-800 font-mono">{fichaTrabajador.telefono || 'Sin teléfono registrado'}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Correo Electrónico:</span>
                <span className="text-slate-800 font-mono">{fichaTrabajador.email || 'Sin correo registrado'}</span>
              </div>
            </div>
          </div>

          {/* Historial rápido de entregas asociadas */}
          <div className="pt-2">
            <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider block mb-2">
              Historial de Entregas de EPP
            </span>
            {entregasAsociadas.length === 0 ? (
              <div className="p-3 bg-slate-50 rounded-lg text-slate-400 border border-slate-200 text-center">
                No registra actas de entrega de EPP hasta el momento.
              </div>
            ) : (
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {entregasAsociadas.map((e, idx) => (
                  <div key={e.id ? `${e.id}-${idx}` : `entrega-${idx}`} className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-slate-900">{e.numeroRegistro}</span>
                      <span className="text-[10px] text-slate-400 ml-2 font-mono">{e.fechaEntrega}</span>
                    </div>
                    <span className="font-mono text-emerald-700 font-semibold">{e.totalUnidades} uds</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              onClose();
              onVerQR(fichaTrabajador);
            }}
            className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
          >
            <QrCode className="w-3.5 h-3.5 text-indigo-600" />
            <span>Credencial QR</span>
          </button>

          <div className="flex items-center gap-2">
            {onGenerarDescuento && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGenerarDescuento(fichaTrabajador.codigo);
                }}
                className="px-3 py-1.5 rounded-lg border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ReceiptText className="w-3.5 h-3.5 text-amber-600" />
                <span>Descuento EPP</span>
              </button>
            )}

            {onReportarInfraccion && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onReportarInfraccion(fichaTrabajador.codigo);
                }}
                className="px-3 py-1.5 rounded-lg border border-rose-300 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                <span>Infracción</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                onClose();
                onNuevaEntrega(fichaTrabajador.codigo);
              }}
              className="px-3 py-1.5 rounded-lg border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <HardHat className="w-3.5 h-3.5 text-emerald-600" />
              <span>Entregar EPP</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onEditar(fichaTrabajador);
              }}
              className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
            >
              <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Editar Ficha</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
