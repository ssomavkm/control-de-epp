import React from 'react';
import { Search, X, FileSpreadsheet, FileText, Plus } from 'lucide-react';

export type CondicionFiltro = 'TODOS' | 'Activo' | 'Inactivo' | 'Cesado';

interface TrabajadoresFiltersProps {
  busqueda: string;
  setBusqueda: (q: string) => void;
  condicionFiltro: CondicionFiltro;
  setCondicionFiltro: (c: CondicionFiltro) => void;
  conteosCondicion: {
    TODOS: number;
    Activo: number;
    Inactivo: number;
    Cesado: number;
  };
  totalFiltrados: number;
  generandoPdf: boolean;
  onExportarCSV: () => void;
  onExportarPDF: () => void;
  onNuevoTrabajador: () => void;
}

const CHIPS_CONDICION: { id: CondicionFiltro; label: string; countKey: 'TODOS' | 'Activo' | 'Inactivo' | 'Cesado' }[] = [
  { id: 'TODOS', label: 'Todo', countKey: 'TODOS' },
  { id: 'Activo', label: 'Activos', countKey: 'Activo' },
  { id: 'Inactivo', label: 'Inactivos', countKey: 'Inactivo' },
  { id: 'Cesado', label: 'Cesó', countKey: 'Cesado' }
];

export const TrabajadoresFilters: React.FC<TrabajadoresFiltersProps> = ({
  busqueda,
  setBusqueda,
  condicionFiltro,
  setCondicionFiltro,
  conteosCondicion,
  totalFiltrados,
  generandoPdf,
  onExportarCSV,
  onExportarPDF,
  onNuevoTrabajador
}) => {
  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Búsqueda rápida con feedback y limpiado instantáneo */}
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Buscar por nombre o DNI..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
          />
          {busqueda && (
            <button 
              type="button" 
              onClick={() => setBusqueda('')}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
              title="Limpiar búsqueda"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Acciones principales de exportación y nuevo registro */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onExportarCSV}
            className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
            title="Exportar padrón a formato Excel / CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden sm:inline">Excel</span>
          </button>

          <button
            type="button"
            onClick={onExportarPDF}
            disabled={generandoPdf}
            className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs disabled:opacity-50"
            title="Generar padrón oficial de trabajadores en PDF"
          >
            <FileText className="w-3.5 h-3.5 text-rose-600" />
            <span className="hidden sm:inline">{generandoPdf ? 'Generando...' : 'PDF'}</span>
          </button>

          <button
            type="button"
            onClick={onNuevoTrabajador}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Nuevo Trabajador</span>
          </button>
        </div>
      </div>

      {/* Chips de filtro estandarizados con conteo en vivo */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-slate-100">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 max-w-full">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider hidden sm:inline">
            Condición:
          </span>
          <div className="inline-flex items-center p-1 bg-slate-100/90 rounded-xl border border-slate-200/90 gap-1">
            {CHIPS_CONDICION.map(chip => {
              const activo = condicionFiltro === chip.id;
              const conteo = conteosCondicion[chip.countKey];
              return (
                <button
                  key={chip.id}
                  type="button"
                  onClick={() => setCondicionFiltro(chip.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                    activo
                      ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <span>{chip.label}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono leading-none ${
                      activo
                        ? chip.id === 'Activo'
                          ? 'bg-emerald-100 text-emerald-800 font-bold'
                          : chip.id === 'Inactivo'
                          ? 'bg-amber-100 text-amber-800 font-bold'
                          : chip.id === 'Cesado'
                          ? 'bg-rose-100 text-rose-800 font-bold'
                          : 'bg-slate-200 text-slate-800 font-bold'
                        : 'bg-slate-200/70 text-slate-500'
                    }`}
                  >
                    {conteo}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="text-xs text-slate-500 font-mono-numbers">
          {totalFiltrados === 1
            ? '1 trabajador encontrado'
            : `${totalFiltrados} trabajadores encontrados`}
        </div>
      </div>
    </div>
  );
};
