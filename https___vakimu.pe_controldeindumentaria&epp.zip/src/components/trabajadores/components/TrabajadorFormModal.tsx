import React, { useState, useEffect, useMemo } from 'react';
import { Users, X, AlertCircle, Save } from 'lucide-react';
import { Trabajador, EmpresaId, Empresa, EstadoTrabajador } from '../../../types';
import { calcularEdad, getTipoDocumento } from '../../../utils/formatters';

interface TrabajadorFormModalProps {
  isOpen: boolean;
  trabajadorEditando: Trabajador | null;
  trabajadores: Trabajador[];
  empresas: Empresa[];
  empresaFiltro: string;
  onClose: () => void;
  onGuardar: (trabajador: Trabajador) => void;
}

export const TrabajadorFormModal: React.FC<TrabajadorFormModalProps> = ({
  isOpen,
  trabajadorEditando,
  trabajadores,
  empresas,
  empresaFiltro,
  onClose,
  onGuardar
}) => {
  const [formDni, setFormDni] = useState<string>('');
  const [formNombre, setFormNombre] = useState<string>('');
  const [formEmpresaId, setFormEmpresaId] = useState<EmpresaId>('EMP-PERPOL');
  const [formArea, setFormArea] = useState<string>('');
  const [formCargo, setFormCargo] = useState<string>('');
  const [formFechaIngreso, setFormFechaIngreso] = useState<string>('');
  const [formFechaNacimiento, setFormFechaNacimiento] = useState<string>('');
  const [formSexo, setFormSexo] = useState<'M' | 'F'>('M');
  const [formEstado, setFormEstado] = useState<EstadoTrabajador>('Activo');
  const [formTelefono, setFormTelefono] = useState<string>('');
  const [formEmail, setFormEmail] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);

  const edadCalculada = useMemo(
    () => calcularEdad(formFechaNacimiento),
    [formFechaNacimiento]
  );

  useEffect(() => {
    if (!isOpen) return;

    if (trabajadorEditando) {
      setFormDni(trabajadorEditando.dni);
      setFormNombre(trabajadorEditando.nombreCompleto);
      setFormEmpresaId(trabajadorEditando.empresaId);
      setFormArea(trabajadorEditando.area);
      setFormCargo(trabajadorEditando.cargo);
      setFormFechaIngreso(trabajadorEditando.fechaIngreso);
      setFormFechaNacimiento(trabajadorEditando.fechaNacimiento || '');
      setFormSexo(trabajadorEditando.sexo || 'M');
      setFormEstado(trabajadorEditando.estado);
      setFormTelefono(trabajadorEditando.telefono || '');
      setFormEmail(trabajadorEditando.email || '');
      setFormError(null);
    } else {
      const empId: EmpresaId = empresaFiltro === 'EMP-TR3' ? 'EMP-TR3' : 'EMP-PERPOL';
      setFormEmpresaId(empId);
      setFormDni('');
      setFormNombre('');
      setFormArea('Producción');
      setFormCargo('');
      setFormFechaIngreso(new Date().toISOString().slice(0, 10));
      setFormFechaNacimiento('');
      setFormSexo('M');
      setFormEstado('Activo');
      setFormTelefono('');
      setFormEmail('');
      setFormError(null);
    }
  }, [isOpen, trabajadorEditando, empresaFiltro]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const dniLimpio = formDni.trim().toUpperCase();
    const nombresLimpios = formNombre.trim();

    if (!dniLimpio || !nombresLimpios) {
      setFormError('El DNI / C.E. y los Apellidos y Nombres son obligatorios.');
      return;
    }

    if (dniLimpio.length < 8) {
      setFormError('El documento debe tener 8 dígitos para DNI o entre 9 y 12 caracteres para C.E.');
      return;
    }

    if (dniLimpio.length > 12) {
      setFormError('El documento (C.E.) no puede exceder los 12 caracteres.');
      return;
    }

    const duplicado = trabajadores.find(
      (t) =>
        t.dni.toLowerCase().trim() === dniLimpio.toLowerCase() &&
        (!trabajadorEditando || t.dni !== trabajadorEditando.dni)
    );

    if (duplicado) {
      setFormError(
        `Ya existe un trabajador registrado con el DNI / C.E. '${dniLimpio}' (${duplicado.nombreCompleto} - ${duplicado.empresaNombre}).`
      );
      return;
    }

    if (!formArea.trim() || !formCargo.trim()) {
      setFormError('El área y puesto/cargo son obligatorios.');
      return;
    }

    const emp = empresas.find((e) => e.id === formEmpresaId);
    const razonSocial = emp ? emp.razonSocial : (formEmpresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.');

    const trabajadorAGuardar: Trabajador = {
      codigo: trabajadorEditando ? trabajadorEditando.codigo : dniLimpio,
      dni: dniLimpio,
      nombreCompleto: nombresLimpios,
      apellidosNombres: nombresLimpios,
      empresaId: formEmpresaId,
      empresaNombre: razonSocial,
      empresa: razonSocial,
      puesto: formCargo.trim(),
      cargo: formCargo.trim(),
      area: formArea.trim(),
      condicion: formEstado,
      estado: formEstado,
      sexo: formSexo,
      fechaNacimiento: formFechaNacimiento || undefined,
      edad: edadCalculada !== null ? edadCalculada : undefined,
      fechaIngreso: formFechaIngreso || new Date().toISOString().slice(0, 10),
      telefono: formTelefono.trim() || undefined,
      correo: formEmail.trim() || undefined,
      email: formEmail.trim() || undefined
    };

    onGuardar(trabajadorAGuardar);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden flex flex-col animate-in fade-in duration-150">
      <div className="px-5 sm:px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white tracking-tight">
              {trabajadorEditando ? 'Editar Ficha del Trabajador' : 'Registrar Nuevo Trabajador'}
            </h3>
            <p className="text-xs text-slate-300">
              Padrón oficial para dotación y control de EPP (ISO 45001 y Ley N° 29783)
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          title="Cancelar y volver al padrón"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs">
          {formError && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 block">
                  DNI / C.E. <span className="text-rose-500">*</span>
                </label>
                {formDni.trim().length > 0 && (
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${
                      getTipoDocumento(formDni) === 'C.E.'
                        ? 'bg-amber-50 text-amber-800 border-amber-300'
                        : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                    }`}
                  >
                    {getTipoDocumento(formDni) === 'C.E.' ? 'C.E. (Carné de Extranjería)' : 'DNI (8 dígitos)'}
                  </span>
                )}
              </div>
              <input
                type="text"
                maxLength={12}
                value={formDni}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^a-zA-Z0-9]/g, '').slice(0, 12).toUpperCase();
                  setFormDni(val);
                }}
                placeholder="DNI (8 d.) o C.E. (máx 12)"
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all uppercase"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>8 dígitos para DNI | 9-12 para C.E.</span>
                <span>{formDni.length}/12</span>
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Razón Social / Empresa Asignada <span className="text-rose-500">*</span>
              </label>
              <select
                value={formEmpresaId}
                onChange={(e) => setFormEmpresaId(e.target.value as EmpresaId)}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-semibold text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all cursor-pointer"
              >
                <option value="EMP-PERPOL">PERPOL IDEAS S.A.C. (RUC: 20392729977)</option>
                <option value="EMP-TR3">TR3 ALIMENTOS S.A.C. (RUC: 20550842891)</option>
              </select>
              <p className="text-[10px] text-slate-500 mt-1">
                Padrón oficial vinculado a dotación de EPP (FO-SST-GEN-050).
              </p>
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Apellidos y Nombres Completos <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={formNombre}
              onChange={(e) => setFormNombre(e.target.value)}
              placeholder="Ej: Quispe Huamán, Juan Carlos"
              required
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Puesto / Cargo <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={formCargo}
                onChange={(e) => setFormCargo(e.target.value)}
                placeholder="Ej: Operario de Envasado..."
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Área Operativa <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={formArea}
                onChange={(e) => setFormArea(e.target.value)}
                placeholder="Ej: Producción, Calidad, Almacén..."
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Condición <span className="text-rose-500">*</span>
              </label>
              <select
                value={formEstado}
                onChange={(e) => setFormEstado(e.target.value as EstadoTrabajador)}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all cursor-pointer"
              >
                <option value="Activo">Activo (En nómina)</option>
                <option value="Inactivo">Inactivo (Suspendido)</option>
                <option value="Cesado">Cesado (Retirado)</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Sexo <span className="text-rose-500">*</span>
              </label>
              <select
                value={formSexo}
                onChange={(e) => setFormSexo(e.target.value as 'M' | 'F')}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all cursor-pointer"
              >
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 block">F. Nacimiento</label>
                {edadCalculada !== null && (
                  <span className="text-[10px] text-emerald-700 font-semibold font-mono">
                    {edadCalculada} años (Edad)
                  </span>
                )}
              </div>
              <input
                type="date"
                value={formFechaNacimiento}
                onChange={(e) => setFormFechaNacimiento(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Fecha Ingreso</label>
              <input
                type="date"
                value={formFechaIngreso}
                onChange={(e) => setFormFechaIngreso(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Teléfono / Celular</label>
              <input
                type="tel"
                value={formTelefono}
                onChange={(e) => setFormTelefono(e.target.value)}
                placeholder="Ej: 984512345"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Correo Electrónico</label>
              <input
                type="email"
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                placeholder="trabajador@empresa.com"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg font-semibold cursor-pointer shadow-2xs transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold shadow-xs cursor-pointer transition-colors flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>{trabajadorEditando ? 'Guardar Cambios' : 'Registrar Trabajador'}</span>
            </button>
          </div>
        </form>
      </div>
  );
};
