import React from 'react';
import { Users, Building2, CheckCircle2 } from 'lucide-react';

export interface MetricasTrabajadores {
  total: number;
  perpol: number;
  tr3: number;
  activos: number;
  cesados: number;
  tasaActivos: number;
}

interface TrabajadoresStatsProps {
  metricas: MetricasTrabajadores;
}

export const TrabajadoresStats: React.FC<TrabajadoresStatsProps> = ({ metricas }) => {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
          <Users className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Padrón Total</p>
          <p className="text-xl font-bold text-slate-900 font-mono-numbers">{metricas.total}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
          <Building2 className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">PERPOL IDEAS</p>
          <p className="text-xl font-bold text-emerald-800 font-mono-numbers">{metricas.perpol}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
          <Building2 className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">TR3 ALIMENTOS</p>
          <p className="text-xl font-bold text-blue-800 font-mono-numbers">{metricas.tr3}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
          <CheckCircle2 className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Activos en Planta</p>
          <p className="text-xl font-bold text-emerald-700 font-mono-numbers">
            {metricas.tasaActivos}% <span className="text-xs font-normal text-slate-400 font-sans">({metricas.activos} personas)</span>
          </p>
        </div>
      </div>
    </div>
  );
};
