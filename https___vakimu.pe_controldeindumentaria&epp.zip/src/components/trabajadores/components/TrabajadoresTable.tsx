import React from 'react';
import {
  Users,
  FilterX,
  RotateCcw,
  Plus,
  Eye,
  QrCode,
  Edit3,
  Trash2,
  ReceiptText,
  AlertTriangle,
  Scale
} from 'lucide-react';
import { Trabajador } from '../../../types';
import { StatusBadge } from '../../common/StatusBadge';
import { TablePagination } from '../../common/TablePagination';
import { calcularEdad, getTipoDocumento } from '../../../utils/formatters';

interface TrabajadoresTableProps {
  trabajadoresFiltrados: Trabajador[];
  trabajadoresPaginados: Trabajador[];
  busqueda: string;
  condicionFiltro: string;
  indiceInicio: number;
  porPagina: number;
  setPorPagina: (n: number) => void;
  paginaActual: number;
  setPaginaActual: React.Dispatch<React.SetStateAction<number>>;
  totalPaginas: number;
  paginaAjustada: number;
  onLimpiarFiltros: () => void;
  onAbrirCrear: () => void;
  onVerFicha: (t: Trabajador) => void;
  onVerQR: (t: Trabajador) => void;
  onEditar: (t: Trabajador) => void;
  onEliminar: (t: Trabajador) => void;
  onNuevaEntrega: (codigoTrabajador: string) => void;
  onGenerarDescuento?: (codigoTrabajador: string) => void;
  onReportarInfraccion?: (codigoTrabajador: string) => void;
  onLiquidarEPP?: (codigoTrabajador: string) => void;
}

export const TrabajadoresTable: React.FC<TrabajadoresTableProps> = ({
  trabajadoresFiltrados,
  trabajadoresPaginados,
  busqueda,
  condicionFiltro,
  indiceInicio,
  porPagina,
  setPorPagina,
  paginaActual,
  setPaginaActual,
  totalPaginas,
  paginaAjustada,
  onLimpiarFiltros,
  onAbrirCrear,
  onVerFicha,
  onVerQR,
  onEditar,
  onEliminar,
  onNuevaEntrega,
  onGenerarDescuento,
  onReportarInfraccion,
  onLiquidarEPP
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs min-w-[1100px]">
          <thead>
            <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
              <th className="py-3.5 px-3.5 w-36">DNI / C.E.</th>
              <th className="py-3.5 px-3.5 min-w-[190px]">Apellidos y Nombres</th>
              <th className="py-3.5 px-3 w-36">Empresa</th>
              <th className="py-3.5 px-3 min-w-[140px]">Puesto / Cargo</th>
              <th className="py-3.5 px-3 min-w-[120px]">Área</th>
              <th className="py-3.5 px-3 text-center w-28">Condición</th>
              <th className="py-3.5 px-2 text-center w-14">Sexo</th>
              <th className="py-3.5 px-3 w-32">F. Nacimiento</th>
              <th className="py-3.5 px-2.5 text-center w-20">Edad</th>
              <th className="py-3.5 px-3 w-28">F. Ingreso</th>
              <th className="py-3.5 px-3 w-28">Teléfono</th>
              <th className="py-3.5 px-3 min-w-[140px]">Correo</th>
              <th className="py-3.5 px-4 text-center w-40">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {trabajadoresFiltrados.length === 0 ? (
              <tr>
                <td colSpan={13} className="py-14 px-4 text-center">
                  <div className="max-w-md mx-auto space-y-3">
                    <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500">
                      {busqueda || condicionFiltro !== 'TODOS' ? (
                        <FilterX className="w-6 h-6 text-slate-500" />
                      ) : (
                        <Users className="w-6 h-6 text-slate-500" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        {busqueda || condicionFiltro !== 'TODOS'
                          ? 'No se encontraron trabajadores coincidentes'
                          : 'Padrón sin trabajadores registrados'}
                      </h4>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                        {busqueda || condicionFiltro !== 'TODOS'
                          ? `No hay registros con los filtros aplicados ${busqueda ? `("${busqueda}")` : ''}. Restablece la búsqueda o selecciona otra condición laboral.`
                          : 'Aún no se han dado de alta trabajadores en este padrón oficial. Comienza registrando al primer personal.'}
                      </p>
                    </div>
                    <div className="flex items-center justify-center gap-2 pt-1">
                      {(busqueda || condicionFiltro !== 'TODOS') && (
                        <button
                          type="button"
                          onClick={onLimpiarFiltros}
                          className="px-3.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-slate-600" />
                          Restablecer filtros
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={onAbrirCrear}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Registrar Trabajador
                      </button>
                    </div>
                  </div>
                </td>
              </tr>
            ) : (
              trabajadoresPaginados.map((t, idx) => {
                const isPerpol = t.empresaId === 'EMP-PERPOL';
                const esActivo = t.estado === 'Activo';
                const tipoDoc = getTipoDocumento(t.dni);
                const edadCalc = t.edad !== undefined && t.edad !== null && t.edad !== '' 
                  ? Number(t.edad) 
                  : calcularEdad(t.fechaNacimiento);

                return (
                  <tr key={t.codigo ? `${t.codigo}-${idx}` : `${t.dni || 't'}-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3.5">
                      <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900">
                        <span>{t.dni}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider uppercase border ${
                            tipoDoc === 'C.E.'
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : 'bg-slate-100 text-slate-800 border-slate-300'
                          }`}
                          title={tipoDoc === 'C.E.' ? 'Carné de Extranjería' : 'Documento Nacional de Identidad'}
                        >
                          {tipoDoc}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-3.5">
                      <div className="font-bold text-slate-900 tracking-tight">{t.nombreCompleto || t.apellidosNombres}</div>
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold border ${
                        isPerpol 
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-300' 
                          : 'bg-blue-100 text-blue-900 border-blue-300'
                      }`}>
                        {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      <span className="font-semibold text-slate-900">{t.cargo || (t as any).puesto}</span>
                    </td>

                    <td className="py-3 px-3">
                      <span className="text-slate-700 font-medium">{t.area}</span>
                    </td>

                    <td className="py-3 px-3 text-center whitespace-nowrap">
                      <StatusBadge condicion={t.estado || (t as any).condicion} />
                    </td>

                    <td className="py-3 px-2 text-center whitespace-nowrap">
                      <span className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-bold ${
                        t.sexo === 'F' ? 'bg-purple-100 text-purple-900' : 'bg-sky-100 text-sky-900'
                      }`}>
                        {t.sexo || 'M'}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-slate-800 text-[11px] font-mono whitespace-nowrap">
                      {t.fechaNacimiento ? (
                        <span className="font-medium">{t.fechaNacimiento.slice(0, 10)}</span>
                      ) : (
                        <span className="text-slate-400 font-medium">-</span>
                      )}
                    </td>

                    <td className="py-3 px-2.5 text-center whitespace-nowrap">
                      {edadCalc !== null && !isNaN(edadCalc) ? (
                        <span className="inline-block px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-800 border border-slate-200">
                          {edadCalc} a.
                        </span>
                      ) : (
                        <span className="text-slate-400 font-mono text-[11px]">-</span>
                      )}
                    </td>

                    <td className="py-3 px-3 font-mono font-medium text-slate-800 whitespace-nowrap text-[11px]">
                      {t.fechaIngreso ? t.fechaIngreso.slice(0, 10) : '-'}
                    </td>

                    <td className="py-3 px-3 font-mono font-medium text-slate-800 text-[11px] whitespace-nowrap">
                      {t.telefono || '-'}
                    </td>

                    <td className="py-3 px-3 text-slate-700 text-[11px]">
                      <span className="truncate block max-w-[160px] font-medium" title={t.email || (t as any).correo || ''}>
                        {t.email || (t as any).correo || '-'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => onVerFicha(t)}
                          aria-label={`Ver ficha técnica de ${t.nombreCompleto || t.apellidosNombres}`}
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                          title="Ver Ficha Detallada del Trabajador"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onVerQR(t)}
                          aria-label={`Ver credencial QR SST de ${t.nombreCompleto || t.apellidosNombres}`}
                          className="p-1.5 text-slate-500 hover:text-indigo-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                          title="Ver Credencial QR de SST"
                        >
                          <QrCode className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEditar(t)}
                          aria-label={`Editar datos de ${t.nombreCompleto || t.apellidosNombres}`}
                          className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                          title="Editar Datos del Trabajador"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEliminar(t)}
                          aria-label={`Eliminar a ${t.nombreCompleto || t.apellidosNombres} del padrón`}
                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                          title="Eliminar Trabajador del Padrón"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        {esActivo && (
                          <>
                            <button
                              type="button"
                              onClick={() => onNuevaEntrega(t.codigo)}
                              aria-label={`Registrar entrega de EPP para ${t.nombreCompleto || t.apellidosNombres}`}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold rounded-lg text-[11px] border border-emerald-200 transition-colors shadow-2xs cursor-pointer ml-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                              title="Registrar Entrega de EPP para este trabajador"
                            >
                              Entregar
                            </button>

                            {onGenerarDescuento && (
                              <button
                                type="button"
                                onClick={() => onGenerarDescuento(t.codigo)}
                                className="p-1.5 text-slate-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                                title="Generar Autorización de Descuento por Pérdida de EPP"
                              >
                                <ReceiptText className="w-4 h-4 text-amber-600" />
                              </button>
                            )}

                            {onReportarInfraccion && (
                              <button
                                type="button"
                                onClick={() => onReportarInfraccion(t.codigo)}
                                className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="Generar Reporte de Infracción por No Uso de EPP"
                              >
                                <AlertTriangle className="w-4 h-4 text-rose-500" />
                              </button>
                            )}
                          </>
                        )}

                        {onLiquidarEPP && (
                          <button
                            type="button"
                            onClick={() => onLiquidarEPP(t.codigo)}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              t.estado === 'Cesado'
                                ? 'text-purple-700 bg-purple-50 hover:bg-purple-100 ring-1 ring-purple-200'
                                : 'text-slate-500 hover:text-purple-700 hover:bg-purple-50'
                            }`}
                            title="Emitir Formato Oficial de Liquidación de EPP por Cese (FO-SST-LIQ-001)"
                          >
                            <Scale className="w-4 h-4 text-purple-600" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Paginación */}
      <TablePagination
        totalRegistros={trabajadoresFiltrados.length}
        paginaActual={paginaActual}
        setPaginaActual={setPaginaActual}
        porPagina={porPagina}
        setPorPagina={setPorPagina}
        nombreEntidadPlural="trabajadores"
      />
    </div>
  );
};
