import React from 'react';
import { Trash2 } from 'lucide-react';
import { Trabajador } from '../../../types';
import { getTipoDocumento } from '../../../utils/formatters';

interface TrabajadorDeleteModalProps {
  trabajadorAEliminar: Trabajador | null;
  onClose: () => void;
  onConfirmar: () => void;
}

export const TrabajadorDeleteModal: React.FC<TrabajadorDeleteModalProps> = ({
  trabajadorAEliminar,
  onClose,
  onConfirmar
}) => {
  // Soporte para cerrar con tecla Escape
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (trabajadorAEliminar) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [trabajadorAEliminar, onClose]);

  if (!trabajadorAEliminar) return null;

  return (
    <div 
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="titulo-eliminar-trabajador"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 border border-rose-200">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h3 id="titulo-eliminar-trabajador" className="text-sm font-bold text-slate-900">Eliminar Trabajador del Padrón</h3>
            <p className="text-xs text-slate-500">Esta acción removerá el registro del padrón oficial.</p>
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
          <div className="font-semibold text-slate-800">{trabajadorAEliminar.nombreCompleto}</div>
          <div className="text-slate-500 font-mono">
            {getTipoDocumento(trabajadorAEliminar.dni)}: {trabajadorAEliminar.dni}
          </div>
          <div className="text-slate-500">{trabajadorAEliminar.empresaNombre}</div>
        </div>

        <p className="text-xs text-slate-600">
          ¿Estás seguro de que deseas eliminar a este trabajador? Las entregas históricas previas mantendrán la trazabilidad del registro documental.
        </p>

        <div className="flex items-center justify-end gap-2.5 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer shadow-2xs transition-colors"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirmar}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Confirmar Eliminación</span>
          </button>
        </div>
      </div>
    </div>
  );
};
