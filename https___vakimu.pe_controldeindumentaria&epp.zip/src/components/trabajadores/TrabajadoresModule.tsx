import React from 'react';
import { X } from 'lucide-react';
import { Trabajador, Empresa, EntregaEPP } from '../../types';
import { QRModal } from '../common/QRModal';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { TrabajadoresStats } from './components/TrabajadoresStats';
import { TrabajadoresFilters } from './components/TrabajadoresFilters';
import { TrabajadoresTable } from './components/TrabajadoresTable';
import { TrabajadorFormModal } from './components/TrabajadorFormModal';
import { TrabajadorFichaModal } from './components/TrabajadorFichaModal';
import { TrabajadorDeleteModal } from './components/TrabajadorDeleteModal';
import { useTrabajadores } from './hooks/useTrabajadores';

interface TrabajadoresModuleProps {
  trabajadores: Trabajador[];
  empresas: Empresa[];
  entregas: EntregaEPP[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  onGuardarTrabajador: (trabajador: Trabajador) => void;
  onEliminarTrabajador?: (codigo: string) => void;
  onNuevaEntregaParaTrabajador: (codigoTrabajador: string) => void;
  onGenerarDescuentoParaTrabajador?: (codigoTrabajador: string) => void;
  onReportarInfraccionParaTrabajador?: (codigoTrabajador: string) => void;
  onLiquidarEPPParaTrabajador?: (codigoTrabajador: string) => void;
}

export const TrabajadoresModule: React.FC<TrabajadoresModuleProps> = ({
  trabajadores,
  empresas,
  entregas,
  empresaFiltro,
  onCambiarEmpresaFiltro,
  onGuardarTrabajador,
  onEliminarTrabajador,
  onNuevaEntregaParaTrabajador,
  onGenerarDescuentoParaTrabajador,
  onReportarInfraccionParaTrabajador,
  onLiquidarEPPParaTrabajador
}) => {
  const {
    busqueda,
    setBusqueda,
    condicionFiltro,
    setCondicionFiltro,
    paginaActual,
    setPaginaActual,
    porPagina,
    setPorPagina,
    modalAbierto,
    setModalAbierto,
    trabajadorEditando,
    fichaTrabajador,
    setFichaTrabajador,
    trabajadorAEliminar,
    setTrabajadorAEliminar,
    qrTrabajador,
    setQrTrabajador,
    viewerPdfUrl,
    setViewerPdfUrl,
    viewerPdfBuffer,
    viewerPdfName,
    generandoPdf,
    errorPadronPdf,
    setErrorPadronPdf,
    trabajadoresFiltrados,
    metricas,
    conteosCondicion,
    totalPaginas,
    paginaAjustada,
    indiceInicio,
    trabajadoresPaginados,
    exportarCSV,
    exportarPDF,
    ejecutarEliminacion,
    abrirModalCrear,
    abrirModalEditar
  } = useTrabajadores({
    trabajadores,
    empresaFiltro,
    onEliminarTrabajador
  });

  return (
    <div className="space-y-6">
      {/* Alerta de error en exportación PDF */}
      {errorPadronPdf && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="font-bold">Error:</span>
            <span>{errorPadronPdf}</span>
          </div>
          <button
            onClick={() => setErrorPadronPdf(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {!modalAbierto ? (
        <>
          {/* Tarjetas KPI de Resumen de Personal */}
          <TrabajadoresStats metricas={metricas} />

          {/* Barra de Herramientas con Filtros y Chips */}
          <TrabajadoresFilters
            busqueda={busqueda}
            setBusqueda={setBusqueda}
            condicionFiltro={condicionFiltro}
            setCondicionFiltro={setCondicionFiltro}
            conteosCondicion={conteosCondicion}
            totalFiltrados={trabajadoresFiltrados.length}
            generandoPdf={generandoPdf}
            onExportarCSV={exportarCSV}
            onExportarPDF={exportarPDF}
            onNuevoTrabajador={abrirModalCrear}
          />

          {/* Tabla de Trabajadores */}
          <TrabajadoresTable
            trabajadoresFiltrados={trabajadoresFiltrados}
            trabajadoresPaginados={trabajadoresPaginados}
            busqueda={busqueda}
            condicionFiltro={condicionFiltro}
            indiceInicio={indiceInicio}
            porPagina={porPagina}
            setPorPagina={setPorPagina}
            paginaActual={paginaActual}
            setPaginaActual={setPaginaActual}
            totalPaginas={totalPaginas}
            paginaAjustada={paginaAjustada}
            onLimpiarFiltros={() => {
              setBusqueda('');
              setCondicionFiltro('TODOS');
              setPaginaActual(1);
            }}
            onAbrirCrear={abrirModalCrear}
            onVerFicha={setFichaTrabajador}
            onVerQR={setQrTrabajador}
            onEditar={abrirModalEditar}
            onEliminar={setTrabajadorAEliminar}
            onNuevaEntrega={onNuevaEntregaParaTrabajador}
            onGenerarDescuento={onGenerarDescuentoParaTrabajador}
            onReportarInfraccion={onReportarInfraccionParaTrabajador}
            onLiquidarEPP={onLiquidarEPPParaTrabajador}
          />
        </>
      ) : (
        /* VISTA INTEGRADA A PANTALLA COMPLETA: REGISTRO Y EDICIÓN INDIVIDUAL DE TRABAJADOR */
        <TrabajadorFormModal
          isOpen={modalAbierto}
          trabajadorEditando={trabajadorEditando}
          trabajadores={trabajadores}
          empresas={empresas}
          empresaFiltro={empresaFiltro}
          onClose={() => setModalAbierto(false)}
          onGuardar={(trabajadorAGuardar) => {
            onGuardarTrabajador(trabajadorAGuardar);
            setModalAbierto(false);
          }}
        />
      )}

      {/* MODAL 2: FICHA DETALLADA DEL TRABAJADOR */}
      <TrabajadorFichaModal
        fichaTrabajador={fichaTrabajador}
        entregas={entregas}
        onClose={() => setFichaTrabajador(null)}
        onVerQR={(t) => {
          setFichaTrabajador(null);
          setQrTrabajador(t);
        }}
        onEditar={(t) => {
          setFichaTrabajador(null);
          abrirModalEditar(t);
        }}
        onNuevaEntrega={(codigo) => {
          setFichaTrabajador(null);
          onNuevaEntregaParaTrabajador(codigo);
        }}
        onGenerarDescuento={onGenerarDescuentoParaTrabajador ? (codigo) => {
          setFichaTrabajador(null);
          onGenerarDescuentoParaTrabajador(codigo);
        } : undefined}
        onReportarInfraccion={onReportarInfraccionParaTrabajador ? (codigo) => {
          setFichaTrabajador(null);
          onReportarInfraccionParaTrabajador(codigo);
        } : undefined}
      />

      {/* MODAL 3: CONFIRMAR ELIMINACIÓN */}
      <TrabajadorDeleteModal
        trabajadorAEliminar={trabajadorAEliminar}
        onClose={() => setTrabajadorAEliminar(null)}
        onConfirmar={ejecutarEliminacion}
      />

      {/* MODAL 4: CREDENCIAL QR SST */}
      <QRModal
        isOpen={Boolean(qrTrabajador)}
        onClose={() => setQrTrabajador(null)}
        tipo="trabajador"
        trabajador={qrTrabajador || undefined}
        historialEntregasTrabajador={qrTrabajador ? entregas.filter(e => e.codigoTrabajador === qrTrabajador.codigo) : []}
      />

      {/* MODAL 5: VISOR PDF DEL PADRÓN OFICIAL */}
      <PDFViewerModal
        isOpen={Boolean(viewerPdfUrl)}
        onClose={() => setViewerPdfUrl(null)}
        pdfBlobUrl={viewerPdfUrl}
        pdfArrayBuffer={viewerPdfBuffer}
        fileName={viewerPdfName}
        titulo="Padrón General de Trabajadores - SSOMA"
        esBorrador={false}
      />
    </div>
  );
};
