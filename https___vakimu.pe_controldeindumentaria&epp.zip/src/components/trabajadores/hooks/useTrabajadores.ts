import { useState, useMemo, useEffect } from 'react';
import { Trabajador } from '../../../types';
import { CondicionFiltro } from '../components/TrabajadoresFilters';
import { MetricasTrabajadores } from '../components/TrabajadoresStats';
import { PDFGeneratorService } from '../../../services/pdfGenerator';
import { calcularEdad } from '../../../utils/formatters';

interface UseTrabajadoresProps {
  trabajadores: Trabajador[];
  empresaFiltro: string;
  onEliminarTrabajador?: (codigo: string) => void;
}

export function useTrabajadores({
  trabajadores,
  empresaFiltro,
  onEliminarTrabajador
}: UseTrabajadoresProps) {
  const [busqueda, setBusqueda] = useState<string>('');
  const [condicionFiltro, setCondicionFiltro] = useState<CondicionFiltro>('TODOS');
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  // Modales
  const [modalAbierto, setModalAbierto] = useState<boolean>(false);
  const [trabajadorEditando, setTrabajadorEditando] = useState<Trabajador | null>(null);
  const [fichaTrabajador, setFichaTrabajador] = useState<Trabajador | null>(null);
  const [trabajadorAEliminar, setTrabajadorAEliminar] = useState<Trabajador | null>(null);
  const [qrTrabajador, setQrTrabajador] = useState<Trabajador | null>(null);

  // PDF Padrón
  const [viewerPdfUrl, setViewerPdfUrl] = useState<string | null>(null);
  const [viewerPdfBuffer, setViewerPdfBuffer] = useState<ArrayBuffer | null>(null);
  const [viewerPdfName, setViewerPdfName] = useState<string>('');
  const [generandoPdf, setGenerandoPdf] = useState<boolean>(false);
  const [errorPadronPdf, setErrorPadronPdf] = useState<string | null>(null);

  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, empresaFiltro, condicionFiltro, porPagina]);

  // Filtrado de trabajadores: Exclusivamente por nombre o DNI
  const trabajadoresFiltrados = useMemo(() => {
    return trabajadores.filter(t => {
      if (empresaFiltro !== 'TODAS' && t.empresaId !== empresaFiltro) return false;
      if (condicionFiltro !== 'TODOS' && t.estado !== condicionFiltro) return false;
      if (busqueda.trim()) {
        const q = busqueda.toLowerCase().trim();
        const tokens = q.split(/\s+/);
        const nombre = String(t.nombreCompleto || t.apellidosNombres || '').toLowerCase();
        const dni = String(t.dni || '').toLowerCase();
        const searchTarget = `${nombre} ${dni}`;
        return tokens.every(tok => searchTarget.includes(tok));
      }
      return true;
    });
  }, [trabajadores, empresaFiltro, condicionFiltro, busqueda]);

  // Métricas
  const metricas = useMemo<MetricasTrabajadores>(() => {
    const total = trabajadoresFiltrados.length;
    let perpol = 0;
    let tr3 = 0;
    let activos = 0;
    let cesados = 0;

    trabajadoresFiltrados.forEach(t => {
      if (t.empresaId === 'EMP-PERPOL') perpol++;
      else tr3++;
      if (t.estado === 'Activo') activos++;
      else if (t.estado === 'Cesado') cesados++;
    });

    return {
      total,
      perpol,
      tr3,
      activos,
      cesados,
      tasaActivos: total > 0 ? Math.round((activos / total) * 100) : 100
    };
  }, [trabajadoresFiltrados]);

  // Conteos por condición
  const conteosCondicion = useMemo(() => {
    const baseEmpresa = trabajadores.filter(t => {
      if (empresaFiltro !== 'TODAS' && t.empresaId !== empresaFiltro) return false;
      if (busqueda.trim()) {
        const q = busqueda.toLowerCase().trim();
        const tokens = q.split(/\s+/);
        const nombre = String(t.nombreCompleto || t.apellidosNombres || '').toLowerCase();
        const dni = String(t.dni || '').toLowerCase();
        const searchTarget = `${nombre} ${dni}`;
        return tokens.every(tok => searchTarget.includes(tok));
      }
      return true;
    });

    return {
      TODOS: baseEmpresa.length,
      Activo: baseEmpresa.filter(t => t.estado === 'Activo').length,
      Inactivo: baseEmpresa.filter(t => t.estado === 'Inactivo').length,
      Cesado: baseEmpresa.filter(t => t.estado === 'Cesado').length
    };
  }, [trabajadores, empresaFiltro, busqueda]);

  // Paginación
  const totalPaginas = Math.max(1, Math.ceil(trabajadoresFiltrados.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;
  const trabajadoresPaginados = useMemo(() => {
    return trabajadoresFiltrados.slice(indiceInicio, indiceInicio + porPagina);
  }, [trabajadoresFiltrados, indiceInicio, porPagina]);

  // Exportar CSV
  const exportarCSV = () => {
    const encabezados = ['dni,apellidosNombres,empresa,puesto,area,condicion,sexo,fechaNacimiento,edad,fechaIngreso,telefono,correo'];
    const filas = trabajadoresFiltrados.map(t => {
      const nom = (t.nombreCompleto || t.apellidosNombres || '').replace(/"/g, '""');
      const emp = (t.empresaNombre || t.empresa || '').replace(/"/g, '""');
      const pto = (t.cargo || (t as any).puesto || '').replace(/"/g, '""');
      const ar = (t.area || '').replace(/"/g, '""');
      const cond = (t.estado || (t as any).condicion || 'Activo').replace(/"/g, '""');
      const sx = t.sexo || 'M';
      const fNac = t.fechaNacimiento ? t.fechaNacimiento.slice(0, 10) : '';
      const edVal = t.edad !== undefined && t.edad !== null && t.edad !== '' ? String(t.edad) : (calcularEdad(t.fechaNacimiento) !== null ? String(calcularEdad(t.fechaNacimiento)) : '');
      const fIng = t.fechaIngreso ? t.fechaIngreso.slice(0, 10) : '';
      const tel = (t.telefono || '').replace(/"/g, '""');
      const cor = (t.email || (t as any).correo || '').replace(/"/g, '""');
      return `"${t.dni}","${nom}","${emp}","${pto}","${ar}","${cond}","${sx}","${fNac}","${edVal}","${fIng}","${tel}","${cor}"`;
    });
    const contenido = encabezados.concat(filas).join('\n');
    const blob = new Blob([contenido], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TRABAJADORES_${empresaFiltro}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Exportar PDF
  const exportarPDF = async () => {
    setGenerandoPdf(true);
    setErrorPadronPdf(null);
    try {
      const res = await PDFGeneratorService.generarPadronTrabajadoresPDF(trabajadoresFiltrados, empresaFiltro);
      setViewerPdfUrl(res.blobUrl);
      setViewerPdfBuffer(res.arrayBuffer);
      setViewerPdfName(res.fileName);
    } catch (e: any) {
      setErrorPadronPdf('Error al generar PDF del padrón: ' + (e.message || 'Error desconocido'));
    } finally {
      setGenerandoPdf(false);
    }
  };

  const ejecutarEliminacion = () => {
    if (!trabajadorAEliminar) return;
    if (onEliminarTrabajador) {
      onEliminarTrabajador(trabajadorAEliminar.codigo);
    }
    setTrabajadorAEliminar(null);
  };

  const abrirModalCrear = () => {
    setTrabajadorEditando(null);
    setModalAbierto(true);
  };

  const abrirModalEditar = (t: Trabajador) => {
    setTrabajadorEditando(t);
    setModalAbierto(true);
  };

  return {
    busqueda,
    setBusqueda,
    condicionFiltro,
    setCondicionFiltro,
    paginaActual,
    setPaginaActual,
    porPagina,
    setPorPagina,
    modalAbierto,
    setModalAbierto,
    trabajadorEditando,
    fichaTrabajador,
    setFichaTrabajador,
    trabajadorAEliminar,
    setTrabajadorAEliminar,
    qrTrabajador,
    setQrTrabajador,
    viewerPdfUrl,
    setViewerPdfUrl,
    viewerPdfBuffer,
    viewerPdfName,
    generandoPdf,
    errorPadronPdf,
    setErrorPadronPdf,
    trabajadoresFiltrados,
    metricas,
    conteosCondicion,
    totalPaginas,
    paginaAjustada,
    indiceInicio,
    trabajadoresPaginados,
    exportarCSV,
    exportarPDF,
    ejecutarEliminacion,
    abrirModalCrear,
    abrirModalEditar
  };
}
