import React from 'react';
import { X, Boxes, Calendar, FileText, CheckCircle2 } from 'lucide-react';
import { IngresoStock } from '../../types';
import { formatMoneda } from '../../utils/formatters';

interface ModalDetalleIngresoProps {
  isOpen: boolean;
  onClose: () => void;
  ingreso: IngresoStock | null;
}

export const ModalDetalleIngreso: React.FC<ModalDetalleIngresoProps> = ({
  isOpen,
  onClose,
  ingreso
}) => {
  if (!isOpen || !ingreso) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Cabecera */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center shrink-0 border border-blue-200">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">
                  Detalle del Ingreso de Stock
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-semibold">
                  {ingreso.id}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Comprobante: <strong className="text-slate-700 font-medium">{ingreso.numeroComprobante}</strong>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
            title="Cerrar ventana"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Contenido */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Ficha Resumen */}
          <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-[11px] text-slate-500 flex items-center gap-1 mb-0.5">
                <FileText className="w-3.5 h-3.5 text-slate-400" />
                N° Documento
              </span>
              <p className="font-semibold text-slate-800 font-mono">{ingreso.numeroComprobante}</p>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 flex items-center gap-1 mb-0.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Fecha Ingreso
              </span>
              <p className="font-semibold text-slate-800 font-mono">{ingreso.fechaIngreso}</p>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 flex items-center gap-1 mb-0.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Total Unidades
              </span>
              <p className="font-bold text-emerald-700 font-mono text-sm">+{ingreso.totalUnidades} uds</p>
            </div>
          </div>

          {/* Tabla de Artículos Ingresados */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="bg-slate-100/80 px-4 py-2 border-b border-slate-200 text-xs font-bold text-slate-700 uppercase tracking-wider">
              Ítems Recibidos en este Ingreso ({ingreso.items.length})
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px] font-semibold">
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3 w-32">Código</th>
                    <th className="py-2.5 px-3 min-w-[200px]">Artículo / Descripción</th>
                    <th className="py-2.5 px-3 text-center w-24">Cantidad</th>
                    <th className="py-2.5 px-3 text-right w-28">Costo Unit.</th>
                    <th className="py-2.5 px-3 text-right w-28">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ingreso.items.map((item, idx) => {
                    const cant = Number(item.cantidad) || 0;
                    const costo = Number(item.costoUnitario) || 0;
                    const subtotal = cant * costo;
                    return (
                      <tr key={item.idItem || `${item.codigoEPP}-${idx}`} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-2.5 px-3 text-center text-slate-400 font-mono text-[11px]">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-mono font-medium text-slate-800">{item.codigoEPP}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-900">{item.articulo}</td>
                        <td className="py-2.5 px-3 text-center font-mono font-bold text-emerald-700">+{cant}</td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-700">{formatMoneda(costo)}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">{formatMoneda(subtotal)}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-50/90 border-t border-slate-200 font-semibold text-slate-800">
                    <td colSpan={3} className="py-2.5 px-3 text-right font-bold text-slate-600 uppercase text-[11px]">
                      Totales del Ingreso:
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-bold text-emerald-700 text-xs">
                      {ingreso.totalUnidades} uds
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-400 text-[11px]">—</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-800 text-sm">
                      {formatMoneda(ingreso.totalImporte)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>

        {/* Pie */}
        <div className="p-4 border-t border-slate-200 flex justify-end bg-slate-50/60">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
