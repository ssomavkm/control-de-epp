import React, { useState } from 'react';
import { 
  X, 
  PackagePlus, 
  Calendar, 
  FileText, 
  Plus, 
  Trash2, 
  AlertCircle, 
  CheckCircle2, 
  Boxes
} from 'lucide-react';
import { EPPItem, IngresoStock, ItemIngresoStock } from '../../types';
import { useToast } from '../../context/ToastContext';
import { formatMoneda } from '../../utils/formatters';

interface ModalRegistrarIngresoProps {
  isOpen: boolean;
  onClose: () => void;
  catalogoEPP: EPPItem[];
  onGuardar: (ingreso: IngresoStock) => Promise<{ success: boolean; mensaje: string }>;
  eppInicialCodigo?: string;
}

interface FilaItemForm {
  codigoEPP: string;
  cantidad: number;
  costoUnitario: number;
}

export const ModalRegistrarIngreso: React.FC<ModalRegistrarIngresoProps> = ({
  isOpen,
  onClose,
  catalogoEPP = [],
  onGuardar,
  eppInicialCodigo
}) => {
  const toast = useToast();

  const [fechaIngreso, setFechaIngreso] = useState<string>(
    () => new Date().toISOString().split('T')[0]
  );
  const [numeroComprobante, setNumeroComprobante] = useState<string>('');
  const [filas, setFilas] = useState<FilaItemForm[]>(() => {
    if (eppInicialCodigo) {
      const epp = catalogoEPP.find(e => e.codigo === eppInicialCodigo);
      return [{ codigoEPP: eppInicialCodigo, cantidad: 10, costoUnitario: epp ? epp.costoUnitario : 0 }];
    }
    return [{ codigoEPP: '', cantidad: 10, costoUnitario: 0 }];
  });
  const [guardando, setGuardando] = useState<boolean>(false);
  const [errorValidacion, setErrorValidacion] = useState<string | null>(null);

  // Sincronizar si cambia eppInicialCodigo al abrir
  React.useEffect(() => {
    if (isOpen) {
      if (eppInicialCodigo) {
        const epp = catalogoEPP.find(e => e.codigo === eppInicialCodigo);
        setFilas([{ codigoEPP: eppInicialCodigo, cantidad: 10, costoUnitario: epp ? epp.costoUnitario : 0 }]);
      } else {
        setFilas([{ codigoEPP: '', cantidad: 10, costoUnitario: 0 }]);
      }
      setNumeroComprobante('');
      setErrorValidacion(null);
    }
  }, [isOpen, eppInicialCodigo, catalogoEPP]);

  if (!isOpen) return null;

  const agregarFila = () => {
    setFilas(prev => [...prev, { codigoEPP: '', cantidad: 10, costoUnitario: 0 }]);
  };

  const eliminarFila = (index: number) => {
    if (filas.length <= 1) {
      toast.show('Debe incluir al menos un EPP en el ingreso.', 'warning');
      return;
    }
    setFilas(prev => prev.filter((_, idx) => idx !== index));
  };

  const actualizarFila = (index: number, campo: keyof FilaItemForm, valor: any) => {
    setFilas(prev => {
      const copia = [...prev];
      const itemActual = { ...copia[index] };

      if (campo === 'codigoEPP') {
        itemActual.codigoEPP = valor;
        const eppEncontrado = catalogoEPP.find(e => e.codigo === valor);
        if (eppEncontrado && itemActual.costoUnitario === 0) {
          itemActual.costoUnitario = eppEncontrado.costoUnitario || 0;
        }
      } else if (campo === 'cantidad') {
        itemActual.cantidad = Math.max(1, Number(valor) || 0);
      } else if (campo === 'costoUnitario') {
        itemActual.costoUnitario = Math.max(0, Number(valor) || 0);
      }

      copia[index] = itemActual;
      return copia;
    });
  };

  // Cálculos totales en tiempo real
  const totalUnidades = filas.reduce((acc, f) => acc + (Number(f.cantidad) || 0), 0);
  const totalImporte = filas.reduce(
    (acc, f) => acc + ((Number(f.cantidad) || 0) * (Number(f.costoUnitario) || 0)),
    0
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorValidacion(null);

    if (!numeroComprobante.trim()) {
      setErrorValidacion('Por favor ingrese el N° de Guía de Remisión o Factura de referencia.');
      return;
    }

    // Validar ítems
    const itemsValidos: ItemIngresoStock[] = [];
    for (let i = 0; i < filas.length; i++) {
      const f = filas[i];
      if (!f.codigoEPP) {
        setErrorValidacion(`Seleccione un EPP en la fila N° ${i + 1}.`);
        return;
      }
      if (f.cantidad <= 0) {
        setErrorValidacion(`La cantidad en la fila N° ${i + 1} debe ser mayor a 0.`);
        return;
      }

      const epp = catalogoEPP.find(item => item.codigo === f.codigoEPP);
      itemsValidos.push({
        codigoEPP: f.codigoEPP,
        articulo: epp ? epp.articulo : f.codigoEPP,
        cantidad: f.cantidad,
        costoUnitario: f.costoUnitario
      });
    }

    const nuevoIngreso: IngresoStock = {
      id: `ING-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`,
      numeroComprobante: numeroComprobante.trim(),
      fechaIngreso,
      items: itemsValidos,
      totalUnidades,
      totalImporte,
      fechaCreacion: new Date().toISOString()
    };

    setGuardando(true);
    try {
      const res = await onGuardar(nuevoIngreso);
      if (res.success) {
        toast.show(res.mensaje, 'success');
        onClose();
      } else {
        setErrorValidacion(res.mensaje);
      }
    } catch (err: any) {
      setErrorValidacion(err.message || 'Error al registrar el ingreso de stock.');
    } finally {
      setGuardando(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Cabecera del Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 border border-emerald-200">
              <PackagePlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Registrar Ingreso de Stock a Almacén
              </h3>
              <p className="text-xs text-slate-500">
                Suma automática de existencias por recepción de Guías de Remisión o Facturas
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
            title="Cerrar ventana"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Formulario */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {errorValidacion && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2.5 text-xs text-rose-800 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorValidacion}</span>
            </div>
          )}

          {/* Bloque 1: Datos Generales */}
          <div className="p-4 bg-slate-50/70 border border-slate-200/80 rounded-xl grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5 mb-1">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                Fecha de Ingreso *
              </label>
              <input
                type="date"
                required
                value={fechaIngreso}
                onChange={(e) => setFechaIngreso(e.target.value)}
                className="w-full h-9.5 px-3 rounded-lg border border-slate-200 bg-white text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5 mb-1">
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                Documento de Referencia (Guía / Factura) *
              </label>
              <input
                type="text"
                required
                placeholder="Ej: GR-001-002345 o Factura F001-4567"
                value={numeroComprobante}
                onChange={(e) => setNumeroComprobante(e.target.value)}
                className="w-full h-9.5 px-3 rounded-lg border border-slate-200 bg-white text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
              />
            </div>
          </div>

          {/* Bloque 2: Detalle de Ítems a Ingresar */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Boxes className="w-4 h-4 text-emerald-600" />
                <span>EPPs a Ingresar ({filas.length})</span>
              </label>
              <button
                type="button"
                onClick={agregarFila}
                className="px-2.5 py-1 text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg hover:bg-emerald-100 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Agregar otro EPP</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {filas.map((fila, idx) => {
                const eppSeleccionado = catalogoEPP.find(e => e.codigo === fila.codigoEPP);
                const subtotal = fila.cantidad * fila.costoUnitario;

                return (
                  <div
                    key={`fila-${idx}`}
                    className="p-3 bg-white border border-slate-200 rounded-xl shadow-2xs space-y-2.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-500 text-[11px]">
                        Ítem #{idx + 1}
                      </span>
                      {filas.length > 1 && (
                        <button
                          type="button"
                          onClick={() => eliminarFila(idx)}
                          className="text-slate-400 hover:text-rose-600 p-1 rounded-md transition-colors cursor-pointer"
                          title="Eliminar fila"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 text-xs">
                      {/* Selector de EPP */}
                      <div className="sm:col-span-6">
                        <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">
                          Equipo de Protección / Prenda *
                        </label>
                        <select
                          required
                          value={fila.codigoEPP}
                          onChange={(e) => actualizarFila(idx, 'codigoEPP', e.target.value)}
                          className="w-full h-9 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                        >
                          <option value="">-- Seleccionar EPP del Catálogo --</option>
                          {catalogoEPP.map((epp) => (
                            <option key={epp.codigo} value={epp.codigo}>
                              {epp.codigo} - {epp.articulo} ({epp.talla || 'Estándar'}) [Stock actual: {epp.stockActual}]
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Cantidad recibida */}
                      <div className="sm:col-span-3">
                        <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">
                          Cantidad (+) *
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            min="1"
                            required
                            value={fila.cantidad}
                            onChange={(e) => actualizarFila(idx, 'cantidad', e.target.value)}
                            className="w-full h-9 px-2.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-emerald-700 text-center focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </div>
                      </div>

                      {/* Costo Unitario */}
                      <div className="sm:col-span-3">
                        <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">
                          Costo Unit. (S/)
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={fila.costoUnitario}
                          onChange={(e) => actualizarFila(idx, 'costoUnitario', e.target.value)}
                          className="w-full h-9 px-2.5 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    {/* Previsualización del impacto de stock */}
                    {eppSeleccionado && (
                      <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500 bg-slate-50/50 p-2 rounded-lg">
                        <div className="flex items-center gap-2">
                          <span>Stock anterior: <strong className="font-mono text-slate-700">{eppSeleccionado.stockActual}</strong></span>
                          <span>+</span>
                          <span className="text-emerald-700 font-bold font-mono">+{fila.cantidad}</span>
                          <span>=</span>
                          <span className="text-slate-900 font-bold font-mono bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            Nuevo Stock: {eppSeleccionado.stockActual + fila.cantidad} uds
                          </span>
                        </div>
                        <div className="font-mono text-slate-600 font-semibold">
                          Subtotal: {formatMoneda(subtotal)}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Banner de Resumen Total */}
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="font-medium text-emerald-950">
                Se sumarán un total de <strong>{totalUnidades} unidades</strong> al inventario.
              </span>
            </div>
            <div className="font-mono font-bold text-emerald-900 text-sm">
              Total Ingreso: {formatMoneda(totalImporte)}
            </div>
          </div>

          {/* Botones de Acción */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={guardando}
              className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-100 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
            >
              <PackagePlus className="w-4 h-4" />
              <span>{guardando ? 'Actualizando Stock...' : 'Confirmar e Ingresar al Stock'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
