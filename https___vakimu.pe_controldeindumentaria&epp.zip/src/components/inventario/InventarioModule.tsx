import React, { useState, useMemo } from 'react';
import { 
  Boxes, 
  PackagePlus, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Search, 
  AlertTriangle, 
  Eye, 
  Coins, 
  Layers,
  TrendingUp,
  X
} from 'lucide-react';
import { EPPItem, IngresoStock, MovimientoKardex } from '../../types';
import { formatMoneda, compararFechasDesc } from '../../utils/formatters';
import { ModalRegistrarIngreso } from './ModalRegistrarIngreso';
import { ModalDetalleIngreso } from './ModalDetalleIngreso';
import { TablePagination } from '../common/TablePagination';

interface InventarioModuleProps {
  catalogoEPP: EPPItem[];
  movimientosKardex: MovimientoKardex[];
  ingresosStock: IngresoStock[];
  onRegistrarIngresoStock: (ingreso: IngresoStock) => Promise<{ success: boolean; mensaje: string }>;
  onIrAEntregas?: () => void;
}

export const InventarioModule: React.FC<InventarioModuleProps> = ({
  catalogoEPP = [],
  movimientosKardex = [],
  ingresosStock = [],
  onRegistrarIngresoStock
}) => {
  // Pestaña activa
  const [tabActiva, setTabActiva] = useState<'ingresos' | 'kardex' | 'existencias'>('ingresos');

  // Modales
  const [modalIngresoAbierto, setModalIngresoAbierto] = useState<boolean>(false);
  const [eppPreseleccionadoIngreso, setEppPreseleccionadoIngreso] = useState<string | undefined>(undefined);
  const [ingresoSeleccionadoDetalle, setIngresoSeleccionadoDetalle] = useState<IngresoStock | null>(null);

  // Filtros Tab 1: Ingresos
  const [busquedaIngresos, setBusquedaIngresos] = useState<string>('');

  // Filtros Tab 2: Kardex
  const [busquedaKardex, setBusquedaKardex] = useState<string>('');
  const [tipoMovFiltro, setTipoMovFiltro] = useState<'TODOS' | 'ENTRADA' | 'SALIDA'>('TODOS');
  const [eppFiltroKardex, setEppFiltroKardex] = useState<string>('TODOS');

  // Filtros Tab 3: Existencias
  const [busquedaExistencias, setBusquedaExistencias] = useState<string>('');
  const [estadoFiltroExistencias, setEstadoFiltroExistencias] = useState<string>('TODOS');

  // Paginación Tab 1: Ingresos
  const [paginaIngresos, setPaginaIngresos] = useState<number>(1);
  const [porPaginaIngresos, setPorPaginaIngresos] = useState<number>(10);

  // Paginación Tab 2: Kardex
  const [paginaKardex, setPaginaKardex] = useState<number>(1);
  const [porPaginaKardex, setPorPaginaKardex] = useState<number>(15);

  // Paginación Tab 3: Existencias
  const [paginaExistencias, setPaginaExistencias] = useState<number>(1);
  const [porPaginaExistencias, setPorPaginaExistencias] = useState<number>(10);

  // KPIs Generales de Inventario
  const metricas = useMemo(() => {
    const totalUnidadesDisponibles = catalogoEPP.reduce((acc, it) => acc + (Number(it.stockActual) || 0), 0);
    const valorTotalInventario = catalogoEPP.reduce((acc, it) => acc + ((Number(it.stockActual) || 0) * (Number(it.costoUnitario) || 0)), 0);
    const articulosCriticos = catalogoEPP.filter(it => it.estado === 'Stock Crítico' || it.estado === 'Agotado').length;
    
    const totalIngresosUds = ingresosStock.reduce((acc, ing) => acc + (Number(ing.totalUnidades) || 0), 0);
    const totalSalidasKardex = movimientosKardex
      .filter(m => m.tipo === 'SALIDA')
      .reduce((acc, m) => acc + (Number(m.cantidad) || 0), 0);

    return {
      totalUnidadesDisponibles,
      valorTotalInventario,
      articulosCriticos,
      totalComprobantesIngreso: ingresosStock.length,
      totalIngresosUds,
      totalSalidasKardex
    };
  }, [catalogoEPP, ingresosStock, movimientosKardex]);

  // Filtrado Tab 1: Ingresos
  const ingresosFiltrados = useMemo(() => {
    return ingresosStock.filter(ing => {
      if (!busquedaIngresos.trim()) return true;
      const q = busquedaIngresos.toLowerCase();
      const coincideCabecera = (
        (ing.id || '').toLowerCase().includes(q) ||
        (ing.numeroComprobante || '').toLowerCase().includes(q) ||
        (ing.fechaIngreso || '').toLowerCase().includes(q)
      );
      if (coincideCabecera) return true;
      return (ing.items || []).some(
        it => (it.articulo || '').toLowerCase().includes(q) || (it.codigoEPP || '').toLowerCase().includes(q)
      );
    }).sort((a, b) => compararFechasDesc(a.fechaIngreso, b.fechaIngreso, a.id, b.id));
  }, [ingresosStock, busquedaIngresos]);

  // Filtrado Tab 2: Kardex
  const kardexFiltrado = useMemo(() => {
    return movimientosKardex.filter(mov => {
      if (tipoMovFiltro !== 'TODOS' && mov.tipo !== tipoMovFiltro) return false;
      if (eppFiltroKardex !== 'TODOS' && mov.codigoEPP !== eppFiltroKardex) return false;
      if (!busquedaKardex.trim()) return true;
      const q = busquedaKardex.toLowerCase();
      return (
        (mov.codigoEPP || '').toLowerCase().includes(q) ||
        (mov.articulo || '').toLowerCase().includes(q) ||
        (mov.documentoReferencia || '').toLowerCase().includes(q) ||
        (mov.trabajadorNombre || '').toLowerCase().includes(q)
      );
    }).sort((a, b) => compararFechasDesc(a.fechaHora, b.fechaHora, a.id, b.id));
  }, [movimientosKardex, tipoMovFiltro, eppFiltroKardex, busquedaKardex]);

  // Filtrado Tab 3: Existencias
  const existenciasFiltradas = useMemo(() => {
    return catalogoEPP.filter(epp => {
      if (estadoFiltroExistencias !== 'TODOS' && epp.estado !== estadoFiltroExistencias) return false;
      if (!busquedaExistencias.trim()) return true;
      const q = busquedaExistencias.toLowerCase();
      return (
        (epp.codigo || '').toLowerCase().includes(q) ||
        (epp.articulo || '').toLowerCase().includes(q) ||
        (epp.categoria || '').toLowerCase().includes(q) ||
        (epp.marca || '').toLowerCase().includes(q)
      );
    });
  }, [catalogoEPP, estadoFiltroExistencias, busquedaExistencias]);

  // Handlers para abrir el modal de ingreso
  const abrirRegistroIngresoGeneral = () => {
    setEppPreseleccionadoIngreso(undefined);
    setModalIngresoAbierto(true);
  };

  const abrirRegistroIngresoParaEPP = (codigoEPP: string) => {
    setEppPreseleccionadoIngreso(codigoEPP);
    setModalIngresoAbierto(true);
  };

  return (
    <div className="space-y-6">
      {/* Tarjetas KPI de Resumen */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* KPI 1: Unidades en Stock */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Existencias en Almacén</p>
            <p className="text-xl font-bold text-slate-900 font-mono-numbers">
              {metricas.totalUnidadesDisponibles} <span className="text-xs font-normal text-slate-400 font-sans">uds</span>
            </p>
          </div>
        </div>

        {/* KPI 2: Valor Total */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Valorización de Stock</p>
            <p className="text-xl font-bold text-slate-900 font-mono-numbers">
              {formatMoneda(metricas.valorTotalInventario)}
            </p>
          </div>
        </div>

        {/* KPI 3: Entradas Acumuladas */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Ingresos Registrados</p>
            <p className="text-xl font-bold text-emerald-700 font-mono-numbers">
              +{metricas.totalIngresosUds} <span className="text-xs font-normal text-slate-500 font-sans">uds ({metricas.totalComprobantesIngreso} guías)</span>
            </p>
          </div>
        </div>

        {/* KPI 4: Salidas / Alertas */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
            metricas.articulosCriticos > 0 ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-slate-600'
          }`}>
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Alertas de Stock</p>
            <p className={`text-xl font-bold font-mono-numbers ${
              metricas.articulosCriticos > 0 ? 'text-amber-700' : 'text-slate-900'
            }`}>
              {metricas.articulosCriticos} <span className="text-xs font-normal text-slate-400 font-sans">críticos/agotados</span>
            </p>
          </div>
        </div>
      </div>

      {/* Selector de Pestañas del Módulo */}
      <div className="flex border-b border-slate-200 gap-2">
        <button
          type="button"
          onClick={() => setTabActiva('ingresos')}
          className={`pb-3 px-4 text-xs font-bold transition-colors cursor-pointer border-b-2 flex items-center gap-2 ${
            tabActiva === 'ingresos'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <PackagePlus className="w-4 h-4" />
          <span>Ingresos de Stock ({ingresosStock.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setTabActiva('kardex')}
          className={`pb-3 px-4 text-xs font-bold transition-colors cursor-pointer border-b-2 flex items-center gap-2 ${
            tabActiva === 'kardex'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Kardex de Movimientos ({movimientosKardex.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setTabActiva('existencias')}
          className={`pb-3 px-4 text-xs font-bold transition-colors cursor-pointer border-b-2 flex items-center gap-2 ${
            tabActiva === 'existencias'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Boxes className="w-4 h-4" />
          <span>Balance de Stock por EPP ({catalogoEPP.length})</span>
        </button>
      </div>

      {/* TAB 1: INGRESOS DE STOCK (Guías / Facturas) */}
      {tabActiva === 'ingresos' && (
        <div className="space-y-4">
          {/* Barra de Filtros de Ingresos */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[240px] max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="Buscar por N° Guía, Factura, Fecha o EPP..."
                value={busquedaIngresos}
                onChange={(e) => {
                  setBusquedaIngresos(e.target.value);
                  setPaginaIngresos(1);
                }}
                className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              {busquedaIngresos && (
                <button
                  type="button"
                  onClick={() => setBusquedaIngresos('')}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-500 font-mono-numbers">
                {ingresosFiltrados.length} ingreso{ingresosFiltrados.length === 1 ? '' : 's'}
              </span>
              <button
                type="button"
                onClick={abrirRegistroIngresoGeneral}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <PackagePlus className="w-3.5 h-3.5" />
                <span>+ Nuevo Ingreso</span>
              </button>
            </div>
          </div>

          {/* Tabla de Ingresos */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs min-w-[750px]">
                <thead>
                  <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-4 w-32">ID Registro</th>
                    <th className="py-3 px-4 min-w-[180px]">N° Documento (Guía / Fac.)</th>
                    <th className="py-3 px-3 w-32">Fecha Ingreso</th>
                    <th className="py-3 px-3 text-center w-28">N° de Ítems</th>
                    <th className="py-3 px-3 text-center w-32">Total Unidades</th>
                    <th className="py-3 px-4 text-right w-36">Importe Total</th>
                    <th className="py-3 px-4 text-center w-28">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ingresosFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-500">
                        <div className="max-w-xs mx-auto space-y-2">
                          <PackagePlus className="w-8 h-8 mx-auto text-slate-300 stroke-1" />
                          <p className="font-semibold text-slate-700 text-xs">No hay ingresos registrados</p>
                          <p className="text-[11px] text-slate-500">Registra un nuevo ingreso con Guía o Factura para sumar stock.</p>
                          <button
                            type="button"
                            onClick={abrirRegistroIngresoGeneral}
                            className="mt-2 px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-medium hover:bg-emerald-700 inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <PackagePlus className="w-3.5 h-3.5" />
                            <span>Registrar Primer Ingreso</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    ingresosFiltrados
                      .slice((paginaIngresos - 1) * porPaginaIngresos, paginaIngresos * porPaginaIngresos)
                      .map((ing) => (
                        <tr key={ing.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4 font-mono font-semibold text-slate-700 text-[11px]">
                            {ing.id}
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-semibold text-slate-900 font-mono text-xs">
                              {ing.numeroComprobante}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-600">
                            {ing.fechaIngreso}
                          </td>
                          <td className="py-3 px-3 text-center">
                            <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium text-[11px]">
                              {ing.items?.length || 0} EPP{ing.items?.length === 1 ? '' : 's'}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-center font-mono font-bold text-emerald-700">
                            +{ing.totalUnidades} uds
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                            {formatMoneda(ing.totalImporte)}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => setIngresoSeleccionadoDetalle(ing)}
                              className="px-2.5 py-1 text-[11px] font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors inline-flex items-center gap-1 cursor-pointer"
                              title="Ver detalle del ingreso"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Detalle</span>
                            </button>
                          </td>
                        </tr>
                      ))
                  )}
                </tbody>
              </table>
            </div>

            {ingresosFiltrados.length > 0 && (
              <TablePagination
                totalRegistros={ingresosFiltrados.length}
                paginaActual={paginaIngresos}
                setPaginaActual={setPaginaIngresos}
                porPagina={porPaginaIngresos}
                setPorPagina={(tam: number) => {
                  setPorPaginaIngresos(tam);
                  setPaginaIngresos(1);
                }}
                nombreEntidadPlural="ingresos"
              />
            )}
          </div>
        </div>
      )}

      {/* TAB 2: KARDEX DE MOVIMIENTOS (Entradas y Salidas) */}
      {tabActiva === 'kardex' && (
        <div className="space-y-4">
          {/* Filtros del Kardex */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Buscar por artículo, documento o trabajador..."
                  value={busquedaKardex}
                  onChange={(e) => {
                    setBusquedaKardex(e.target.value);
                    setPaginaKardex(1);
                  }}
                  className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                {busquedaKardex && (
                  <button
                    type="button"
                    onClick={() => setBusquedaKardex('')}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <select
                value={tipoMovFiltro}
                onChange={(e) => {
                  setTipoMovFiltro(e.target.value as any);
                  setPaginaKardex(1);
                }}
                className="py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:bg-white cursor-pointer"
              >
                <option value="TODOS">Todos los Movimientos</option>
                <option value="ENTRADA">Solo Entradas (+)</option>
                <option value="SALIDA">Solo Salidas / Consumos (-)</option>
              </select>

              <select
                value={eppFiltroKardex}
                onChange={(e) => {
                  setEppFiltroKardex(e.target.value);
                  setPaginaKardex(1);
                }}
                className="py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:bg-white cursor-pointer max-w-[200px] truncate"
              >
                <option value="TODOS">Todos los EPPs</option>
                {catalogoEPP.map((epp) => (
                  <option key={epp.codigo} value={epp.codigo}>
                    {epp.codigo} - {epp.articulo}
                  </option>
                ))}
              </select>
            </div>

            <div className="text-xs text-slate-500 font-mono-numbers">
              {kardexFiltrado.length} registro{kardexFiltrado.length === 1 ? '' : 's'}
            </div>
          </div>

          {/* Tabla de Movimientos Kardex */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs min-w-[900px]">
                <thead>
                  <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-3.5 w-36">Fecha / Hora</th>
                    <th className="py-3 px-3 text-center w-28">Tipo</th>
                    <th className="py-3 px-3 w-32">Código EPP</th>
                    <th className="py-3 px-3 min-w-[200px]">Artículo / Equipo</th>
                    <th className="py-3 px-3 min-w-[160px]">Doc. Referencia</th>
                    <th className="py-3 px-3 text-center w-28">Movimiento</th>
                    <th className="py-3 px-3 text-center w-36">Stock Ant. &rarr; Result.</th>
                    <th className="py-3 px-3.5 text-right w-28">Costo Unit.</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {kardexFiltrado.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-500">
                        <div className="max-w-xs mx-auto space-y-1">
                          <Layers className="w-7 h-7 mx-auto text-slate-300 stroke-1" />
                          <p className="font-semibold text-slate-700 text-xs">No hay movimientos en Kardex</p>
                          <p className="text-[11px] text-slate-500">Los ingresos sumarán y las entregas restarán aquí automáticamente.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    kardexFiltrado
                      .slice((paginaKardex - 1) * porPaginaKardex, paginaKardex * porPaginaKardex)
                      .map((mov) => {
                        const esEntrada = mov.tipo === 'ENTRADA';
                        return (
                          <tr key={mov.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="py-3 px-3.5 font-mono text-slate-600 text-[11px]">
                              {mov.fechaHora}
                            </td>
                            <td className="py-3 px-3 text-center">
                              {esEntrada ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                  <ArrowDownLeft className="w-3 h-3 text-emerald-600" />
                                  ENTRADA
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                                  <ArrowUpRight className="w-3 h-3 text-blue-600" />
                                  SALIDA
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-3 font-mono font-medium text-slate-800">
                              {mov.codigoEPP}
                            </td>
                            <td className="py-3 px-3 font-medium text-slate-900">
                              {mov.articulo}
                            </td>
                            <td className="py-3 px-3 text-slate-700">
                              <span className="font-mono text-xs">{mov.documentoReferencia}</span>
                              {mov.trabajadorNombre && (
                                <div className="text-[11px] text-slate-500 truncate max-w-[180px]">
                                  Para: {mov.trabajadorNombre}
                                </div>
                              )}
                            </td>
                            <td className="py-3 px-3 text-center font-mono font-bold text-xs">
                              {esEntrada ? (
                                <span className="text-emerald-700">+{mov.cantidad}</span>
                              ) : (
                                <span className="text-rose-600">-{mov.cantidad}</span>
                              )}
                            </td>
                            <td className="py-3 px-3 text-center font-mono text-[11px]">
                              <span className="text-slate-500">{mov.stockAnterior}</span>
                              <span className="text-slate-400 mx-1">&rarr;</span>
                              <span className="font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded">
                                {mov.stockResultante}
                              </span>
                            </td>
                            <td className="py-3 px-3.5 text-right font-mono text-slate-700">
                              {mov.costoUnitario !== undefined ? formatMoneda(mov.costoUnitario) : '—'}
                            </td>
                          </tr>
                        );
                      })
                  )}
                </tbody>
              </table>
            </div>

            {kardexFiltrado.length > 0 && (
              <TablePagination
                totalRegistros={kardexFiltrado.length}
                paginaActual={paginaKardex}
                setPaginaActual={setPaginaKardex}
                porPagina={porPaginaKardex}
                setPorPagina={(tam: number) => {
                  setPorPaginaKardex(tam);
                  setPaginaKardex(1);
                }}
                nombreEntidadPlural="movimientos"
              />
            )}
          </div>
        </div>
      )}

      {/* TAB 3: BALANCE Y EXISTENCIAS POR ARTÍCULO */}
      {tabActiva === 'existencias' && (
        <div className="space-y-4">
          {/* Barra de Filtros de Existencias */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[220px] max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Buscar por artículo, código, categoría..."
                  value={busquedaExistencias}
                  onChange={(e) => {
                    setBusquedaExistencias(e.target.value);
                    setPaginaExistencias(1);
                  }}
                  className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                {busquedaExistencias && (
                  <button
                    type="button"
                    onClick={() => setBusquedaExistencias('')}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <select
                value={estadoFiltroExistencias}
                onChange={(e) => {
                  setEstadoFiltroExistencias(e.target.value);
                  setPaginaExistencias(1);
                }}
                className="py-2 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:bg-white cursor-pointer"
              >
                <option value="TODOS">Todos los Estados</option>
                <option value="Disponible">Disponible</option>
                <option value="Stock Crítico">Stock Crítico</option>
                <option value="Agotado">Agotado</option>
              </select>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-500 font-mono-numbers">
                {existenciasFiltradas.length} artículo{existenciasFiltradas.length === 1 ? '' : 's'}
              </span>
              <button
                type="button"
                onClick={abrirRegistroIngresoGeneral}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <PackagePlus className="w-3.5 h-3.5" />
                <span>Ingresar Stock General</span>
              </button>
            </div>
          </div>

          {/* Tabla de Existencias */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs min-w-[850px]">
                <thead>
                  <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-4 w-32">Código</th>
                    <th className="py-3 px-4 min-w-[220px]">Artículo EPP / Talla</th>
                    <th className="py-3 px-3 min-w-[140px]">Categoría</th>
                    <th className="py-3 px-3 text-center w-28">Stock Actual</th>
                    <th className="py-3 px-3 text-center w-24">Mínimo</th>
                    <th className="py-3 px-3 text-center w-28">Estado</th>
                    <th className="py-3 px-3 text-right w-24">P. Unit</th>
                    <th className="py-3 px-3 text-right w-28">Valor Total</th>
                    <th className="py-3 px-4 text-center w-36">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {existenciasFiltradas.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-500">
                        No se encontraron artículos con los filtros seleccionados.
                      </td>
                    </tr>
                  ) : (
                    existenciasFiltradas
                      .slice((paginaExistencias - 1) * porPaginaExistencias, paginaExistencias * porPaginaExistencias)
                      .map((epp) => {
                        const valorTotalItem = (epp.stockActual || 0) * (epp.costoUnitario || 0);
                        const esCritico = epp.estado === 'Stock Crítico';
                        const esAgotado = epp.estado === 'Agotado';

                        return (
                          <tr key={epp.codigo} className="hover:bg-slate-50/70 transition-colors">
                            <td className="py-3 px-4 font-mono font-medium text-slate-800">
                              {epp.codigo}
                            </td>
                            <td className="py-3 px-4">
                              <p className="font-semibold text-slate-900">{epp.articulo}</p>
                              <p className="text-[11px] text-slate-500">
                                {epp.marca} • Talla: {epp.talla || 'Estándar'}
                              </p>
                            </td>
                            <td className="py-3 px-3 text-slate-600">
                              {epp.categoria}
                            </td>
                            <td className="py-3 px-3 text-center">
                              <span className={`font-mono font-bold text-sm px-2 py-0.5 rounded ${
                                esAgotado
                                  ? 'bg-rose-100 text-rose-800'
                                  : esCritico
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-emerald-50 text-emerald-800'
                              }`}>
                                {epp.stockActual} {epp.unidad}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-center font-mono text-slate-500">
                              {epp.stockMinimo}
                            </td>
                            <td className="py-3 px-3 text-center">
                              {esAgotado ? (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                  Agotado
                                </span>
                              ) : esCritico ? (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                                  Stock Crítico
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                  Disponible
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-3 text-right font-mono text-slate-700">
                              {formatMoneda(epp.costoUnitario)}
                            </td>
                            <td className="py-3 px-3 text-right font-mono font-semibold text-slate-900">
                              {formatMoneda(valorTotalItem)}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <button
                                type="button"
                                onClick={() => abrirRegistroIngresoParaEPP(epp.codigo)}
                                className="px-2.5 py-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors inline-flex items-center gap-1 cursor-pointer"
                                title={`Ingresar stock para ${epp.codigo}`}
                              >
                                <PackagePlus className="w-3.5 h-3.5" />
                                <span>+ Ingresar</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })
                  )}
                </tbody>
              </table>
            </div>

            {existenciasFiltradas.length > 0 && (
              <TablePagination
                totalRegistros={existenciasFiltradas.length}
                paginaActual={paginaExistencias}
                setPaginaActual={setPaginaExistencias}
                porPagina={porPaginaExistencias}
                setPorPagina={(tam: number) => {
                  setPorPaginaExistencias(tam);
                  setPaginaExistencias(1);
                }}
                nombreEntidadPlural="artículos"
              />
            )}
          </div>
        </div>
      )}

      {/* Modales */}
      <ModalRegistrarIngreso
        isOpen={modalIngresoAbierto}
        onClose={() => {
          setModalIngresoAbierto(false);
          setEppPreseleccionadoIngreso(undefined);
        }}
        catalogoEPP={catalogoEPP}
        eppInicialCodigo={eppPreseleccionadoIngreso}
        onGuardar={onRegistrarIngresoStock}
      />

      <ModalDetalleIngreso
        isOpen={!!ingresoSeleccionadoDetalle}
        onClose={() => setIngresoSeleccionadoDetalle(null)}
        ingreso={ingresoSeleccionadoDetalle}
      />
    </div>
  );
};
