import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { LiquidacionesModule } from '../LiquidacionesModule';
import { CATALOGO_EPP_SEED } from '../../../data/seeds/catalogoEPP';
import { EMPRESAS_SEED } from '../../../data/seeds/empresas';
import { Trabajador, EntregaEPP } from '../../../types';

const mockTrabajadores: Trabajador[] = [
  {
    codigo: 'TRAB-P001',
    dni: '45892134',
    nombreCompleto: 'Juan Carlos Pérez García',
    empresaId: 'EMP-PERPOL',
    empresaNombre: 'PERPOL IDEAS S.A.C.',
    area: 'Producción',
    cargo: 'Operario de Pasteurización',
    fechaIngreso: '2023-03-15',
    estado: 'Activo'
  },
  {
    codigo: 'TRAB-RRHH01',
    dni: '44556677',
    nombreCompleto: 'Lic. Ana Paredes Solís',
    empresaId: 'EMP-PERPOL',
    empresaNombre: 'PERPOL IDEAS S.A.C.',
    area: 'Recursos Humanos',
    cargo: 'Coordinadora de Recursos Humanos',
    fechaIngreso: '2022-01-15',
    estado: 'Activo'
  }
];

const mockEntregas: EntregaEPP[] = [
  {
    id: 'ENT-2026-0001',
    numeroRegistro: 'REG-0001',
    fechaEntrega: '2026-01-15',
    codigoTrabajador: 'TRAB-P001',
    dni: '45892134',
    trabajadorNombre: 'Juan Carlos Pérez García',
    empresaId: 'EMP-PERPOL',
    razonSocial: 'PERPOL IDEAS S.A.C.',
    ruc: '20392729977',
    direccion: 'CAL.LOS BRILLANTES NRO. 096',
    actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
    area: 'Producción',
    cargo: 'Operario',
    numTrabajadoresActivosCalculado: 10,
    fechaHoraCalculoTrabajadores: '2026-01-15 08:30:00',
    responsableEntrega: 'Supervisor SSOMA',
    tipoEntregaGeneral: 'Entrega inicial',
    observacionesGenerales: '',
    totalUnidades: 1,
    importeTotal: 48.50,
    estado: 'Confirmada',
    codigoPlantilla: 'FO-SST-GEN-050',
    versionPlantilla: '02',
    fechaCreacion: '2026-01-15 08:30:00',
    operationId: 'op-mock-1',
    detalles: []
  }
];

describe('LiquidacionesModule - Empresa y V°B° Recursos Humanos / Administración', () => {
  it('muestra solo la empresa a la que pertenece el trabajador (sin selector desplegable) y completa Nombre y Puesto de Trabajo en V°B° RRHH', () => {
    const handleGuardada = vi.fn();
    const handleCambiarEmpresa = vi.fn();

    render(
      <LiquidacionesModule
        liquidaciones={[]}
        trabajadores={mockTrabajadores}
        catalogoEPP={CATALOGO_EPP_SEED}
        entregas={mockEntregas}
        empresas={EMPRESAS_SEED}
        empresaFiltro="TODAS"
        trabajadorPreseleccionado="TRAB-P001"
        onCambiarEmpresaFiltro={handleCambiarEmpresa}
        onLiquidacionGuardada={handleGuardada}
      />
    );

    // 1. La empresa debe mostrarse directamente como texto de la ficha, NO como selector desplegable
    expect(screen.getByText('PERPOL IDEAS S.A.C.')).toBeDefined();
    // No debe existir selector desplegable para empresa empleadora
    expect(screen.queryByRole('combobox', { name: /Empresa Empleadora/i })).toBeNull();

    // 2. Sección V°B° Recursos Humanos / Administración con badge de Área RRHH
    expect(screen.getByText(/V°B° Recursos Humanos \/ Administración/i)).toBeDefined();
    expect(screen.getByText(/Área RRHH/i)).toBeDefined();

    // Debe mostrar exactamente los dos campos: Nombre y Puesto de Trabajo
    const inputNombre = screen.getByPlaceholderText(/Nombre de RRHH.../i) as HTMLInputElement;
    const inputPuesto = screen.getByPlaceholderText(/Puesto de trabajo \(ej\. Jefa de Recursos Humanos\)\.\.\./i) as HTMLInputElement;

    expect(inputNombre).toBeDefined();
    expect(inputPuesto).toBeDefined();

    // Al escribir o autocompletar un colaborador de RRHH, autocompleta su puesto de trabajo
    fireEvent.change(inputNombre, { target: { value: 'Lic. Ana Paredes Solís' } });
    expect(inputPuesto.value).toBe('Coordinadora de Recursos Humanos');
  });
});
