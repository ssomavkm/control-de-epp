import React, { useState, useMemo, useEffect } from 'react';
import {
  Scale,
  Plus,
  Search,
  FileText,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Filter,
  Layers,
  Calendar,
  RotateCcw,
  Eye,
  AlertTriangle,
  FileCheck2,
  Info,
  DollarSign,
  Package,
  Clock,
  UserCheck
} from 'lucide-react';
import {
  LiquidacionEPP,
  ItemLiquidacionEPP,
  EstadoLiquidacion,
  EstadoItemLiquidacion,
  Trabajador,
  EPPItem,
  Empresa,
  EntregaEPP,
  DatosPreseleccionadosLiquidacion,
  RESPONSABLES_SST_OPCIONES
} from '../../types';
import { storageService } from '../../services/storageService';
import { PDFGeneratorService } from '../../services/pdfGenerator';
import { googleDriveService } from '../../services/drive/googleDriveService';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { SignaturePad } from '../common/SignaturePad';
import { TablePagination } from '../common/TablePagination';
import { ModuleHeader } from '../common/ModuleHeader';
import { ModuleFilterBar } from '../common/ModuleFilterBar';
import { TrabajadorSearchAutocomplete } from '../common/TrabajadorSearchAutocomplete';
import { compararFechasDesc } from '../../utils/formatters';
import { obtenerEmpresaCanonica } from '../../utils/empresaResolver';

interface LiquidacionesModuleProps {
  liquidaciones: LiquidacionEPP[];
  trabajadores: Trabajador[];
  catalogoEPP: EPPItem[];
  entregas: EntregaEPP[];
  empresas: Empresa[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  trabajadorPreseleccionado?: string;
  datosPreseleccionados?: DatosPreseleccionadosLiquidacion | null;
  onLimpiarDatosPreseleccionados?: () => void;
  onLiquidacionGuardada: () => void;
  onActualizarTrabajadorCese?: (codigoTrabajador: string, fechaCese: string) => Promise<void>;
}

const MOTIVOS_CESE = [
  'Término de Contrato',
  'Renuncia Voluntaria',
  'Mutuo Disenso',
  'Despido por Causa Justa',
  'Despido Arbitrario / Sin Expresión de Causa',
  'No Superación del Periodo de Prueba',
  'Jubilación',
  'Cese por Invalidez Absoluta Permanente'
];

export const LiquidacionesModule: React.FC<LiquidacionesModuleProps> = ({
  liquidaciones,
  trabajadores,
  catalogoEPP,
  entregas,
  empresas,
  empresaFiltro,
  onCambiarEmpresaFiltro,
  trabajadorPreseleccionado,
  datosPreseleccionados,
  onLimpiarDatosPreseleccionados,
  onLiquidacionGuardada,
  onActualizarTrabajadorCese
}) => {
  const [vistaActiva, setVistaActiva] = useState<'lista' | 'nuevo'>(() => {
    return trabajadorPreseleccionado || datosPreseleccionados ? 'nuevo' : 'lista';
  });

  // Filtros de listado
  const [busqueda, setBusqueda] = useState<string>('');
  const [filtroEstado, setFiltroEstado] = useState<string>('TODOS');

  // Visor PDF
  const [modalPDFOpen, setModalPDFOpen] = useState<boolean>(false);
  const [pdfData, setPdfData] = useState<{ url: string | null; buffer: ArrayBuffer | null; fileName: string }>({
    url: null,
    buffer: null,
    fileName: ''
  });
  const [generandoPDF, setGenerandoPDF] = useState<boolean>(false);

  // Modal de Detalle de Liquidación Previa
  const [liquidacionDetalle, setLiquidacionDetalle] = useState<LiquidacionEPP | null>(null);

  // Mensajes de feedback
  const [mensajeExito, setMensajeExito] = useState<string | null>(null);
  const [mensajeError, setMensajeError] = useState<string | null>(null);

  // --- Formulario de Nueva Liquidación ---
  const [codigoTrabajador, setCodigoTrabajador] = useState<string>(
    trabajadorPreseleccionado || datosPreseleccionados?.codigoTrabajador || ''
  );
  const [fechaCese, setFechaCese] = useState<string>(
    () => datosPreseleccionados?.fechaCese || new Date().toISOString().split('T')[0]
  );
  const [motivoCese, setMotivoCese] = useState<string>(
    () => datosPreseleccionados?.motivoCese || 'Término de Contrato'
  );
  const [actualizarEstadoCesado, setActualizarEstadoCesado] = useState<boolean>(true);

  const [itemsAuditoria, setItemsAuditoria] = useState<ItemLiquidacionEPP[]>([]);
  const [observacionesGenerales, setObservacionesGenerales] = useState<string>('');

  const [responsableSeleccionado, setResponsableSeleccionado] = useState<string>(
    'Ing. Jhon Rojas (Supervisor SSOMA)'
  );
  const [responsableNombre, setResponsableNombre] = useState<string>('Ing. Jhon Rojas');
  const [responsableCargo, setResponsableCargo] = useState<string>('Supervisor SSOMA');

  const [responsableRRHH, setResponsableRRHH] = useState<string>('Lic. Patricia Vargas');
  const [puestoRRHH, setPuestoRRHH] = useState<string>('Jefa de Recursos Humanos');

  const [firmaTrabajador, setFirmaTrabajador] = useState<string>('');
  const [firmaSupervisor, setFirmaSupervisor] = useState<string>('');

  const [guardando, setGuardando] = useState<boolean>(false);

  // Plantilla oficial activa
  const plantillaActiva = useMemo(() => {
    return (
      storageService.getPlantillaPorCodigo('FO-SST-LIQ-001') || {
        id: 'PLANT-LIQ-01',
        codigo: 'FO-SST-LIQ-001',
        version: '01',
        nombre: 'ACTA DE LIQUIDACIÓN DE EPP POR CESE LABORAL',
        fechaAprobacion: '02/01/2026',
        estado: 'Activa' as const,
        descripcion: 'Liquidación oficial y balance de amortización de EPP en cese'
      }
    );
  }, []);

  // Manejo de cambio de supervisor
  const handleCambiarResponsable = (valor: string) => {
    setResponsableSeleccionado(valor);
    const encontrado = RESPONSABLES_SST_OPCIONES.find((r) => r.valor === valor);
    if (encontrado) {
      setResponsableNombre(encontrado.nombre);
      setResponsableCargo(encontrado.cargo);
    } else {
      const match = valor.match(/^(.*?)\s*\((.*?)\)$/);
      if (match) {
        setResponsableNombre(match[1].trim());
        setResponsableCargo(match[2].trim());
      } else {
        setResponsableNombre(valor);
      }
    }
  };

  // Personal del área de RRHH para autocompletar V°B° Recursos Humanos / Administración
  const personalRRHH = useMemo(() => {
    const todos = Array.isArray(trabajadores) ? trabajadores : [];
    return todos.filter((t) => {
      const area = (t.area || '').toUpperCase().trim();
      const cargo = (t.cargo || t.puesto || '').toUpperCase().trim();
      return (
        area === 'RRHH' ||
        area === 'RECURSOS HUMANOS' ||
        area.includes('RRHH') ||
        area.includes('RECURSOS HUMANOS') ||
        area.includes('TALENTO') ||
        area.includes('PERSONAL') ||
        cargo.includes('RRHH') ||
        cargo.includes('RECURSOS HUMANOS') ||
        cargo.includes('TALENTO')
      );
    });
  }, [trabajadores]);

  // Manejo de autocompletado con colaborador de RRHH (SOLO DOS DATOS: NOMBRE Y PUESTO DE TRABAJO)
  const handleSeleccionarRRHH = (codigo: string) => {
    if (!codigo) return;
    const seleccionado = personalRRHH.find((p) => p.codigo === codigo);
    if (seleccionado) {
      const nombre = seleccionado.nombreCompleto || seleccionado.apellidosNombres || '';
      const puesto = seleccionado.puesto || seleccionado.cargo || 'Recursos Humanos';
      setResponsableRRHH(nombre);
      setPuestoRRHH(puesto);
    }
  };

  const handleNombreRRHHChange = (val: string) => {
    setResponsableRRHH(val);
    const coincidencia = personalRRHH.find(
      (p) => (p.nombreCompleto || p.apellidosNombres || '').toLowerCase().trim() === val.toLowerCase().trim()
    );
    if (coincidencia) {
      setPuestoRRHH(coincidencia.puesto || coincidencia.cargo || 'Recursos Humanos');
    }
  };

  // Trabajador seleccionado actualmente en el formulario
  const trabajadorSeleccionado = useMemo(() => {
    if (!codigoTrabajador) return undefined;
    return trabajadores.find((t) => t.codigo === codigoTrabajador || t.dni === codigoTrabajador);
  }, [codigoTrabajador, trabajadores]);

  // Empresa exacta a la cual pertenece el trabajador
  const empresaTrabajador = useMemo(() => {
    if (!trabajadorSeleccionado) return undefined;

    // 1. Revisar si el trabajador tiene historial de entregas registradas en alguna empresa
    const entregasTrabajador = (entregas || []).filter(
      (e) => e.codigoTrabajador === trabajadorSeleccionado.codigo || e.dni === trabajadorSeleccionado.dni
    );
    if (entregasTrabajador.length > 0) {
      const ult = entregasTrabajador[0];
      return obtenerEmpresaCanonica(ult, empresas);
    }

    // 2. Si hay filtro activo de empresa en la barra superior (diferente a TODAS)
    if (empresaFiltro && empresaFiltro !== 'TODAS') {
      return obtenerEmpresaCanonica(empresaFiltro, empresas);
    }

    // 3. Resolución canónica analizando datos del trabajador
    return obtenerEmpresaCanonica(trabajadorSeleccionado, empresas);
  }, [trabajadorSeleccionado, entregas, empresaFiltro, empresas]);

  // Sincronizar trabajador preseleccionado desde el exterior
  useEffect(() => {
    if (trabajadorPreseleccionado) {
      setCodigoTrabajador(trabajadorPreseleccionado);
      setVistaActiva('nuevo');
    }
  }, [trabajadorPreseleccionado]);

  useEffect(() => {
    if (datosPreseleccionados?.codigoTrabajador) {
      setCodigoTrabajador(datosPreseleccionados.codigoTrabajador);
      if (datosPreseleccionados.fechaCese) setFechaCese(datosPreseleccionados.fechaCese);
      if (datosPreseleccionados.motivoCese) setMotivoCese(datosPreseleccionados.motivoCese);
      setVistaActiva('nuevo');
    }
  }, [datosPreseleccionados]);

  // Auditoría automática de entregas cuando cambia el trabajador o la fecha de cese
  useEffect(() => {
    if (!codigoTrabajador) {
      setItemsAuditoria([]);
      return;
    }

    const audit = storageService.prepararAuditoriaCese(codigoTrabajador, fechaCese);
    setItemsAuditoria(audit.items);
  }, [codigoTrabajador, fechaCese]);

  // Cambiar estado o cantidades de un ítem de liquidación
  const handleActualizarItem = (
    idItem: string,
    cambios: Partial<ItemLiquidacionEPP>
  ) => {
    setItemsAuditoria((prev) =>
      prev.map((it) => {
        if (it.idItem !== idItem) return it;

        const updated = { ...it, ...cambios };

        // Si se cambió el estado principal del ítem
        if (cambios.estadoItem) {
          if (cambios.estadoItem === 'Vencido') {
            updated.cantidadVencida = updated.cantidadEntregada;
            updated.cantidadDevuelta = 0;
            updated.cantidadALiquidar = 0;
            updated.montoALiquidar = 0;
            updated.observaciones = 'Amortizado 100% por tiempo de vida útil cumplido. No genera costo al trabajador.';
          } else if (cambios.estadoItem === 'Devuelto') {
            updated.cantidadDevuelta = updated.cantidadEntregada;
            updated.cantidadVencida = 0;
            updated.cantidadALiquidar = 0;
            updated.montoALiquidar = 0;
            updated.observaciones = 'Devuelto físicamente a almacén en buen estado de conservación.';
          } else if (cambios.estadoItem === 'Pendiente') {
            updated.cantidadALiquidar = updated.cantidadEntregada;
            updated.cantidadDevuelta = 0;
            updated.cantidadVencida = 0;
            updated.montoALiquidar = updated.cantidadALiquidar * updated.costoUnitario;
            updated.observaciones = 'Equipo vigente no devuelto en almacén; sujeto a descuento en liquidación.';
          } else if (cambios.estadoItem === 'Exonerado') {
            updated.cantidadDevuelta = 0;
            updated.cantidadVencida = 0;
            updated.cantidadALiquidar = 0;
            updated.montoALiquidar = 0;
            updated.observaciones = 'Exonerado de cobro por disposición expresa de la jefatura de SSOMA.';
          }
        }

        // Si se modificaron cantidades manuales
        if (cambios.cantidadALiquidar !== undefined) {
          const cantALiq = Math.max(0, Number(cambios.cantidadALiquidar) || 0);
          updated.cantidadALiquidar = cantALiq;
          updated.montoALiquidar = cantALiq * updated.costoUnitario;
        }

        return updated;
      })
    );
  };

  // Acciones en lote para el formulario de auditoría
  const handleMarcarTodosVigentesComoDevueltos = () => {
    setItemsAuditoria((prev) =>
      prev.map((it) => {
        const estaVencido = it.fechaVencimiento && it.fechaVencimiento <= fechaCese;
        if (estaVencido) {
          return {
            ...it,
            estadoItem: 'Vencido',
            cantidadVencida: it.cantidadEntregada,
            cantidadDevuelta: 0,
            cantidadALiquidar: 0,
            montoALiquidar: 0,
            observaciones: 'Amortizado 100% por tiempo de vida útil cumplido.'
          };
        }
        return {
          ...it,
          estadoItem: 'Devuelto',
          cantidadDevuelta: it.cantidadEntregada,
          cantidadVencida: 0,
          cantidadALiquidar: 0,
          montoALiquidar: 0,
          observaciones: 'Devuelto físicamente a almacén en buen estado.'
        };
      })
    );
  };

  const handleMarcarTodosVigentesComoNoDevueltos = () => {
    setItemsAuditoria((prev) =>
      prev.map((it) => {
        const estaVencido = it.fechaVencimiento && it.fechaVencimiento <= fechaCese;
        if (estaVencido) {
          return {
            ...it,
            estadoItem: 'Vencido',
            cantidadVencida: it.cantidadEntregada,
            cantidadDevuelta: 0,
            cantidadALiquidar: 0,
            montoALiquidar: 0,
            observaciones: 'Amortizado 100% por tiempo de vida útil cumplido.'
          };
        }
        return {
          ...it,
          estadoItem: 'Pendiente',
          cantidadALiquidar: it.cantidadEntregada,
          cantidadDevuelta: 0,
          cantidadVencida: 0,
          montoALiquidar: it.cantidadEntregada * it.costoUnitario,
          observaciones: 'Equipo vigente no retornado a almacén. Sujeto a cobro en liquidación.'
        };
      })
    );
  };

  const handleRestablecerAuditoria = () => {
    if (!codigoTrabajador) return;
    const audit = storageService.prepararAuditoriaCese(codigoTrabajador, fechaCese);
    setItemsAuditoria(audit.items);
  };

  // Cálculos consolidados en tiempo real del formulario actual
  const resumenFormulario = useMemo(() => {
    const totalEntregados = itemsAuditoria.reduce((acc, it) => acc + (Number(it.cantidadEntregada) || 0), 0);
    const totalDevueltos = itemsAuditoria.reduce((acc, it) => acc + (Number(it.cantidadDevuelta) || 0), 0);
    const totalVencidos = itemsAuditoria.reduce((acc, it) => acc + (Number(it.cantidadVencida) || 0), 0);
    const totalALiquidar = itemsAuditoria.reduce((acc, it) => acc + (Number(it.cantidadALiquidar) || 0), 0);

    const montoTotalEntregado = itemsAuditoria.reduce((acc, it) => acc + (Number(it.importeTotalEntregado) || 0), 0);
    const montoNetoALiquidar = itemsAuditoria.reduce((acc, it) => acc + (Number(it.montoALiquidar) || 0), 0);
    const montoDeducido = Math.max(0, montoTotalEntregado - montoNetoALiquidar);

    return {
      totalEntregados,
      totalDevueltos,
      totalVencidos,
      totalALiquidar,
      montoTotalEntregado,
      montoDeducido,
      montoNetoALiquidar
    };
  }, [itemsAuditoria]);

  // Manejo de emisión y guardado de Liquidación
  const handleSubmitLiquidacion = async (e: React.FormEvent) => {
    e.preventDefault();
    setMensajeError(null);
    setMensajeExito(null);

    if (!codigoTrabajador || !trabajadorSeleccionado) {
      setMensajeError('Por favor seleccione un trabajador cesante.');
      return;
    }

    if (!fechaCese) {
      setMensajeError('Por favor especifique la fecha de cese laboral.');
      return;
    }

    if (itemsAuditoria.length === 0) {
      setMensajeError('El trabajador no cuenta con entregas históricas de EPP para liquidar.');
      return;
    }

    setGuardando(true);
    try {
      const nuevoNumero = storageService.generarNuevoNumeroLiquidacion();
      const nuevoId = storageService.generarNuevoIdLiquidacion();

      const empresaFinal = empresaTrabajador || obtenerEmpresaCanonica(trabajadorSeleccionado, empresas);

      const nuevaLiquidacion: LiquidacionEPP = {
        id: nuevoId,
        numeroRegistro: nuevoNumero,
        codigoPlantilla: plantillaActiva.codigo || 'FO-SST-LIQ-001',
        versionPlantilla: plantillaActiva.version || '01',
        fechaLiquidacion: new Date().toISOString().split('T')[0],
        fechaCese: fechaCese,
        motivoCese: motivoCese,
        codigoTrabajador: trabajadorSeleccionado.codigo,
        dni: trabajadorSeleccionado.dni,
        trabajadorNombre: trabajadorSeleccionado.nombreCompleto || trabajadorSeleccionado.apellidosNombres || '',
        empresaId: empresaFinal.id,
        empresaNombre: empresaFinal.razonSocial,
        ruc: empresaFinal.ruc,
        area: trabajadorSeleccionado.area || 'Operaciones',
        cargo: trabajadorSeleccionado.cargo || trabajadorSeleccionado.puesto || 'Trabajador',
        fechaIngreso: trabajadorSeleccionado.fechaIngreso,
        items: itemsAuditoria,
        totalItemsEntregados: resumenFormulario.totalEntregados,
        totalItemsDevueltos: resumenFormulario.totalDevueltos,
        totalItemsVencidos: resumenFormulario.totalVencidos,
        totalItemsALiquidar: resumenFormulario.totalALiquidar,
        montoTotalEntregado: resumenFormulario.montoTotalEntregado,
        montoDescontadoVencidosYDevueltos: resumenFormulario.montoDeducido,
        montoNetoALiquidar: resumenFormulario.montoNetoALiquidar,
        observacionesGenerales: observacionesGenerales || `Liquidación de EPP por cese laboral (${motivoCese}). Total deducido por vencimientos y devoluciones: S/ ${resumenFormulario.montoDeducido.toFixed(2)}. Saldo a retener: S/ ${resumenFormulario.montoNetoALiquidar.toFixed(2)}.`,
        supervisorResponsable: responsableNombre,
        cargoSupervisor: responsableCargo,
        responsableRRHH: responsableRRHH,
        cargoRRHH: puestoRRHH,
        areaRRHH: 'Recursos Humanos',
        firmaTrabajador: firmaTrabajador || undefined,
        firmaSupervisor: firmaSupervisor || undefined,
        estado: 'Emitida',
        pdfFileName: `ACTA_LIQUIDACION_EPP_${nuevoNumero}_${trabajadorSeleccionado.dni}.pdf`,
        fechaCreacion: new Date().toISOString()
      };

      await storageService.registrarLiquidacion(nuevaLiquidacion);

      // Si se solicitó actualizar el estado del trabajador a Cesado
      if (actualizarEstadoCesado && onActualizarTrabajadorCese) {
        try {
          await onActualizarTrabajadorCese(trabajadorSeleccionado.codigo, fechaCese);
        } catch (err) {
          console.warn('No se pudo actualizar condición del trabajador a Cesado:', err);
        }
      }

      onLiquidacionGuardada();
      if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();

      setMensajeExito(
        `¡Acta ${nuevoNumero} emitida con éxito! Se cargó un saldo neto de S/ ${nuevaLiquidacion.montoNetoALiquidar.toFixed(2)}.`
      );

      // Generar PDF y abrir visor
      try {
        setGenerandoPDF(true);
        const pdfRes = await PDFGeneratorService.generarDocumentoLiquidacionPDF(nuevaLiquidacion, plantillaActiva);
        setPdfData({
          url: pdfRes.blobUrl,
          buffer: pdfRes.arrayBuffer,
          fileName: pdfRes.fileName
        });
        setModalPDFOpen(true);

        // Respaldo automático del acta de liquidación en Google Drive
        if (pdfRes && pdfRes.blob) {
          googleDriveService.subirArchivo({
            nombreArchivo: pdfRes.fileName,
            mimeType: 'application/pdf',
            datosBlob: pdfRes.blob,
            subcarpeta: '05_Liquidaciones_EPP',
            claveIdentificador: nuevaLiquidacion.numeroRegistro,
            descripcion: `Acta de Devolución y Liquidación de EPP ${nuevaLiquidacion.numeroRegistro} - ${nuevaLiquidacion.trabajadorNombre}`
          }).catch(e => console.info('Respaldo automático en Drive diferido:', e));
        }
      } catch (pdfErr) {
        console.warn('Error al previsualizar PDF de liquidación:', pdfErr);
      } finally {
        setGenerandoPDF(false);
      }

      // Limpiar formulario y volver al listado
      setCodigoTrabajador('');
      setFirmaTrabajador('');
      setFirmaSupervisor('');
      setObservacionesGenerales('');
      setVistaActiva('lista');
    } catch (err: any) {
      setMensajeError(err.message || 'Error al guardar la liquidación de EPP.');
    } finally {
      setGuardando(false);
    }
  };

  // Abrir PDF de una liquidación histórica
  const handleVerPDFLiquidacion = async (liq: LiquidacionEPP) => {
    setGenerandoPDF(true);
    try {
      const pdfRes = await PDFGeneratorService.generarDocumentoLiquidacionPDF(liq, plantillaActiva);
      setPdfData({
        url: pdfRes.blobUrl,
        buffer: pdfRes.arrayBuffer,
        fileName: pdfRes.fileName
      });
      setModalPDFOpen(true);
    } catch (err: any) {
      setMensajeError(`Error al generar el PDF del acta ${liq.numeroRegistro}: ${err.message}`);
    } finally {
      setGenerandoPDF(false);
    }
  };

  // Filtrado de liquidaciones para la tabla de historial
  const liquidacionesFiltradas = useMemo(() => {
    return liquidaciones.filter((liq) => {
      // Filtro por empresa
      if (empresaFiltro && empresaFiltro !== 'TODAS') {
        if (liq.empresaId !== empresaFiltro) return false;
      }

      // Filtro por estado
      if (filtroEstado !== 'TODOS') {
        if (liq.estado !== filtroEstado) return false;
      }

      // Filtro por búsqueda
      if (busqueda.trim()) {
        const q = busqueda.toLowerCase().trim();
        const matchNum = String(liq.numeroRegistro || '').toLowerCase().includes(q);
        const matchTrab = String(liq.trabajadorNombre || '').toLowerCase().includes(q);
        const matchDni = String(liq.dni || '').includes(q);
        const items = Array.isArray(liq.items) ? liq.items : [];
        const matchArt = items.some((it) => it && it.articulo && it.articulo.toLowerCase().includes(q));
        if (!matchNum && !matchTrab && !matchDni && !matchArt) return false;
      }

      return true;
    }).sort((a, b) => compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro));
  }, [liquidaciones, empresaFiltro, filtroEstado, busqueda]);

  // KPIs consolidados del historial
  const kpisHistorial = useMemo(() => {
    const totalDocs = liquidacionesFiltradas.length;
    const totalEntregadosSoles = liquidacionesFiltradas.reduce(
      (acc, l) => acc + (Number(l.montoTotalEntregado) || 0),
      0
    );
    const totalDeducidoSoles = liquidacionesFiltradas.reduce(
      (acc, l) => acc + (Number(l.montoDescontadoVencidosYDevueltos) || 0),
      0
    );
    const totalNetoSoles = liquidacionesFiltradas.reduce(
      (acc, l) => acc + (Number(l.montoNetoALiquidar) || 0),
      0
    );
    const liquidadasEnPlanilla = liquidacionesFiltradas.filter((l) => l.estado === 'Liquidada en Planilla').length;

    return {
      totalDocs,
      totalEntregadosSoles,
      totalDeducidoSoles,
      totalNetoSoles,
      liquidadasEnPlanilla
    };
  }, [liquidacionesFiltradas]);

  // Paginación para historial de liquidaciones
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, empresaFiltro, filtroEstado, liquidaciones.length]);

  const totalPaginas = Math.max(1, Math.ceil(liquidacionesFiltradas.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;

  const liquidacionesPaginadas = useMemo(() => {
    return liquidacionesFiltradas.slice(indiceInicio, indiceInicio + porPagina);
  }, [liquidacionesFiltradas, indiceInicio, porPagina]);

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Encabezado del Módulo con Formato Aprobado FO-SST-LIQ-001 Estandarizado */}
      <ModuleHeader
        icon={Scale}
        title="Liquidación de EPP por Cese Laboral"
        badge={`${plantillaActiva.codigo} v${plantillaActiva.version}`}
        subtitle="Auditoría integral y valorización de equipos entregados al trabajador cesante, deduciendo EPPs con vida útil cumplida (amortizados) y EPPs devueltos físicamente al almacén."
        colorTheme="purple"
        actions={
          vistaActiva === 'lista' ? (
            <button
              onClick={() => {
                setVistaActiva('nuevo');
                if (trabajadorPreseleccionado) setCodigoTrabajador(trabajadorPreseleccionado);
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Emitir Liquidación de Cese</span>
            </button>
          ) : null
        }
      />

      {mensajeExito && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2.5 shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{mensajeExito}</span>
        </div>
      )}

      {mensajeError && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center justify-between gap-2.5 shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{mensajeError}</span>
          </div>
          <button
            onClick={() => setMensajeError(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* =========================================================================
          VISTA 1: FORMULARIO DE NUEVA LIQUIDACIÓN POR CESE
          ========================================================================= */}
      {vistaActiva === 'nuevo' && (
        <form onSubmit={handleSubmitLiquidacion} className="space-y-6">
          {/* PASO 1: SELECCIÓN DEL TRABAJADOR Y DATOS DEL CESE */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center border border-slate-200">
                  1
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Datos del Trabajador Cesante y Fecha de Cese
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Seleccione al trabajador para cargar automáticamente todas las dotaciones históricas de EPP y ropa de trabajo.
                  </p>
                </div>
              </div>
              {trabajadorSeleccionado && (
                <span
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                    trabajadorSeleccionado.estado === 'Cesado'
                      ? 'bg-slate-100 text-slate-800 border-slate-200'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  }`}
                >
                  Condición Actual: {trabajadorSeleccionado.estado}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Selector de Trabajador Predictivo */}
              <div className="md:col-span-1">
                <TrabajadorSearchAutocomplete
                  trabajadores={trabajadores}
                  valorSeleccionado={codigoTrabajador}
                  onSeleccionar={(t) => setCodigoTrabajador(t ? t.codigo : '')}
                  empresaFiltro={empresaFiltro}
                  label="Trabajador a Liquidar"
                  required
                  colorTheme="emerald"
                  placeholder="Escriba nombre, apellido o DNI..."
                />
              </div>

              {/* Fecha Efectiva de Cese */}
              <div className="space-y-1.5 md:col-span-1">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-rose-600" />
                  Fecha Efectiva de Cese *
                </label>
                <input
                  type="date"
                  value={fechaCese}
                  onChange={(e) => setFechaCese(e.target.value)}
                  className="w-full h-9.5 px-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
                  required
                />
              </div>

              {/* Motivo de Extinción / Cese */}
              <div className="space-y-1.5 md:col-span-1">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  Motivo de Cese Laboral *
                </label>
                <select
                  value={motivoCese}
                  onChange={(e) => setMotivoCese(e.target.value)}
                  className="w-full h-9.5 px-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all cursor-pointer"
                >
                  {MOTIVOS_CESE.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Ficha rápida del trabajador seleccionado */}
            {trabajadorSeleccionado && (
              <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-200 text-slate-700 font-bold flex items-center justify-center shrink-0 border border-slate-300">
                    {trabajadorSeleccionado.nombreCompleto?.slice(0, 2).toUpperCase() || 'TR'}
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">
                      {trabajadorSeleccionado.nombreCompleto || trabajadorSeleccionado.apellidosNombres}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-2">
                      <span>DNI: {trabajadorSeleccionado.dni}</span>
                      <span>•</span>
                      <span>Área: {trabajadorSeleccionado.area}</span>
                      <span>•</span>
                      <span>Puesto: {trabajadorSeleccionado.cargo || trabajadorSeleccionado.puesto}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Empresa</span>
                    <span className="font-semibold text-slate-700">
                      {empresaTrabajador?.razonSocial || trabajadorSeleccionado.empresaNombre || 'PERPOL IDEAS S.A.C.'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Ingreso</span>
                    <span className="font-semibold text-slate-700 font-mono">
                      {trabajadorSeleccionado.fechaIngreso || 'No registrada'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Opción para actualizar condición del trabajador */}
            <div className="pt-1">
              <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={actualizarEstadoCesado}
                  onChange={(e) => setActualizarEstadoCesado(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                />
                <span>
                  Actualizar automáticamente la condición del trabajador a <strong>"Cesado"</strong> en el Padrón de Trabajadores al emitir este acta.
                </span>
              </label>
            </div>
          </div>

          {/* PASO 2: CONTEO, AUDITORÍA Y VALORIZACIÓN DE ENTREGAS (EL NÚCLEO) */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center border border-slate-200">
                  2
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Auditoría de Entregas y Ajuste por Vencimiento / Devolución
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    El sistema resta automáticamente los EPPs con tiempo de vida útil vencido y los EPPs devueltos físicamente.
                  </p>
                </div>
              </div>

              {/* Botones de acción rápida de lote */}
              {itemsAuditoria.length > 0 && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleMarcarTodosVigentesComoDevueltos}
                    className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors cursor-pointer"
                    title="Marca todos los equipos vigentes como devueltos al almacén (deducción a S/ 0)"
                  >
                    ✓ Todos Devueltos
                  </button>
                  <button
                    type="button"
                    onClick={handleMarcarTodosVigentesComoNoDevueltos}
                    className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-colors cursor-pointer"
                    title="Marca los equipos vigentes como no devueltos para cargo a liquidación"
                  >
                    ✕ Todos No Devueltos
                  </button>
                  <button
                    type="button"
                    onClick={handleRestablecerAuditoria}
                    className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                    title="Restablecer cálculo automático"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            {/* Cuadro explicativo de las reglas de liquidación */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-3 text-xs text-slate-800">
              <Info className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-[11.5px] text-slate-900">
                  Criterios Técnicos de Liquidación Oficial de EPP (Ley N° 29783 / D.S. 005-2012-TR):
                </p>
                <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-700">
                  <li>
                    <strong>Vencidos / Amortizados:</strong> Equipos cuya fecha estimada de cambio venció antes o al cese. Están amortizados al 100% y <strong>no generan cobro</strong> al trabajador (descuento S/ 0.00).
                  </li>
                  <li>
                    <strong>Devueltos a Almacén:</strong> Equipos vigentes que el trabajador entrega físicamente en buen estado al almacén. <strong>No generan cobro</strong> (descuento S/ 0.00).
                  </li>
                  <li>
                    <strong>No Devueltos / Pendientes:</strong> Equipos vigentes que el trabajador retuvo, extravió o no entregó al almacén. Son los únicos que conforman la <strong>lista oficial a descontar</strong> en la liquidación de beneficios sociales.
                  </li>
                </ul>
              </div>
            </div>

            {/* Tabla de ítems auditados */}
            {itemsAuditoria.length === 0 ? (
              <div className="text-center py-10 px-4 bg-slate-50/60 rounded-xl border border-dashed border-slate-200">
                <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h4 className="text-xs font-bold text-slate-700">
                  {codigoTrabajador
                    ? 'No se encontraron entregas de EPP registradas para este trabajador'
                    : 'Seleccione un trabajador en el Paso 1 para ver el detalle de entregas'}
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5 max-w-md mx-auto">
                  {codigoTrabajador
                    ? 'Si el trabajador recibió equipos con anterioridad, asegúrese de que figuren en el módulo de Entregas de EPP.'
                    : 'La auditoría cargará automáticamente todos los implementos asignados históricamente.'}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs min-w-[850px]">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                      <th className="py-2.5 px-3 w-10 text-center">N°</th>
                      <th className="py-2.5 px-3">F. Entrega</th>
                      <th className="py-2.5 px-3">Artículo / EPP</th>
                      <th className="py-2.5 px-3 text-center">Cant.</th>
                      <th className="py-2.5 px-3">F. Vencimiento</th>
                      <th className="py-2.5 px-3">Condición en Cese</th>
                      <th className="py-2.5 px-3 text-right">P. Unit.</th>
                      <th className="py-2.5 px-3 text-right">A Cobrar</th>
                      <th className="py-2.5 px-3">Observación</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {itemsAuditoria.map((it, idx) => {
                      const estaVencidoCalculado = it.fechaVencimiento && it.fechaVencimiento <= fechaCese;

                      return (
                        <tr
                          key={it.idItem}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            it.estadoItem === 'Pendiente' && it.montoALiquidar > 0
                              ? 'bg-rose-50/30'
                              : it.estadoItem === 'Vencido'
                              ? 'bg-emerald-50/20'
                              : ''
                          }`}
                        >
                          <td className="py-2.5 px-3 text-center text-slate-400 font-mono text-[10px]">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-600 whitespace-nowrap">
                            <div>{it.fechaEntrega || '-'}</div>
                            <div className="text-[10px] text-slate-400">{it.numeroRegistroOrigen}</div>
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="font-semibold text-slate-900">{it.articulo}</div>
                            <div className="text-[10px] text-slate-500 flex items-center gap-2">
                              <span>Talla: {it.talla || 'Estándar'}</span>
                              <span>•</span>
                              <span>Código: {it.codigoEPP}</span>
                            </div>
                          </td>
                          <td className="py-2.5 px-3 text-center font-bold text-slate-800">
                            {it.cantidadEntregada} {it.unidad || 'und'}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <div
                              className={`font-mono text-xs flex items-center gap-1 ${
                                estaVencidoCalculado ? 'text-emerald-700 font-bold' : 'text-slate-600'
                              }`}
                            >
                              {it.fechaVencimiento || '-'}
                            </div>
                            <span
                              className={`text-[10px] inline-block px-1.5 py-0.2 rounded font-semibold ${
                                estaVencidoCalculado
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {estaVencidoCalculado ? 'Vida Útil Cumplida' : 'Vigente al Cese'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3">
                            <select
                              value={it.estadoItem}
                              onChange={(e) =>
                                handleActualizarItem(it.idItem, {
                                  estadoItem: e.target.value as EstadoItemLiquidacion
                                })
                              }
                              className={`h-8 px-2 rounded-lg text-xs font-semibold border cursor-pointer transition-colors ${
                                it.estadoItem === 'Vencido'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : it.estadoItem === 'Devuelto'
                                  ? 'bg-blue-50 text-blue-800 border-blue-200'
                                  : it.estadoItem === 'Pendiente'
                                  ? 'bg-rose-50 text-rose-800 border-rose-300 font-bold'
                                  : 'bg-slate-50 text-slate-700 border-slate-200'
                              }`}
                            >
                              <option value="Vencido">✓ Vencido (Amortizado 100%)</option>
                              <option value="Devuelto">✓ Devuelto al Almacén</option>
                              <option value="Pendiente">✕ No Devuelto (A Cobrar)</option>
                              <option value="Exonerado">○ Exonerado SSOMA</option>
                            </select>
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                            S/ {it.costoUnitario.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold">
                            {it.montoALiquidar > 0 ? (
                              <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                                S/ {it.montoALiquidar.toFixed(2)}
                              </span>
                            ) : (
                              <span className="text-emerald-700">S/ 0.00</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 min-w-[140px]">
                            <input
                              type="text"
                              value={it.observaciones || ''}
                              onChange={(e) =>
                                handleActualizarItem(it.idItem, {
                                  observaciones: e.target.value
                                })
                              }
                              placeholder="Observación..."
                              className="w-full h-7 px-2 rounded border border-slate-200 text-[11px] text-slate-700 focus:bg-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* BALANCE Y RESUMEN FINANCIERO OFICIAL (TARJETA COMPARATIVA) */}
            {itemsAuditoria.length > 0 && (
              <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 text-xs w-full md:w-auto">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">
                      Total Entregado Histórico
                    </span>
                    <span className="text-base font-bold text-slate-100">
                      S/ {resumenFormulario.montoTotalEntregado.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      ({resumenFormulario.totalEntregados} uds 100%)
                    </span>
                  </div>

                  <div>
                    <span className="text-emerald-400 block text-[10px] uppercase font-bold tracking-wider">
                      (-) Vencidos + Devueltos
                    </span>
                    <span className="text-base font-bold text-emerald-400">
                      - S/ {resumenFormulario.montoDeducido.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-emerald-300 block">
                      ({resumenFormulario.totalVencidos + resumenFormulario.totalDevueltos} uds exoneradas)
                    </span>
                  </div>

                  <div>
                    <span className="text-amber-300 block text-[10px] uppercase font-bold tracking-wider">
                      (=) Saldo Neto a Descontar
                    </span>
                    <span
                      className={`text-lg font-black ${
                        resumenFormulario.montoNetoALiquidar > 0 ? 'text-rose-400' : 'text-emerald-300'
                      }`}
                    >
                      S/ {resumenFormulario.montoNetoALiquidar.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-300 block">
                      ({resumenFormulario.totalALiquidar} uds a liquidar)
                    </span>
                  </div>
                </div>

                <div className="w-full md:w-auto text-right border-t md:border-t-0 md:border-l border-slate-700 pt-3 md:pt-0 md:pl-6">
                  {resumenFormulario.montoNetoALiquidar === 0 ? (
                    <div className="text-left md:text-right">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        Conformidad Total (Sin Deuda)
                      </span>
                      <p className="text-[10px] text-slate-400 mt-1">
                        Todo fue devuelto o se amortizó por vencimiento reglamentario.
                      </p>
                    </div>
                  ) : (
                    <div className="text-left md:text-right">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        <AlertTriangle className="w-4 h-4 text-rose-400" />
                        Cargo a Liquidación Final
                      </span>
                      <p className="text-[10px] text-slate-400 mt-1">
                        Se enviará esta deducción a Recursos Humanos para la liquidación.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* PASO 3: RESPONSABLES, FIRMAS Y OBSERVACIONES */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5">
            <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
              <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center border border-slate-200">
                3
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Responsables, Firmas de Conformidad y Emisión Oficial
                </h3>
                <p className="text-[11px] text-slate-500">
                  El acta oficial FO-SST-LIQ-001 se emitirá con firmas digitales y código QR de autenticidad.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Selector de Supervisor SSOMA */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700">
                  Supervisor SSOMA Responsable *
                </label>
                <select
                  value={responsableSeleccionado}
                  onChange={(e) => handleCambiarResponsable(e.target.value)}
                  className="w-full h-9.5 px-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 cursor-pointer"
                >
                  {RESPONSABLES_SST_OPCIONES.map((r) => (
                    <option key={r.valor} value={r.valor}>
                      {r.nombre} — {r.cargo}
                    </option>
                  ))}
                  <option value="otro">Otro Responsable...</option>
                </select>
                {responsableSeleccionado === 'otro' && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="Nombre supervisor..."
                      value={responsableNombre}
                      onChange={(e) => setResponsableNombre(e.target.value)}
                      className="h-8 px-2.5 rounded-lg border border-slate-200 text-xs text-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                      required
                    />
                    <input
                      type="text"
                      placeholder="Cargo supervisor..."
                      value={responsableCargo}
                      onChange={(e) => setResponsableCargo(e.target.value)}
                      className="h-8 px-2.5 rounded-lg border border-slate-200 text-xs text-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                      required
                    />
                  </div>
                )}
              </div>

              {/* Responsable de RRHH */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                    <span>V°B° Recursos Humanos / Administración</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-200">
                      Área RRHH
                    </span>
                  </label>
                  {personalRRHH.length > 0 && (
                    <span className="text-[11px] text-slate-500 font-medium">
                      {personalRRHH.length} colaborador(es) en RRHH
                    </span>
                  )}
                </div>

                {/* Selector rápido autocompletable con personal de RRHH */}
                {personalRRHH.length > 0 && (
                  <div className="space-y-1.5">
                    <select
                      aria-label="Seleccionar colaborador del Área de RRHH"
                      onChange={(e) => handleSeleccionarRRHH(e.target.value)}
                      defaultValue=""
                      className="w-full h-9 px-3 rounded-xl border border-purple-200 bg-purple-50/50 text-xs font-semibold text-purple-900 focus:bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 cursor-pointer transition-all"
                    >
                      <option value="">⚡ Seleccionar colaborador del Área de RRHH...</option>
                      {personalRRHH.map((p) => (
                        <option key={p.codigo} value={p.codigo}>
                          {p.nombreCompleto || p.apellidosNombres} — Puesto: {p.puesto || p.cargo} ({p.empresaNombre || p.empresaId})
                        </option>
                      ))}
                    </select>

                    {/* Chips de autocompletado en un clic */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Autocompletar:</span>
                      {personalRRHH.map((p) => {
                        const nombre = p.nombreCompleto || p.apellidosNombres || '';
                        const activo = responsableRRHH.trim() === nombre.trim();
                        return (
                          <button
                            key={p.codigo}
                            type="button"
                            onClick={() => {
                              setResponsableRRHH(nombre);
                              setPuestoRRHH(p.puesto || p.cargo || 'Recursos Humanos');
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1.5 border ${
                              activo
                                ? 'bg-purple-600 text-white border-purple-600 shadow-2xs'
                                : 'bg-slate-50 hover:bg-purple-50 text-slate-700 hover:text-purple-800 border-slate-200 hover:border-purple-300'
                            }`}
                          >
                            <UserCheck className={`w-3 h-3 ${activo ? 'text-white' : 'text-purple-600'}`} />
                            <span>{nombre}</span>
                            <span className={`text-[10px] ${activo ? 'text-purple-200' : 'text-slate-400'}`}>({p.puesto || p.cargo})</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* SOLO DOS DATOS: NOMBRE Y PUESTO DE TRABAJO */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase text-slate-500">Nombre *</label>
                    <div className="relative">
                      <input
                        type="text"
                        list="personal-rrhh-datalist"
                        placeholder="Nombre de RRHH..."
                        value={responsableRRHH}
                        onChange={(e) => handleNombreRRHHChange(e.target.value)}
                        className="w-full h-9.5 px-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-800 focus:bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                        required
                      />
                      <datalist id="personal-rrhh-datalist">
                        {personalRRHH.map((p) => (
                          <option key={p.codigo} value={p.nombreCompleto || p.apellidosNombres}>
                            Puesto: {p.puesto || p.cargo} — {p.empresaNombre}
                          </option>
                        ))}
                      </datalist>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase text-slate-500">Puesto de Trabajo *</label>
                    <input
                      type="text"
                      placeholder="Puesto de trabajo (ej. Jefa de Recursos Humanos)..."
                      value={puestoRRHH}
                      onChange={(e) => setPuestoRRHH(e.target.value)}
                      className="w-full h-9.5 px-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-800 focus:bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Observaciones Generales */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Observaciones Generales de la Liquidación
              </label>
              <textarea
                value={observacionesGenerales}
                onChange={(e) => setObservacionesGenerales(e.target.value)}
                placeholder="Indique detalles adicionales, motivos de exoneración, constancia de entrega de carnet o fotocheck, etc..."
                rows={2}
                className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            {/* Firmas Digitales en Canvas */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <SignaturePad
                titulo="Firma del Trabajador Cesante"
                subtitulo="Aceptación de conformidad del inventario y descuento si correspondiese"
                firmanteNombre={trabajadorSeleccionado?.nombreCompleto || trabajadorSeleccionado?.apellidosNombres || 'Trabajador Cesante'}
                firmanteDni={trabajadorSeleccionado?.dni}
                initialDataUrl={firmaTrabajador}
                onSave={setFirmaTrabajador}
              />

              <SignaturePad
                titulo="Firma del Supervisor SSOMA"
                subtitulo="Revisión y liquidación de inventario técnico de seguridad"
                firmanteNombre={responsableNombre}
                firmanteCargo={responsableCargo}
                initialDataUrl={firmaSupervisor}
                onSave={setFirmaSupervisor}
              />
            </div>

            {/* Cláusula legal oficial */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 italic">
              "El presente documento certifica la auditoría de equipos de protección personal y uniformes asignados al trabajador por cese de labores. Las deducciones consignadas obedecen exclusivamente a implementos vigentes no devueltos al almacén general de la empresa, conforme a la Ley N° 29783 y el Reglamento Interno de SST."
            </div>

            {/* Botón de Emisión con apilamiento flexible para móviles y zoom alto */}
            <div className="flex flex-col-reverse sm:flex-row sm:items-center justify-end gap-2.5 sm:gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setVistaActiva('lista');
                  if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();
                }}
                className="w-full sm:w-auto min-h-[44px] px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer flex items-center justify-center"
              >
                Cancelar
              </button>

              <button
                type="submit"
                disabled={guardando || itemsAuditoria.length === 0}
                className="w-full sm:w-auto min-h-[44px] px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
              >
                {guardando ? (
                  <>
                    <Clock className="w-4 h-4 animate-spin" />
                    <span>Guardando y Generando Acta...</span>
                  </>
                ) : (
                  <>
                    <FileCheck2 className="w-4 h-4" />
                    <span>Emitir Acta Oficial y Generar PDF (FO-SST-LIQ-001)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* =========================================================================
          VISTA 2: HISTORIAL DE LIQUIDACIONES EMITIDAS
          ========================================================================= */}
      {vistaActiva === 'lista' && (
        <div className="space-y-6">
          {/* Tarjetas KPI del Historial */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
                <span>Actas Emitidas</span>
                <Scale className="w-4 h-4 text-slate-700" />
              </div>
              <div className="text-2xl font-bold text-slate-900">{kpisHistorial.totalDocs}</div>
              <p className="text-[11px] text-slate-400 mt-1">Trabajadores liquidados</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
                <span>Total Auditado</span>
                <Package className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900">
                S/ {kpisHistorial.totalEntregadosSoles.toFixed(2)}
              </div>
              <p className="text-[11px] text-blue-600 font-medium mt-1">Valor histórico 100%</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
                <span>Total Deducido / Restado</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-emerald-600">
                S/ {kpisHistorial.totalDeducidoSoles.toFixed(2)}
              </div>
              <p className="text-[11px] text-emerald-600 font-medium mt-1">Vencimientos y devueltos</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
                <span>Cargo Neto Retenido</span>
                <DollarSign className="w-4 h-4 text-rose-600" />
              </div>
              <div className="text-2xl font-bold text-rose-600">
                S/ {kpisHistorial.totalNetoSoles.toFixed(2)}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {kpisHistorial.liquidadasEnPlanilla} aplicadas en nómina
              </p>
            </div>
          </div>

          {/* Barra de Filtros y Búsqueda Estandarizada */}
          <ModuleFilterBar
            busqueda={busqueda}
            onBusquedaChange={setBusqueda}
            placeholder="Buscar por DNI, trabajador, acta o artículo..."
            totalResultados={liquidacionesFiltradas.length}
            etiquetaPlural="liquidaciones"
            etiquetaSingular="liquidación"
            hayFiltrosActivos={busqueda !== '' || filtroEstado !== 'TODOS'}
            onLimpiarFiltros={() => {
              setBusqueda('');
              setFiltroEstado('TODOS');
            }}
          >
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className="font-medium text-slate-500">Estado:</span>
              <select
                value={filtroEstado}
                onChange={(e) => setFiltroEstado(e.target.value)}
                className="h-8 px-2.5 rounded-lg border border-slate-200 bg-slate-50 text-xs text-slate-700 cursor-pointer focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              >
                <option value="TODOS">Todos los Estados</option>
                <option value="Emitida">Emitida</option>
                <option value="Enviada a RRHH">Enviada a RRHH</option>
                <option value="Liquidada en Planilla">Liquidada en Planilla</option>
                <option value="Borrador">Borrador</option>
                <option value="Anulada">Anulada</option>
              </select>
            </div>
          </ModuleFilterBar>

          {/* Tabla de Historial (Diseño unificado con Padrón de Trabajadores) */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs min-w-[1050px]">
                <thead>
                  <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-3 text-center w-12">N°</th>
                    <th className="py-3 px-3">Acta Oficial</th>
                    <th className="py-3 px-3">F. Cese</th>
                    <th className="py-3 px-3">Trabajador / DNI</th>
                    <th className="py-3 px-3">Empresa & Área</th>
                    <th className="py-3 px-3 text-center">EPP Entregados</th>
                    <th className="py-3 px-3 text-right">Deducciones</th>
                    <th className="py-3 px-3 text-right">Cargo Neto</th>
                    <th className="py-3 px-3 text-center">Estado</th>
                    <th className="py-3 px-3 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {liquidacionesPaginadas.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-slate-400">
                        <Scale className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                        <p className="font-semibold text-xs text-slate-600">
                          No se encontraron liquidaciones de EPP registradas
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Haga clic en "Emitir Liquidación de Cese" para crear la primera acta.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    liquidacionesPaginadas.map((liq, idx) => {
                      const numFila = indiceInicio + idx + 1;
                      const neto = Number(liq.montoNetoALiquidar) || 0;
                      const deducido = Number(liq.montoDescontadoVencidosYDevueltos) || 0;

                      return (
                        <tr key={liq.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-3 text-center font-mono text-[11px] text-slate-400">
                            {numFila}
                          </td>
                          <td className="py-3 px-3 font-mono font-bold text-slate-800">
                            <div className="flex items-center gap-1.5">
                              <span className="text-purple-700">{liq.numeroRegistro}</span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-normal">
                              {liq.codigoPlantilla}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap">
                            <div>{liq.fechaCese || liq.fechaLiquidacion}</div>
                            <div className="text-[10px] text-slate-400">{liq.motivoCese || 'Cese laboral'}</div>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-semibold text-slate-900">{liq.trabajadorNombre}</div>
                            <div className="text-[11px] text-slate-500 font-mono">DNI: {liq.dni}</div>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-medium text-slate-700">{liq.empresaNombre}</div>
                            <div className="text-[11px] text-slate-500">
                              {liq.area} / {liq.cargo}
                            </div>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <span className="font-bold text-slate-800">
                              {liq.totalItemsEntregados || liq.items?.length || 0} uds
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              S/ {(Number(liq.montoTotalEntregado) || 0).toFixed(2)}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right">
                            <span className="font-semibold text-emerald-700 font-mono">
                              - S/ {deducido.toFixed(2)}
                            </span>
                            <span className="text-[10px] text-emerald-600 block">
                              {(liq.totalItemsVencidos || 0) + (liq.totalItemsDevueltos || 0)} exoneradas
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right font-mono font-bold">
                            {neto > 0 ? (
                              <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">
                                S/ {neto.toFixed(2)}
                              </span>
                            ) : (
                              <span className="text-emerald-700">S/ 0.00</span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-center">
                            <select
                              value={liq.estado}
                              onChange={(e) => {
                                const nuevoEst = e.target.value as EstadoLiquidacion;
                                storageService.actualizarEstadoLiquidacion(liq.id, nuevoEst);
                                onLiquidacionGuardada();
                              }}
                              className={`h-7 px-2 rounded-full text-[11px] font-bold border cursor-pointer transition-colors ${
                                liq.estado === 'Liquidada en Planilla'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : liq.estado === 'Enviada a RRHH'
                                  ? 'bg-blue-50 text-blue-800 border-blue-200'
                                  : liq.estado === 'Emitida'
                                  ? 'bg-purple-50 text-purple-800 border-purple-200'
                                  : 'bg-slate-100 text-slate-700 border-slate-200'
                              }`}
                            >
                              <option value="Emitida">Emitida</option>
                              <option value="Enviada a RRHH">Enviada a RRHH</option>
                              <option value="Liquidada en Planilla">Liquidada en Planilla</option>
                              <option value="Borrador">Borrador</option>
                              <option value="Anulada">Anulada</option>
                            </select>
                          </td>
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => setLiquidacionDetalle(liq)}
                                className="p-1.5 text-slate-500 hover:text-indigo-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                                title="Ver desglose detallado de ítems auditados"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              <button
                                type="button"
                                onClick={() => handleVerPDFLiquidacion(liq)}
                                className="p-1.5 text-slate-500 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
                                title="Ver y descargar acta oficial en PDF"
                                aria-label={`Ver y descargar acta oficial en PDF de liquidación ${liq.numeroRegistro}`}
                              >
                                <FileText className="w-4 h-4 text-purple-600" />
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (
                                    window.confirm(
                                      `¿Está seguro de eliminar el acta de liquidación ${liq.numeroRegistro}?`
                                    )
                                  ) {
                                    storageService.eliminarLiquidacion(liq.id);
                                    onLiquidacionGuardada();
                                  }
                                }}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="Eliminar liquidación"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Paginación Reutilizable Unificada */}
            <TablePagination
              totalRegistros={liquidacionesFiltradas.length}
              porPagina={porPagina}
              paginaActual={paginaAjustada}
              setPaginaActual={setPaginaActual}
              setPorPagina={setPorPagina}
              nombreEntidadPlural="liquidaciones"
            />
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: DETALLE COMPLETO DE ÍTEMS AUDITADOS
          ========================================================================= */}
      {liquidacionDetalle && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-100">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-xl border border-slate-200 overflow-hidden my-8">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                  <Scale className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Desglose de Auditoría: {liquidacionDetalle.numeroRegistro}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {liquidacionDetalle.trabajadorNombre} • DNI {liquidacionDetalle.dni} • Cese: {liquidacionDetalle.fechaCese}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setLiquidacionDetalle(null)}
                className="w-8 h-8 rounded-lg hover:bg-slate-200/80 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Resumen */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Entregado</span>
                  <span className="font-bold text-slate-800">
                    S/ {(Number(liquidacionDetalle.montoTotalEntregado) || 0).toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">EPP Vencidos</span>
                  <span className="font-bold text-emerald-700">
                    {liquidacionDetalle.totalItemsVencidos || 0} uds (S/ 0.00)
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">EPP Devueltos</span>
                  <span className="font-bold text-blue-700">
                    {liquidacionDetalle.totalItemsDevueltos || 0} uds (S/ 0.00)
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">A Descontar en Cese</span>
                  <span className="font-extrabold text-rose-600 text-sm">
                    S/ {(Number(liquidacionDetalle.montoNetoALiquidar) || 0).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Tabla de ítems del acta */}
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase">
                      <th className="py-2.5 px-3">N°</th>
                      <th className="py-2.5 px-3">Artículo / EPP</th>
                      <th className="py-2.5 px-3 text-center">Cant.</th>
                      <th className="py-2.5 px-3">F. Vencim.</th>
                      <th className="py-2.5 px-3">Condición</th>
                      <th className="py-2.5 px-3 text-right">P. Unit.</th>
                      <th className="py-2.5 px-3 text-right">A Cobrar</th>
                      <th className="py-2.5 px-3">Observación</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(liquidacionDetalle.items || []).map((it, idx) => (
                      <tr key={it.idItem || idx} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3 font-mono text-slate-400 text-center">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-900">{it.articulo}</td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-700">
                          {it.cantidadEntregada} {it.unidad || 'und'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">{it.fechaVencimiento || '-'}</td>
                        <td className="py-2.5 px-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              it.estadoItem === 'Vencido'
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : it.estadoItem === 'Devuelto'
                                ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                : it.estadoItem === 'Pendiente'
                                ? 'bg-rose-50 text-rose-800 border border-rose-200'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {it.estadoItem}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                          S/ {Number(it.costoUnitario || 0).toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold">
                          {Number(it.montoALiquidar || 0) > 0 ? (
                            <span className="text-rose-600 font-bold">
                              S/ {Number(it.montoALiquidar).toFixed(2)}
                            </span>
                          ) : (
                            <span className="text-emerald-700">S/ 0.00</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-slate-500 text-[11px]">{it.observaciones || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 flex items-center justify-end gap-2 bg-slate-50">
              <button
                type="button"
                onClick={() => handleVerPDFLiquidacion(liquidacionDetalle)}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
              >
                <FileText className="w-4 h-4" />
                <span>Ver Acta PDF Oficial</span>
              </button>
              <button
                type="button"
                onClick={() => setLiquidacionDetalle(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: VISOR DE DOCUMENTO PDF OFICIAL
          ========================================================================= */}
      <PDFViewerModal
        isOpen={modalPDFOpen}
        onClose={() => setModalPDFOpen(false)}
        pdfBlobUrl={pdfData.url}
        pdfArrayBuffer={pdfData.buffer}
        fileName={pdfData.fileName}
        titulo="Acta de Liquidación de EPP por Cese (FO-SST-LIQ-001)"
      />
    </div>
  );
};
