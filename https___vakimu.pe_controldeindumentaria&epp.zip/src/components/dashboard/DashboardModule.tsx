import React, { useState, useMemo, useEffect } from 'react';
import { 
  Boxes, 
  Clock, 
  Download, 
  Search,
  Filter,
  Layers,
  X,
  Calendar,
  ShieldAlert,
  ClipboardCheck,
  RotateCcw,
  Package,
  Receipt,
  ChevronRight,
  BarChart3
} from 'lucide-react';
import { 
  EntregaEPP, 
  ItemRenovacion, 
  Trabajador, 
  InspeccionEPP, 
  InfraccionEPP, 
  DescuentoEPP, 
  LiquidacionEPP, 
  EPPItem 
} from '../../types';
import { TablePagination } from '../common/TablePagination';
import { compararFechasDesc, formatMoneda, formatFecha } from '../../utils/formatters';

interface DashboardModuleProps {
  entregas: EntregaEPP[];
  renovaciones: ItemRenovacion[];
  trabajadores: Trabajador[];
  inspecciones?: InspeccionEPP[];
  infracciones?: InfraccionEPP[];
  descuentos?: DescuentoEPP[];
  liquidaciones?: LiquidacionEPP[];
  catalogoEPP?: EPPItem[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  onNuevaEntregaConEPP?: (codigoEPP: string, codigoTrabajador?: string) => void;
  onNavegarModulo?: (ruta: string) => void;
  onGenerarDescuento?: (codigoTrabajador?: string, codigoEPP?: string, idInspeccion?: string) => void;
}

// Normalización flexible para IDs de empresas (PERPOL, EMP-PERPOL, TR3, EMP-TR3)
const coincideEmpresa = (itemEmpresaId?: string, filtro?: string): boolean => {
  if (!filtro || filtro === 'TODAS') return true;
  if (!itemEmpresaId) return false;
  const normItem = itemEmpresaId.replace('EMP-', '').trim().toUpperCase();
  const normFiltro = filtro.replace('EMP-', '').trim().toUpperCase();
  return normItem === normFiltro;
};

// Comprobación de fecha según Año y Mes seleccionados
const coincideFecha = (fechaStr?: string, anioFiltro: string = 'TODOS', mesFiltro: string = 'TODOS'): boolean => {
  if (!fechaStr) return anioFiltro === 'TODOS' && mesFiltro === 'TODOS';
  const anio = fechaStr.slice(0, 4);
  const mes = fechaStr.slice(5, 7);

  if (anioFiltro !== 'TODOS' && anio !== anioFiltro) return false;
  if (mesFiltro !== 'TODOS' && mes !== mesFiltro) return false;
  return true;
};

const MESES_OPCIONES = [
  { valor: 'TODOS', label: 'Todos los Meses' },
  { valor: '01', label: '01 - Enero' },
  { valor: '02', label: '02 - Febrero' },
  { valor: '03', label: '03 - Marzo' },
  { valor: '04', label: '04 - Abril' },
  { valor: '05', label: '05 - Mayo' },
  { valor: '06', label: '06 - Junio' },
  { valor: '07', label: '07 - Julio' },
  { valor: '08', label: '08 - Agosto' },
  { valor: '09', label: '09 - Setiembre' },
  { valor: '10', label: '10 - Octubre' },
  { valor: '11', label: '11 - Noviembre' },
  { valor: '12', label: '12 - Diciembre' },
];

export const DashboardModule: React.FC<DashboardModuleProps> = ({
  entregas = [],
  renovaciones = [],
  trabajadores = [],
  inspecciones = [],
  infracciones = [],
  descuentos = [],
  liquidaciones = [],
  catalogoEPP = [],
  empresaFiltro = 'TODAS',
  onCambiarEmpresaFiltro,
  onNuevaEntregaConEPP,
  onNavegarModulo,
  onGenerarDescuento
}) => {
  // --- Estados de Filtros Analíticos Globales ---
  const [anioFiltro, setAnioFiltro] = useState<string>('TODOS');
  const [mesFiltro, setMesFiltro] = useState<string>('TODOS');
  const [areaFiltro, setAreaFiltro] = useState<string>('TODAS');
  const [tipoFiltro, setTipoFiltro] = useState<string>('TODOS');

  // Estado para la tabla de acción / pestañas
  const [pestañaActiva, setPestañaActiva] = useState<'renovaciones' | 'inspecciones' | 'infracciones' | 'stock'>('renovaciones');
  const [busquedaDetalle, setBusquedaDetalle] = useState<string>('');
  const [estadoRenovacionFiltro, setEstadoRenovacionFiltro] = useState<string>('TODOS');

  // Asegurar que las colecciones sean arreglos válidos
  const safeEntregas = useMemo(() => Array.isArray(entregas) ? entregas : [], [entregas]);
  const safeRenovaciones = useMemo(() => Array.isArray(renovaciones) ? renovaciones : [], [renovaciones]);
  const safeTrabajadores = useMemo(() => Array.isArray(trabajadores) ? trabajadores : [], [trabajadores]);
  const safeInspecciones = useMemo(() => Array.isArray(inspecciones) ? inspecciones : [], [inspecciones]);
  const safeInfracciones = useMemo(() => Array.isArray(infracciones) ? infracciones : [], [infracciones]);
  const safeDescuentos = useMemo(() => Array.isArray(descuentos) ? descuentos : [], [descuentos]);
  const safeLiquidaciones = useMemo(() => Array.isArray(liquidaciones) ? liquidaciones : [], [liquidaciones]);
  const safeCatalogo = useMemo(() => Array.isArray(catalogoEPP) ? catalogoEPP : [], [catalogoEPP]);

  // Detección automática de Años Disponibles en el sistema
  const aniosDisponibles = useMemo(() => {
    const aniosSet = new Set<string>();
    const anioActual = new Date().getFullYear().toString();
    aniosSet.add(anioActual);

    const regex = /^\d{4}/;
    safeEntregas.forEach(e => {
      if (e?.fechaEntrega && regex.test(e.fechaEntrega)) aniosSet.add(e.fechaEntrega.slice(0, 4));
    });
    safeInspecciones.forEach(i => {
      if (i?.fechaHora && regex.test(i.fechaHora)) aniosSet.add(i.fechaHora.slice(0, 4));
    });
    safeInfracciones.forEach(inf => {
      if (inf?.fechaHora && regex.test(inf.fechaHora)) aniosSet.add(inf.fechaHora.slice(0, 4));
    });
    safeDescuentos.forEach(d => {
      if (d?.fechaSolicitud && regex.test(d.fechaSolicitud)) aniosSet.add(d.fechaSolicitud.slice(0, 4));
    });
    safeLiquidaciones.forEach(l => {
      if (l?.fechaLiquidacion && regex.test(l.fechaLiquidacion)) aniosSet.add(l.fechaLiquidacion.slice(0, 4));
    });

    return Array.from(aniosSet).sort((a, b) => b.localeCompare(a));
  }, [safeEntregas, safeInspecciones, safeInfracciones, safeDescuentos, safeLiquidaciones]);

  // Áreas únicas presentes en los datos
  const areasDisponibles = useMemo(() => {
    const set = new Set<string>();
    safeTrabajadores.forEach(t => t?.area && set.add(t.area));
    safeEntregas.forEach(e => e?.area && set.add(e.area));
    safeInspecciones.forEach(i => i?.area && set.add(i.area));
    safeInfracciones.forEach(inf => inf?.area && set.add(inf.area));
    return Array.from(set).sort();
  }, [safeTrabajadores, safeEntregas, safeInspecciones, safeInfracciones]);

  // --- FILTRADO MULTI-DIMENSIONAL DE TODAS LAS COLECCIONES ---
  // 1. Entregas filtradas
  const entregasFiltradas = useMemo(() => {
    return safeEntregas.filter(e => {
      if (!e) return false;
      if (!coincideEmpresa(e.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && e.area !== areaFiltro) return false;
      if (!coincideFecha(e.fechaEntrega, anioFiltro, mesFiltro)) return false;
      if (tipoFiltro !== 'TODOS') {
        const detalles = Array.isArray(e.detalles) ? e.detalles : [];
        const tieneTipo = detalles.some(d => d && d.tipo === tipoFiltro);
        if (!tieneTipo) return false;
      }
      return true;
    });
  }, [safeEntregas, empresaFiltro, areaFiltro, anioFiltro, mesFiltro, tipoFiltro]);

  // 2. Inspecciones filtradas
  const inspeccionesFiltradas = useMemo(() => {
    return safeInspecciones.filter(i => {
      if (!i) return false;
      if (!coincideEmpresa(i.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && i.area !== areaFiltro) return false;
      if (!coincideFecha(i.fechaHora, anioFiltro, mesFiltro)) return false;
      return true;
    });
  }, [safeInspecciones, empresaFiltro, areaFiltro, anioFiltro, mesFiltro]);

  // 3. Infracciones filtradas
  const infraccionesFiltradas = useMemo(() => {
    return safeInfracciones.filter(inf => {
      if (!inf) return false;
      if (!coincideEmpresa(inf.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && inf.area !== areaFiltro) return false;
      if (!coincideFecha(inf.fechaHora, anioFiltro, mesFiltro)) return false;
      return true;
    });
  }, [safeInfracciones, empresaFiltro, areaFiltro, anioFiltro, mesFiltro]);

  // 4. Descuentos filtrados
  const descuentosFiltrados = useMemo(() => {
    return safeDescuentos.filter(d => {
      if (!d) return false;
      if (!coincideEmpresa(d.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && d.area !== areaFiltro) return false;
      if (!coincideFecha(d.fechaSolicitud || d.fechaIncidente, anioFiltro, mesFiltro)) return false;
      return true;
    });
  }, [safeDescuentos, empresaFiltro, areaFiltro, anioFiltro, mesFiltro]);

  // 5. Liquidaciones filtradas
  const liquidacionesFiltradas = useMemo(() => {
    return safeLiquidaciones.filter(l => {
      if (!l) return false;
      if (!coincideEmpresa(l.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && l.area !== areaFiltro) return false;
      if (!coincideFecha(l.fechaLiquidacion || l.fechaCese, anioFiltro, mesFiltro)) return false;
      return true;
    });
  }, [safeLiquidaciones, empresaFiltro, areaFiltro, anioFiltro, mesFiltro]);

  // 6. Renovaciones filtradas
  const renovacionesFiltradas = useMemo(() => {
    return safeRenovaciones.filter(r => {
      if (!r) return false;
      if (!coincideEmpresa(r.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && r.area !== areaFiltro) return false;
      if (tipoFiltro !== 'TODOS' && r.tipo !== tipoFiltro) return false;
      if (estadoRenovacionFiltro !== 'TODOS' && r.estadoRenovacion !== estadoRenovacionFiltro) return false;
      if (busquedaDetalle) {
        const query = busquedaDetalle.toLowerCase().trim();
        const tokens = query.split(/\s+/);
        const nombre = String(r.trabajadorNombre || '').toLowerCase();
        const dni = String(r.dni || '').toLowerCase();
        const searchTarget = `${nombre} ${dni}`;
        const coincide = tokens.every(tok => searchTarget.includes(tok));
        if (!coincide) return false;
      }
      return true;
    }).sort((a, b) => compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro));
  }, [safeRenovaciones, empresaFiltro, areaFiltro, tipoFiltro, estadoRenovacionFiltro, busquedaDetalle]);

  // --- CÁLCULO DE KPIS EJECUTIVOS SSOMA ---
  // KPI 1: Dotaciones Asumidas por la Empresa (S/) y Unidades
  const kpiDotaciones = useMemo(() => {
    let unidades = 0;
    let monto = 0;
    entregasFiltradas.forEach(e => {
      const detalles = Array.isArray(e.detalles) ? e.detalles : [];
      if (tipoFiltro === 'TODOS') {
        unidades += (e.totalUnidades || 0);
        monto += (e.importeTotal || 0);
      } else {
        detalles.filter(d => d && d.tipo === tipoFiltro).forEach(d => {
          unidades += (d.cantidad || 0);
          monto += (d.importe || 0);
        });
      }
    });
    return { unidades, monto, totalActas: entregasFiltradas.length };
  }, [entregasFiltradas, tipoFiltro]);

  // KPI 2: Inspecciones Técnicas en Campo
  const kpiInspecciones = useMemo(() => {
    let totalItemsInspeccionados = 0;
    let itemsBuenEstado = 0;
    let itemsDesgaste = 0;
    let itemsDañados = 0;
    let itemsExtraviados = 0;

    inspeccionesFiltradas.forEach(i => {
      const detalles = Array.isArray(i.detalles) ? i.detalles : [];
      detalles.forEach(d => {
        totalItemsInspeccionados++;
        if (d.resultado === 'Buen estado') itemsBuenEstado++;
        else if (d.resultado === 'Desgastado') itemsDesgaste++;
        else if (d.resultado === 'Deteriorado o dañado') itemsDañados++;
        else if (d.resultado === 'EPP Extraviado/ A Descontar' || d.resultado === 'No presentado') itemsExtraviados++;
      });
    });

    const porcentajeConforme = totalItemsInspeccionados > 0 
      ? Math.round((itemsBuenEstado / totalItemsInspeccionados) * 100) 
      : 100;

    return {
      totalAuditorias: inspeccionesFiltradas.length,
      totalItemsInspeccionados,
      itemsBuenEstado,
      itemsDesgaste,
      itemsDañados,
      itemsExtraviados,
      porcentajeConforme
    };
  }, [inspeccionesFiltradas]);

  // KPI 3: Infracciones & Disciplina SST
  const kpiInfracciones = useMemo(() => {
    let leves = 0;
    let graves = 0;
    let muyGraves = 0;

    infraccionesFiltradas.forEach(inf => {
      if (inf.gravedad === 'Leve') leves++;
      else if (inf.gravedad === 'Grave') graves++;
      else if (inf.gravedad === 'Muy Grave') muyGraves++;
    });

    return {
      total: infraccionesFiltradas.length,
      leves,
      graves,
      muyGraves,
      criticas: graves + muyGraves
    };
  }, [infraccionesFiltradas]);

  // KPI 5: Autorizaciones de Descuento (S/)
  const kpiDescuentos = useMemo(() => {
    const totalMonto = descuentosFiltrados
      .filter(d => d.estado !== 'Anulado')
      .reduce((sum, d) => sum + (d.montoTotalDescuento || 0), 0);
    const autorizadosCount = descuentosFiltrados.filter(d => d.estado === 'Autorizado' || d.estado === 'Aplicado en Planilla').length;
    return {
      totalMonto,
      totalRegistros: descuentosFiltrados.length,
      autorizadosCount
    };
  }, [descuentosFiltrados]);

  // KPI 6: Liquidaciones por Cese (S/)
  const kpiLiquidaciones = useMemo(() => {
    let totalMontoALiquidar = 0;
    let totalEntregados = 0;
    let totalDevueltos = 0;
    let totalVencidos = 0;

    liquidacionesFiltradas.forEach(l => {
      if (l.estado !== 'Anulada') {
        totalMontoALiquidar += (l.montoNetoALiquidar || 0);
        totalEntregados += (l.totalItemsEntregados || 0);
        totalDevueltos += (l.totalItemsDevueltos || 0);
        totalVencidos += (l.totalItemsVencidos || 0);
      }
    });

    return {
      totalMontoALiquidar,
      totalCeses: liquidacionesFiltradas.length,
      totalDevueltos,
      totalVencidos
    };
  }, [liquidacionesFiltradas]);

  // --- HISTOGRAMA: DISTRIBUCIÓN DE CONSUMO Y COSTOS POR MES ---
  const histogramaMensual = useMemo(() => {
    // Determinar año base para el histograma
    const anioHistograma = anioFiltro !== 'TODOS' 
      ? anioFiltro 
      : (aniosDisponibles[0] || new Date().getFullYear().toString());

    const mesesInfo = [
      { mes: '01', abr: 'Ene', nombre: 'Enero' },
      { mes: '02', abr: 'Feb', nombre: 'Febrero' },
      { mes: '03', abr: 'Mar', nombre: 'Marzo' },
      { mes: '04', abr: 'Abr', nombre: 'Abril' },
      { mes: '05', abr: 'May', nombre: 'Mayo' },
      { mes: '06', abr: 'Jun', nombre: 'Junio' },
      { mes: '07', abr: 'Jul', nombre: 'Julio' },
      { mes: '08', abr: 'Ago', nombre: 'Agosto' },
      { mes: '09', abr: 'Set', nombre: 'Setiembre' },
      { mes: '10', abr: 'Oct', nombre: 'Octubre' },
      { mes: '11', abr: 'Nov', nombre: 'Noviembre' },
      { mes: '12', abr: 'Dic', nombre: 'Diciembre' },
    ];

    // Para el histograma consideramos todas las entregas del año seleccionado según empresa, área y tipo
    const entregasDelAnio = safeEntregas.filter(e => {
      if (!e) return false;
      if (!coincideEmpresa(e.empresaId, empresaFiltro)) return false;
      if (areaFiltro !== 'TODAS' && e.area !== areaFiltro) return false;
      const anioItem = e.fechaEntrega ? e.fechaEntrega.slice(0, 4) : '';
      return anioItem === anioHistograma;
    });

    const barras = mesesInfo.map(m => {
      let unidades = 0;
      let importe = 0;
      let actas = 0;

      entregasDelAnio.forEach(e => {
        const mesItem = e.fechaEntrega ? e.fechaEntrega.slice(5, 7) : '';
        if (mesItem === m.mes) {
          actas++;
          const detalles = Array.isArray(e.detalles) ? e.detalles : [];
          if (tipoFiltro === 'TODOS') {
            unidades += (e.totalUnidades || 0);
            importe += (e.importeTotal || 0);
          } else {
            detalles.filter(d => d && d.tipo === tipoFiltro).forEach(d => {
              unidades += (d.cantidad || 0);
              importe += (d.importe || 0);
            });
          }
        }
      });

      return {
        mes: m.mes,
        abr: m.abr,
        nombre: m.nombre,
        unidades,
        importe,
        actas,
        seleccionado: mesFiltro === m.mes
      };
    });

    const maxImporte = Math.max(...barras.map(b => b.importe), 1);
    const totalAnualMonto = barras.reduce((s, b) => s + b.importe, 0);
    const totalAnualUnidades = barras.reduce((s, b) => s + b.unidades, 0);

    return {
      anio: anioHistograma,
      barras,
      maxImporte,
      totalAnualMonto,
      totalAnualUnidades
    };
  }, [safeEntregas, anioFiltro, mesFiltro, aniosDisponibles, empresaFiltro, areaFiltro, tipoFiltro]);

  // --- DISTRIBUCIÓN DE CONSUMO Y COSTOS POR ÁREA ---
  const entregasPorArea = useMemo(() => {
    const map = new Map<string, { cantidad: number; importe: number }>();
    entregasFiltradas.forEach(e => {
      if (!e) return;
      const area = e.area || 'Sin Área';
      const actual = map.get(area) || { cantidad: 0, importe: 0 };
      const detalles = Array.isArray(e.detalles) ? e.detalles : [];
      detalles.forEach(d => {
        if (!d) return;
        if (tipoFiltro === 'TODOS' || d.tipo === tipoFiltro) {
          actual.cantidad += (d.cantidad || 0);
          actual.importe += (d.importe || 0);
        }
      });
      map.set(area, actual);
    });
    return Array.from(map.entries())
      .map(([area, data]) => ({ area, ...data }))
      .sort((a, b) => b.importe - a.importe);
  }, [entregasFiltradas, tipoFiltro]);

  // --- BALANCE ECONÓMICO SST (Dotaciones vs Recuperaciones) ---
  const balanceEconomico = useMemo(() => {
    const dotaciones = kpiDotaciones.monto;
    const descuentosRecuperados = kpiDescuentos.totalMonto;
    const liquidacionesCese = kpiLiquidaciones.totalMontoALiquidar;
    const totalRecuperable = descuentosRecuperados + liquidacionesCese;
    const costoNetoEmpresa = Math.max(dotaciones - totalRecuperable, 0);
    const maxMonto = Math.max(dotaciones, totalRecuperable, 1);

    return {
      dotaciones,
      descuentosRecuperados,
      liquidacionesCese,
      totalRecuperable,
      costoNetoEmpresa,
      maxMonto
    };
  }, [kpiDotaciones.monto, kpiDescuentos.totalMonto, kpiLiquidaciones.totalMontoALiquidar]);

  // --- INFRACCIONES POR ÁREA ---
  const infraccionesPorArea = useMemo(() => {
    const map = new Map<string, { leves: number; graves: number; muyGraves: number; total: number }>();
    infraccionesFiltradas.forEach(inf => {
      const area = inf.area || 'Sin Área';
      const actual = map.get(area) || { leves: 0, graves: 0, muyGraves: 0, total: 0 };
      actual.total++;
      if (inf.gravedad === 'Leve') actual.leves++;
      else if (inf.gravedad === 'Grave') actual.graves++;
      else if (inf.gravedad === 'Muy Grave') actual.muyGraves++;
      map.set(area, actual);
    });
    return Array.from(map.entries())
      .map(([area, data]) => ({ area, ...data }))
      .sort((a, b) => b.total - a.total);
  }, [infraccionesFiltradas]);

  // --- EPP VS UNIFORME ---
  const distribucionTipo = useMemo(() => {
    let cantEPP = 0;
    let impEPP = 0;
    let cantUni = 0;
    let impUni = 0;

    entregasFiltradas.forEach(e => {
      const detalles = Array.isArray(e.detalles) ? e.detalles : [];
      detalles.forEach(d => {
        if (!d) return;
        if (d.tipo === 'Uniforme') {
          cantUni += (d.cantidad || 0);
          impUni += (d.importe || 0);
        } else {
          cantEPP += (d.cantidad || 0);
          impEPP += (d.importe || 0);
        }
      });
    });

    const totalCant = cantEPP + cantUni || 1;
    return {
      cantEPP,
      impEPP,
      cantUni,
      impUni,
      pctEPP: Math.round((cantEPP / totalCant) * 100),
      pctUni: Math.round((cantUni / totalCant) * 100)
    };
  }, [entregasFiltradas]);

  // --- STOCK CRÍTICO DE ALMACÉN ---
  const stockCriticoItems = useMemo(() => {
    return safeCatalogo.filter(item => {
      const stock = item.stockActual ?? 0;
      const min = item.stockMinimo ?? 0;
      return stock <= min || item.estado === 'Stock Crítico' || item.estado === 'Agotado';
    });
  }, [safeCatalogo]);

  // --- Paginación para Tabla Inferior ---
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  useEffect(() => {
    setPaginaActual(1);
  }, [empresaFiltro, areaFiltro, anioFiltro, mesFiltro, tipoFiltro, estadoRenovacionFiltro, busquedaDetalle, pestañaActiva]);

  const renovacionesPaginadas = useMemo(() => {
    return renovacionesFiltradas.slice((paginaActual - 1) * porPagina, paginaActual * porPagina);
  }, [renovacionesFiltradas, paginaActual, porPagina]);

  const descargarCSVAtencion = () => {
    const encabezados = ['Trabajador,DNI,Empresa,Área,Artículo,Cantidad,Fecha Entrega,Fecha Renovación,Días Restantes,Estado'];
    const filas = renovacionesFiltradas.map(r => 
      `"${r.trabajadorNombre}","${r.dni}","${r.empresaNombre}","${r.area}","${r.articulo}","${r.cantidad}","${r.fechaEntrega}","${r.fechaRenovacion}","${r.diasRestantes}","${r.estadoRenovacion}"`
    );
    const contenido = encabezados.concat(filas).join('\n');
    const blob = new Blob([contenido], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DETALLE_SSOMA_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const hayFiltrosActivos = anioFiltro !== 'TODOS' || mesFiltro !== 'TODOS' || areaFiltro !== 'TODAS' || tipoFiltro !== 'TODOS';

  const resetearFiltros = () => {
    setAnioFiltro('TODOS');
    setMesFiltro('TODOS');
    setAreaFiltro('TODAS');
    setTipoFiltro('TODOS');
  };

  return (
    <div className="space-y-6">
      {/* 1. Header del Dashboard y Barra de Filtros Analíticos SST */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                <BarChart3 className="w-5 h-5 text-emerald-700" />
              </span>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                Tablero de Control SSOMA
              </h1>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Monitoreo analítico integral de dotaciones, inspecciones, disciplina y balance económico
            </p>
          </div>

          {/* Filtros Analíticos SST */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="font-bold text-slate-700 flex items-center gap-1.5 bg-slate-100/90 px-2.5 py-1.5 rounded-lg border border-slate-200">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              <span>Filtros Analíticos SST</span>
            </span>

            {/* Ámbito de Empresa */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5">
              <span className="text-slate-400 text-[11px] font-medium">Empresa:</span>
              <span className={`font-bold ${
                empresaFiltro.includes('PERPOL')
                  ? 'text-emerald-700'
                  : empresaFiltro.includes('TR3')
                  ? 'text-blue-700'
                  : 'text-slate-800'
              }`}>
                {empresaFiltro.includes('PERPOL')
                  ? 'PERPOL IDEAS'
                  : empresaFiltro.includes('TR3')
                  ? 'TR3 ALIMENTOS'
                  : 'Consolidado General'}
              </span>
              {empresaFiltro !== 'TODAS' && (
                <button
                  type="button"
                  onClick={() => onCambiarEmpresaFiltro('TODAS')}
                  className="ml-1 p-0.5 hover:bg-slate-200 rounded text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  title="Restablecer a consolidado de ambas empresas"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filtro Año */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Año:
              </span>
              <select
                value={anioFiltro}
                onChange={(e) => setAnioFiltro(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-100/80 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 transition-colors cursor-pointer"
              >
                <option value="TODOS">Todos los Años</option>
                {aniosDisponibles.map(anio => (
                  <option key={anio} value={anio}>{anio}</option>
                ))}
              </select>
            </div>

            {/* Filtro Mes */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Mes:</span>
              <select
                value={mesFiltro}
                onChange={(e) => setMesFiltro(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-100/80 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 transition-colors cursor-pointer"
              >
                {MESES_OPCIONES.map(m => (
                  <option key={m.valor} value={m.valor}>{m.label}</option>
                ))}
              </select>
            </div>

            {/* Filtro Área */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Área:</span>
              <select
                value={areaFiltro}
                onChange={(e) => setAreaFiltro(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100/80 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 transition-colors cursor-pointer max-w-[150px] truncate"
              >
                <option value="TODAS">Todas las Áreas</option>
                {areasDisponibles.map(a => (
                  <option key={a} value={a}>{a}</option>
                ))}
              </select>
            </div>

            {/* Filtro Tipo EPP / Uniforme */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Tipo:</span>
              <select
                value={tipoFiltro}
                onChange={(e) => setTipoFiltro(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100/80 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 transition-colors cursor-pointer"
              >
                <option value="TODOS">Todos</option>
                <option value="EPP">Solo EPP</option>
                <option value="Uniforme">Solo Uniforme</option>
              </select>
            </div>

            {/* Botón de Limpiar Filtros */}
            {hayFiltrosActivos && (
              <button
                type="button"
                onClick={resetearFiltros}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1 text-[11px]"
                title="Restablecer filtros de período y área"
              >
                <RotateCcw className="w-3 h-3 text-slate-500" />
                <span>Limpiar</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Grid de 5 Tarjetas de Indicadores Clave (KPIs) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3.5 sm:gap-4">
        {/* KPI 1: Dotaciones Asumidas por la Empresa (S/) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider line-clamp-1">
              Dotaciones Asumidas
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900 font-mono-numbers">
              {formatMoneda(kpiDotaciones.monto)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono-numbers">
              <span className="text-emerald-700 font-bold">{kpiDotaciones.unidades} uds</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>{kpiDotaciones.totalActas} actas</span>
            </div>
          </div>
        </div>

        {/* KPI 2: Inspecciones Técnicas de EPP */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider line-clamp-1">
              Inspecciones Técnicas
            </span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <ClipboardCheck className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-bold text-blue-800 font-mono-numbers flex items-baseline gap-1">
              {kpiInspecciones.porcentajeConforme}%
              <span className="text-xs font-normal text-blue-600 font-sans">conforme</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono-numbers">
              <span>{kpiInspecciones.totalAuditorias} auditorías</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="text-slate-700">{kpiInspecciones.totalItemsInspeccionados} ítems</span>
            </div>
          </div>
        </div>

        {/* KPI 3: Infracciones & Disciplina SST */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider line-clamp-1">
              Infracciones SST
            </span>
            <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900 font-mono-numbers flex items-baseline gap-1">
              {kpiInfracciones.total}
              <span className="text-xs font-normal text-slate-500 font-sans">reportes</span>
            </div>
            <div className="text-[11px] mt-1 flex items-center gap-1 font-mono-numbers">
              <span className="text-rose-700 font-bold">{kpiInfracciones.criticas} graves</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="text-slate-600">{kpiInfracciones.leves} leves</span>
            </div>
          </div>
        </div>

        {/* KPI 4: Autorizaciones de Descuento (S/) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider line-clamp-1">
              Descuentos Planilla
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-bold text-amber-800 font-mono-numbers">
              {formatMoneda(kpiDescuentos.totalMonto)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono-numbers">
              <span className="font-semibold text-slate-700">{kpiDescuentos.autorizadosCount} autorizados</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>Pérdidas/daño</span>
            </div>
          </div>
        </div>

        {/* KPI 5: Liquidaciones por Cese (S/) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider line-clamp-1">
              Liquidaciones Cese
            </span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
              <RotateCcw className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl font-bold text-indigo-900 font-mono-numbers">
              {formatMoneda(kpiLiquidaciones.totalMontoALiquidar)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono-numbers">
              <span className="font-semibold text-slate-700">{kpiLiquidaciones.totalCeses} ceses</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>{kpiLiquidaciones.totalDevueltos} devueltos</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. NUEVO GRÁFICO: Histograma de Distribución de Consumo y Costos por Mes */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
              <h2 className="text-sm font-bold text-slate-900">
                Distribución de Consumo y Costos por Mes (Año {histogramaMensual.anio})
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Histograma mensual con etiqueta de importe exacto (S/.) y unidades suministradas
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono-numbers bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 self-start sm:self-auto">
            <span className="text-slate-500 font-sans text-[11px]">Total acumulado en el año:</span>
            <span className="font-bold text-slate-900">{formatMoneda(histogramaMensual.totalAnualMonto)}</span>
            <span className="text-slate-300">|</span>
            <span className="font-semibold text-emerald-800">{histogramaMensual.totalAnualUnidades} uds</span>
          </div>
        </div>

        {/* Contenedor del Histograma con etiquetas de monto visibles */}
        <div className="overflow-x-auto pt-4 pb-2">
          <div className="min-w-[700px] h-64 flex items-end gap-2 sm:gap-3 px-2 border-b border-slate-200">
            {histogramaMensual.barras.map((b) => {
              const porcentajeAltura = Math.round((b.importe / histogramaMensual.maxImporte) * 100);
              const alturaCss = b.importe > 0 ? Math.max(porcentajeAltura, 8) : 4;
              const tieneMonto = b.importe > 0;

              return (
                <div 
                  key={b.mes} 
                  className="flex-1 flex flex-col items-center justify-end h-full group relative cursor-pointer"
                  onClick={() => setMesFiltro(b.mes === mesFiltro ? 'TODOS' : b.mes)}
                  title={`Click para ${b.seleccionado ? 'quitar filtro' : 'filtrar por ' + b.nombre}`}
                >
                  {/* Etiqueta de Monto en S/. por encima de la barra */}
                  <div className={`mb-1.5 text-center transition-all ${
                    b.seleccionado 
                      ? 'scale-110' 
                      : ''
                  }`}>
                    <span className={`block text-[10px] font-bold font-mono-numbers whitespace-nowrap leading-none ${
                      tieneMonto 
                        ? b.seleccionado ? 'text-emerald-800 bg-emerald-100 px-1 py-0.5 rounded' : 'text-slate-800'
                        : 'text-slate-300'
                    }`}>
                      {tieneMonto ? `S/ ${b.importe.toLocaleString('es-PE', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}` : 'S/ 0'}
                    </span>
                  </div>

                  {/* Barra del Histograma */}
                  <div 
                    className={`w-full rounded-t-md transition-all duration-300 ${
                      b.seleccionado
                        ? 'bg-emerald-700 ring-2 ring-emerald-400 shadow-md'
                        : tieneMonto
                        ? 'bg-emerald-500 hover:bg-emerald-600 group-hover:brightness-105'
                        : 'bg-slate-100'
                    }`}
                    style={{ height: `${alturaCss}%` }}
                  />

                  {/* Etiqueta del Mes y Unidades debajo de la barra */}
                  <div className="mt-2 text-center">
                    <span className={`block text-xs font-bold ${
                      b.seleccionado ? 'text-emerald-700 font-extrabold' : 'text-slate-700'
                    }`}>
                      {b.abr}
                    </span>
                    <span className="block text-[10px] font-mono-numbers text-slate-500 font-medium">
                      {b.unidades} uds
                    </span>
                  </div>

                  {/* Tooltip flotante al pasar el mouse */}
                  <div className="opacity-0 group-hover:opacity-100 pointer-events-none absolute bottom-full mb-8 z-30 transition-opacity duration-150">
                    <div className="bg-slate-900 text-white rounded-lg p-2.5 shadow-xl text-xs whitespace-nowrap">
                      <div className="font-bold text-emerald-300 mb-1">{b.nombre} {histogramaMensual.anio}</div>
                      <div className="font-mono font-semibold">Dotaciones: {formatMoneda(b.importe)}</div>
                      <div className="text-slate-300 text-[11px] font-mono-numbers mt-0.5">
                        {b.unidades} unidades · {b.actas} entregas
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1 italic border-t border-slate-800 pt-1">
                        {b.seleccionado ? 'Filtro activo (click para quitar)' : 'Click para filtrar este mes'}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Leyenda y Ayuda Rápida */}
        <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-slate-500 pt-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-emerald-500" />
              <span>Inversión asumida en dotaciones</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-emerald-700 ring-1 ring-emerald-400" />
              <span>Mes filtrado en el tablero</span>
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Tip: Puedes hacer click sobre cualquier barra del mes para acotar todo el tablero.
          </span>
        </div>
      </div>

      {/* 4. Bloque de Análisis Comparativo: Balance Económico + Consumo por Área */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico: Balance Económico SST */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Balance Económico SST</h3>
                <p className="text-xs text-slate-500">Dotaciones asumidas vs deducciones por pérdida y ceses</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700">
                Trazabilidad Financiera
              </span>
            </div>

            <div className="space-y-4 my-2">
              {/* Barra 1: Dotaciones Asumidas por la Empresa (S/) */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                    Dotaciones Asumidas por la Empresa (S/)
                  </span>
                  <span className="font-mono font-bold text-emerald-800">
                    {formatMoneda(balanceEconomico.dotaciones)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.round((balanceEconomico.dotaciones / balanceEconomico.maxMonto) * 100)}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between">
                  <span>Equipos de protección y uniforme asignados al personal</span>
                  <span className="font-mono-numbers">{kpiDotaciones.unidades} uds</span>
                </div>
              </div>

              {/* Barra 2: Deducciones por Descuentos (S/) */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    Deducciones por Pérdida / Daño (FO-SST-DES-001)
                  </span>
                  <span className="font-mono font-bold text-amber-800">
                    {formatMoneda(balanceEconomico.descuentosRecuperados)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.round((balanceEconomico.descuentosRecuperados / balanceEconomico.maxMonto) * 100)}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between">
                  <span>Autorizaciones firmadas con cargo a planilla</span>
                  <span className="font-mono-numbers">{kpiDescuentos.totalRegistros} expedientes</span>
                </div>
              </div>

              {/* Barra 3: Retenciones en Liquidaciones por Cese (S/) */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
                    Cargos de Liquidación por Cese (FO-SST-LIQ-001)
                  </span>
                  <span className="font-mono font-bold text-indigo-800">
                    {formatMoneda(balanceEconomico.liquidacionesCese)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.round((balanceEconomico.liquidacionesCese / balanceEconomico.maxMonto) * 100)}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between">
                  <span>Prendas no devueltas ni amortizadas al cese</span>
                  <span className="font-mono-numbers">{kpiLiquidaciones.totalCeses} actas de cese</span>
                </div>
              </div>
            </div>
          </div>

          {/* Tarjeta de Resumen Neto */}
          <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wide block">
                Costo Neto Asumido por la Empresa
              </span>
              <span className="text-xs text-slate-500">
                (Dotaciones menos deducciones recuperadas)
              </span>
            </div>
            <div className="text-right">
              <span className="text-base font-extrabold text-slate-900 font-mono-numbers">
                {formatMoneda(balanceEconomico.costoNetoEmpresa)}
              </span>
            </div>
          </div>
        </div>

        {/* Gráfico: Distribución de Consumo y Costos por Área */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Distribución de Consumo y Costos por Área</h3>
              <p className="text-xs text-slate-500">Unidades de EPP entregadas e importe total por sección operativa</p>
            </div>
          </div>

          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {entregasPorArea.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No hay entregas registradas para el período y filtros seleccionados
              </div>
            ) : (
              entregasPorArea.map((item, idx) => {
                const maxImporte = Math.max(...entregasPorArea.map(i => i.importe), 1);
                const porcentaje = Math.round((item.importe / maxImporte) * 100);
                return (
                  <div key={`${item.area}-${idx}`} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-slate-800 truncate max-w-[200px]">{item.area}</span>
                      <div className="flex items-center gap-3 font-mono-numbers text-slate-600 shrink-0">
                        <span>{item.cantidad} uds</span>
                        <span className="font-bold text-slate-900">{formatMoneda(item.importe)}</span>
                      </div>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                        style={{ width: `${Math.max(porcentaje, 4)}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* 5. Bloque de Cumplimiento Técnico y Disciplinario */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Gráfico 1: Estado Físico del EPP en Inspecciones */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Estado Físico en Inspecciones</h3>
            <p className="text-xs text-slate-500 mb-3">Auditorías técnicas de campo FO-SST-EPP-003</p>

            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 font-medium text-slate-700">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  Buen estado
                </span>
                <span className="font-mono font-bold text-emerald-800">{kpiInspecciones.itemsBuenEstado}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 font-medium text-slate-700">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  Desgaste normal de trabajo
                </span>
                <span className="font-mono font-bold text-blue-800">{kpiInspecciones.itemsDesgaste}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 font-medium text-slate-700">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  Deteriorado o dañado
                </span>
                <span className="font-mono font-bold text-amber-800">{kpiInspecciones.itemsDañados}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 font-medium text-slate-700">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  Extraviado / A descontar
                </span>
                <span className="font-mono font-bold text-rose-800">{kpiInspecciones.itemsExtraviados}</span>
              </div>
            </div>

            {/* Barra segmentada */}
            <div className="w-full h-3 rounded-full overflow-hidden flex bg-slate-100 mt-4">
              {kpiInspecciones.totalItemsInspeccionados > 0 ? (
                <>
                  <div 
                    className="bg-emerald-500 h-full" 
                    style={{ width: `${(kpiInspecciones.itemsBuenEstado / kpiInspecciones.totalItemsInspeccionados) * 100}%` }} 
                  />
                  <div 
                    className="bg-blue-500 h-full" 
                    style={{ width: `${(kpiInspecciones.itemsDesgaste / kpiInspecciones.totalItemsInspeccionados) * 100}%` }} 
                  />
                  <div 
                    className="bg-amber-500 h-full" 
                    style={{ width: `${(kpiInspecciones.itemsDañados / kpiInspecciones.totalItemsInspeccionados) * 100}%` }} 
                  />
                  <div 
                    className="bg-rose-500 h-full" 
                    style={{ width: `${(kpiInspecciones.itemsExtraviados / kpiInspecciones.totalItemsInspeccionados) * 100}%` }} 
                  />
                </>
              ) : (
                <div className="w-full bg-slate-200 h-full" />
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Ítems evaluados: {kpiInspecciones.totalItemsInspeccionados}</span>
            <button
              onClick={() => onNavegarModulo && onNavegarModulo('/inspecciones')}
              className="text-emerald-700 font-bold hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Ir a Inspecciones <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Gráfico 2: Infracciones SST por Área */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Infracciones por Área</h3>
            <p className="text-xs text-slate-500 mb-3">No portar o uso indebido de EPP (FO-SST-INF-001)</p>

            <div className="space-y-2.5 max-h-[170px] overflow-y-auto pr-1">
              {infraccionesPorArea.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  Sin infracciones registradas en el período
                </div>
              ) : (
                infraccionesPorArea.map(item => (
                  <div key={item.area} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-slate-800">{item.area}</span>
                      <span className="font-mono font-bold text-slate-900">{item.total} faltas</span>
                    </div>
                    <div className="flex items-center gap-1 text-[10px] font-mono-numbers">
                      {item.muyGraves > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 font-bold">
                          {item.muyGraves} Muy Graves
                        </span>
                      )}
                      {item.graves > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-bold">
                          {item.graves} Graves
                        </span>
                      )}
                      {item.leves > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                          {item.leves} Leves
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Total reportes: {kpiInfracciones.total}</span>
            <button
              onClick={() => onNavegarModulo && onNavegarModulo('/infracciones')}
              className="text-purple-700 font-bold hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              Ir a Infracciones <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Gráfico 3: Clasificación EPP vs Uniforme */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Clasificación EPP vs Uniforme</h3>
            <p className="text-xs text-slate-500 mb-3">Distribución de dotación por categoría técnica</p>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-3 mb-3">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-emerald-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                    EPP de Protección
                  </span>
                  <span className="font-mono">{distribucionTipo.pctEPP}%</span>
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between font-mono-numbers">
                  <span>{distribucionTipo.cantEPP} unidades</span>
                  <span>{formatMoneda(distribucionTipo.impEPP)}</span>
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-blue-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    Uniforme de Trabajo
                  </span>
                  <span className="font-mono">{distribucionTipo.pctUni}%</span>
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between font-mono-numbers">
                  <span>{distribucionTipo.cantUni} unidades</span>
                  <span>{formatMoneda(distribucionTipo.impUni)}</span>
                </div>
              </div>

              {/* Barra segmentada */}
              <div className="w-full h-2.5 rounded-full overflow-hidden flex bg-slate-200">
                <div
                  className="bg-emerald-600 h-full transition-all duration-300"
                  style={{ width: `${distribucionTipo.pctEPP}%` }}
                />
                <div
                  className="bg-blue-600 h-full transition-all duration-300"
                  style={{ width: `${distribucionTipo.pctUni}%` }}
                />
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Total: {kpiDotaciones.unidades} unidades</span>
            <span className="font-bold text-slate-900 font-mono-numbers">{formatMoneda(kpiDotaciones.monto)}</span>
          </div>
        </div>
      </div>

      {/* 6. Panel Operativo de Acción Rápida (Pestañas) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        {/* Navegación de Pestañas */}
        <div className="p-4 sm:p-5 border-b border-slate-200/90 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setPestañaActiva('renovaciones')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                pestañaActiva === 'renovaciones'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Semáforo de Renovaciones</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono-numbers ${
                pestañaActiva === 'renovaciones' ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {renovacionesFiltradas.length}
              </span>
            </button>

            <button
              onClick={() => setPestañaActiva('inspecciones')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                pestañaActiva === 'inspecciones'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <ClipboardCheck className="w-4 h-4" />
              <span>Inspecciones con Acción</span>
            </button>

            <button
              onClick={() => setPestañaActiva('infracciones')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                pestañaActiva === 'infracciones'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Infracciones Recientes</span>
            </button>

            <button
              onClick={() => setPestañaActiva('stock')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                pestañaActiva === 'stock'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Alertas de Stock</span>
              {stockCriticoItems.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono-numbers bg-rose-500 text-white">
                  {stockCriticoItems.length}
                </span>
              )}
            </button>
          </div>

          {/* Opciones de la Pestaña de Renovaciones (Búsqueda y CSV) */}
          {pestañaActiva === 'renovaciones' && (
            <div className="flex flex-wrap items-center gap-2.5">
              <select
                value={estadoRenovacionFiltro}
                onChange={(e) => setEstadoRenovacionFiltro(e.target.value)}
                className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 hover:bg-slate-100/80 focus:outline-hidden cursor-pointer"
              >
                <option value="TODOS">Todos los estados</option>
                <option value="Vencido">🔴 Solo Vencidos</option>
                <option value="Próximo a vencer">🟡 Próximos a Vencer (30d)</option>
                <option value="Vigente">🟢 Vigentes</option>
              </select>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Buscar por nombre o DNI..."
                  value={busquedaDetalle}
                  onChange={(e) => setBusquedaDetalle(e.target.value)}
                  className="pl-9 pr-7 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg w-48 sm:w-56 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white"
                />
                {busquedaDetalle && (
                  <button
                    onClick={() => setBusquedaDetalle('')}
                    className="absolute right-2 top-2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <button
                onClick={descargarCSVAtencion}
                className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>CSV</span>
              </button>
            </div>
          )}
        </div>

        {/* Contenido de la Pestaña 1: Semáforo de Renovaciones */}
        {pestañaActiva === 'renovaciones' && (
          <div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs min-w-[950px]">
                <thead>
                  <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-4 min-w-[180px]">Trabajador</th>
                    <th className="py-3 px-3 w-32">Empresa</th>
                    <th className="py-3 px-3 min-w-[140px]">Área / Cargo</th>
                    <th className="py-3 px-4 min-w-[190px]">Artículo EPP y Talla</th>
                    <th className="py-3 px-3 text-center w-20">Cantidad</th>
                    <th className="py-3 px-3 w-28">F. Entrega</th>
                    <th className="py-3 px-3 w-28">F. Renovación</th>
                    <th className="py-3 px-3 text-center w-36">Semáforo</th>
                    <th className="py-3 px-3 text-center w-24">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {renovacionesFiltradas.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-500">
                        <div className="max-w-xs mx-auto space-y-2">
                          <Layers className="w-7 h-7 mx-auto text-slate-400 stroke-1" />
                          <p className="font-semibold text-slate-700 text-xs">No se encontraron registros</p>
                          <p className="text-[11px] text-slate-500">Intenta modificando los filtros aplicados.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    renovacionesPaginadas.map((r, i) => {
                      const esVencido = r.estadoRenovacion === 'Vencido';
                      const esProximo = r.estadoRenovacion === 'Próximo a vencer';
                      const isPerpol = r.empresaId.includes('PERPOL');

                      return (
                        <tr key={r.idDetalle ? `${r.idDetalle}-${i}` : `renov-${i}`} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900 tracking-tight">{r.trabajadorNombre}</div>
                            <div className="text-[11px] font-mono text-slate-600 font-medium mt-0.5">DNI: {r.dni}</div>
                          </td>
                          <td className="py-3 px-3 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold border ${
                              isPerpol 
                                ? 'bg-emerald-50 text-emerald-900 border-emerald-300' 
                                : 'bg-blue-50 text-blue-900 border-blue-300'
                            }`}>
                              {isPerpol ? 'PERPOL' : 'TR3'}
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-semibold text-slate-900">{r.area}</div>
                            <div className="text-[11px] text-slate-500">{r.cargo}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{r.articulo}</div>
                            <div className="text-[11px] text-slate-500 font-mono">{r.codigoEPP} · {r.talla || 'Estándar'}</div>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <span className="font-mono font-bold text-slate-900">{r.cantidad}</span>
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-700 whitespace-nowrap">
                            {formatFecha(r.fechaEntrega)}
                          </td>
                          <td className="py-3 px-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                            {formatFecha(r.fechaRenovacion)}
                          </td>
                          <td className="py-3 px-3 text-center whitespace-nowrap">
                            <div className="inline-flex flex-col items-center">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                esVencido
                                  ? 'bg-rose-100 text-rose-900 border-rose-300'
                                  : esProximo
                                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                                  : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${esVencido ? 'bg-rose-600' : esProximo ? 'bg-amber-600' : 'bg-emerald-600'}`} />
                                <span>{r.estadoRenovacion}</span>
                              </span>
                              <span className={`text-[10px] font-mono font-bold mt-0.5 ${
                                esVencido ? 'text-rose-700' : esProximo ? 'text-amber-700' : 'text-slate-500'
                              }`}>
                                {r.diasRestantes <= 0 ? `${Math.abs(r.diasRestantes)}d vencido` : `${r.diasRestantes}d restantes`}
                              </span>
                            </div>
                          </td>
                          <td className="py-3 px-3 text-center">
                            {onNuevaEntregaConEPP && (
                              <button
                                onClick={() => onNuevaEntregaConEPP(r.codigoEPP, r.codigoTrabajador)}
                                className="px-2.5 py-1 text-[11px] font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-md border border-emerald-200 transition-colors cursor-pointer"
                                title="Generar nueva entrega para este EPP"
                              >
                                Atender
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <TablePagination
              totalRegistros={renovacionesFiltradas.length}
              paginaActual={paginaActual}
              setPaginaActual={setPaginaActual}
              porPagina={porPagina}
              setPorPagina={setPorPagina}
              nombreEntidadPlural="registros de EPP en uso"
            />
          </div>
        )}

        {/* Contenido de la Pestaña 2: Inspecciones Técnicas con Acción */}
        {pestañaActiva === 'inspecciones' && (
          <div className="p-4">
            <div className="space-y-3">
              {inspeccionesFiltradas.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No hay inspecciones registradas en este período
                </div>
              ) : (
                inspeccionesFiltradas.slice(0, 10).map((insp) => (
                  <div key={insp.id} className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-white transition-all">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{insp.numeroInspeccion}</span>
                        <span className="text-[11px] text-slate-500">· {insp.trabajadorNombre} ({insp.area})</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          insp.empresaId.includes('PERPOL') ? 'bg-emerald-50 text-emerald-800' : 'bg-blue-50 text-blue-800'
                        }`}>
                          {insp.empresaId.includes('PERPOL') ? 'PERPOL' : 'TR3'}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-slate-500">{formatFecha(insp.fechaHora)}</span>
                    </div>

                    {/* Hallazgos de ítems */}
                    <div className="space-y-1.5 mt-2">
                      {insp.detalles.map((det, dIdx) => (
                        <div key={dIdx} className="flex flex-wrap items-center justify-between text-xs bg-slate-50 p-2 rounded-lg gap-2">
                          <div>
                            <span className="font-semibold text-slate-800">{det.articulo}</span>
                            <span className="text-slate-500 text-[11px] ml-1.5 font-mono">({det.codigoEPP})</span>
                            <div className="text-[11px] text-slate-500 mt-0.5">{det.hallazgo || 'Sin observaciones'}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              det.resultado === 'Buen estado'
                                ? 'bg-emerald-100 text-emerald-800'
                                : det.resultado === 'Desgastado'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              {det.resultado}
                            </span>
                            {det.resultado === 'EPP Extraviado/ A Descontar' && onGenerarDescuento && (
                              <button
                                onClick={() => onGenerarDescuento(insp.codigoTrabajador, det.codigoEPP, insp.id)}
                                className="px-2 py-1 text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded hover:bg-rose-100 cursor-pointer"
                              >
                                Tramitar Descuento
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Contenido de la Pestaña 3: Infracciones Recientes */}
        {pestañaActiva === 'infracciones' && (
          <div className="p-4">
            <div className="space-y-3">
              {infraccionesFiltradas.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No hay reportes de infracción registrados en este período
                </div>
              ) : (
                infraccionesFiltradas.slice(0, 10).map((inf) => (
                  <div key={inf.id} className="p-3.5 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{inf.numeroReporte}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          inf.gravedad === 'Muy Grave' 
                            ? 'bg-rose-100 text-rose-800' 
                            : inf.gravedad === 'Grave' 
                            ? 'bg-amber-100 text-amber-800' 
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {inf.gravedad}
                        </span>
                        <span className="text-[11px] text-slate-600 font-mono">{inf.reincidencia}</span>
                      </div>
                      <div className="text-xs font-semibold text-slate-800 mt-1">
                        {inf.trabajadorNombre} · {inf.area} ({inf.cargo})
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5 max-w-xl">
                        {inf.descripcionHechos}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-xs font-mono text-slate-500">{formatFecha(inf.fechaHora)}</div>
                      <div className="text-xs font-bold text-purple-800 mt-1">{inf.tipoSancion}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Contenido de la Pestaña 4: Alertas de Stock */}
        {pestañaActiva === 'stock' && (
          <div className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {stockCriticoItems.length === 0 ? (
                <div className="col-span-full py-12 text-center text-slate-400 text-xs">
                  Todos los artículos cuentan con niveles de stock óptimos sobre el mínimo
                </div>
              ) : (
                stockCriticoItems.map((item) => (
                  <div key={item.codigo} className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/20 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-mono font-bold text-slate-500">{item.codigo}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                          {item.estado}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 leading-tight">{item.articulo}</h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">{item.categoria} · Talla: {item.talla || 'Estándar'}</p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-amber-100 flex items-center justify-between text-xs font-mono-numbers">
                      <div>
                        <span className="text-[10px] text-slate-400 font-sans block">Stock Actual</span>
                        <span className="font-bold text-rose-700 text-sm">{item.stockActual} {item.unidad}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 font-sans block">Mínimo Requerido</span>
                        <span className="font-semibold text-slate-600">{item.stockMinimo} {item.unidad}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
