import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { DashboardModule } from '../DashboardModule';

describe('DashboardModule Component', () => {
  it('debería renderizar sin errores con props vacías o indefinidas', () => {
    render(
      <DashboardModule
        entregas={[] as any}
        renovaciones={[] as any}
        trabajadores={[] as any}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={() => {}}
      />
    );

    expect(screen.getByText(/Filtros Analíticos SST/i)).toBeInTheDocument();
  });

  it('debería manejar entregas con detalles undefined o null defensivamente', () => {
    const entregasIncompletas = [
      {
        id: 'ENT-01',
        numeroRegistro: 'REG-0001',
        fechaEntrega: '2026-03-01',
        codigoTrabajador: 'TRAB-01',
        dni: '12345678',
        trabajadorNombre: 'Juan Perez',
        empresaId: 'EMP-PERPOL',
        razonSocial: 'PERPOL',
        ruc: '20392729977',
        direccion: '',
        actividadEconomica: '',
        area: 'Producción',
        cargo: 'Operario',
        numTrabajadoresActivosCalculado: 1,
        fechaHoraCalculoTrabajadores: '',
        responsableEntrega: 'Supervisor',
        tipoEntregaGeneral: 'Entrega inicial',
        observacionesGenerales: '',
        totalUnidades: 1,
        importeTotal: 50,
        estado: 'Confirmada',
        codigoPlantilla: 'FO-SST-GEN-050',
        versionPlantilla: '02',
        detalles: undefined as any,
        fechaCreacion: '2026-03-01',
        operationId: 'op-1'
      }
    ];

    render(
      <DashboardModule
        entregas={entregasIncompletas as any}
        renovaciones={undefined as any}
        trabajadores={undefined as any}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={() => {}}
      />
    );

    expect(screen.getByText(/Filtros Analíticos SST/i)).toBeInTheDocument();
  });

  it('debería renderizar las 5 tarjetas KPI principales sin la tarjeta de Semáforo', () => {
    render(
      <DashboardModule
        entregas={[] as any}
        renovaciones={[] as any}
        trabajadores={[] as any}
        empresaFiltro="TODAS"
        onCambiarEmpresaFiltro={() => {}}
      />
    );

    // Debe incluir las tarjetas de indicadores clave
    expect(screen.getAllByText(/Dotaciones Asumidas/i).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/Inspecciones Técnicas/i).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/Infracciones SST/i).length).toBeGreaterThan(0);
    expect(screen.getByText(/Descuentos Planilla/i)).toBeInTheDocument();
    expect(screen.getByText(/Liquidaciones Cese/i)).toBeInTheDocument();

    // No debe existir la tarjeta de "Semáforo Renovación" en los KPIs superiores
    expect(screen.queryByText(/Semáforo Renovación/i)).not.toBeInTheDocument();
  });
});

