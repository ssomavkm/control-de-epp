import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Edit3, 
  QrCode, 
  AlertTriangle, 
  ShieldCheck, 
  Coins,
  Package,
  Boxes,
  X
} from 'lucide-react';
import { EPPItem, CategoriaEPP, TipoArticulo } from '../../types';
import { QRModal } from '../common/QRModal';
import { TablePagination } from '../common/TablePagination';

interface CatalogoEPPModuleProps {
  catalogoEPP: EPPItem[];
  onGuardarEPP: (item: EPPItem) => void;
  onNuevaEntregaConEPP: (codigoEPP: string) => void;
  onIrAInventario?: () => void;
}

const CATEGORIAS_EPP: CategoriaEPP[] = [
  'Protección Craneal',
  'Protección Ocular y Facial',
  'Protección Auditiva',
  'Protección Respiratoria',
  'Protección Manual',
  'Calzado de Seguridad',
  'Protección Contra Caídas',
  'Ropa de Trabajo y Uniforme'
];

export const CatalogoEPPModule: React.FC<CatalogoEPPModuleProps> = ({
  catalogoEPP,
  onGuardarEPP,
  onNuevaEntregaConEPP,
  onIrAInventario
}) => {
  const [busqueda, setBusqueda] = useState<string>('');
  const [categoriaFiltro, setCategoriaFiltro] = useState<string>('TODAS');
  const [tipoFiltro, setTipoFiltro] = useState<string>('TODOS');
  
  // Modal de edición / creación
  const [modalAbierto, setModalAbierto] = useState<boolean>(false);
  const [eppEditando, setEppEditando] = useState<EPPItem | null>(null);

  // Modal QR
  const [qrItem, setQrItem] = useState<EPPItem | null>(null);

  // Form State
  const [codigo, setCodigo] = useState<string>('');
  const [articulo, setArticulo] = useState<string>('');
  const [categoria, setCategoria] = useState<CategoriaEPP>('Protección Craneal');
  const [tipo, setTipo] = useState<TipoArticulo>('EPP');
  const [marca, setMarca] = useState<string>('');
  const [modelo, setModelo] = useState<string>('');
  const [norma, setNorma] = useState<string>('');
  const [talla, setTalla] = useState<string>('Estándar');
  const [unidad, setUnidad] = useState<string>('Unidad');
  const [vidaUtilDias, setVidaUtilDias] = useState<number>(180);
  const [costoUnitario, setCostoUnitario] = useState<number>(25.00);
  const [stockActual, setStockActual] = useState<number>(20);
  const [stockMinimo, setStockMinimo] = useState<number>(5);

  const abrirModalCrear = () => {
    setEppEditando(null);
    setCodigo(`EPP-NEW-${Date.now().toString().slice(-4)}`);
    setArticulo('');
    setCategoria('Protección Craneal');
    setTipo('EPP');
    setMarca('3M');
    setModelo('');
    setNorma('ANSI Z89.1 / EN 397');
    setTalla('Estándar');
    setUnidad('Unidad');
    setVidaUtilDias(180);
    setCostoUnitario(35.00);
    setStockActual(20);
    setStockMinimo(5);
    setModalAbierto(true);
  };

  const abrirModalEditar = (item: EPPItem) => {
    setEppEditando(item);
    setCodigo(item.codigo);
    setArticulo(item.articulo);
    setCategoria(item.categoria);
    setTipo(item.tipo);
    setMarca(item.marca);
    setModelo(item.modelo);
    setNorma(item.norma);
    setTalla(item.talla);
    setUnidad(item.unidad);
    setVidaUtilDias(item.vidaUtilDias);
    setCostoUnitario(item.costoUnitario);
    setStockActual(item.stockActual);
    setStockMinimo(item.stockMinimo);
    setModalAbierto(true);
  };

  const handleGuardar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!articulo.trim()) return;

    let estadoCalculado: 'Disponible' | 'Stock Crítico' | 'Agotado' = 'Disponible';
    if (stockActual === 0) estadoCalculado = 'Agotado';
    else if (stockActual <= stockMinimo) estadoCalculado = 'Stock Crítico';

    const itemAGuardar: EPPItem = {
      codigo,
      articulo: articulo.trim(),
      categoria,
      tipo,
      marca: marca.trim(),
      modelo: modelo.trim(),
      norma: norma.trim(),
      talla: talla.trim(),
      unidad,
      vidaUtilDias: Number(vidaUtilDias) || 180,
      costoUnitario: Number(costoUnitario) || 0,
      stockActual: Number(stockActual) || 0,
      stockMinimo: Number(stockMinimo) || 0,
      estado: estadoCalculado
    };

    onGuardarEPP(itemAGuardar);
    setModalAbierto(false);
  };

  const itemsFiltrados = useMemo(() => {
    return catalogoEPP.filter(item => {
      if (categoriaFiltro !== 'TODAS' && item.categoria !== categoriaFiltro) return false;
      if (tipoFiltro !== 'TODOS' && item.tipo !== tipoFiltro) return false;
      if (busqueda) {
        const q = busqueda.toLowerCase();
        return (
          item.articulo.toLowerCase().includes(q) ||
          item.codigo.toLowerCase().includes(q) ||
          item.marca.toLowerCase().includes(q) ||
          item.norma.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [catalogoEPP, categoriaFiltro, tipoFiltro, busqueda]);

  // Métricas del catálogo
  const metricas = useMemo(() => {
    const totalArticulos = itemsFiltrados.length;
    const categorias = new Set(itemsFiltrados.map(i => i.categoria)).size;
    const criticos = itemsFiltrados.filter(i => i.estado === 'Stock Crítico' || i.estado === 'Agotado').length;
    const valorTotal = itemsFiltrados.reduce((sum, i) => sum + (i.costoUnitario * i.stockActual), 0);

    return { totalArticulos, categorias, criticos, valorTotal };
  }, [itemsFiltrados]);

  // Paginación para catálogo de EPP
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, categoriaFiltro, tipoFiltro, catalogoEPP.length]);

  const totalPaginas = Math.max(1, Math.ceil(itemsFiltrados.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;

  const itemsPaginados = useMemo(() => {
    return itemsFiltrados.slice(indiceInicio, indiceInicio + porPagina);
  }, [itemsFiltrados, indiceInicio, porPagina]);

  return (
    <div className="space-y-6">
      {!modalAbierto ? (
        <>
          {/* Tarjetas KPI de Resumen de Catálogo */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Artículos Homologados</p>
            <p className="text-xl font-bold text-slate-900 font-mono-numbers">{metricas.totalArticulos}</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Familias de EPP</p>
            <p className="text-xl font-bold text-slate-900 font-mono-numbers">{metricas.categorias} <span className="text-xs font-normal text-slate-400 font-sans">líneas</span></p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Stock Crítico / Agotado</p>
            <p className={`text-xl font-bold font-mono-numbers ${metricas.criticos > 0 ? 'text-amber-700' : 'text-slate-900'}`}>
              {metricas.criticos} <span className="text-xs font-normal text-slate-400 font-sans">alertas</span>
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Valor Inventario</p>
            <p className="text-xl font-bold text-slate-900 font-mono-numbers">S/. {metricas.valorTotal.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Barra de Filtros y Búsqueda */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <label htmlFor="busqueda-catalogo-input" className="sr-only">
              Buscar artículo en catálogo
            </label>
            <input
              id="busqueda-catalogo-input"
              type="text"
              placeholder="Buscar por artículo, norma o código..."
              aria-label="Buscar artículo en catálogo por nombre, norma o código"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:bg-white transition-all"
            />
            {busqueda && (
              <button 
                type="button"
                onClick={() => setBusqueda('')}
                aria-label="Limpiar término de búsqueda en catálogo"
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <label htmlFor="select-categoria-catalogo" className="sr-only">
            Filtrar por categoría
          </label>
          <select
            id="select-categoria-catalogo"
            value={categoriaFiltro}
            onChange={(e) => setCategoriaFiltro(e.target.value)}
            aria-label="Filtrar por categoría de EPP"
            className="text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100/80 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-emerald-600 cursor-pointer"
          >
            <option value="TODAS">Todas las Categorías</option>
            {CATEGORIAS_EPP.map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>

          <select
            value={tipoFiltro}
            onChange={(e) => setTipoFiltro(e.target.value)}
            className="text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100/80 focus:outline-hidden cursor-pointer"
          >
            <option value="TODOS">Todos los tipos</option>
            <option value="EPP">Solo EPP</option>
            <option value="Uniforme">Solo Uniforme</option>
          </select>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-slate-500 font-mono-numbers mr-1 hidden sm:inline">
            {itemsFiltrados.length} artículo{itemsFiltrados.length === 1 ? '' : 's'}
          </span>

          {onIrAInventario && (
            <button
              type="button"
              onClick={onIrAInventario}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-200"
              title="Ir a Gestión de Stock e Ingresos"
            >
              <Boxes className="w-4 h-4 text-emerald-600" />
              <span className="hidden sm:inline">Gestión de Stock / Kardex</span>
              <span className="sm:hidden">Stock</span>
            </button>
          )}

          <button
            onClick={abrirModalCrear}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Nuevo Artículo</span>
          </button>
        </div>
      </div>

      {/* Tabla de Artículos EPP con Espaciado Ergonómico */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs min-w-[950px]">
            <thead>
              <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
                <th className="py-3.5 px-4 w-36">Código</th>
                <th className="py-3.5 px-4 min-w-[200px]">Artículo EPP / Talla</th>
                <th className="py-3.5 px-3 min-w-[150px]">Categoría</th>
                <th className="py-3.5 px-3 min-w-[140px]">Marca / Modelo</th>
                <th className="py-3.5 px-3 min-w-[150px]">Norma Técnica</th>
                <th className="py-3.5 px-2 text-center w-24">Vida Útil</th>
                <th className="py-3.5 px-3 text-right w-24">P. Unit</th>
                <th className="py-3.5 px-3 text-center w-28">Stock</th>
                <th className="py-3.5 px-3 text-center w-28">Estado</th>
                <th className="py-3.5 px-4 text-center w-36">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {itemsFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-14 text-center text-slate-500">
                    <div className="max-w-xs mx-auto space-y-2">
                      <Package className="w-8 h-8 mx-auto text-slate-400 stroke-1" />
                      <p className="font-semibold text-slate-700 text-xs">No se encontraron artículos</p>
                      <p className="text-[11px] text-slate-500">Prueba cambiando la categoría o registra un nuevo ítem en el catálogo.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                itemsPaginados.map((item, idx) => {
                  const esCritico = item.estado === 'Stock Crítico';
                  const esAgotado = item.estado === 'Agotado';

                  return (
                    <tr key={item.codigo ? `${item.codigo}-${idx}` : `epp-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {item.codigo}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 tracking-tight">{item.articulo}</div>
                        <div className="text-[11px] text-slate-600 font-mono font-medium mt-0.5">Talla: {item.talla} · {item.unidad}</div>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-800 border border-slate-200">
                          {item.categoria}
                        </span>
                      </td>

                      <td className="py-3.5 px-3">
                        <div className="font-semibold text-slate-900">{item.marca}</div>
                        <div className="text-[11px] text-slate-600 font-medium mt-0.5">{item.modelo}</div>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className="text-[11px] font-mono font-bold text-emerald-900 bg-emerald-100 px-2.5 py-0.5 rounded border border-emerald-300">
                          {item.norma}
                        </span>
                      </td>

                      <td className="py-3.5 px-2 text-center font-mono font-bold text-slate-800">
                        {item.vidaUtilDias} d
                      </td>

                      <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                        S/. {item.costoUnitario.toFixed(2)}
                      </td>

                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <div className={`font-mono font-bold text-xs ${esCritico ? 'text-amber-800' : esAgotado ? 'text-rose-800' : 'text-slate-900'}`}>
                          {item.stockActual} uds
                        </div>
                        <div className="text-[11px] text-slate-600 font-mono font-medium">mín: {item.stockMinimo}</div>
                      </td>

                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                          esAgotado
                            ? 'bg-rose-100 text-rose-900 border-rose-300'
                            : esCritico
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${esAgotado ? 'bg-rose-600' : esCritico ? 'bg-amber-600' : 'bg-emerald-600'}`} />
                          <span>{item.estado}</span>
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setQrItem(item)}
                            aria-label={`Ver ficha técnica QR de ${item.articulo}`}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                            title="Ver Ficha Técnica QR"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => abrirModalEditar(item)}
                            aria-label={`Editar datos de artículo ${item.articulo}`}
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                            title="Editar Artículo"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          {item.stockActual > 0 && (
                            <button
                              type="button"
                              onClick={() => onNuevaEntregaConEPP(item.codigo)}
                              aria-label={`Iniciar registro de entrega con ${item.articulo}`}
                              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded-lg text-[11px] border border-emerald-200 transition-colors shadow-2xs cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                              title="Iniciar Entrega con este EPP"
                            >
                              Entregar
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Paginación idéntica al Padrón de Trabajadores */}
        <TablePagination
          totalRegistros={itemsFiltrados.length}
          paginaActual={paginaActual}
          setPaginaActual={setPaginaActual}
          porPagina={porPagina}
          setPorPagina={setPorPagina}
          nombreEntidadPlural="artículos de EPP"
        />
      </div>
        </>
      ) : (
        /* VISTA INTEGRADA A PANTALLA COMPLETA: REGISTRAR / EDITAR ARTÍCULO EPP */
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden flex flex-col animate-in fade-in duration-150">
          <div className="px-5 sm:px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800">
                <Package className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  {eppEditando ? 'Editar Artículo EPP' : 'Registrar Nuevo Artículo Homologado'}
                </h3>
                <p className="text-xs text-slate-300">
                  Catálogo oficial para dotación y control de EPP conforme a normas técnicas (ANSI / EN / NTP y Ley N° 29783)
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setModalAbierto(false)}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Cancelar y volver al catálogo"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleGuardar} className="p-5 sm:p-6 space-y-5 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Código EPP <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={codigo}
                  onChange={(e) => setCodigo(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all uppercase"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Tipo de Artículo
                </label>
                <select
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value as TipoArticulo)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all cursor-pointer"
                >
                  <option value="EPP">Equipo de Protección Personal (EPP)</option>
                  <option value="Uniforme">Uniforme / Ropa Térmica</option>
                </select>
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Descripción Oficial del Artículo <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={articulo}
                onChange={(e) => setArticulo(e.target.value)}
                placeholder="Ej: Casco de Seguridad Industrial Tipo I Clase E"
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Categoría SST
                </label>
                <select
                  value={categoria}
                  onChange={(e) => setCategoria(e.target.value as CategoriaEPP)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-medium text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all cursor-pointer"
                >
                  {CATEGORIAS_EPP.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Norma Homologada
                </label>
                <input
                  type="text"
                  value={norma}
                  onChange={(e) => setNorma(e.target.value)}
                  placeholder="Ej: ANSI Z89.1 / EN 388"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Marca</label>
                <input
                  type="text"
                  value={marca}
                  onChange={(e) => setMarca(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Modelo</label>
                <input
                  type="text"
                  value={modelo}
                  onChange={(e) => setModelo(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Talla</label>
                <input
                  type="text"
                  value={talla}
                  onChange={(e) => setTalla(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Vida Útil (días)</label>
                <input
                  type="number"
                  min={1}
                  value={vidaUtilDias}
                  onChange={(e) => setVidaUtilDias(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Costo Unit (S/.)</label>
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  value={costoUnitario}
                  onChange={(e) => setCostoUnitario(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Stock Actual</label>
                <input
                  type="number"
                  min={0}
                  value={stockActual}
                  onChange={(e) => setStockActual(parseInt(e.target.value, 10) || 0)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Stock Mínimo</label>
                <input
                  type="number"
                  min={0}
                  value={stockMinimo}
                  onChange={(e) => setStockMinimo(parseInt(e.target.value, 10) || 0)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setModalAbierto(false)}
                className="px-4 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer shadow-2xs transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer transition-colors"
              >
                {eppEditando ? 'Guardar Cambios' : 'Guardar en Catálogo'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal QR */}
      <QRModal
        isOpen={Boolean(qrItem)}
        onClose={() => setQrItem(null)}
        tipo="epp"
        epp={qrItem || undefined}
      />
    </div>
  );
};
