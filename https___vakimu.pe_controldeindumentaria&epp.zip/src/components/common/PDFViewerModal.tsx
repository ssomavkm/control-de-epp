import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  FileText, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight, 
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';

// Configuración de Worker de PDF.js para renderizado seguro en Canvas (inmune al bloqueo de iframes de Chrome)
try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url
  ).toString();
} catch (e) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version || '6.3.289'}/build/pdf.worker.min.mjs`;
}

interface PDFViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  pdfBlobUrl: string | null;
  pdfArrayBuffer?: ArrayBuffer | null;
  fileName: string;
  titulo?: string;
  esBorrador?: boolean;
  onConfirmarEntrega?: () => void;
  guardandoEntrega?: boolean;
}

export const PDFViewerModal: React.FC<PDFViewerModalProps> = ({
  isOpen,
  onClose,
  pdfBlobUrl,
  pdfArrayBuffer,
  fileName,
  titulo = 'Formato Oficial de Entrega FO-SST-GEN-050',
  esBorrador = false,
  onConfirmarEntrega,
  guardandoEntrega = false
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [numPages, setNumPages] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [cargando, setCargando] = useState<boolean>(true);
  const [errorRender, setErrorRender] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);
  const pdfDocRef = useRef<any>(null);

  // Soporte para cerrar con tecla Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Cargar documento PDF en memoria
  useEffect(() => {
    if (!isOpen || (!pdfBlobUrl && !pdfArrayBuffer)) {
      setCargando(false);
      return;
    }

    let isMounted = true;
    let activeLoadingTask: any = null;
    setCargando(true);
    setErrorRender(null);

    const cargarPDF = async () => {
      try {
        let dataPayload: Uint8Array | undefined;

        // 1. Priorizar siempre pdfBlobUrl porque fetch() genera un ArrayBuffer fresco e independiente
        if (pdfBlobUrl) {
          try {
            const res = await fetch(pdfBlobUrl);
            const buf = await res.arrayBuffer();
            dataPayload = new Uint8Array(buf);
          } catch (e) {
            console.warn('Fallo al obtener blob URL, probando ArrayBuffer:', e);
          }
        }

        // 2. Si no hay blobUrl o falló el fetch, usar pdfArrayBuffer clonándolo (.slice(0)) para evitar desprendimiento (detached buffer)
        if (!dataPayload && pdfArrayBuffer && pdfArrayBuffer.byteLength > 0) {
          dataPayload = new Uint8Array(pdfArrayBuffer.slice(0));
        }

        if (!dataPayload || dataPayload.byteLength === 0) {
          throw new Error('No se recibieron datos binarios válidos del documento PDF.');
        }

        const loadingTask = pdfjsLib.getDocument({
          data: dataPayload,
          cMapUrl: `https://unpkg.com/pdfjs-dist@${pdfjsLib.version || '6.3.289'}/cmaps/`,
          cMapPacked: true
        });

        activeLoadingTask = loadingTask;
        const pdfDoc = await loadingTask.promise;
        if (!isMounted) return;

        pdfDocRef.current = pdfDoc;
        setNumPages(pdfDoc.numPages);
        setCurrentPage(1);
        setCargando(false);
      } catch (err: any) {
        console.error('Error al inicializar PDF.js:', err);
        if (!isMounted) return;
        setErrorRender(err.message || 'Error al procesar el archivo PDF');
        setCargando(false);
      }
    };

    cargarPDF();

    return () => {
      isMounted = false;
      if (activeLoadingTask) {
        try {
          activeLoadingTask.destroy();
        } catch (e) {}
      }
    };
  }, [isOpen, pdfBlobUrl, pdfArrayBuffer]);

  // Renderizar las páginas en canvas cuando cambie la página, zoom o pdfDoc
  useEffect(() => {
    if (!pdfDocRef.current || cargando) return;

    let cancelado = false;

    const renderPaginas = async () => {
      const pdf = pdfDocRef.current;
      const scale = (zoomLevel / 100) * 1.35; // Escala base nítida
      const dpr = window.devicePixelRatio || 1;

      for (let p = 1; p <= pdf.numPages; p++) {
        if (cancelado) break;

        const canvas = canvasRefs.current[p - 1];
        if (!canvas) continue;

        try {
          const page = await pdf.getPage(p);
          const viewport = page.getViewport({ scale });

          canvas.width = Math.floor(viewport.width * dpr);
          canvas.height = Math.floor(viewport.height * dpr);
          canvas.style.width = `${Math.floor(viewport.width)}px`;
          canvas.style.height = `${Math.floor(viewport.height)}px`;

          const ctx = canvas.getContext('2d');
          if (!ctx) continue;

          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

          const renderContext = {
            canvasContext: ctx,
            viewport: viewport
          };

          await page.render(renderContext).promise;
        } catch (err: any) {
          if (err.name !== 'RenderingCancelledException') {
            console.warn(`Error al renderizar página ${p}:`, err);
          }
        }
      }
    };

    renderPaginas();

    return () => {
      cancelado = true;
    };
  }, [numPages, zoomLevel, cargando]);

  const handleDownload = () => {
    if (!pdfBlobUrl) return;
    const a = document.createElement('a');
    a.href = pdfBlobUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handlePrint = () => {
    if (!pdfBlobUrl) return;

    try {
      const existingIframe = document.getElementById('pdf-print-iframe') as HTMLIFrameElement;
      if (existingIframe) {
        existingIframe.remove();
      }
      const iframe = document.createElement('iframe');
      iframe.id = 'pdf-print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      iframe.src = pdfBlobUrl;
      iframe.onload = () => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
        } catch (e) {
          console.warn('Iframe print not supported, falling back to download:', e);
          handleDownload();
        }
      };
      document.body.appendChild(iframe);
    } catch (e) {
      handleDownload();
    }
  };

  const zoomIn = () => setZoomLevel(prev => Math.min(prev + 25, 200));
  const zoomOut = () => setZoomLevel(prev => Math.max(prev - 25, 50));
  const resetZoom = () => setZoomLevel(100);

  if (!isOpen) return null;

  return (
    <div 
      role="dialog"
      aria-modal="true"
      aria-labelledby="titulo-visor-pdf"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-6xl h-[94vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Barra superior de herramientas */}
        <div className="px-4 py-3 bg-slate-800/90 border-b border-slate-700 flex flex-wrap items-center justify-between gap-3 text-slate-100">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 id="titulo-visor-pdf" className="text-sm font-semibold truncate text-white">{titulo}</h3>
                {esBorrador && (
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Borrador Previo
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 font-mono truncate">{fileName}</p>
            </div>
          </div>

          {/* Controles de Zoom, Paginación, Descarga e Impresión */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Navegación de páginas */}
            {numPages > 1 && (
              <div className="flex items-center bg-slate-700/60 rounded-lg p-0.5 border border-slate-600/50 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    const next = Math.max(1, currentPage - 1);
                    setCurrentPage(next);
                    const el = document.getElementById(`page-canvas-wrapper-${next}`);
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  disabled={currentPage <= 1}
                  className="p-1.5 hover:text-white disabled:opacity-40 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 rounded"
                  title="Página anterior"
                  aria-label="Página anterior del documento"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <span className="px-2 font-mono text-[11px] text-slate-300">
                  Pág. {currentPage} / {numPages}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const next = Math.min(numPages, currentPage + 1);
                    setCurrentPage(next);
                    const el = document.getElementById(`page-canvas-wrapper-${next}`);
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  disabled={currentPage >= numPages}
                  className="p-1.5 hover:text-white disabled:opacity-40 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 rounded"
                  title="Página siguiente"
                  aria-label="Página siguiente del documento"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Controles de Zoom */}
            <div className="flex items-center bg-slate-700/60 rounded-lg p-0.5 border border-slate-600/50 text-xs">
              <button
                type="button"
                onClick={zoomOut}
                disabled={zoomLevel <= 50}
                className="p-1.5 hover:text-white disabled:opacity-40 rounded transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                title="Reducir zoom"
                aria-label="Reducir zoom del visor"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono tabular-nums text-[11px] text-slate-300">
                {zoomLevel}%
              </span>
              <button
                type="button"
                onClick={zoomIn}
                disabled={zoomLevel >= 200}
                className="p-1.5 hover:text-white disabled:opacity-40 rounded transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                title="Aumentar zoom"
                aria-label="Aumentar zoom del visor"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={resetZoom}
                className="p-1.5 hover:text-white rounded border-l border-slate-600/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                title="Restablecer tamaño normal (100%)"
                aria-label="Restablecer tamaño del visor al 100%"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Abrir en pestaña nueva */}
            {pdfBlobUrl && (
              <a
                href={pdfBlobUrl}
                target="_blank"
                rel="noreferrer"
                className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition-colors flex items-center gap-1 text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                title="Abrir en pestaña nueva"
                aria-label="Abrir archivo PDF en nueva pestaña"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">Abrir pestaña</span>
              </a>
            )}

            {/* Imprimir */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
              title="Imprimir documento a escala 100%"
              aria-label="Imprimir documento oficial"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Imprimir</span>
            </button>

            {/* Descargar PDF Exacto */}
            <button
              type="button"
              onClick={handleDownload}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
              title="Descargar exactamente el mismo archivo PDF emitido"
              aria-label="Descargar archivo PDF oficial emitido"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Descargar PDF</span>
            </button>

            {esBorrador && onConfirmarEntrega && (
              <button
                type="button"
                onClick={onConfirmarEntrega}
                disabled={guardandoEntrega}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{guardandoEntrega ? 'Confirmando...' : 'Confirmar y Descontar Stock'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg transition-colors ml-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
              title="Cerrar visor"
              aria-label="Cerrar visor de documento"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Contenedor de visualización de páginas mediante HTML5 Canvas (100% inmune a bloqueos de Chrome) */}
        <div 
          ref={containerRef}
          className="flex-1 bg-slate-950 p-3 sm:p-6 overflow-auto flex flex-col items-center gap-6"
        >
          {cargando && (
            <div className="py-20 flex flex-col items-center justify-center text-slate-400 gap-3">
              <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
              <span className="text-sm font-medium">Renderizando páginas oficiales del documento FO-SST-GEN-050...</span>
            </div>
          )}

          {errorRender && (
            <div className="py-16 max-w-md text-center p-6 bg-slate-900 border border-rose-500/40 rounded-xl space-y-3">
              <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
              <h4 className="text-sm font-bold text-white">Aviso de visualización</h4>
              <p className="text-xs text-slate-300">{errorRender}</p>
              <div className="pt-2 flex justify-center gap-2">
                <button
                  onClick={handleDownload}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Descargar Archivo PDF
                </button>
                {pdfBlobUrl && (
                  <a
                    href={pdfBlobUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Abrir Externamente
                  </a>
                )}
              </div>
            </div>
          )}

          {/* Renderizado de cada página en Canvas de alta fidelidad */}
          {!cargando && !errorRender && (
            <div className="space-y-6 flex flex-col items-center">
              {Array.from({ length: numPages }).map((_, index) => {
                const pageNumber = index + 1;
                return (
                  <div
                    key={pageNumber}
                    id={`page-canvas-wrapper-${pageNumber}`}
                    className="relative bg-white rounded-md shadow-2xl overflow-hidden border border-slate-700/60"
                  >
                    <canvas
                      ref={(el) => {
                        canvasRefs.current[index] = el;
                      }}
                      className="block max-w-full"
                    />
                    <div className="absolute bottom-1 right-2 bg-slate-900/60 backdrop-blur-xs text-white text-[9px] font-mono px-2 py-0.5 rounded">
                      Página {pageNumber} de {numPages}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Barra de estado inferior */}
        <div className="px-4 py-2 bg-slate-800/80 border-t border-slate-700 text-[11px] text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Visor de Documentos Oficiales SSOMA
            </span>
            <span aria-hidden="true">·</span>
            <span>Renderizado seguro en Canvas</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-300">FO-SST-GEN-050 Versión 02</span>
          </div>
          <div className="hidden sm:block font-mono text-slate-400">
            {numPages} {numPages === 1 ? 'página' : 'páginas'} generadas
          </div>
        </div>
      </div>
    </div>
  );
};
