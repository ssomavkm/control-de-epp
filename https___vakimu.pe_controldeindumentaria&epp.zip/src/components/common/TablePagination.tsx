import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from 'lucide-react';

export interface TablePaginationProps {
  totalRegistros: number;
  paginaActual: number;
  setPaginaActual: React.Dispatch<React.SetStateAction<number>> | ((pag: number | ((p: number) => number)) => void);
  porPagina: number;
  setPorPagina: (n: number) => void;
  nombreEntidadPlural?: string;
  opcionesPorPagina?: number[];
}

export const TablePagination: React.FC<TablePaginationProps> = ({
  totalRegistros,
  paginaActual,
  setPaginaActual,
  porPagina,
  setPorPagina,
  nombreEntidadPlural = 'registros',
  opcionesPorPagina = [10, 25, 50]
}) => {
  const totalPaginas = Math.max(1, Math.ceil(totalRegistros / (porPagina || 10)));

  React.useEffect(() => {
    if (totalRegistros > 0) {
      if (paginaActual > totalPaginas) {
        setPaginaActual(totalPaginas);
      } else if (paginaActual < 1) {
        setPaginaActual(1);
      }
    }
  }, [paginaActual, totalPaginas, totalRegistros, setPaginaActual]);

  if (totalRegistros <= 0) return null;

  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;
  const indiceFin = Math.min(indiceInicio + porPagina, totalRegistros);

  return (
    <div className="px-4 py-3 bg-slate-50/80 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
      <div className="font-mono-numbers">
        Mostrando <strong className="text-slate-900 font-semibold">{totalRegistros > 0 ? indiceInicio + 1 : 0}</strong> a{' '}
        <strong className="text-slate-900 font-semibold">{indiceFin}</strong>{' '}
        de <strong className="text-slate-900 font-semibold">{totalRegistros}</strong> {nombreEntidadPlural}
      </div>

      <div className="flex flex-wrap items-center gap-3 sm:gap-4">
        <div className="flex items-center gap-1.5">
          <span className="text-slate-500 text-[11px]">Por página:</span>
          <select
            value={porPagina}
            onChange={(e) => {
              setPorPagina(Number(e.target.value));
              setPaginaActual(1);
            }}
            aria-label="Filas por página"
            className="bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 cursor-pointer shadow-2xs"
          >
            {opcionesPorPagina.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setPaginaActual(1)}
            disabled={paginaAjustada <= 1}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none text-slate-600 transition-colors shadow-2xs cursor-pointer"
            title="Primera página"
            aria-label="Primera página"
          >
            <ChevronsLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setPaginaActual((p) => Math.max(1, p - 1))}
            disabled={paginaAjustada <= 1}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none text-slate-600 transition-colors shadow-2xs cursor-pointer"
            title="Página anterior"
            aria-label="Página anterior"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center gap-1 px-1 font-mono-numbers">
            {Array.from({ length: totalPaginas }, (_, i) => i + 1)
              .filter((pag) => {
                if (totalPaginas <= 5) return true;
                if (pag === 1 || pag === totalPaginas) return true;
                return Math.abs(pag - paginaAjustada) <= 1;
              })
              .map((pag, idx, arr) => {
                const prev = arr[idx - 1];
                const tieneSalto = prev && pag - prev > 1;
                return (
                  <React.Fragment key={pag}>
                    {tieneSalto && <span className="px-1 text-slate-400">...</span>}
                    <button
                      type="button"
                      onClick={() => setPaginaActual(pag)}
                      className={`min-w-[28px] h-7 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        pag === paginaAjustada
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {pag}
                    </button>
                  </React.Fragment>
                );
              })}
          </div>

          <button
            type="button"
            onClick={() => setPaginaActual((p) => Math.min(totalPaginas, p + 1))}
            disabled={paginaAjustada >= totalPaginas}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none text-slate-600 transition-colors shadow-2xs cursor-pointer"
            title="Página siguiente"
            aria-label="Página siguiente"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setPaginaActual(totalPaginas)}
            disabled={paginaAjustada >= totalPaginas}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none text-slate-600 transition-colors shadow-2xs cursor-pointer"
            title="Última página"
            aria-label="Última página"
          >
            <ChevronsRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
