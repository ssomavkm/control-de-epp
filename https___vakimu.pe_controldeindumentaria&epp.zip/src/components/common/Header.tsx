import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Menu, 
  ShieldCheck, 
  RefreshCw, 
  LayoutDashboard, 
  ClipboardList, 
  ShieldAlert, 
  HardHat, 
  Users, 
  FileCheck2, 
  FileSpreadsheet,
  ReceiptText,
  AlertTriangle,
  Scale,
  Boxes,
  Cloud,
  KeyRound,
  Unlock,
  X,
  WifiOff
} from 'lucide-react';
import { EstadoConexion } from '../../types';
import { offlineQueue } from '../../services/storage/sync/offlineQueue';

interface HeaderProps {
  currentTab?: string;
  onNavigate?: (tab: string) => void;
  onNuevaEntrega?: () => void;
  estadoConexion: EstadoConexion;
  latenciaMs?: number;
  onSyncManual: () => void;
  sincronizando: boolean;
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  sidebarAbierto?: boolean;
  onToggleSidebar?: () => void;
}

const PIN_AUTORIZADO = '2295';

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onNavigate,
  onNuevaEntrega,
  estadoConexion,
  latenciaMs,
  onSyncManual,
  sincronizando,
  empresaFiltro,
  onCambiarEmpresaFiltro,
  sidebarAbierto = true,
  onToggleSidebar
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Estados de control de seguridad PIN
  const [pinAutenticado, setPinAutenticado] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('ssoma_pin_navbar') === 'true';
    } catch {
      return false;
    }
  });
  const [modalPinAbierto, setModalPinAbierto] = useState<boolean>(false);
  const [accionPendiente, setAccionPendiente] = useState<'sync' | 'estado' | null>(null);
  const [pinInput, setPinInput] = useState<string>('');
  const [errorPin, setErrorPin] = useState<string | null>(null);
  const [modalDetallesAbierto, setModalDetallesAbierto] = useState<boolean>(false);
  const [pendientesCola, setPendientesCola] = useState<number>(() => offlineQueue.obtenerCantidadPendientes());
  const [redOnline, setRedOnline] = useState<boolean>(() => typeof navigator !== 'undefined' ? navigator.onLine : true);

  useEffect(() => {
    const unsub = offlineQueue.suscribir(setPendientesCola);
    const handleOnline = () => setRedOnline(true);
    const handleOffline = () => setRedOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsub();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const navItems = [
    { path: '/', label: 'Dashboard SST', icon: LayoutDashboard },
    { path: '/entregas', label: 'Entrega y Dotación de EPP', icon: ClipboardList },
    { path: '/inspecciones', label: 'Inspecciones de EPP', icon: ShieldAlert },
    { path: '/descuentos', label: 'Autorización de Descuentos EPP', icon: ReceiptText },
    { path: '/infracciones', label: 'Infracciones y Sanciones EPP', icon: AlertTriangle },
    { path: '/liquidaciones', label: 'Liquidación de EPP por Cese', icon: Scale },
    { path: '/trabajadores', label: 'Padrón de Trabajadores', icon: Users },
    { path: '/catalogo', label: 'Catálogo de EPP', icon: HardHat },
    { path: '/inventario', label: 'Gestión de Stock', icon: Boxes },
    { path: '/documental', label: 'Control Documental', icon: FileCheck2 }
  ];

  const handleToggle = () => {
    if (onToggleSidebar) {
      onToggleSidebar();
    } else {
      setMobileMenuOpen(!mobileMenuOpen);
    }
  };

  // Solicitar acción protegida por PIN
  const handleSolicitarAccion = (accion: 'sync' | 'estado') => {
    if (pinAutenticado) {
      ejecutarAccion(accion);
    } else {
      setAccionPendiente(accion);
      setPinInput('');
      setErrorPin(null);
      setModalPinAbierto(true);
    }
  };

  // Cerrar modales con tecla Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (modalPinAbierto) {
          setModalPinAbierto(false);
          setErrorPin(null);
          setPinInput('');
          setAccionPendiente(null);
        }
        if (modalDetallesAbierto) {
          setModalDetallesAbierto(false);
        }
      }
    };
    if (modalPinAbierto || modalDetallesAbierto) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [modalPinAbierto, modalDetallesAbierto]);

  // Ejecución de la acción una vez autorizado
  const ejecutarAccion = (accion: 'sync' | 'estado') => {
    if (accion === 'sync') {
      onSyncManual();
    } else if (accion === 'estado') {
      setModalDetallesAbierto(true);
    }
  };

  // Verificación confidencial del PIN de 4 dígitos (sin mostrarlo en la interfaz)
  const handleVerificarPin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pinInput === PIN_AUTORIZADO) {
      setPinAutenticado(true);
      try {
        sessionStorage.setItem('ssoma_pin_navbar', 'true');
      } catch {}
      setModalPinAbierto(false);
      setErrorPin(null);
      if (accionPendiente) {
        ejecutarAccion(accionPendiente);
        setAccionPendiente(null);
      }
    } else {
      setErrorPin('PIN incorrecto. Ingrese el código de 4 dígitos de seguridad.');
      setPinInput('');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/90 shadow-2xs">
      <div className="flex flex-wrap md:flex-nowrap items-center justify-between px-3 sm:px-4 lg:px-6">
        {/* ZONA IZQUIERDA: Botón toggle menú + Logo + Textos Institucionales */}
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0 h-14 order-1">
          <button
            onClick={handleToggle}
            className="p-1.5 -ml-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            title={sidebarAbierto ? 'Contraer menú' : 'Expandir menú'}
            aria-label="Toggle Navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Escudo / Marca institucional */}
          <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>

          {/* Bloque de Identidad Oficial */}
          <div className="flex flex-col min-w-0 justify-center">
            <div className="flex items-center gap-1.5 leading-none">
              <span className="font-bold text-slate-900 tracking-tight text-xs sm:text-sm">
                PORTAL SSOMA
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200/90 shrink-0 font-mono">
                v2.0
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium leading-none mt-0.5 whitespace-nowrap hidden sm:block">
              <span className="hidden xl:inline">Seguridad, Salud Ocupacional y Medio Ambiente</span>
              <span className="xl:hidden">Seguridad y Salud Ocupacional</span>
            </p>
          </div>
        </div>

        {/* ZONA DERECHA: Botones Icon-Only con Protección PIN (en móvil se alinea a la derecha en la fila superior) */}
        <div className="flex items-center gap-1.5 shrink-0 h-14 order-2 md:order-3">
          {/* Botón Icon-Only: Estado de Conexión y Cola Offline (Protegido por PIN) */}
          <button
            type="button"
            onClick={() => handleSolicitarAccion('estado')}
            className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-all shadow-2xs cursor-pointer relative focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
              !redOnline || estadoConexion === 'desconectado'
                ? 'bg-rose-50 hover:bg-rose-100 border-rose-300 text-rose-700'
                : estadoConexion === 'conectado'
                ? 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-800'
                : estadoConexion === 'lento'
                ? 'bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800'
                : estadoConexion === 'error'
                ? 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-800'
                : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-600'
            }`}
            title={`Estado de Conexión: ${
              !redOnline || estadoConexion === 'desconectado'
                ? '🔴 Sin conexión a internet (Modo Offline)'
                : estadoConexion === 'conectado' 
                ? `Google Sheets Conectado (${latenciaMs || 240} ms)` 
                : estadoConexion === 'lento' 
                ? `Conexión lenta (${latenciaMs} ms)` 
                : estadoConexion === 'error' 
                ? 'Error de conexión con Sheets' 
                : 'Requiere Configurar URL'
            }${pendientesCola > 0 ? ` | ${pendientesCola} pendiente(s) en cola offline` : ''} - Clic para ver detalles`}
            aria-label={`Estado de conexión: ${
              !redOnline ? 'Sin internet' : estadoConexion === 'conectado' ? 'Conectado' : 'Desconectado'
            }. Presione para ver detalles técnicos`}
          >
            {!redOnline ? (
              <WifiOff className="w-4 h-4 text-rose-600" />
            ) : (
              <Cloud className="w-4 h-4" />
            )}
            
            {/* Indicador de estado */}
            <span className={`absolute top-1 right-1 w-2 h-2 rounded-full ring-1 ring-white ${
              !redOnline || estadoConexion === 'desconectado'
                ? 'bg-rose-600'
                : estadoConexion === 'conectado' 
                ? 'bg-emerald-500 animate-pulse' 
                : estadoConexion === 'lento' 
                ? 'bg-amber-500' 
                : estadoConexion === 'error' 
                ? 'bg-rose-500' 
                : 'bg-slate-400'
            }`} />

            {/* Badge de mutaciones pendientes en cola offline */}
            {pendientesCola > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-amber-600 text-white font-bold text-[9px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center ring-2 ring-white shadow-xs">
                {pendientesCola > 9 ? '9+' : pendientesCola}
              </span>
            )}
          </button>

          {/* Botón Icon-Only: Sincronizar Sheets en vivo */}
          <button
            type="button"
            onClick={() => onSyncManual()}
            disabled={sincronizando}
            className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-all shadow-2xs cursor-pointer disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
              sincronizando
                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700'
            }`}
            title={sincronizando ? 'Sincronizando con Google Sheets...' : 'Sincronizar Sheets'}
            aria-label={sincronizando ? 'Sincronizando datos con Google Sheets' : 'Sincronizar datos con Google Sheets ahora'}
          >
            <RefreshCw className={`w-4 h-4 ${sincronizando ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* ZONA CENTRAL: Selector Segmentado (Fila 2 en Móvil de ancho completo; Centrado en Desktop) */}
        <div className="w-full md:w-auto order-3 md:order-2 flex flex-col items-center justify-center pb-2 pt-1 md:py-0 border-t border-slate-100 md:border-t-0">
          <div 
            role="group" 
            aria-label="Seleccionar razón social o consolidado"
            className="inline-flex w-full md:w-auto max-w-md md:max-w-none items-center p-0.5 bg-slate-100/95 border border-slate-200/90 rounded-lg gap-0.5 shadow-2xs"
          >
            <button
              type="button"
              onClick={() => onCambiarEmpresaFiltro('TODAS')}
              aria-pressed={empresaFiltro === 'TODAS'}
              className={`flex-1 md:flex-initial min-w-0 px-2 sm:px-3 py-1.5 md:py-1 rounded-md text-[10px] xs:text-[11px] font-medium transition-all cursor-pointer whitespace-nowrap text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                empresaFiltro === 'TODAS'
                  ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              Consolidado
            </button>
            <button
              type="button"
              onClick={() => onCambiarEmpresaFiltro('EMP-PERPOL')}
              aria-pressed={empresaFiltro === 'EMP-PERPOL'}
              className={`flex-1 md:flex-initial min-w-0 px-1.5 sm:px-3 py-1.5 md:py-1 rounded-md text-[10px] xs:text-[11px] font-medium transition-all cursor-pointer whitespace-nowrap text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                empresaFiltro === 'EMP-PERPOL'
                  ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <span className="hidden sm:inline">PERPOL IDEAS S.A.C.</span>
              <span className="sm:hidden">PERPOL</span>
            </button>
            <button
              type="button"
              onClick={() => onCambiarEmpresaFiltro('EMP-TR3')}
              aria-pressed={empresaFiltro === 'EMP-TR3'}
              className={`flex-1 md:flex-initial min-w-0 px-1.5 sm:px-3 py-1.5 md:py-1 rounded-md text-[10px] xs:text-[11px] font-medium transition-all cursor-pointer whitespace-nowrap text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                empresaFiltro === 'EMP-TR3'
                  ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <span className="hidden sm:inline">TR3 ALIMENTOS S.A.C.</span>
              <span className="sm:hidden">TR3</span>
            </button>
          </div>

          <span className="text-[10px] text-slate-500 text-center mt-0.5 font-medium tracking-tight whitespace-nowrap hidden md:block">
            {empresaFiltro === 'TODAS' && 'Vista combinada: Ambas razones sociales'}
            {empresaFiltro === 'EMP-PERPOL' && 'Razón social activa: PERPOL IDEAS S.A.C.'}
            {empresaFiltro === 'EMP-TR3' && 'Razón social activa: TR3 ALIMENTOS S.A.C.'}
          </span>
        </div>
      </div>


      {/* Modal 1: Autenticación por PIN (4 dígitos confidencial, sin revelar el código) */}
      {modalPinAbierto && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="titulo-modal-pin"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-sm w-full p-6 text-slate-900 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center border border-slate-200 shadow-2xs">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 id="titulo-modal-pin" className="font-bold text-base text-slate-900">
                Acceso de Seguridad
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Ingrese el PIN de seguridad de 4 dígitos para autorizar la operación en Google Sheets.
              </p>
            </div>

            {errorPin && (
              <div role="alert" className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 text-center font-medium animate-in shake">
                {errorPin}
              </div>
            )}

            <form onSubmit={handleVerificarPin} className="space-y-4">
              <div>
                <label htmlFor="input-pin-navbar" className="sr-only">
                  PIN de seguridad de cuatro dígitos
                </label>
                <input
                  id="input-pin-navbar"
                  type="password"
                  maxLength={4}
                  autoFocus
                  placeholder="••••"
                  aria-label="PIN de seguridad de 4 dígitos"
                  value={pinInput}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                    setPinInput(val);
                    if (errorPin) setErrorPin(null);
                    if (val.length === 4 && val === PIN_AUTORIZADO) {
                      setPinAutenticado(true);
                      try {
                        sessionStorage.setItem('ssoma_pin_navbar', 'true');
                      } catch {}
                      setModalPinAbierto(false);
                      setErrorPin(null);
                      if (accionPendiente) {
                        ejecutarAccion(accionPendiente);
                        setAccionPendiente(null);
                      }
                    }
                  }}
                  className="w-full text-center tracking-[0.6em] font-mono font-bold text-2xl py-3 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all shadow-2xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setModalPinAbierto(false);
                    setErrorPin(null);
                    setPinInput('');
                    setAccionPendiente(null);
                  }}
                  className="flex-1 py-2.5 px-3 border border-slate-200 text-slate-700 hover:bg-slate-100 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={pinInput.length < 4}
                  className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Validar</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Diagnóstico y Detalles del Estado de Conexión */}
      {modalDetallesAbierto && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="titulo-modal-diagnostico"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-md w-full p-6 text-slate-900 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                  !redOnline
                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                    : estadoConexion === 'conectado'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : estadoConexion === 'lento'
                    ? 'bg-amber-50 text-amber-700 border-amber-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200'
                }`}>
                  {!redOnline ? <WifiOff className="w-5 h-5" /> : <Cloud className="w-5 h-5" />}
                </div>
                <div>
                  <h3 id="titulo-modal-diagnostico" className="font-bold text-base text-slate-900">
                    Diagnóstico de Red y Conexión
                  </h3>
                  <p className="text-xs text-slate-500">
                    Google Sheets API · Modo Local-First Resiliente
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalDetallesAbierto(false)}
                aria-label="Cerrar ventana de diagnóstico"
                className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Conexión a Internet:</span>
                  <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                    redOnline ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {redOnline ? '🟢 En línea' : '🔴 Sin internet (Offline)'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Google Sheets (GAS):</span>
                  <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                    estadoConexion === 'conectado'
                      ? 'bg-emerald-100 text-emerald-800'
                      : estadoConexion === 'lento'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}>
                    {estadoConexion === 'conectado' ? '🟢 Conectado' : estadoConexion === 'lento' ? '🟡 Conexión lenta' : '🔴 Sin conexión'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Latencia de Respuesta:</span>
                  <div className="text-right">
                    <span className="font-mono font-bold text-slate-800">
                      {latenciaMs ? `${latenciaMs} ms` : 'No medido'}
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      (&lt; 6000 ms estándar normal en GAS)
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Cola Offline Pendiente:</span>
                  <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                    pendientesCola === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {pendientesCola === 0 ? '🟢 0 pendientes (Al día)' : `🟡 ${pendientesCola} operación(es)`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Polling Inteligente:</span>
                  <span className="font-medium text-emerald-700">
                    Pausado en 2° plano (Ahorro 70%)
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Reintentos con Backoff:</span>
                  <span className="font-medium text-slate-700">
                    Activo con Jitter (3 intentos)
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 leading-relaxed">
                <strong className="text-slate-700">Arquitectura Local-First:</strong> Si se interrumpe la red, las entregas, inspecciones y trabajadores se guardan de forma instantánea en el dispositivo y se resguardan en cola. Al regresar la conexión, se sincronizan automáticamente con Google Sheets.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setModalDetallesAbierto(false)}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Cerrar
              </button>

              <button
                type="button"
                onClick={() => {
                  setModalDetallesAbierto(false);
                  onSyncManual();
                }}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sincronizar Ahora</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Menú desplegable móvil */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-slate-900 text-white p-4 space-y-2 animate-in slide-in-from-top-2 duration-150">
          <div className="space-y-1 pt-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = item.path === '/' 
                ? location.pathname === '/' 
                : location.pathname === item.path || (item.path === '/entregas' && location.pathname.startsWith('/entregas'));
              return (
                <button
                  key={item.path}
                  onClick={() => {
                    navigate(item.path);
                    if (onNavigate) onNavigate(item.path.replace('/', '') || 'dashboard');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium text-left transition-colors cursor-pointer ${
                    isActive 
                      ? 'bg-emerald-600 text-white font-semibold' 
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
