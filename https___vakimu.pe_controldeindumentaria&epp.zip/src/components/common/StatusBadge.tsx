import React from 'react';
import { EstadoTrabajador } from '../../types';

interface StatusBadgeProps {
  condicion: EstadoTrabajador | string;
  size?: 'sm' | 'md';
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  condicion,
  size = 'sm',
  className = ''
}) => {
  const estadoNormalizado = (condicion || '').trim();

  let badgeColor = 'bg-slate-50 text-slate-700 border-slate-200';
  let dotColor = 'bg-slate-400';

  if (estadoNormalizado === 'Activo') {
    badgeColor = 'bg-emerald-100 text-emerald-900 border-emerald-300';
    dotColor = 'bg-emerald-600';
  } else if (estadoNormalizado === 'Inactivo') {
    badgeColor = 'bg-amber-100 text-amber-900 border-amber-300';
    dotColor = 'bg-amber-600';
  } else if (estadoNormalizado === 'Cesado') {
    badgeColor = 'bg-rose-100 text-rose-900 border-rose-300';
    dotColor = 'bg-rose-600';
  }

  const sizeClasses = size === 'md' 
    ? 'px-3 py-1 text-xs gap-1.5' 
    : 'px-2.5 py-0.5 text-[11px] gap-1.5';

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border shadow-2xs transition-colors ${badgeColor} ${sizeClasses} ${className}`}
      title={`Condición: ${estadoNormalizado}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${dotColor}`} aria-hidden="true" />
      <span className="font-semibold">{estadoNormalizado || 'Desconocido'}</span>
    </span>
  );
};
