import React from 'react';
import { Search, X, RotateCcw } from 'lucide-react';

export interface FilterChipItem {
  id: string;
  label: string;
  count?: number;
  color?: 'emerald' | 'amber' | 'rose' | 'slate' | 'blue' | 'purple';
}

export interface ModuleFilterBarProps {
  busqueda: string;
  onBusquedaChange: (val: string) => void;
  placeholder?: string;
  totalResultados?: number;
  etiquetaPlural?: string;
  etiquetaSingular?: string;
  /** Selectores u otros filtros complementarios en la fila principal */
  children?: React.ReactNode;
  /** Chips interactivos con conteo en vivo */
  chips?: FilterChipItem[];
  chipActivo?: string;
  onChipChange?: (id: string) => void;
  /** Acción para resetear filtros si están activos */
  hayFiltrosActivos?: boolean;
  onLimpiarFiltros?: () => void;
  /** Botones de acción complementarios (ej. exportación Excel/PDF) */
  acciones?: React.ReactNode;
}

/**
 * Barra de filtros y herramientas estandarizada para todos los módulos.
 * Integra:
 * - Buscador en vivo con lupa y botón X de limpieza.
 * - Espacio para filtros desplegables (selects) homogéneos.
 * - Chips interactivos con conteo en tiempo real.
 * - Contador de resultados encontrados.
 * - Botón de reinicio rápido de filtros.
 */
export const ModuleFilterBar: React.FC<ModuleFilterBarProps> = ({
  busqueda,
  onBusquedaChange,
  placeholder = 'Buscar por nombre, DNI, código...',
  totalResultados,
  etiquetaPlural = 'registros',
  etiquetaSingular = 'registro',
  children,
  chips,
  chipActivo,
  onChipChange,
  hayFiltrosActivos,
  onLimpiarFiltros,
  acciones
}) => {
  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
      {/* Fila Principal: Buscador + Filtros complementarios + Acciones */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Campo de búsqueda con icono y botón de limpieza */}
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder={placeholder}
            value={busqueda}
            onChange={(e) => onBusquedaChange(e.target.value)}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
          />
          {busqueda && (
            <button
              type="button"
              onClick={() => onBusquedaChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5 rounded"
              title="Limpiar búsqueda"
              aria-label="Limpiar búsqueda"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filtros complementarios (selects) y Acciones */}
        <div className="flex flex-wrap items-center gap-2">
          {children}

          {hayFiltrosActivos && onLimpiarFiltros && (
            <button
              type="button"
              onClick={onLimpiarFiltros}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Restablecer todos los filtros"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Limpiar</span>
            </button>
          )}

          {acciones}
        </div>
      </div>

      {/* Fila Secundaria (Opcional): Chips de estado y Contador de resultados */}
      {(chips && chips.length > 0 || totalResultados !== undefined) && (
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-slate-100">
          {chips && chips.length > 0 && onChipChange ? (
            <div className="inline-flex items-center p-1 bg-slate-100/90 rounded-xl border border-slate-200/90 gap-1 overflow-x-auto max-w-full">
              {chips.map((chip) => {
                const activo = chipActivo === chip.id;
                return (
                  <button
                    key={chip.id}
                    type="button"
                    onClick={() => onChipChange(chip.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                      activo
                        ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                    }`}
                  >
                    <span>{chip.label}</span>
                    {chip.count !== undefined && (
                      <span
                        className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono leading-none ${
                          activo
                            ? 'bg-emerald-100 text-emerald-800 font-bold'
                            : 'bg-slate-200/80 text-slate-600'
                        }`}
                      >
                        {chip.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ) : (
            <div />
          )}

          {totalResultados !== undefined && (
            <div className="text-xs text-slate-500 font-mono-numbers">
              {totalResultados === 1
                ? `1 ${etiquetaSingular} encontrado`
                : `${totalResultados} ${etiquetaPlural} encontrados`}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
