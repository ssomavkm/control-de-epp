import React from 'react';

export type ModuleHeaderTheme = 'emerald' | 'amber' | 'rose' | 'purple' | 'blue' | 'slate' | 'teal';

export interface ModuleHeaderProps {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle?: string;
  badge?: string;
  colorTheme?: ModuleHeaderTheme;
  badgeColorTheme?: ModuleHeaderTheme;
  extraContent?: React.ReactNode;
  actions?: React.ReactNode;
}

const THEME_CLASSES: Record<ModuleHeaderTheme, { iconBox: string; icon: string; badge: string }> = {
  emerald: {
    iconBox: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600',
    icon: 'text-emerald-600',
    badge: 'bg-emerald-50 text-emerald-800 border-emerald-200'
  },
  amber: {
    iconBox: 'bg-amber-500/10 border-amber-500/20 text-amber-600',
    icon: 'text-amber-600',
    badge: 'bg-amber-50 text-amber-800 border-amber-200'
  },
  rose: {
    iconBox: 'bg-rose-500/10 border-rose-500/20 text-rose-600',
    icon: 'text-rose-600',
    badge: 'bg-rose-50 text-rose-800 border-rose-200'
  },
  purple: {
    iconBox: 'bg-purple-500/10 border-purple-500/20 text-purple-600',
    icon: 'text-purple-600',
    badge: 'bg-purple-50 text-purple-800 border-purple-200'
  },
  blue: {
    iconBox: 'bg-blue-500/10 border-blue-500/20 text-blue-600',
    icon: 'text-blue-600',
    badge: 'bg-blue-50 text-blue-800 border-blue-200'
  },
  teal: {
    iconBox: 'bg-teal-500/10 border-teal-500/20 text-teal-600',
    icon: 'text-teal-600',
    badge: 'bg-teal-50 text-teal-800 border-teal-200'
  },
  slate: {
    iconBox: 'bg-slate-500/10 border-slate-500/20 text-slate-700',
    icon: 'text-slate-700',
    badge: 'bg-slate-100 text-slate-800 border-slate-200'
  }
};

/**
 * Encabezado oficial estandarizado para los módulos del sistema SST.
 * Muestra el icono temático, título principal, badge de código homologado
 * y subtítulo con referencia normativa, sin recargar el lado derecho con botones.
 */
export const ModuleHeader: React.FC<ModuleHeaderProps> = ({
  icon: Icon,
  title,
  subtitle,
  badge,
  colorTheme = 'emerald',
  badgeColorTheme,
  extraContent,
  actions
}) => {
  const theme = THEME_CLASSES[colorTheme] || THEME_CLASSES.emerald;
  const badgeTheme = badgeColorTheme ? THEME_CLASSES[badgeColorTheme] : theme;

  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-center gap-3.5">
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${theme.iconBox}`}>
          <Icon className="w-6 h-6" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              {title}
            </h1>
            {badge && (
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${badgeTheme.badge}`}>
                {badge}
              </span>
            )}
            {extraContent}
          </div>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-0.5">
              {subtitle}
            </p>
          )}
        </div>
      </div>
      {actions && (
        <div className="flex items-center gap-2 shrink-0">
          {actions}
        </div>
      )}
    </div>
  );
};
