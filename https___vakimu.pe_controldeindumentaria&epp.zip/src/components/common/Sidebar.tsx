import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ClipboardList, 
  ShieldAlert, 
  HardHat, 
  Users, 
  FileCheck2, 
  Building2,
  ReceiptText,
  AlertTriangle,
  Scale,
  Boxes
} from 'lucide-react';

interface SidebarProps {
  currentTab?: string;
  onNavigate?: (tab: string) => void;
  onItemClick?: () => void;
}

interface MenuGroup {
  titulo: string;
  items: {
    path: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({ onItemClick }) => {
  const location = useLocation();

  const gruposMenu: MenuGroup[] = [
    {
      titulo: 'Operaciones EPP',
      items: [
        {
          path: '/',
          label: 'Dashboard SST',
          icon: LayoutDashboard
        },
        {
          path: '/entregas',
          label: 'Entrega y Dotación de EPP',
          icon: ClipboardList
        },
        {
          path: '/inspecciones',
          label: 'Inspecciones de EPP',
          icon: ShieldAlert
        }
      ]
    },
    {
      titulo: 'Control y Disciplina',
      items: [
        {
          path: '/descuentos',
          label: 'Autorización de Descuentos EPP',
          icon: ReceiptText
        },
        {
          path: '/infracciones',
          label: 'Infracciones y Sanciones EPP',
          icon: AlertTriangle
        },
        {
          path: '/liquidaciones',
          label: 'Liquidación de EPP por Cese',
          icon: Scale
        }
      ]
    },
    {
      titulo: 'Registros y Maestros',
      items: [
        {
          path: '/trabajadores',
          label: 'Padrón de Trabajadores',
          icon: Users
        },
        {
          path: '/catalogo',
          label: 'Catálogo de EPP',
          icon: HardHat
        },
        {
          path: '/inventario',
          label: 'Gestión de Stock',
          icon: Boxes
        },
        {
          path: '/documental',
          label: 'Control Documental',
          icon: FileCheck2
        }
      ]
    }
  ];

  return (
    <aside 
      aria-label="Navegación lateral de módulos"
      className="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 h-full border-r border-slate-800 overflow-y-auto"
    >
      {/* Información de Empresas Activas */}
      <div className="p-4 border-b border-slate-800">
        <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Building2 className="w-3.5 h-3.5 text-emerald-400" />
          Plantas Industriales
        </div>
        <div className="space-y-1.5 text-xs">
          <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700/60 flex items-center justify-between">
            <span className="font-semibold text-slate-200">PERPOL IDEAS</span>
            <span className="text-[10px] font-mono text-emerald-400">RUC 20392729977</span>
          </div>
          <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700/60 flex items-center justify-between">
            <span className="font-semibold text-slate-200">TR3 ALIMENTOS</span>
            <span className="text-[10px] font-mono text-blue-400">RUC 20550842891</span>
          </div>
        </div>
      </div>

      {/* Menú de navegación agrupado por áreas operativas con NavLink */}
      <nav aria-label="Módulos del sistema SST" className="p-3 space-y-4 flex-1">
        {gruposMenu.map((grupo) => (
          <div key={grupo.titulo} className="space-y-1">
            <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {grupo.titulo}
            </div>
            {grupo.items.map((item) => {
              const Icon = item.icon;
              const isActive = item.path === '/' 
                ? location.pathname === '/' 
                : location.pathname === item.path || (item.path === '/entregas' && location.pathname.startsWith('/entregas'));
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => {
                    if (onItemClick) onItemClick();
                  }}
                  aria-current={isActive ? 'page' : undefined}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 ${
                    isActive
                      ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded shrink-0 ${
                      isActive 
                        ? 'bg-emerald-700 text-emerald-100 font-bold' 
                        : 'bg-slate-800 text-slate-400 border border-slate-700/60'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
};
