import React, { useRef, useState, useEffect } from 'react';
import { Eraser, Check, Undo2, Maximize2, X, CheckCircle2 } from 'lucide-react';

interface SignaturePadProps {
  titulo: string;
  subtitulo?: string;
  firmanteNombre?: string;
  firmanteCargo?: string;
  firmanteDni?: string;
  onSave: (dataUrl: string) => void;
  initialDataUrl?: string;
  requerido?: boolean;
}

export const SignaturePad: React.FC<SignaturePadProps> = ({
  titulo,
  subtitulo,
  firmanteNombre,
  firmanteCargo,
  firmanteDni,
  onSave,
  initialDataUrl,
  requerido = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const modalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [modalFullscreen, setModalFullscreen] = useState(false);
  const [currentSignatureUrl, setCurrentSignatureUrl] = useState<string>(initialDataUrl || '');

  // Sincronizar canvas regular y adaptar nítidamente ante cambios de zoom (80%-200%)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const setupCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        canvas.width = rect.width * 2;
        canvas.height = rect.height * 2;
        ctx.scale(2, 2);
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2.5;

        const urlToDraw = currentSignatureUrl || initialDataUrl;
        if (urlToDraw) {
          const img = new Image();
          img.onload = () => {
            ctx.clearRect(0, 0, rect.width, rect.height);
            ctx.drawImage(img, 0, 0, rect.width, rect.height);
            setHasSignature(true);
          };
          img.src = urlToDraw;
        }
      }
    };

    setupCanvas();

    const resizeObserver = new ResizeObserver(() => {
      setupCanvas();
    });
    if (canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    return () => {
      resizeObserver.disconnect();
    };
  }, [initialDataUrl, currentSignatureUrl]);

  // Inicializar canvas de modal en pantalla completa
  useEffect(() => {
    if (!modalFullscreen) return;
    const canvas = modalCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * 2;
    canvas.height = rect.height * 2;
    ctx.scale(2, 2);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 3;

    if (currentSignatureUrl) {
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, rect.width, rect.height);
        ctx.drawImage(img, 0, 0, rect.width, rect.height);
      };
      img.src = currentSignatureUrl;
    }
  }, [modalFullscreen, currentSignatureUrl]);

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent, targetCanvas: HTMLCanvasElement) => {
    const rect = targetCanvas.getBoundingClientRect();
    if ('touches' in e && e.touches.length > 0) {
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top
      };
    }
    const mouseEv = e as React.MouseEvent;
    return {
      x: mouseEv.clientX - rect.left,
      y: mouseEv.clientY - rect.top
    };
  };

  const handleStart = (e: React.MouseEvent | React.TouchEvent, isModal = false) => {
    e.preventDefault();
    const canvas = isModal ? modalCanvasRef.current : canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e, canvas);
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);

    try {
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory(prev => [...prev.slice(-8), imgData]);
    } catch {
      // Ignorar
    }
  };

  const handleDraw = (e: React.MouseEvent | React.TouchEvent, isModal = false) => {
    if (!isDrawing) return;
    e.preventDefault();
    const canvas = isModal ? modalCanvasRef.current : canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e, canvas);
    ctx.lineTo(x, y);
    ctx.stroke();
    setHasSignature(true);
  };

  const obtenerDataUrlOptimizada = (canvas: HTMLCanvasElement): string => {
    try {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tCtx = tempCanvas.getContext('2d');
      if (tCtx) {
        // Fondo blanco para evitar fondos negros y mantener máxima nitidez en actas
        tCtx.fillStyle = '#FFFFFF';
        tCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        tCtx.drawImage(canvas, 0, 0);
        return tempCanvas.toDataURL('image/jpeg', 0.85);
      }
    } catch {
      // Fallback
    }
    return canvas.toDataURL('image/png');
  };

  const handleStop = (isModal = false) => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = isModal ? modalCanvasRef.current : canvasRef.current;
    if (!canvas) return;
    const dataUrl = obtenerDataUrlOptimizada(canvas);
    setCurrentSignatureUrl(dataUrl);
    if (!isModal) {
      onSave(dataUrl);
    }
  };

  const limpiar = (isModal = false) => {
    const canvas = isModal ? modalCanvasRef.current : canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
    setHistory([]);
    setCurrentSignatureUrl('');
    if (!isModal) {
      onSave('');
    }
  };

  const deshacer = (isModal = false) => {
    const canvas = isModal ? modalCanvasRef.current : canvasRef.current;
    if (!canvas || history.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const previous = history[history.length - 1];
    setHistory(prev => prev.slice(0, -1));
    ctx.putImageData(previous, 0, 0);

    if (history.length <= 1) {
      setHasSignature(false);
      setCurrentSignatureUrl('');
      if (!isModal) onSave('');
    } else {
      const dataUrl = obtenerDataUrlOptimizada(canvas);
      setCurrentSignatureUrl(dataUrl);
      if (!isModal) onSave(dataUrl);
    }
  };

  const confirmarFirmaModal = () => {
    const canvas = modalCanvasRef.current;
    if (canvas) {
      const dataUrl = obtenerDataUrlOptimizada(canvas);
      setCurrentSignatureUrl(dataUrl);
      onSave(dataUrl);
    }
    setModalFullscreen(false);
  };

  return (
    <div className="bg-white p-3.5 rounded-xl border border-slate-200">
      <div className="flex items-center justify-between mb-2">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2 flex-wrap">
            <label className="text-xs font-semibold text-slate-800 flex items-center gap-1">
              {titulo}
              {requerido && <span className="text-rose-500 font-bold">*</span>}
            </label>
            {firmanteNombre && (
              <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 inline-flex items-center gap-1.5 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>{firmanteNombre}</span>
                {firmanteCargo && <span className="text-emerald-600 font-normal">({firmanteCargo})</span>}
              </span>
            )}
          </div>
          {subtitulo && <p className="text-[11px] text-slate-500">{subtitulo}</p>}
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setModalFullscreen(true)}
            className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded transition-colors"
            title="Firmar en pantalla completa (Recomendado para celular o tablet)"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => deshacer(false)}
            disabled={history.length === 0}
            className="p-1 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded disabled:opacity-30 transition-colors"
            title="Deshacer trazo"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => limpiar(false)}
            className="px-2 py-0.5 text-[11px] font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded border border-slate-200 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Eraser className="w-3 h-3" />
            Limpiar
          </button>
        </div>
      </div>

      <div className="relative border-2 border-dashed border-slate-300 rounded-lg overflow-hidden bg-slate-50/50 touch-none">
        <canvas
          ref={canvasRef}
          onMouseDown={(e) => handleStart(e, false)}
          onMouseMove={(e) => handleDraw(e, false)}
          onMouseUp={() => handleStop(false)}
          onMouseLeave={() => handleStop(false)}
          onTouchStart={(e) => handleStart(e, false)}
          onTouchMove={(e) => handleDraw(e, false)}
          onTouchEnd={() => handleStop(false)}
          className="w-full h-28 cursor-crosshair block"
        />
        {!hasSignature && (
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center text-slate-400 text-xs font-medium gap-1">
            <span>Firme con el dedo o stylus dentro del recuadro</span>
            <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Tip: Puede usar el botón ⛶ para ampliar en pantalla completa
            </span>
          </div>
        )}
        <div className="absolute bottom-1 left-2 pointer-events-none text-[10px] text-slate-500 font-medium">
          {firmanteNombre
            ? `Línea de firma: ${firmanteNombre}${firmanteCargo ? ` (${firmanteCargo})` : ''}`
            : 'Línea de firma y conformidad SST'}
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-1.5 mt-2">
        {hasSignature ? (
          <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
            <Check className="w-3.5 h-3.5 text-emerald-600" />
            <span>Firma digital registrada</span>
          </div>
        ) : (
          <span className="text-[10px] text-slate-400 italic">Pendiente de firma</span>
        )}

        {firmanteNombre && (
          <div className="text-[11px] text-slate-700 font-medium flex items-center gap-1.5 ml-auto bg-slate-50 px-2 py-1 rounded-md border border-slate-200">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Firmante:</span>
            <span className="font-semibold text-slate-900">{firmanteNombre}</span>
            {firmanteCargo && (
              <span className="text-[10px] bg-slate-200/70 text-slate-700 px-1.5 py-0.2 rounded font-medium">
                {firmanteCargo}
              </span>
            )}
            {firmanteDni && (
              <span className="text-[10px] text-slate-500 font-mono">
                (DNI: {firmanteDni})
              </span>
            )}
          </div>
        )}
      </div>

      {/* Modal Pantalla Completa para Firma en Campo (Tablet / Móvil) */}
      {modalFullscreen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-300 flex flex-col overflow-hidden">
            {/* Header del Modal */}
            <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold flex items-center gap-2">
                  <span>{titulo}</span>
                  <span className="text-[10px] bg-emerald-700/80 px-2 py-0.5 rounded text-emerald-100 font-mono">
                    Modo Campo Táctil
                  </span>
                </h3>
                <p className="text-[11px] text-slate-300">
                  {firmanteNombre
                    ? `Firmante: ${firmanteNombre}${firmanteCargo ? ` (${firmanteCargo})` : ''}${firmanteDni ? ` | DNI: ${firmanteDni}` : ''}`
                    : 'Firme con su dedo o stylus en el área espaciosa inferior'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setModalFullscreen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Canvas Amplio */}
            <div className="p-4 bg-slate-100/60 flex-1">
              <div className="relative border-2 border-dashed border-slate-400 rounded-xl overflow-hidden bg-white shadow-inner touch-none">
                <canvas
                  ref={modalCanvasRef}
                  onMouseDown={(e) => handleStart(e, true)}
                  onMouseMove={(e) => handleDraw(e, true)}
                  onMouseUp={() => handleStop(true)}
                  onMouseLeave={() => handleStop(true)}
                  onTouchStart={(e) => handleStart(e, true)}
                  onTouchMove={(e) => handleDraw(e, true)}
                  onTouchEnd={() => handleStop(true)}
                  className="w-full h-72 sm:h-80 cursor-crosshair block"
                />
                <div className="absolute bottom-3 left-4 pointer-events-none text-xs text-slate-400 uppercase tracking-widest font-mono">
                  ___________________________ Trazo Digital SST
                </div>
              </div>
            </div>

            {/* Footer de Acciones del Modal */}
            <div className="px-5 py-3 bg-white border-t border-slate-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => deshacer(true)}
                  className="px-3 py-1.5 border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Undo2 className="w-3.5 h-3.5" />
                  <span>Deshacer</span>
                </button>
                <button
                  type="button"
                  onClick={() => limpiar(true)}
                  className="px-3 py-1.5 border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Eraser className="w-3.5 h-3.5" />
                  <span>Limpiar</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setModalFullscreen(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={confirmarFirmaModal}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Aceptar y Aplicar Firma</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
