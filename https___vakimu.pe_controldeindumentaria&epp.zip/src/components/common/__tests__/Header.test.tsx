/// <reference types="@testing-library/jest-dom/vitest" />
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, it, expect, vi } from 'vitest';
import '@testing-library/jest-dom';
import { Header } from '../Header';

describe('Header Component', () => {
  const defaultProps = {
    estadoConexion: 'conectado' as const,
    onSyncManual: vi.fn(),
    sincronizando: false,
    empresaFiltro: 'TODAS',
    onCambiarEmpresaFiltro: vi.fn(),
  };

  it('debería renderizar la identidad oficial del portal SSOMA', () => {
    render(
      <MemoryRouter>
        <Header {...defaultProps} />
      </MemoryRouter>
    );

    expect(screen.getByText(/PORTAL SSOMA/i)).toBeInTheDocument();
    expect(screen.getByText(/v2.0/i)).toBeInTheDocument();
  });

  it('debería renderizar las opciones de segmentación por empresa', () => {
    render(
      <MemoryRouter>
        <Header {...defaultProps} />
      </MemoryRouter>
    );

    expect(screen.getByText('Consolidado')).toBeInTheDocument();
    expect(screen.getByText('PERPOL IDEAS S.A.C.')).toBeInTheDocument();
    expect(screen.getByText('TR3 ALIMENTOS S.A.C.')).toBeInTheDocument();
  });

  it('debería disparar el callback de cambio de empresa filtro', () => {
    const handleCambiar = vi.fn();
    render(
      <MemoryRouter>
        <Header {...defaultProps} onCambiarEmpresaFiltro={handleCambiar} />
      </MemoryRouter>
    );

    const btnPerpol = screen.getByText('PERPOL IDEAS S.A.C.');
    fireEvent.click(btnPerpol);
    expect(handleCambiar).toHaveBeenCalledWith('EMP-PERPOL');

    const btnTr3 = screen.getByText('TR3 ALIMENTOS S.A.C.');
    fireEvent.click(btnTr3);
    expect(handleCambiar).toHaveBeenCalledWith('EMP-TR3');
  });

  it('debería llamar a onToggleSidebar al pulsar el botón de menú', () => {
    const handleToggle = vi.fn();
    render(
      <MemoryRouter>
        <Header {...defaultProps} onToggleSidebar={handleToggle} />
      </MemoryRouter>
    );

    const toggleBtn = screen.getByLabelText(/Toggle Navigation/i);
    fireEvent.click(toggleBtn);
    expect(handleToggle).toHaveBeenCalled();
  });
});
