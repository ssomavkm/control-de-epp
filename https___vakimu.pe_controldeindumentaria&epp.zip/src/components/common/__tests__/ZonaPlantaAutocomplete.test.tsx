import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { ZonaPlantaAutocomplete } from '../ZonaPlantaAutocomplete';
import { ZONAS_PLANTA_INDUSTRIAL } from '../../../data/seeds/zonasPlanta';

describe('ZonaPlantaAutocomplete', () => {
  it('contiene exactamente las 58 zonas industriales oficiales', () => {
    expect(ZONAS_PLANTA_INDUSTRIAL).toHaveLength(58);
    expect(ZONAS_PLANTA_INDUSTRIAL).toContain('Procesos');
    expect(ZONAS_PLANTA_INDUSTRIAL).toContain('Laboratorio');
    expect(ZONAS_PLANTA_INDUSTRIAL).toContain('Sala de mezclas');
    expect(ZONAS_PLANTA_INDUSTRIAL).toContain('Caldero');
    expect(ZONAS_PLANTA_INDUSTRIAL).toContain('Despacho');
    expect(ZONAS_PLANTA_INDUSTRIAL).toContain('Sala de Reuniones');
  });

  it('renderiza con el valor seleccionado y permite filtrar', () => {
    const handleChange = vi.fn();
    render(
      <ZonaPlantaAutocomplete
        valor="Procesos"
        onChange={handleChange}
        label="Lugar / Zona Exacta de la Planta Industrial"
      />
    );

    const input = screen.getByRole('combobox') as HTMLInputElement;
    expect(input.value).toBe('Procesos');

    fireEvent.change(input, { target: { value: 'Caldero' } });
    expect(handleChange).toHaveBeenCalledWith('Caldero');
  });
});
