import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { describe, it, expect } from 'vitest';
import { Sidebar } from '../Sidebar';

describe('Sidebar - Navegación Operativa Limpia', () => {
  it('no muestra el módulo de Configuración ya que se administra desde el código base', () => {
    render(
      <MemoryRouter initialEntries={['/']}>
        <Sidebar />
      </MemoryRouter>
    );

    const configLink = screen.queryByRole('link', { name: /Configuración/i });
    expect(configLink).not.toBeInTheDocument();
  });

  it('permite navegar normalmente a módulos operativos', () => {
    render(
      <MemoryRouter initialEntries={['/']}>
        <Sidebar />
        <Routes>
          <Route path="/" element={<div>Página Dashboard</div>} />
          <Route path="/trabajadores" element={<div>Página Trabajadores</div>} />
        </Routes>
      </MemoryRouter>
    );

    const trabLink = screen.getByRole('link', { name: /Padrón de Trabajadores/i });
    fireEvent.click(trabLink);
    expect(screen.getByText('Página Trabajadores')).toBeInTheDocument();
  });
});
