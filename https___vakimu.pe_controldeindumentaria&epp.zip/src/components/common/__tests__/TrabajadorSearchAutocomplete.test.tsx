import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { TrabajadorSearchAutocomplete } from '../TrabajadorSearchAutocomplete';
import { Trabajador } from '../../../types';

const MOCK_TRABAJADORES: Trabajador[] = [
  {
    codigo: 'TRAB-001',
    dni: '12345678',
    nombreCompleto: 'Juan Carlos Perez Rodriguez',
    empresaId: 'EMP-PERPOL',
    empresaNombre: 'PERPOL IDEAS S.A.C.',
    area: 'Mantenimiento Electromecánico',
    cargo: 'Técnico Soldador',
    estado: 'Activo',
    fechaIngreso: '2024-01-15'
  },
  {
    codigo: 'TRAB-002',
    dni: '87654321',
    nombreCompleto: 'Maria Elena Gonzales Quispe',
    empresaId: 'EMP-TR3',
    empresaNombre: 'TR3 INVERSIONES S.A.C.',
    area: 'Costura y Confección',
    cargo: 'Operaria de Costura',
    estado: 'Cesado',
    fechaIngreso: '2023-05-10'
  }
];

describe('TrabajadorSearchAutocomplete - Restricción de búsqueda a solo Nombre o DNI', () => {
  it('permite buscar trabajadores por nombre o apellido', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado=""
        onSeleccionar={handleSelect}
      />
    );

    const input = screen.getByPlaceholderText(/Buscar por nombre o DNI/i);
    fireEvent.change(input, { target: { value: 'Carlos' } });

    expect(screen.getByText(/Juan Carlos Perez Rodriguez/i)).toBeInTheDocument();
    expect(screen.queryByText(/Maria Elena Gonzales Quispe/i)).not.toBeInTheDocument();
  });

  it('permite buscar trabajadores por número de DNI', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado=""
        onSeleccionar={handleSelect}
      />
    );

    const input = screen.getByPlaceholderText(/Buscar por nombre o DNI/i);
    fireEvent.change(input, { target: { value: '87654321' } });

    expect(screen.getByText(/Maria Elena Gonzales Quispe/i)).toBeInTheDocument();
    expect(screen.queryByText(/Juan Carlos Perez Rodriguez/i)).not.toBeInTheDocument();
  });

  it('NO permite buscar por cargo o puesto', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado=""
        onSeleccionar={handleSelect}
      />
    );

    const input = screen.getByPlaceholderText(/Buscar por nombre o DNI/i);
    // Escribir el cargo de Juan
    fireEvent.change(input, { target: { value: 'Soldador' } });

    // No debe coincidir porque solo se permite por nombre o DNI
    expect(screen.queryByText(/Juan Carlos Perez Rodriguez/i)).not.toBeInTheDocument();
    expect(screen.getByText(/No se encontraron trabajadores/i)).toBeInTheDocument();
  });

  it('NO permite buscar por área operativa', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado=""
        onSeleccionar={handleSelect}
      />
    );

    const input = screen.getByPlaceholderText(/Buscar por nombre o DNI/i);
    // Escribir el área de Maria Elena
    fireEvent.change(input, { target: { value: 'Costura' } });

    expect(screen.queryByText(/Maria Elena Gonzales Quispe/i)).not.toBeInTheDocument();
    expect(screen.getByText(/No se encontraron trabajadores/i)).toBeInTheDocument();
  });

  it('NO permite buscar por código interno del trabajador', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado=""
        onSeleccionar={handleSelect}
      />
    );

    const input = screen.getByPlaceholderText(/Buscar por nombre o DNI/i);
    fireEvent.change(input, { target: { value: 'TRAB-001' } });

    expect(screen.queryByText(/Juan Carlos Perez Rodriguez/i)).not.toBeInTheDocument();
    expect(screen.getByText(/No se encontraron trabajadores/i)).toBeInTheDocument();
  });

  it('solo muestra Nombre y DNI en la lista de sugerencias, sin cargo, área, empresa ni estado', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado=""
        onSeleccionar={handleSelect}
      />
    );

    const input = screen.getByPlaceholderText(/Buscar por nombre o DNI/i);
    fireEvent.focus(input);

    // Debe mostrar nombre y DNI
    expect(screen.getByText(/Juan Carlos Perez Rodriguez/i)).toBeInTheDocument();
    expect(screen.getByText(/DNI: 12345678/i)).toBeInTheDocument();

    // NO debe mostrar cargo, área, empresa ni estado
    expect(screen.queryByText(/Técnico Soldador/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/Mantenimiento Electromecánico/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/PERPOL IDEAS/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/^PERPOL$/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/^Activo$/i)).not.toBeInTheDocument();
  });

  it('solo muestra Nombre y DNI cuando el trabajador está seleccionado', () => {
    const handleSelect = vi.fn();
    render(
      <TrabajadorSearchAutocomplete
        trabajadores={MOCK_TRABAJADORES}
        valorSeleccionado="TRAB-001"
        onSeleccionar={handleSelect}
      />
    );

    // Debe mostrar nombre y DNI
    expect(screen.getByText(/Juan Carlos Perez Rodriguez/i)).toBeInTheDocument();
    expect(screen.getByText(/DNI: 12345678/i)).toBeInTheDocument();

    // NO debe mostrar cargo, área ni empresa en la ficha
    expect(screen.queryByText(/Técnico Soldador/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/Mantenimiento Electromecánico/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/^PERPOL$/i)).not.toBeInTheDocument();
  });
});

