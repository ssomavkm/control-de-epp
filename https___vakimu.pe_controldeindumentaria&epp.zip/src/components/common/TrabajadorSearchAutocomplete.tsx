import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, UserCheck, X, Check, ChevronDown } from 'lucide-react';
import { Trabajador } from '../../types';

export interface TrabajadorSearchAutocompleteProps {
  trabajadores: Trabajador[];
  valorSeleccionado: string; // codigo del trabajador
  onSeleccionar: (trabajador: Trabajador | null) => void;
  empresaFiltro?: string;
  label?: string;
  sublabel?: string;
  placeholder?: string;
  required?: boolean;
  colorTheme?: 'purple' | 'emerald' | 'amber' | 'rose' | 'blue';
  autoFocus?: boolean;
  disabled?: boolean;
  className?: string;
}

export const TrabajadorSearchAutocomplete: React.FC<TrabajadorSearchAutocompleteProps> = ({
  trabajadores = [],
  valorSeleccionado = '',
  onSeleccionar,
  empresaFiltro = 'TODAS',
  label = 'Trabajador',
  sublabel,
  placeholder = 'Buscar por nombre o DNI...',
  required = false,
  colorTheme = 'purple',
  autoFocus = false,
  disabled = false,
  className = ''
}) => {
  const [textoBusqueda, setTextoBusqueda] = useState<string>('');
  const [abierto, setAbierto] = useState<boolean>(false);
  const [indiceFoco, setIndiceFoco] = useState<number>(-1);

  const contenedorRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listaRef = useRef<HTMLUListElement>(null);

  // Trabajador actualmente seleccionado
  const trabajadorActual = useMemo(() => {
    if (!valorSeleccionado) return null;
    const target = valorSeleccionado.trim().toUpperCase();
    return (
      trabajadores.find(
        (t) =>
          String(t.codigo || '').trim().toUpperCase() === target ||
          String(t.dni || '').trim().toUpperCase() === target
      ) || null
    );
  }, [trabajadores, valorSeleccionado]);

  // Filtrado de trabajadores por empresa (si aplica)
  const trabajadoresPorEmpresa = useMemo(() => {
    const lista = Array.isArray(trabajadores) ? trabajadores : [];
    if (!empresaFiltro || empresaFiltro === 'TODAS') return lista;
    return lista.filter((t) => t.empresaId === empresaFiltro);
  }, [trabajadores, empresaFiltro]);

  // Filtrado predictivo multi-token por texto de búsqueda: ÚNICAMENTE por nombre o DNI
  const sugerencias = useMemo(() => {
    if (!textoBusqueda.trim()) {
      return trabajadoresPorEmpresa.slice(0, 15);
    }
    const tokens = textoBusqueda.toLowerCase().trim().split(/\s+/);
    return trabajadoresPorEmpresa
      .filter((t) => {
        const nombre = (t.nombreCompleto || t.apellidosNombres || '').toLowerCase();
        const dni = String(t.dni || '').toLowerCase();
        // Solo debe permitir buscar por nombre o DNI
        const searchTarget = `${nombre} ${dni}`;

        return tokens.every((tok) => searchTarget.includes(tok));
      })
      .slice(0, 20);
  }, [trabajadoresPorEmpresa, textoBusqueda]);

  // Cerrar sugerencias al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (contenedorRef.current && !contenedorRef.current.contains(event.target as Node)) {
        setAbierto(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Manejo de teclado (flechas arriba/abajo, enter, escape)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (disabled) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!abierto) {
        setAbierto(true);
        setIndiceFoco(0);
      } else {
        setIndiceFoco((prev) => (prev < sugerencias.length - 1 ? prev + 1 : 0));
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (abierto) {
        setIndiceFoco((prev) => (prev > 0 ? prev - 1 : sugerencias.length - 1));
      }
    } else if (e.key === 'Enter') {
      if (abierto && indiceFoco >= 0 && indiceFoco < sugerencias.length) {
        e.preventDefault();
        seleccionarTrabajador(sugerencias[indiceFoco]);
      }
    } else if (e.key === 'Escape') {
      setAbierto(false);
      setIndiceFoco(-1);
    }
  };

  // Scroll automático en lista al navegar con flechas
  useEffect(() => {
    if (indiceFoco >= 0 && listaRef.current) {
      const item = listaRef.current.children[indiceFoco] as HTMLElement;
      if (item) {
        item.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [indiceFoco]);

  const seleccionarTrabajador = (t: Trabajador) => {
    onSeleccionar(t);
    setTextoBusqueda('');
    setAbierto(false);
    setIndiceFoco(-1);
  };

  const limpiarSeleccion = () => {
    onSeleccionar(null);
    setTextoBusqueda('');
    setAbierto(true);
    setIndiceFoco(-1);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 50);
  };

  // Estilos según el tema de color del módulo
  const themeClasses = useMemo(() => {
    switch (colorTheme) {
      case 'emerald':
        return {
          icon: 'text-emerald-600',
          focusRing: 'focus:border-emerald-500 focus:ring-emerald-500/20',
          activeBg: 'bg-emerald-50 text-emerald-900',
          badgeEmpresa: 'bg-emerald-100 text-emerald-900 border-emerald-300',
          avatarBg: 'bg-emerald-100 text-emerald-700 border-emerald-200',
          buttonClear: 'text-emerald-700 hover:bg-emerald-100',
          checkIcon: 'text-emerald-600'
        };
      case 'amber':
        return {
          icon: 'text-amber-600',
          focusRing: 'focus:border-amber-500 focus:ring-amber-500/20',
          activeBg: 'bg-amber-50 text-amber-900',
          badgeEmpresa: 'bg-amber-100 text-amber-900 border-amber-300',
          avatarBg: 'bg-amber-100 text-amber-800 border-amber-200',
          buttonClear: 'text-amber-700 hover:bg-amber-100',
          checkIcon: 'text-amber-600'
        };
      case 'rose':
        return {
          icon: 'text-rose-600',
          focusRing: 'focus:border-rose-500 focus:ring-rose-500/20',
          activeBg: 'bg-rose-50 text-rose-900',
          badgeEmpresa: 'bg-rose-100 text-rose-900 border-rose-300',
          avatarBg: 'bg-rose-100 text-rose-700 border-rose-200',
          buttonClear: 'text-rose-700 hover:bg-rose-100',
          checkIcon: 'text-rose-600'
        };
      case 'blue':
        return {
          icon: 'text-blue-600',
          focusRing: 'focus:border-blue-500 focus:ring-blue-500/20',
          activeBg: 'bg-blue-50 text-blue-900',
          badgeEmpresa: 'bg-blue-100 text-blue-900 border-blue-300',
          avatarBg: 'bg-blue-100 text-blue-700 border-blue-200',
          buttonClear: 'text-blue-700 hover:bg-blue-100',
          checkIcon: 'text-blue-600'
        };
      case 'purple':
      default:
        return {
          icon: 'text-purple-600',
          focusRing: 'focus:border-purple-500 focus:ring-purple-500/20',
          activeBg: 'bg-purple-50 text-purple-900',
          badgeEmpresa: 'bg-purple-100 text-purple-900 border-purple-300',
          avatarBg: 'bg-purple-100 text-purple-700 border-purple-200',
          buttonClear: 'text-purple-700 hover:bg-purple-100',
          checkIcon: 'text-purple-600'
        };
    }
  }, [colorTheme]);

  return (
    <div className={`space-y-1.5 ${className}`} ref={contenedorRef}>
      {label && (
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <UserCheck className={`w-3.5 h-3.5 ${themeClasses.icon}`} />
            <span>{label}</span>
            {required && <span className="text-rose-500 font-bold">*</span>}
          </label>
          {sublabel && (
            <span className="text-[10px] text-slate-400 font-mono">
              {sublabel}
            </span>
          )}
        </div>
      )}

      {/* ESTADO 1: TRABAJADOR SELECCIONADO (Chip informativo con botón de cambio) */}
      {trabajadorActual ? (
        <div className="p-2.5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 shadow-2xs flex items-center justify-between gap-2.5 transition-all">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className={`w-8 h-8 rounded-full ${themeClasses.avatarBg} font-bold text-xs flex items-center justify-center shrink-0 border`}
            >
              {(trabajadorActual.nombreCompleto || trabajadorActual.apellidosNombres || 'TR')
                .slice(0, 2)
                .toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-slate-900 truncate">
                  {trabajadorActual.nombreCompleto || trabajadorActual.apellidosNombres}
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-100 text-slate-700 shrink-0">
                  DNI: {trabajadorActual.dni}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={limpiarSeleccion}
              disabled={disabled}
              className={`px-2 py-1 text-xs font-semibold rounded-lg ${themeClasses.buttonClear} transition-colors cursor-pointer flex items-center gap-1 border border-slate-200`}
              title="Cambiar o buscar otro trabajador"
            >
              <span>Cambiar</span>
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        /* ESTADO 2: BUSCADOR CON AUTOCOMPLETADO INTERACTIVO */
        <div className="relative">
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              ref={inputRef}
              type="text"
              autoFocus={autoFocus}
              disabled={disabled}
              value={textoBusqueda}
              onChange={(e) => {
                setTextoBusqueda(e.target.value);
                setAbierto(true);
                setIndiceFoco(-1);
              }}
              onFocus={() => setAbierto(true)}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              className={`w-full h-9.5 pl-9 pr-8 text-xs bg-slate-50/70 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 ${themeClasses.focusRing} transition-all`}
            />

            {textoBusqueda ? (
              <button
                type="button"
                onClick={() => {
                  setTextoBusqueda('');
                  setIndiceFoco(-1);
                  inputRef.current?.focus();
                }}
                className="absolute right-2.5 p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                title="Limpiar texto"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setAbierto((prev) => !prev)}
                className="absolute right-2.5 p-1 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                title="Desplegar sugerencias"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Menú flotante de sugerencias */}
          {abierto && (
            <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-100 max-h-72 flex flex-col">
              <div className="px-3 py-1.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-medium">
                <span>
                  {sugerencias.length === 0
                    ? 'Sin resultados'
                    : `Sugerencias (${sugerencias.length} disponibles)`}
                </span>
                <span className="text-[10px] text-slate-400">
                  Usa ↑ ↓ y Enter para elegir
                </span>
              </div>

              <ul
                ref={listaRef}
                className="overflow-y-auto divide-y divide-slate-100 text-xs py-1"
                role="listbox"
              >
                {sugerencias.length === 0 ? (
                  <li className="p-4 text-center text-slate-400">
                    <p className="font-semibold text-slate-600">No se encontraron trabajadores</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Pruebe buscando por otro nombre o número de DNI.
                    </p>
                  </li>
                ) : (
                  sugerencias.map((t, idx) => {
                    const seleccionado = Boolean(valorSeleccionado && (valorSeleccionado === t.codigo || valorSeleccionado === t.dni));
                    const enfocado = indiceFoco === idx;
                    const nombre = t.nombreCompleto || t.apellidosNombres || 'Trabajador';
                    const isPerpol = t.empresaId === 'EMP-PERPOL';

                    return (
                      <li
                        key={t.codigo || `trab-${idx}`}
                        role="option"
                        aria-selected={seleccionado}
                        onMouseEnter={() => setIndiceFoco(idx)}
                        onClick={() => seleccionarTrabajador(t)}
                        className={`p-2.5 cursor-pointer flex items-center justify-between gap-3 transition-colors ${
                          enfocado
                            ? themeClasses.activeBg
                            : 'hover:bg-slate-50 text-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className={`w-7 h-7 rounded-full ${
                              isPerpol
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-blue-100 text-blue-800'
                            } font-bold text-[10px] flex items-center justify-center shrink-0 border border-slate-200`}
                          >
                            {nombre.slice(0, 2).toUpperCase()}
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900 truncate">
                                {nombre}
                              </span>
                              <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold shrink-0">
                                DNI: {t.dni}
                              </span>
                            </div>
                          </div>
                        </div>

                        {seleccionado && (
                          <div className="flex items-center shrink-0">
                            <Check className={`w-4 h-4 ${themeClasses.checkIcon}`} />
                          </div>
                        )}
                      </li>
                    );
                  })
                )}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
