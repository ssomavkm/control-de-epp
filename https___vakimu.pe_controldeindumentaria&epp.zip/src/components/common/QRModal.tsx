import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { X, Printer, QrCode as QrIcon, ShieldCheck } from 'lucide-react';
import { Trabajador, EPPItem, EntregaEPP } from '../../types';

interface QRModalProps {
  isOpen: boolean;
  onClose: () => void;
  tipo: 'trabajador' | 'epp';
  trabajador?: Trabajador;
  historialEntregasTrabajador?: EntregaEPP[];
  epp?: EPPItem;
}

export const QRModal: React.FC<QRModalProps> = ({
  isOpen,
  onClose,
  tipo,
  trabajador,
  historialEntregasTrabajador = [],
  epp
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (!isOpen) return;

    let payload = '';
    if (tipo === 'trabajador' && trabajador) {
      payload = JSON.stringify({
        tipo: 'TRABAJADOR_SST',
        codigo: trabajador.codigo,
        dni: trabajador.dni,
        nombre: trabajador.nombreCompleto,
        empresa: trabajador.empresaNombre,
        area: trabajador.area,
        cargo: trabajador.cargo,
        estado: trabajador.estado
      });
    } else if (tipo === 'epp' && epp) {
      payload = JSON.stringify({
        tipo: 'EPP_CATALOGO',
        codigo: epp.codigo,
        articulo: epp.articulo,
        norma: epp.norma,
        stock: epp.stockActual,
        vidaUtilDias: epp.vidaUtilDias,
        estado: epp.estado
      });
    }

    if (payload) {
      QRCode.toDataURL(payload, {
        width: 260,
        margin: 1.5,
        color: {
          dark: '#0f172a',
          light: '#ffffff'
        }
      }).then(setQrDataUrl).catch(console.error);
    }
  }, [isOpen, tipo, trabajador, epp]);

  // Soporte para cerrar con tecla Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div 
      role="dialog"
      aria-modal="true"
      aria-labelledby="titulo-modal-qr"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs"
    >
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 overflow-hidden">
        {/* Cabecera del modal */}
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrIcon className="w-5 h-5 text-emerald-400" />
            <h3 id="titulo-modal-qr" className="text-sm font-bold">
              {tipo === 'trabajador' ? 'Credencial QR SST - Trabajador' : 'Ficha Técnica QR - Artículo EPP'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar credencial QR"
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido / Tarjeta Imprimible */}
        <div className="p-6">
          <div className="bg-slate-50 border-2 border-slate-300 rounded-xl p-5 text-center flex flex-col items-center">
            {/* Header del Carnet / Etiqueta */}
            <div className="flex items-center justify-between w-full border-b border-slate-200 pb-3 mb-4">
              <div className="text-left">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">
                  SISTEMA DE GESTIÓN SSOMA
                </span>
                <span className="text-xs font-bold text-slate-900">
                  {tipo === 'trabajador' ? trabajador?.empresaNombre : 'CATÁLOGO HOMOLOGADO'}
                </span>
              </div>
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
            </div>

            {/* Código QR */}
            {qrDataUrl ? (
              <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-xs mb-3">
                <img src={qrDataUrl} alt="Código QR" className="w-48 h-48 block" />
              </div>
            ) : (
              <div className="w-48 h-48 bg-slate-100 flex items-center justify-center text-slate-400 text-xs">
                Generando QR...
              </div>
            )}

            {/* Datos detallados */}
            {tipo === 'trabajador' && trabajador && (
              <div className="text-left w-full space-y-1.5 text-xs">
                <div className="text-center font-bold text-slate-900 text-sm">
                  {trabajador.nombreCompleto}
                </div>
                <div className="text-center text-slate-500 font-mono text-xs">
                  DNI: {trabajador.dni} · CÓDIGO: {trabajador.codigo}
                </div>
                <div className="pt-2 border-t border-slate-200 text-slate-600 grid grid-cols-2 gap-1 text-[11px]">
                  <div><span className="font-semibold text-slate-800">Área:</span> {trabajador.area}</div>
                  <div><span className="font-semibold text-slate-800">Cargo:</span> {trabajador.cargo}</div>
                  <div><span className="font-semibold text-slate-800">Estado:</span> {trabajador.estado}</div>
                  <div><span className="font-semibold text-slate-800">Ingreso:</span> {trabajador.fechaIngreso}</div>
                </div>

                {historialEntregasTrabajador.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-slate-200 text-[11px] text-slate-500">
                    <span className="font-semibold text-slate-700">Entregas registradas:</span> {historialEntregasTrabajador.length} entregas ({historialEntregasTrabajador.reduce((acc, e) => acc + e.totalUnidades, 0)} unidades de EPP)
                  </div>
                )}
              </div>
            )}

            {tipo === 'epp' && epp && (
              <div className="text-left w-full space-y-1.5 text-xs">
                <div className="text-center font-bold text-slate-900 text-sm">
                  {epp.articulo}
                </div>
                <div className="text-center font-mono text-slate-500 text-xs">
                  CÓDIGO: {epp.codigo} · TALLA: {epp.talla}
                </div>
                <div className="pt-2 border-t border-slate-200 text-slate-600 grid grid-cols-2 gap-1 text-[11px]">
                  <div><span className="font-semibold text-slate-800">Norma:</span> {epp.norma}</div>
                  <div><span className="font-semibold text-slate-800">Marca:</span> {epp.marca}</div>
                  <div><span className="font-semibold text-slate-800">Stock Actual:</span> <span className="font-mono font-bold text-slate-900">{epp.stockActual} {epp.unidad}</span></div>
                  <div><span className="font-semibold text-slate-800">Vida Útil:</span> {epp.vidaUtilDias} días</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Acciones */}
        <div className="px-6 py-3.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Escaneable con cualquier lector QR estándar
          </span>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimir Etiqueta
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 border border-slate-300 text-slate-700 hover:bg-slate-200 rounded-lg text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-500"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
