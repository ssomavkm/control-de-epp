import React, { useState, useMemo, useRef, useEffect } from 'react';
import { MapPin, ChevronDown, X, Check } from 'lucide-react';
import { ZONAS_PLANTA_INDUSTRIAL } from '../../data/seeds/zonasPlanta';

export interface ZonaPlantaAutocompleteProps {
  valor: string;
  onChange: (zona: string) => void;
  required?: boolean;
  label?: string;
  placeholder?: string;
  colorTheme?: 'rose' | 'emerald' | 'blue' | 'purple' | 'amber';
  disabled?: boolean;
  className?: string;
}

export const ZonaPlantaAutocomplete: React.FC<ZonaPlantaAutocompleteProps> = ({
  valor = '',
  onChange,
  required = false,
  label = 'Lugar / Zona Exacta de la Planta Industrial',
  placeholder = 'Buscar o seleccionar zona de la planta...',
  colorTheme = 'rose',
  disabled = false,
  className = ''
}) => {
  const [abierto, setAbierto] = useState<boolean>(false);
  const [filtroTexto, setFiltroTexto] = useState<string>('');
  const [indiceFoco, setIndiceFoco] = useState<number>(-1);

  const contenedorRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listaRef = useRef<HTMLUListElement>(null);

  // Normalizador para búsqueda insensible a acentos y mayúsculas
  const normalizar = (txt: string) =>
    (txt || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');

  // Filtrado reactivo de las 58 zonas
  const zonasSugeridas = useMemo(() => {
    const query = normalizar(filtroTexto.trim());
    if (!query) {
      return ZONAS_PLANTA_INDUSTRIAL;
    }
    const palabras = query.split(/\s+/);
    return ZONAS_PLANTA_INDUSTRIAL.filter((zona) => {
      const zNorm = normalizar(zona);
      return palabras.every((palabra) => zNorm.includes(palabra));
    });
  }, [filtroTexto]);

  // Cerrar al hacer clic fuera
  useEffect(() => {
    const handleClickFuera = (e: MouseEvent) => {
      if (contenedorRef.current && !contenedorRef.current.contains(e.target as Node)) {
        setAbierto(false);
      }
    };
    document.addEventListener('mousedown', handleClickFuera);
    return () => document.removeEventListener('mousedown', handleClickFuera);
  }, []);

  // Sincronizar texto de filtro al cambiar el valor externamente
  useEffect(() => {
    if (valor) {
      setFiltroTexto(valor);
    }
  }, [valor]);

  // Manejo de teclado accesible
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (disabled) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!abierto) {
        setAbierto(true);
        setIndiceFoco(0);
      } else {
        setIndiceFoco((prev) => (prev < zonasSugeridas.length - 1 ? prev + 1 : 0));
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (abierto) {
        setIndiceFoco((prev) => (prev > 0 ? prev - 1 : zonasSugeridas.length - 1));
      }
    } else if (e.key === 'Enter') {
      if (abierto && indiceFoco >= 0 && indiceFoco < zonasSugeridas.length) {
        e.preventDefault();
        seleccionarZona(zonasSugeridas[indiceFoco]);
      }
    } else if (e.key === 'Escape') {
      setAbierto(false);
      setIndiceFoco(-1);
    }
  };

  // Scroll automático hacia el elemento enfocado con teclado
  useEffect(() => {
    if (indiceFoco >= 0 && listaRef.current) {
      const item = listaRef.current.children[indiceFoco] as HTMLElement;
      if (item) {
        item.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [indiceFoco]);

  const seleccionarZona = (zona: string) => {
    onChange(zona);
    setFiltroTexto(zona);
    setAbierto(false);
    setIndiceFoco(-1);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setFiltroTexto(val);
    onChange(val);
    if (!abierto) setAbierto(true);
    setIndiceFoco(-1);
  };

  const handleLimpiar = () => {
    onChange('');
    setFiltroTexto('');
    setAbierto(true);
    setIndiceFoco(-1);
    inputRef.current?.focus();
  };

  // Tema de colores
  const focusRingClass = useMemo(() => {
    switch (colorTheme) {
      case 'rose':
        return 'focus-within:ring-2 focus-within:ring-rose-500 border-rose-300';
      case 'emerald':
        return 'focus-within:ring-2 focus-within:ring-emerald-500 border-emerald-300';
      case 'blue':
        return 'focus-within:ring-2 focus-within:ring-blue-500 border-blue-300';
      case 'purple':
        return 'focus-within:ring-2 focus-within:ring-purple-500 border-purple-300';
      default:
        return 'focus-within:ring-2 focus-within:ring-slate-400 border-slate-300';
    }
  }, [colorTheme]);

  return (
    <div ref={contenedorRef} className={`relative ${className}`}>
      {label && (
        <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
          <span>
            {label} {required && <span className="text-rose-500">*</span>}
          </span>
          <span className="text-[10px] font-normal text-slate-400">
            {ZONAS_PLANTA_INDUSTRIAL.length} zonas en catálogo
          </span>
        </label>
      )}

      {/* Input con Iconos y Acciones Rápidas */}
      <div
        className={`flex items-center w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl transition-all shadow-2xs ${
          disabled ? 'opacity-60 cursor-not-allowed' : 'hover:border-slate-300'
        } ${focusRingClass}`}
      >
        <MapPin className="w-3.5 h-3.5 text-slate-400 mr-2 shrink-0" />
        
        <input
          ref={inputRef}
          type="text"
          value={filtroTexto}
          onChange={handleInputChange}
          onFocus={() => {
            if (!disabled) setAbierto(true);
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          required={required}
          disabled={disabled}
          list="lista-zonas-planta-datalist"
          autoComplete="off"
          className="w-full bg-transparent text-xs text-slate-800 placeholder-slate-400 focus:outline-none"
        />

        <div className="flex items-center gap-1 ml-1.5 shrink-0">
          {filtroTexto && !disabled && (
            <button
              type="button"
              onClick={handleLimpiar}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200/60 transition-colors"
              title="Borrar texto"
            >
              <X className="w-3 h-3" />
            </button>
          )}

          <button
            type="button"
            disabled={disabled}
            onClick={() => {
              if (!disabled) {
                setAbierto(!abierto);
                inputRef.current?.focus();
              }
            }}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200/60 transition-colors"
            title={abierto ? 'Cerrar opciones' : 'Desplegar zonas'}
          >
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${abierto ? 'rotate-180 text-rose-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Datalist nativo como respaldo para accesibilidad / autocompletado del navegador */}
      <datalist id="lista-zonas-planta-datalist">
        {ZONAS_PLANTA_INDUSTRIAL.map((zona) => (
          <option key={zona} value={zona} />
        ))}
      </datalist>

      {/* Menú Desplegable Autocompletable */}
      {abierto && !disabled && (
        <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden animate-in fade-in-50 duration-150">
          <div className="p-2 border-b border-slate-100 bg-slate-50/80 flex items-center justify-between text-[11px] text-slate-500 font-medium">
            <span>
              {zonasSugeridas.length} de {ZONAS_PLANTA_INDUSTRIAL.length} zona(s) encontrada(s)
            </span>
            {filtroTexto && (
              <button
                type="button"
                onClick={() => setFiltroTexto('')}
                className="text-rose-600 hover:text-rose-700 font-semibold cursor-pointer"
              >
                Ver todas
              </button>
            )}
          </div>

          <ul
            ref={listaRef}
            className="max-h-56 overflow-y-auto divide-y divide-slate-50 text-xs py-1"
          >
            {zonasSugeridas.length === 0 ? (
              <li className="px-4 py-3 text-center text-slate-400">
                <p className="font-semibold text-slate-600 mb-0.5">No se encontró una zona exacta</p>
                <p className="text-[11px]">Puedes presionar Enter para usar "{filtroTexto}" o elegir de la lista general.</p>
                <button
                  type="button"
                  onClick={() => setFiltroTexto('')}
                  className="mt-2 text-xs font-semibold text-rose-600 hover:underline"
                >
                  Restablecer lista completa (58 zonas)
                </button>
              </li>
            ) : (
              zonasSugeridas.map((zona, idx) => {
                const seleccionada = valor.trim().toLowerCase() === zona.toLowerCase();
                const enfocado = idx === indiceFoco;

                return (
                  <li
                    key={zona}
                    onClick={() => seleccionarZona(zona)}
                    className={`px-3 py-2 cursor-pointer flex items-center justify-between transition-colors ${
                      enfocado
                        ? 'bg-rose-50 text-rose-900 font-semibold'
                        : seleccionada
                        ? 'bg-rose-50/70 text-rose-800 font-medium'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <MapPin
                        className={`w-3.5 h-3.5 shrink-0 ${
                          seleccionada || enfocado ? 'text-rose-600' : 'text-slate-400'
                        }`}
                      />
                      <span className="truncate">{zona}</span>
                    </div>

                    {seleccionada && (
                      <Check className="w-3.5 h-3.5 text-rose-600 shrink-0 ml-2" />
                    )}
                  </li>
                );
              })
            )}
          </ul>
        </div>
      )}
    </div>
  );
};
