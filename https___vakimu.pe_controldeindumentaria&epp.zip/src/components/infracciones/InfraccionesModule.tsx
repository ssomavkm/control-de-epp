import React from 'react';
import { ShieldAlert, Plus, CheckCircle2, AlertCircle } from 'lucide-react';
import { InfraccionEPP, Trabajador, Empresa, DatosPreseleccionadosInfraccion } from '../../types';
import { storageService } from '../../services/storageService';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { ModuleHeader } from '../common/ModuleHeader';
import { InfraccionesStats } from './components/InfraccionesStats';
import { InfraccionesFilters } from './components/InfraccionesFilters';
import { InfraccionesTable } from './components/InfraccionesTable';
import { NuevaInfraccionForm } from './components/NuevaInfraccionForm';
import { InfraccionDeleteModal } from './components/InfraccionDeleteModal';
import { useInfracciones } from './hooks/useInfracciones';

interface InfraccionesModuleProps {
  infracciones: InfraccionEPP[];
  trabajadores: Trabajador[];
  empresas: Empresa[];
  empresaFiltro: string;
  onCambiarEmpresaFiltro: (empresaId: string) => void;
  trabajadorPreseleccionado?: string;
  datosPreseleccionados?: DatosPreseleccionadosInfraccion | null;
  onLimpiarDatosPreseleccionados?: () => void;
  onInfraccionGuardada: () => void;
}

export const InfraccionesModule: React.FC<InfraccionesModuleProps> = ({
  infracciones,
  trabajadores,
  empresaFiltro,
  trabajadorPreseleccionado,
  datosPreseleccionados,
  onLimpiarDatosPreseleccionados,
  onInfraccionGuardada
}) => {
  const {
    vistaActiva,
    setVistaActiva,
    busqueda,
    setBusqueda,
    filtroGravedad,
    setFiltroGravedad,
    filtroEstado,
    setFiltroEstado,
    modalPDFOpen,
    setModalPDFOpen,
    pdfData,
    generandoPDF,
    origenInspeccion,
    setOrigenInspeccion,
    codigoTrabajador,
    setCodigoTrabajador,
    fechaHora,
    setFechaHora,
    lugarZona,
    setLugarZona,
    eppsOmitidos,
    otroEPP,
    setOtroEPP,
    gravedad,
    tipoSancion,
    setTipoSancion,
    descripcionHechos,
    setDescripcionHechos,
    justificacionTrabajador,
    setJustificacionTrabajador,
    medidaCorrectivaInmediata,
    setMedidaCorrectivaInmediata,
    supervisorSeleccionado,
    supervisorReporta,
    setSupervisorReporta,
    cargoSupervisor,
    setCargoSupervisor,
    handleCambiarSupervisor,
    seNegoAFirmar,
    setSeNegoAFirmar,
    testigoNombre,
    setTestigoNombre,
    testigoDni,
    setTestigoDni,
    firmaSupervisor,
    setFirmaSupervisor,
    firmaTrabajador,
    setFirmaTrabajador,
    guardando,
    mensajeExito,
    mensajeError,
    setMensajeError,
    infraccionAEliminar,
    setInfraccionAEliminar,
    plantillaActiva,
    trabajadorSeleccionado,
    listaCompletaEPP,
    infraccionesPrevias,
    nivelReincidenciaCalculado,
    handleToggleEPP,
    handleAgregarOtroEPP,
    handleCambiarGravedad,
    handlePrevisualizarPDF,
    handleGuardarInfraccion,
    handleVerPDFExistente,
    infraccionesFiltradas,
    kpis
  } = useInfracciones({
    infracciones,
    trabajadores,
    empresaFiltro,
    trabajadorPreseleccionado,
    datosPreseleccionados,
    onLimpiarDatosPreseleccionados,
    onInfraccionGuardada
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Encabezado del Módulo Estandarizado */}
      <ModuleHeader
        icon={ShieldAlert}
        title="Reporte de Infracción y Sanción Disciplinaria por No Uso de EPP"
        badge={`${plantillaActiva.codigo} v${plantillaActiva.version}`}
        subtitle="Control de actos subestándar, amonestaciones disciplinarias y trazabilidad de reincidencias de seguridad (Ley N° 29783 Art. 79)."
        colorTheme="rose"
        actions={
          vistaActiva === 'lista' ? (
            <button
              onClick={() => setVistaActiva('nuevo')}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Registrar Nueva Infracción</span>
            </button>
          ) : null
        }
      />

      {mensajeExito && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2.5 shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{mensajeExito}</span>
        </div>
      )}

      {mensajeError && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center justify-between gap-2.5 shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{mensajeError}</span>
          </div>
          <button
            onClick={() => setMensajeError(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* VISTA 1: LISTADO DE REPORTES */}
      {vistaActiva === 'lista' && (
        <div className="space-y-6">
          <InfraccionesStats kpis={kpis} />
          <InfraccionesFilters
            busqueda={busqueda}
            setBusqueda={setBusqueda}
            filtroGravedad={filtroGravedad}
            setFiltroGravedad={setFiltroGravedad}
            filtroEstado={filtroEstado}
            setFiltroEstado={setFiltroEstado}
            totalFiltrados={infraccionesFiltradas.length}
          />
          <InfraccionesTable
            infracciones={infraccionesFiltradas}
            onVerPDF={handleVerPDFExistente}
            onSolicitarEliminar={setInfraccionAEliminar}
          />
        </div>
      )}

      {/* VISTA 2: FORMULARIO DE NUEVA INFRACCIÓN */}
      {vistaActiva === 'nuevo' && (
        <NuevaInfraccionForm
          origenInspeccion={origenInspeccion}
          onLimpiarOrigen={() => {
            setOrigenInspeccion(null);
            if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();
          }}
          codigoTrabajador={codigoTrabajador}
          setCodigoTrabajador={setCodigoTrabajador}
          trabajadores={trabajadores}
          empresaFiltro={empresaFiltro}
          trabajadorSeleccionado={trabajadorSeleccionado}
          fechaHora={fechaHora}
          setFechaHora={setFechaHora}
          infraccionesPrevias={infraccionesPrevias}
          nivelReincidenciaCalculado={nivelReincidenciaCalculado}
          lugarZona={lugarZona}
          setLugarZona={setLugarZona}
          listaCompletaEPP={listaCompletaEPP}
          eppsOmitidos={eppsOmitidos}
          handleToggleEPP={handleToggleEPP}
          otroEPP={otroEPP}
          setOtroEPP={setOtroEPP}
          handleAgregarOtroEPP={handleAgregarOtroEPP}
          gravedad={gravedad}
          handleCambiarGravedad={handleCambiarGravedad}
          tipoSancion={tipoSancion}
          setTipoSancion={setTipoSancion}
          descripcionHechos={descripcionHechos}
          setDescripcionHechos={setDescripcionHechos}
          justificacionTrabajador={justificacionTrabajador}
          setJustificacionTrabajador={setJustificacionTrabajador}
          medidaCorrectivaInmediata={medidaCorrectivaInmediata}
          setMedidaCorrectivaInmediata={setMedidaCorrectivaInmediata}
          supervisorReporta={supervisorReporta}
          cargoSupervisor={cargoSupervisor}
          supervisorSeleccionado={supervisorSeleccionado}
          onCambiarSupervisor={handleCambiarSupervisor}
          seNegoAFirmar={seNegoAFirmar}
          setSeNegoAFirmar={setSeNegoAFirmar}
          testigoNombre={testigoNombre}
          setTestigoNombre={setTestigoNombre}
          testigoDni={testigoDni}
          setTestigoDni={setTestigoDni}
          firmaTrabajador={firmaTrabajador}
          setFirmaTrabajador={setFirmaTrabajador}
          firmaSupervisor={firmaSupervisor}
          setFirmaSupervisor={setFirmaSupervisor}
          generandoPDF={generandoPDF}
          guardando={guardando}
          onCancelar={() => {
            setVistaActiva('lista');
            if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();
          }}
          onPrevisualizarPDF={handlePrevisualizarPDF}
          onSubmit={handleGuardarInfraccion}
        />
      )}

      {/* Visor Modal de PDF Oficial */}
      {modalPDFOpen && (
        <PDFViewerModal
          isOpen={modalPDFOpen}
          onClose={() => setModalPDFOpen(false)}
          pdfBlobUrl={pdfData.url}
          pdfArrayBuffer={pdfData.buffer}
          fileName={pdfData.fileName}
          titulo="Reporte Oficial de Infracción FO-SST-INF-001"
          esBorrador={vistaActiva === 'nuevo'}
        />
      )}

      {/* Modal de Confirmación de Eliminación */}
      <InfraccionDeleteModal
        infraccionAEliminar={infraccionAEliminar}
        onClose={() => setInfraccionAEliminar(null)}
        onConfirmar={() => {
          if (infraccionAEliminar) {
            storageService.eliminarInfraccion(infraccionAEliminar.id);
            setInfraccionAEliminar(null);
            onInfraccionGuardada();
          }
        }}
      />
    </div>
  );
};
