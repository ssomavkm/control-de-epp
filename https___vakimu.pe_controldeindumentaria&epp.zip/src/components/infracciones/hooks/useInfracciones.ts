import React, { useState, useMemo, useEffect } from 'react';
import {
  InfraccionEPP,
  Trabajador,
  GravedadInfraccion,
  TipoSancionInfraccion,
  NivelReincidencia,
  DatosPreseleccionadosInfraccion,
  RESPONSABLES_SST_OPCIONES
} from '../../../types';
import { storageService } from '../../../services/storageService';
import { PDFGeneratorService, PDFResult } from '../../../services/pdfGenerator';
import { googleDriveService } from '../../../services/drive/googleDriveService';
import { compararFechasDesc } from '../../../utils/formatters';

export const LISTA_EPP_COMUNES = [
  'Casco de seguridad tipo jockey',
  'Barbiquejo para casco',
  'Lentes de seguridad antiempañantes claros',
  'Lentes de seguridad oscuros para exteriores',
  'Botas de jebe blancas con puntera de acero',
  'Calzado de seguridad de cuero dieléctrico',
  'Protector auditivo tipo copa',
  'Tapones auditivos reutilizables',
  'Guantes de nitrilo verde químico',
  'Guantes de badana / cuero',
  'Respirador de media cara con filtros',
  'Mascarilla descartable KN95',
  'Arnés de cuerpo entero contra caídas',
  'Chaleco de seguridad reflectivo'
];

interface UseInfraccionesProps {
  infracciones: InfraccionEPP[];
  trabajadores: Trabajador[];
  empresaFiltro: string;
  trabajadorPreseleccionado?: string;
  datosPreseleccionados?: DatosPreseleccionadosInfraccion | null;
  onLimpiarDatosPreseleccionados?: () => void;
  onInfraccionGuardada: () => void;
}

export function useInfracciones({
  infracciones,
  trabajadores,
  empresaFiltro,
  trabajadorPreseleccionado,
  datosPreseleccionados,
  onLimpiarDatosPreseleccionados,
  onInfraccionGuardada
}: UseInfraccionesProps) {
  const [vistaActiva, setVistaActiva] = useState<'lista' | 'nuevo'>(() => {
    return trabajadorPreseleccionado || datosPreseleccionados ? 'nuevo' : 'lista';
  });

  // Filtros de listado
  const [busqueda, setBusqueda] = useState<string>('');
  const [filtroGravedad, setFiltroGravedad] = useState<string>('TODOS');
  const [filtroEstado, setFiltroEstado] = useState<string>('TODOS');

  // Visor PDF
  const [modalPDFOpen, setModalPDFOpen] = useState<boolean>(false);
  const [pdfData, setPdfData] = useState<{ url: string | null; buffer: ArrayBuffer | null; fileName: string }>({
    url: null,
    buffer: null,
    fileName: ''
  });
  const [generandoPDF, setGenerandoPDF] = useState<boolean>(false);

  // Origen de inspección heredada
  const [origenInspeccion, setOrigenInspeccion] = useState<{
    id?: string;
    numero?: string;
  } | null>(() => {
    if (datosPreseleccionados?.numeroInspeccionOrigen) {
      return {
        id: datosPreseleccionados.idInspeccionOrigen,
        numero: datosPreseleccionados.numeroInspeccionOrigen
      };
    }
    return null;
  });

  // Formulario nuevo reporte
  const [codigoTrabajador, setCodigoTrabajador] = useState<string>(
    datosPreseleccionados?.codigoTrabajador || trabajadorPreseleccionado || ''
  );
  const [fechaHora, setFechaHora] = useState<string>(() => {
    if (datosPreseleccionados?.fechaHora) {
      return datosPreseleccionados.fechaHora.includes('T')
        ? datosPreseleccionados.fechaHora.slice(0, 16)
        : datosPreseleccionados.fechaHora.replace(' ', 'T').slice(0, 16);
    }
    const now = new Date();
    const isoDate = now.toISOString().slice(0, 10);
    const hours = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    return `${isoDate}T${hours}:${mins}`;
  });
  const [lugarZona, setLugarZona] = useState<string>(
    datosPreseleccionados?.lugarZona || 'Procesos'
  );
  const [eppsOmitidos, setEppsOmitidos] = useState<string[]>(
    datosPreseleccionados?.eppsOmitidos || []
  );
  const [otroEPP, setOtroEPP] = useState<string>('');
  const [gravedad, setGravedad] = useState<GravedadInfraccion>('Grave');
  const [tipoSancion, setTipoSancion] = useState<TipoSancionInfraccion>('Amonestación Escrita');
  const [descripcionHechos, setDescripcionHechos] = useState<string>(
    datosPreseleccionados?.descripcionHechos || ''
  );
  const [justificacionTrabajador, setJustificacionTrabajador] = useState<string>('');
  const [medidaCorrectivaInmediata, setMedidaCorrectivaInmediata] = useState<string>(
    'Paralización preventiva de la labor, colocación inmediata del EPP reglamentario y reinducción técnica de 5 minutos.'
  );
  const [supervisorSeleccionado, setSupervisorSeleccionado] = useState<string>(() => {
    if (datosPreseleccionados?.supervisorReporta) {
      const match = RESPONSABLES_SST_OPCIONES.find(
        r => r.nombre === datosPreseleccionados.supervisorReporta || r.valor === datosPreseleccionados.supervisorReporta
      );
      if (match) return match.valor;
    }
    return 'Ing. Jhon Rojas (Supervisor SSOMA)';
  });
  const [supervisorReporta, setSupervisorReporta] = useState<string>(() => {
    if (datosPreseleccionados?.supervisorReporta) {
      const match = RESPONSABLES_SST_OPCIONES.find(
        r => r.nombre === datosPreseleccionados.supervisorReporta || r.valor === datosPreseleccionados.supervisorReporta
      );
      if (match) return match.nombre;
      return datosPreseleccionados.supervisorReporta;
    }
    return 'Ing. Jhon Rojas';
  });
  const [cargoSupervisor, setCargoSupervisor] = useState<string>(() => {
    if (datosPreseleccionados?.supervisorReporta) {
      const match = RESPONSABLES_SST_OPCIONES.find(
        r => r.nombre === datosPreseleccionados.supervisorReporta || r.valor === datosPreseleccionados.supervisorReporta
      );
      if (match) return match.cargo;
    }
    return 'Supervisor SSOMA';
  });

  const handleCambiarSupervisor = (valor: string) => {
    setSupervisorSeleccionado(valor);
    const encontrado = RESPONSABLES_SST_OPCIONES.find(r => r.valor === valor);
    if (encontrado) {
      setSupervisorReporta(encontrado.nombre);
      setCargoSupervisor(encontrado.cargo);
    } else {
      const match = valor.match(/^(.*?)\s*\((.*?)\)$/);
      if (match) {
        setSupervisorReporta(match[1].trim());
        setCargoSupervisor(match[2].trim());
      } else {
        setSupervisorReporta(valor);
      }
    }
  };
  const [seNegoAFirmar, setSeNegoAFirmar] = useState<boolean>(false);
  const [testigoNombre, setTestigoNombre] = useState<string>('');
  const [testigoDni, setTestigoDni] = useState<string>('');
  const [firmaSupervisor, setFirmaSupervisor] = useState<string>('');
  const [firmaTrabajador, setFirmaTrabajador] = useState<string>('');
  const [observaciones, setObservaciones] = useState<string>('');
  const [guardando, setGuardando] = useState<boolean>(false);
  const [mensajeExito, setMensajeExito] = useState<string | null>(null);
  const [mensajeError, setMensajeError] = useState<string | null>(null);
  const [infraccionAEliminar, setInfraccionAEliminar] = useState<InfraccionEPP | null>(null);

  const plantillaActiva = useMemo(() => {
    return storageService.getPlantillaActivaParaInfraccion();
  }, []);

  const trabajadorSeleccionado = useMemo(() => {
    return trabajadores.find(t => t.codigo === codigoTrabajador);
  }, [trabajadores, codigoTrabajador]);

  useEffect(() => {
    if (datosPreseleccionados) {
      if (datosPreseleccionados.codigoTrabajador) {
        setCodigoTrabajador(datosPreseleccionados.codigoTrabajador);
      }
      if (datosPreseleccionados.eppsOmitidos && datosPreseleccionados.eppsOmitidos.length > 0) {
        setEppsOmitidos(datosPreseleccionados.eppsOmitidos);
      }
      if (datosPreseleccionados.lugarZona) {
        setLugarZona(datosPreseleccionados.lugarZona);
      }
      if (datosPreseleccionados.supervisorReporta) {
        const match = RESPONSABLES_SST_OPCIONES.find(
          r => r.nombre === datosPreseleccionados.supervisorReporta || r.valor === datosPreseleccionados.supervisorReporta
        );
        if (match) {
          setSupervisorSeleccionado(match.valor);
          setSupervisorReporta(match.nombre);
          setCargoSupervisor(match.cargo);
        } else {
          setSupervisorReporta(datosPreseleccionados.supervisorReporta);
        }
      }
      if (datosPreseleccionados.descripcionHechos) {
        setDescripcionHechos(datosPreseleccionados.descripcionHechos);
      }
      if (datosPreseleccionados.fechaHora) {
        setFechaHora(
          datosPreseleccionados.fechaHora.includes('T')
            ? datosPreseleccionados.fechaHora.slice(0, 16)
            : datosPreseleccionados.fechaHora.replace(' ', 'T').slice(0, 16)
        );
      }
      if (datosPreseleccionados.numeroInspeccionOrigen) {
        setOrigenInspeccion({
          id: datosPreseleccionados.idInspeccionOrigen,
          numero: datosPreseleccionados.numeroInspeccionOrigen
        });
      }
      setVistaActiva('nuevo');
    } else if (trabajadorPreseleccionado && trabajadorPreseleccionado !== codigoTrabajador) {
      setCodigoTrabajador(trabajadorPreseleccionado);
      setVistaActiva('nuevo');
    }
  }, [datosPreseleccionados, trabajadorPreseleccionado]);

  const listaCompletaEPP = useMemo(() => {
    const todos = [...LISTA_EPP_COMUNES];
    for (const item of eppsOmitidos) {
      if (!todos.includes(item)) {
        todos.unshift(item);
      }
    }
    return todos;
  }, [eppsOmitidos]);

  const infraccionesPrevias = useMemo(() => {
    if (!codigoTrabajador) return 0;
    return storageService.contarInfraccionesPorTrabajador(codigoTrabajador);
  }, [codigoTrabajador, infracciones]);

  const nivelReincidenciaCalculado: NivelReincidencia = useMemo(() => {
    if (infraccionesPrevias === 0) return 'Primera vez';
    if (infraccionesPrevias === 1) return 'Segunda vez (Reiterativa)';
    return 'Tercera vez o más (Grave)';
  }, [infraccionesPrevias]);

  const handleToggleEPP = (epp: string) => {
    if (eppsOmitidos.includes(epp)) {
      setEppsOmitidos(prev => prev.filter(e => e !== epp));
    } else {
      setEppsOmitidos(prev => [...prev, epp]);
    }
  };

  const handleAgregarOtroEPP = () => {
    if (otroEPP.trim() && !eppsOmitidos.includes(otroEPP.trim())) {
      setEppsOmitidos(prev => [...prev, otroEPP.trim()]);
      setOtroEPP('');
    }
  };

  const handleCambiarGravedad = (g: GravedadInfraccion) => {
    setGravedad(g);
    if (g === 'Leve') setTipoSancion('Amonestación Verbal');
    else if (g === 'Grave') setTipoSancion('Amonestación Escrita');
    else if (g === 'Muy Grave') setTipoSancion('Reporte a Recursos Humanos');
  };

  const handlePrevisualizarPDF = async () => {
    setMensajeError(null);
    if (!trabajadorSeleccionado) {
      setMensajeError('Seleccione el trabajador infractor para visualizar.');
      return;
    }
    if (eppsOmitidos.length === 0) {
      setMensajeError('Seleccione al menos un EPP omitido.');
      return;
    }

    setGenerandoPDF(true);
    try {
      const numBorrador = storageService.generarNuevoNumeroInfraccion();
      const borrador: InfraccionEPP = {
        id: storageService.generarNuevoIdInfraccion(),
        numeroReporte: numBorrador,
        codigoPlantilla: plantillaActiva?.codigo || 'FO-SST-INF-001',
        versionPlantilla: plantillaActiva?.version || '01',
        fechaHora,
        codigoTrabajador: trabajadorSeleccionado.codigo,
        dni: trabajadorSeleccionado.dni,
        trabajadorNombre: trabajadorSeleccionado.nombreCompleto,
        empresaId: trabajadorSeleccionado.empresaId,
        empresaNombre: trabajadorSeleccionado.empresaNombre,
        ruc: trabajadorSeleccionado.empresaId === 'EMP-PERPOL' ? '20392729977' : '20550842891',
        area: trabajadorSeleccionado.area,
        cargo: trabajadorSeleccionado.cargo,
        lugarZona,
        eppsOmitidos,
        gravedad,
        tipoSancion,
        reincidencia: nivelReincidenciaCalculado,
        descripcionHechos: descripcionHechos || 'Trabajador detectado sin el equipo de protección personal requerido.',
        justificacionTrabajador,
        medidaCorrectivaInmediata,
        supervisorReporta,
        cargoSupervisor,
        testigoNombre: seNegoAFirmar ? testigoNombre : undefined,
        testigoDni: seNegoAFirmar ? testigoDni : undefined,
        firmaTrabajador: seNegoAFirmar ? undefined : firmaTrabajador,
        firmaSupervisor,
        seNegoAFirmar,
        estado: 'Registrada',
        idInspeccionOrigen: origenInspeccion?.id,
        numeroInspeccionOrigen: origenInspeccion?.numero,
        fechaCreacion: new Date().toISOString(),
        observaciones
      };

      const result: PDFResult = await PDFGeneratorService.generarReporteInfraccionPDF(borrador, plantillaActiva);
      setPdfData({
        url: result.blobUrl,
        buffer: result.arrayBuffer,
        fileName: result.fileName
      });
      setModalPDFOpen(true);
    } catch (err: any) {
      console.error('Error al generar PDF de infracción:', err);
      setMensajeError('Error al generar PDF: ' + err.message);
    } finally {
      setGenerandoPDF(false);
    }
  };

  const handleGuardarInfraccion = async (e: React.FormEvent) => {
    e.preventDefault();
    setMensajeError(null);
    if (!trabajadorSeleccionado) {
      setMensajeError('Seleccione un trabajador infractor.');
      return;
    }
    if (eppsOmitidos.length === 0) {
      setMensajeError('Debe especificar al menos un EPP omitido o no portado.');
      return;
    }
    if (seNegoAFirmar && (!testigoNombre.trim() || !testigoDni.trim())) {
      setMensajeError('Si el trabajador se negó a firmar, es obligatorio registrar los datos del testigo presencial.');
      return;
    }

    setGuardando(true);
    try {
      const nuevoNum = storageService.generarNuevoNumeroInfraccion();
      const nuevoId = storageService.generarNuevoIdInfraccion();
      const ruc = trabajadorSeleccionado.empresaId === 'EMP-PERPOL' ? '20392729977' : '20550842891';

      const nuevaInfraccion: InfraccionEPP = {
        id: nuevoId,
        numeroReporte: nuevoNum,
        codigoPlantilla: plantillaActiva?.codigo || 'FO-SST-INF-001',
        versionPlantilla: plantillaActiva?.version || '01',
        fechaHora,
        codigoTrabajador: trabajadorSeleccionado.codigo,
        dni: trabajadorSeleccionado.dni,
        trabajadorNombre: trabajadorSeleccionado.nombreCompleto,
        empresaId: trabajadorSeleccionado.empresaId,
        empresaNombre: trabajadorSeleccionado.empresaNombre,
        ruc,
        area: trabajadorSeleccionado.area,
        cargo: trabajadorSeleccionado.cargo,
        lugarZona,
        eppsOmitidos,
        gravedad,
        tipoSancion,
        reincidencia: nivelReincidenciaCalculado,
        descripcionHechos: descripcionHechos || 'Incumplimiento en el uso de equipos de protección personal requeridos por matriz IPERC.',
        justificacionTrabajador,
        medidaCorrectivaInmediata,
        supervisorReporta,
        cargoSupervisor,
        testigoNombre: seNegoAFirmar ? testigoNombre : undefined,
        testigoDni: seNegoAFirmar ? testigoDni : undefined,
        firmaTrabajador: seNegoAFirmar ? undefined : firmaTrabajador,
        firmaSupervisor,
        seNegoAFirmar,
        estado: 'Registrada',
        idInspeccionOrigen: origenInspeccion?.id,
        numeroInspeccionOrigen: origenInspeccion?.numero,
        fechaCreacion: new Date().toISOString(),
        observaciones,
        pdfFileName: `REPORTE_INFRACCION_${nuevoNum}_${ruc}_${trabajadorSeleccionado.dni}_${fechaHora.slice(0, 10).replace(/-/g, '')}.pdf`
      };

      await storageService.registrarInfraccion(nuevaInfraccion);

      // Respaldo automático del reporte PDF en Google Drive
      const plantillaAsociada = storageService.getPlantillaPorCodigo(nuevaInfraccion.codigoPlantilla || 'FO-SST-INF-001') || storageService.getPlantillaActivaParaInfraccion();
      PDFGeneratorService.generarReporteInfraccionPDF(nuevaInfraccion, plantillaAsociada)
        .then(pdfRes => {
          if (pdfRes && pdfRes.blob) {
            googleDriveService.subirArchivo({
              nombreArchivo: pdfRes.fileName,
              mimeType: 'application/pdf',
              datosBlob: pdfRes.blob,
              subcarpeta: '04_Infracciones_Evidencias',
              claveIdentificador: nuevaInfraccion.numeroReporte,
              descripcion: `Reporte de Infracción y Sanción ${nuevaInfraccion.numeroReporte} - ${nuevaInfraccion.trabajadorNombre}`
            }).catch(e => console.info('Respaldo automático en Drive diferido:', e));
          }
        })
        .catch(e => console.warn('Generación de PDF de infracción para Drive:', e));

      setMensajeExito(`¡Reporte de infracción ${nuevoNum} registrado con éxito!`);
      onInfraccionGuardada();
      if (onLimpiarDatosPreseleccionados) onLimpiarDatosPreseleccionados();

      // Limpiar formulario
      setEppsOmitidos([]);
      setDescripcionHechos('');
      setJustificacionTrabajador('');
      setFirmaTrabajador('');
      setFirmaSupervisor('');
      setSeNegoAFirmar(false);
      setTestigoNombre('');
      setTestigoDni('');

      setTimeout(() => {
        setMensajeExito(null);
        setVistaActiva('lista');
      }, 2000);

    } catch (err: any) {
      console.error('Error al registrar infracción:', err);
      setMensajeError('Error: ' + err.message);
    } finally {
      setGuardando(false);
    }
  };

  const handleVerPDFExistente = async (inf: InfraccionEPP) => {
    setGenerandoPDF(true);
    setMensajeError(null);
    try {
      const plantillaAsociada = storageService.getPlantillaPorCodigo(inf.codigoPlantilla || 'FO-SST-INF-001') || storageService.getPlantillaActivaParaInfraccion();
      const result = await PDFGeneratorService.generarReporteInfraccionPDF(inf, plantillaAsociada);
      setPdfData({
        url: result.blobUrl,
        buffer: result.arrayBuffer,
        fileName: result.fileName
      });
      setModalPDFOpen(true);
    } catch (err: any) {
      setMensajeError('Error al generar PDF: ' + err.message);
    } finally {
      setGenerandoPDF(false);
    }
  };

  const infraccionesFiltradas = useMemo(() => {
    const lista = Array.isArray(infracciones) ? infracciones : [];
    return lista.filter(i => {
      if (!i) return false;
      if (empresaFiltro !== 'TODAS' && i.empresaId !== empresaFiltro) return false;
      if (filtroGravedad !== 'TODOS' && i.gravedad !== filtroGravedad) return false;
      if (filtroEstado !== 'TODOS' && i.estado !== filtroEstado) return false;

      if (busqueda.trim()) {
        const q = busqueda.toLowerCase();
        const matchRep = String(i.numeroReporte || '').toLowerCase().includes(q);
        const matchTrab = String(i.trabajadorNombre || '').toLowerCase().includes(q);
        const matchDni = String(i.dni || '').includes(q);
        const epps = Array.isArray(i.eppsOmitidos) ? i.eppsOmitidos : [];
        const matchEpp = epps.some(e => e && e.toLowerCase().includes(q));
        const matchZona = (i.lugarZona || '').toLowerCase().includes(q);
        if (!matchRep && !matchTrab && !matchDni && !matchEpp && !matchZona) return false;
      }

      return true;
    }).sort((a, b) => compararFechasDesc(a.fechaHora, b.fechaHora, a.numeroReporte, b.numeroReporte));
  }, [infracciones, empresaFiltro, filtroGravedad, filtroEstado, busqueda]);

  const kpis = useMemo(() => {
    const total = infraccionesFiltradas.length;
    const leves = infraccionesFiltradas.filter(i => i.gravedad === 'Leve').length;
    const graves = infraccionesFiltradas.filter(i => i.gravedad === 'Grave' || i.gravedad === 'Muy Grave').length;
    const reincidentes = infraccionesFiltradas.filter(i => i.reincidencia !== 'Primera vez').length;
    return { total, leves, graves, reincidentes };
  }, [infraccionesFiltradas]);

  return {
    vistaActiva,
    setVistaActiva,
    busqueda,
    setBusqueda,
    filtroGravedad,
    setFiltroGravedad,
    filtroEstado,
    setFiltroEstado,
    modalPDFOpen,
    setModalPDFOpen,
    pdfData,
    generandoPDF,
    origenInspeccion,
    setOrigenInspeccion,
    codigoTrabajador,
    setCodigoTrabajador,
    fechaHora,
    setFechaHora,
    lugarZona,
    setLugarZona,
    eppsOmitidos,
    setEppsOmitidos,
    otroEPP,
    setOtroEPP,
    gravedad,
    tipoSancion,
    setTipoSancion,
    descripcionHechos,
    setDescripcionHechos,
    justificacionTrabajador,
    setJustificacionTrabajador,
    medidaCorrectivaInmediata,
    setMedidaCorrectivaInmediata,
    supervisorSeleccionado,
    supervisorReporta,
    setSupervisorReporta,
    cargoSupervisor,
    setCargoSupervisor,
    handleCambiarSupervisor,
    seNegoAFirmar,
    setSeNegoAFirmar,
    testigoNombre,
    setTestigoNombre,
    testigoDni,
    setTestigoDni,
    firmaSupervisor,
    setFirmaSupervisor,
    firmaTrabajador,
    setFirmaTrabajador,
    observaciones,
    setObservaciones,
    guardando,
    mensajeExito,
    mensajeError,
    setMensajeError,
    infraccionAEliminar,
    setInfraccionAEliminar,
    plantillaActiva,
    trabajadorSeleccionado,
    listaCompletaEPP,
    infraccionesPrevias,
    nivelReincidenciaCalculado,
    handleToggleEPP,
    handleAgregarOtroEPP,
    handleCambiarGravedad,
    handlePrevisualizarPDF,
    handleGuardarInfraccion,
    handleVerPDFExistente,
    infraccionesFiltradas,
    kpis
  };
}
