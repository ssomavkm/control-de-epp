import React from 'react';
import { FileText, AlertTriangle, AlertOctagon, Users } from 'lucide-react';

export interface InfraccionesKPIs {
  total: number;
  leves: number;
  graves: number;
  reincidentes: number;
}

interface InfraccionesStatsProps {
  kpis: InfraccionesKPIs;
}

export const InfraccionesStats: React.FC<InfraccionesStatsProps> = ({ kpis }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 font-medium">Total Infracciones</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{kpis.total}</p>
          <span className="text-[11px] text-slate-400">Actas levantadas</span>
        </div>
        <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
          <FileText className="w-5 h-5" />
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 font-medium">Infracciones Leves</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">{kpis.leves}</p>
          <span className="text-[11px] text-slate-400">Amonestación verbal</span>
        </div>
        <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
          <AlertTriangle className="w-5 h-5" />
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 font-medium">Graves y Muy Graves</p>
          <p className="text-2xl font-bold text-rose-600 mt-1">{kpis.graves}</p>
          <span className="text-[11px] text-slate-400">Amonestación escrita</span>
        </div>
        <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
          <AlertOctagon className="w-5 h-5" />
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 font-medium">Casos de Reincidencia</p>
          <p className="text-2xl font-bold text-purple-600 mt-1">{kpis.reincidentes}</p>
          <span className="text-[11px] text-slate-400">Segunda falta o más</span>
        </div>
        <div className="w-10 h-10 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
          <Users className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};
