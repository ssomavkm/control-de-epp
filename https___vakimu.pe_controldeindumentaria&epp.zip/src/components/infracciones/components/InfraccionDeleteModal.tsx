import React from 'react';
import { Trash2 } from 'lucide-react';
import { InfraccionEPP } from '../../../types';

interface InfraccionDeleteModalProps {
  infraccionAEliminar: InfraccionEPP | null;
  onClose: () => void;
  onConfirmar: () => void;
}

export const InfraccionDeleteModal: React.FC<InfraccionDeleteModalProps> = ({
  infraccionAEliminar,
  onClose,
  onConfirmar
}) => {
  // Soporte para cerrar con tecla Escape
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (infraccionAEliminar) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [infraccionAEliminar, onClose]);

  if (!infraccionAEliminar) return null;

  return (
    <div 
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="titulo-eliminar-infraccion"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
    >
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4">
        <div className="flex items-center gap-3 text-rose-600">
          <div className="p-2.5 bg-rose-50 rounded-xl">
            <Trash2 className="w-6 h-6" />
          </div>
          <div>
            <h3 id="titulo-eliminar-infraccion" className="text-base font-bold text-slate-900">Eliminar Reporte de Infracción</h3>
            <p className="text-xs text-slate-500 font-mono">{infraccionAEliminar.numeroReporte}</p>
          </div>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          ¿Está seguro de que desea eliminar este reporte de infracción del trabajador <strong>{infraccionAEliminar.trabajadorNombre}</strong>? Esta acción no se puede deshacer.
        </p>
        <div className="flex items-center justify-end gap-2.5 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirmar}
            className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Confirmar Eliminación
          </button>
        </div>
      </div>
    </div>
  );
};
