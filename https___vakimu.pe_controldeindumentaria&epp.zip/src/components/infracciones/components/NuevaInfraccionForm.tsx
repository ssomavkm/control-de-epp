import React, { useState } from 'react';
import { AlertTriangle, UserX, Eye, CheckCircle2, Camera, Upload, X } from 'lucide-react';
import { 
  Trabajador, 
  GravedadInfraccion, 
  TipoSancionInfraccion, 
  NivelReincidencia,
  RESPONSABLES_SST_OPCIONES 
} from '../../../types';
import { SignaturePad } from '../../common/SignaturePad';
import { TrabajadorSearchAutocomplete } from '../../common/TrabajadorSearchAutocomplete';
import { ZonaPlantaAutocomplete } from '../../common/ZonaPlantaAutocomplete';
import { googleDriveService } from '../../../services/drive/googleDriveService';
import { DriveStorageService } from '../../../services/drive/driveStorageService';

interface NuevaInfraccionFormProps {
  origenInspeccion: { id?: string; numero?: string } | null;
  onLimpiarOrigen?: () => void;
  codigoTrabajador: string;
  setCodigoTrabajador: (c: string) => void;
  trabajadores: Trabajador[];
  empresaFiltro: string;
  trabajadorSeleccionado: Trabajador | undefined;
  fechaHora: string;
  setFechaHora: (f: string) => void;
  infraccionesPrevias: number;
  nivelReincidenciaCalculado: NivelReincidencia;
  lugarZona: string;
  setLugarZona: (l: string) => void;
  listaCompletaEPP: string[];
  eppsOmitidos: string[];
  handleToggleEPP: (epp: string) => void;
  otroEPP: string;
  setOtroEPP: (val: string) => void;
  handleAgregarOtroEPP: () => void;
  gravedad: GravedadInfraccion;
  handleCambiarGravedad: (g: GravedadInfraccion) => void;
  tipoSancion: TipoSancionInfraccion;
  setTipoSancion: (s: TipoSancionInfraccion) => void;
  descripcionHechos: string;
  setDescripcionHechos: (d: string) => void;
  justificacionTrabajador: string;
  setJustificacionTrabajador: (j: string) => void;
  medidaCorrectivaInmediata: string;
  setMedidaCorrectivaInmediata: (m: string) => void;
  supervisorReporta: string;
  cargoSupervisor: string;
  supervisorSeleccionado: string;
  onCambiarSupervisor: (val: string) => void;
  seNegoAFirmar: boolean;
  setSeNegoAFirmar: (val: boolean) => void;
  testigoNombre: string;
  setTestigoNombre: (t: string) => void;
  testigoDni: string;
  setTestigoDni: (d: string) => void;
  firmaTrabajador: string;
  setFirmaTrabajador: (f: string) => void;
  firmaSupervisor: string;
  setFirmaSupervisor: (f: string) => void;
  generandoPDF: boolean;
  guardando: boolean;
  onCancelar: () => void;
  onPrevisualizarPDF: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const NuevaInfraccionForm: React.FC<NuevaInfraccionFormProps> = ({
  origenInspeccion,
  onLimpiarOrigen,
  codigoTrabajador,
  setCodigoTrabajador,
  trabajadores,
  empresaFiltro,
  trabajadorSeleccionado,
  fechaHora,
  setFechaHora,
  infraccionesPrevias,
  nivelReincidenciaCalculado,
  lugarZona,
  setLugarZona,
  listaCompletaEPP,
  eppsOmitidos,
  handleToggleEPP,
  otroEPP,
  setOtroEPP,
  handleAgregarOtroEPP,
  gravedad,
  handleCambiarGravedad,
  tipoSancion,
  setTipoSancion,
  descripcionHechos,
  setDescripcionHechos,
  justificacionTrabajador,
  setJustificacionTrabajador,
  medidaCorrectivaInmediata,
  setMedidaCorrectivaInmediata,
  supervisorReporta,
  cargoSupervisor,
  supervisorSeleccionado,
  onCambiarSupervisor,
  seNegoAFirmar,
  setSeNegoAFirmar,
  testigoNombre,
  setTestigoNombre,
  testigoDni,
  setTestigoDni,
  firmaTrabajador,
  setFirmaTrabajador,
  firmaSupervisor,
  setFirmaSupervisor,
  generandoPDF,
  guardando,
  onCancelar,
  onPrevisualizarPDF,
  onSubmit
}) => {
  const [fotosEvidencia, setFotosEvidencia] = useState<string[]>([]);
  const [comprimiendoFotos, setComprimiendoFotos] = useState<boolean>(false);

  const handleSeleccionarFotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files).filter(f => f.type.startsWith('image/'));
    if (files.length === 0) return;

    setComprimiendoFotos(true);
    try {
      const nuevasFotos: string[] = [];
      for (const file of files) {
        // Redimensionar a máx 1200px y comprimir a JPEG 82% en Canvas HTML5 (~150KB en lugar de 8MB)
        const comp = await DriveStorageService.compressImage(file, {
          maxDimension: 1200,
          quality: 0.82
        });
        nuevasFotos.push(comp.dataUrl);
      }
      setFotosEvidencia(prev => [...prev, ...nuevasFotos].slice(0, 4));
    } catch (err) {
      console.warn('Error al comprimir fotos de evidencia:', err);
    } finally {
      setComprimiendoFotos(false);
    }
  };

  const handleEliminarFoto = (idx: number) => {
    setFotosEvidencia(prev => prev.filter((_, i) => i !== idx));
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (fotosEvidencia.length > 0) {
      fotosEvidencia.forEach((foto, i) => {
        const nom = `EVIDENCIA_INF_${codigoTrabajador || 'TRAB'}_${Date.now()}_${i + 1}.png`;
        googleDriveService.subirImagenBase64({
          base64Data: foto,
          nombreArchivo: nom,
          subcarpeta: '04_Infracciones_Evidencias',
          descripcion: `Evidencia fotográfica de infracción - ${trabajadorSeleccionado?.nombreCompleto || 'Trabajador'}`
        }).catch(err => console.info('Subida de foto a Drive diferida:', err));
      });
    }
    onSubmit(e);
  };

  return (
    <form onSubmit={handleFormSubmit} className="space-y-6">
      {/* Banner de datos heredados desde Inspección */}
      {origenInspeccion?.numero && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 flex items-start justify-between gap-3 text-amber-900 shadow-2xs">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs uppercase tracking-wider text-amber-900">
                  Infracción Heredada de Inspección EPP: <span className="font-mono text-amber-800 font-extrabold">{origenInspeccion.numero}</span>
                </span>
                <span className="text-[10px] bg-amber-200 text-amber-900 font-semibold px-2 py-0.5 rounded-full">
                  Detección: No Presentó EPP
                </span>
              </div>
              <p className="text-xs text-amber-800 mt-1">
                Se han cargado automáticamente los datos del trabajador, lugar de inspección, supervisor responsable y los equipos obligatorios que no fueron presentados. Revise y formalice el reporte correspondiente.
              </p>
            </div>
          </div>
          {onLimpiarOrigen && (
            <button
              type="button"
              onClick={onLimpiarOrigen}
              className="text-[11px] text-amber-700 hover:text-amber-950 font-medium underline shrink-0 cursor-pointer"
            >
              Limpiar vínculo
            </button>
          )}
        </div>
      )}

      {/* SECCIÓN 1: DATOS DEL TRABAJADOR Y LUGAR */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-800 text-xs font-bold flex items-center justify-center">
              1
            </span>
            <h2 className="text-sm font-bold text-slate-900">
              Datos del Trabajador Infractor y Hallazgo en Planta
            </h2>
          </div>
          <span className="text-xs text-slate-400">Identificación del trabajador observado</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <TrabajadorSearchAutocomplete
              trabajadores={trabajadores}
              valorSeleccionado={codigoTrabajador}
              onSeleccionar={(t) => setCodigoTrabajador(t ? t.codigo : '')}
              empresaFiltro={empresaFiltro}
              label="Trabajador Observado"
              required
              colorTheme="rose"
              placeholder="Escriba nombre, apellido o DNI..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Fecha y Hora de la Observación <span className="text-rose-500">*</span>
            </label>
            <input
              type="datetime-local"
              value={fechaHora}
              onChange={(e) => setFechaHora(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>
        </div>

        {/* Ficha de datos y cálculo de reincidencia */}
        {trabajadorSeleccionado && (
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Empresa Empleadora:</span>
                <span className="font-semibold text-slate-800">{trabajadorSeleccionado.empresaNombre}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">DNI:</span>
                <span className="font-semibold font-mono text-slate-800">{trabajadorSeleccionado.dni}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Área de Trabajo:</span>
                <span className="font-semibold text-slate-800">{trabajadorSeleccionado.area}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Puesto / Cargo:</span>
                <span className="font-semibold text-slate-800">{trabajadorSeleccionado.cargo}</span>
              </div>
            </div>

            {/* Banner de Reincidencia */}
            <div className={`p-3 rounded-lg flex items-center justify-between text-xs ${
              infraccionesPrevias === 0
                ? 'bg-blue-50 text-blue-800 border border-blue-200'
                : 'bg-rose-50 text-rose-800 border border-rose-300'
            }`}>
              <div className="flex items-center gap-2">
                <AlertTriangle className={`w-4 h-4 ${infraccionesPrevias === 0 ? 'text-blue-600' : 'text-rose-600'}`} />
                <span className="font-bold">
                  {infraccionesPrevias === 0
                    ? 'Primer reporte registrado para este trabajador.'
                    : `⚠️ Trabajador con antecedentes: Cuenta con ${infraccionesPrevias} infracción(es) previa(s).`}
                </span>
              </div>
              <span className="font-mono font-bold uppercase tracking-wider text-[11px]">
                Clasificación: {nivelReincidenciaCalculado}
              </span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <ZonaPlantaAutocomplete
            valor={lugarZona}
            onChange={setLugarZona}
            required
            colorTheme="rose"
            label="Lugar / Zona Exacta de la Planta Industrial"
            placeholder="Seleccione o busque una zona de la planta industrial..."
          />

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Responsable SST / Supervisor <span className="text-rose-500">*</span>
            </label>
            <select
              value={supervisorSeleccionado}
              onChange={(e) => onCambiarSupervisor(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 cursor-pointer"
            >
              {RESPONSABLES_SST_OPCIONES.map((opc) => (
                <option key={opc.valor} value={opc.valor}>
                  {opc.valor}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* SECCIÓN 2: EPPs OMITIDOS / NO PORTADOS */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-800 text-xs font-bold flex items-center justify-center">
            2
          </span>
          <h2 className="text-sm font-bold text-slate-900">
            Equipos de Protección Personal (EPP) Omitidos o No Portados
          </h2>
        </div>

        <p className="text-xs text-slate-500">
          Marque todos los equipos reglamentarios con los que el trabajador no contaba al momento de la intervención:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {listaCompletaEPP.map((epp, eppIdx) => {
            const isSelected = eppsOmitidos.includes(epp);
            return (
              <button
                key={`${epp}-${eppIdx}`}
                type="button"
                onClick={() => handleToggleEPP(epp)}
                className={`p-2.5 rounded-xl border text-xs text-left font-medium transition-colors flex items-center justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-rose-50 border-rose-300 text-rose-900 font-semibold shadow-2xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>{epp}</span>
                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] shrink-0 ml-2 ${
                  isSelected ? 'bg-rose-600 text-white' : 'border border-slate-300'
                }`}>
                  {isSelected ? '✓' : ''}
                </span>
              </button>
            );
          })}
        </div>

        {/* Agregar otro no listado */}
        <div className="flex items-center gap-2 pt-1">
          <input
            type="text"
            value={otroEPP}
            onChange={(e) => setOtroEPP(e.target.value)}
            placeholder="Especificar otro EPP no listado..."
            className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
          />
          <button
            type="button"
            onClick={handleAgregarOtroEPP}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
          >
            + Agregar
          </button>
        </div>
      </div>

      {/* SECCIÓN 3: TIPIFICACIÓN, DESCRIPCIÓN Y MEDIDA CORRECTIVA */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-800 text-xs font-bold flex items-center justify-center">
            3
          </span>
          <h2 className="text-sm font-bold text-slate-900">
            Clasificación de Gravedad, Hechos y Medidas Aplicadas
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nivel de Gravedad de la Infracción
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Leve', 'Grave', 'Muy Grave'] as GravedadInfraccion[]).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => handleCambiarGravedad(g)}
                  className={`py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    gravedad === g
                      ? g === 'Muy Grave'
                        ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                        : g === 'Grave'
                        ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                        : 'bg-amber-500 text-white border-amber-500 shadow-xs'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Medida Disciplinaria / Tipo de Sanción
            </label>
            <select
              value={tipoSancion}
              onChange={(e) => setTipoSancion(e.target.value as TipoSancionInfraccion)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
            >
              <option value="Amonestación Verbal">Amonestación Verbal</option>
              <option value="Amonestación Escrita">Amonestación Escrita (Memorándum)</option>
              <option value="Reporte a Recursos Humanos">Reporte Formal a RRHH / Legajo</option>
              <option value="Suspensión Temporal">Suspensión Temporal de Labores</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Descripción Detallada de los Hechos (Hallazgo del Inspector SST) <span className="text-rose-500">*</span>
          </label>
          <textarea
            rows={3}
            value={descripcionHechos}
            onChange={(e) => setDescripcionHechos(e.target.value)}
            required
            placeholder="Describa la labor que ejecutaba el trabajador, el riesgo inminente al que se exponía y cómo se intervino..."
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Manifestación o Descargo del Trabajador
            </label>
            <textarea
              rows={2}
              value={justificacionTrabajador}
              onChange={(e) => setJustificacionTrabajador(e.target.value)}
              placeholder="Declaración efectuada por el trabajador al momento de la intervención..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Medida Correctiva Inmediata Aplicada en Planta <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={2}
              value={medidaCorrectivaInmediata}
              onChange={(e) => setMedidaCorrectivaInmediata(e.target.value)}
              required
              placeholder="Acción correctiva obligatoria..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 3.5: EVIDENCIAS FOTOGRÁFICAS / RESPALDO EN DRIVE */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 text-xs font-bold flex items-center justify-center">
              <Camera className="w-3.5 h-3.5 text-blue-700" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Fotografías y Evidencias del Incidente
              </h2>
              <p className="text-xs text-slate-500">
                Adjunte imágenes para resguardar automáticamente en la subcarpeta <span className="font-mono text-blue-700">04_Infracciones_Evidencias</span> de Google Drive.
              </p>
            </div>
          </div>
          <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
            {fotosEvidencia.length}/4 fotos
          </span>
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition-colors border border-slate-300">
              <Upload className="w-4 h-4 text-slate-600" />
              <span>Adjuntar o tomar fotos</span>
              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleSeleccionarFotos}
              />
            </label>
            <span className="text-[11px] text-slate-500">
              JPG, PNG o WEBP (máx. 4 fotos).
            </span>
          </div>

          {fotosEvidencia.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {fotosEvidencia.map((foto, idx) => (
                <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-900 aspect-video shadow-xs">
                  <img src={foto} alt={`Evidencia ${idx + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => handleEliminarFoto(idx)}
                    className="absolute top-1.5 right-1.5 w-6 h-6 bg-rose-600 hover:bg-rose-700 text-white rounded-full flex items-center justify-center shadow-md transition-transform transform active:scale-90 cursor-pointer"
                    title="Eliminar foto"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                  <span className="absolute bottom-1 left-1.5 bg-black/60 text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                    Foto {idx + 1}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* SECCIÓN 4: FIRMAS DIGITALES Y CONSTANCIA DE NEGATIVA */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-800 text-xs font-bold flex items-center justify-center">
              4
            </span>
            <h2 className="text-sm font-bold text-slate-900">
              Notificación, Firmas y Constancia de Negativa
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Selector de Responsable SST / Supervisor */}
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-700 whitespace-nowrap">
                Responsable SST / Supervisor: <span className="text-rose-500">*</span>
              </label>
              <select
                value={supervisorSeleccionado}
                onChange={(e) => onCambiarSupervisor(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 cursor-pointer"
              >
                {RESPONSABLES_SST_OPCIONES.map((opc) => (
                  <option key={opc.valor} value={opc.valor}>
                    {opc.valor}
                  </option>
                ))}
              </select>
            </div>

            {/* Toggle de Negativa a firmar */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="checkNegativa"
                checked={seNegoAFirmar}
                onChange={(e) => setSeNegoAFirmar(e.target.checked)}
                className="w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500 cursor-pointer"
              />
              <label htmlFor="checkNegativa" className="text-xs font-bold text-rose-700 cursor-pointer">
                El trabajador se negó a firmar
              </label>
            </div>
          </div>
        </div>

        {/* Bloque de dos columnas: Col 1 Trabajador o Testigo / Col 2 Responsable SST Supervisor */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {seNegoAFirmar ? (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-rose-800 font-bold text-xs mb-1">
                  <UserX className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>Constancia de Testigo Presencial (Negativa a Firmar)</span>
                </div>
                <p className="text-[11px] text-rose-600 leading-relaxed">
                  Conforme al Reglamento Interno SST y Ley 29783, si el trabajador se rehúsa a suscribir el reporte, se valida con la acreditación de un testigo presencial.
                </p>
              </div>

              <div className="space-y-3 pt-1">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nombre Completo del Testigo Presencial <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={testigoNombre}
                    onChange={(e) => setTestigoNombre(e.target.value)}
                    required={seNegoAFirmar}
                    placeholder="Ej: Víctor Cárdenas Rojas"
                    className="w-full px-3 py-2 bg-white border border-rose-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    DNI del Testigo Presencial <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    maxLength={8}
                    value={testigoDni}
                    onChange={(e) => setTestigoDni(e.target.value)}
                    required={seNegoAFirmar}
                    placeholder="Ej: 43981245"
                    className="w-full px-3 py-2 bg-white border border-rose-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono"
                  />
                </div>
              </div>
            </div>
          ) : (
            <SignaturePad
              titulo="Firma del Trabajador Infractor (Notificado)"
              subtitulo="Firma digital de recepción de la amonestación"
              requerido={false}
              initialDataUrl={firmaTrabajador}
              onSave={setFirmaTrabajador}
              firmanteNombre={trabajadorSeleccionado?.nombreCompleto}
              firmanteCargo={trabajadorSeleccionado?.cargo}
              firmanteDni={trabajadorSeleccionado?.dni}
            />
          )}

          <SignaturePad
            titulo="Firma del Responsable SST / Supervisor"
            subtitulo={`Constatación técnica por: ${supervisorReporta} (${cargoSupervisor})`}
            requerido={false}
            initialDataUrl={firmaSupervisor}
            onSave={setFirmaSupervisor}
            firmanteNombre={supervisorReporta}
            firmanteCargo={cargoSupervisor}
          />
        </div>
      </div>

      {/* BOTONES DE ACCIÓN */}
      <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
        <button
          type="button"
          onClick={onCancelar}
          className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
        >
          Cancelar
        </button>

        <button
          type="button"
          onClick={onPrevisualizarPDF}
          disabled={generandoPDF || !trabajadorSeleccionado || eppsOmitidos.length === 0}
          className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
        >
          <Eye className="w-4 h-4" />
          <span>{generandoPDF ? 'Generando PDF...' : 'Previsualizar Acta Oficial'}</span>
        </button>

        <button
          type="submit"
          disabled={guardando || !trabajadorSeleccionado || eppsOmitidos.length === 0}
          className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{guardando ? 'Guardando...' : 'Emitir Reporte de Infracción'}</span>
        </button>
      </div>
    </form>
  );
};
