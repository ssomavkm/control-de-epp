import React, { useState, useMemo, useEffect } from 'react';
import { Calendar, FileText, Trash2, ShieldAlert, Eye } from 'lucide-react';
import { InfraccionEPP } from '../../../types';
import { TablePagination } from '../../common/TablePagination';

interface InfraccionesTableProps {
  infracciones: InfraccionEPP[];
  onVerPDF: (inf: InfraccionEPP) => void;
  onSolicitarEliminar: (inf: InfraccionEPP) => void;
}

export const InfraccionesTable: React.FC<InfraccionesTableProps> = ({
  infracciones,
  onVerPDF,
  onSolicitarEliminar
}) => {
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);
  const [infraccionDetalle, setInfraccionDetalle] = useState<InfraccionEPP | null>(null);

  // Resetear a página 1 cuando cambie la lista filtrada
  useEffect(() => {
    setPaginaActual(1);
  }, [infracciones.length]);

  const totalPaginas = Math.max(1, Math.ceil(infracciones.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;

  const infraccionesPaginadas = useMemo(() => {
    return infracciones.slice(indiceInicio, indiceInicio + porPagina);
  }, [infracciones, indiceInicio, porPagina]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs min-w-[850px]">
          <thead>
            <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold uppercase tracking-wider text-[11px]">
              <th className="py-3.5 px-4 w-40">Reporte / Fecha</th>
              <th className="py-3.5 px-4 min-w-[210px]">Trabajador Infractor</th>
              <th className="py-3.5 px-4 w-44">Empresa / Ubicación</th>
              <th className="py-3.5 px-4 min-w-[220px]">EPP(s) Omitido(s)</th>
              <th className="py-3.5 px-3 text-center w-28">Gravedad</th>
              <th className="py-3.5 px-3 text-center w-28">Reincidencia</th>
              <th className="py-3.5 px-4 min-w-[220px]">Medida / Sanción</th>
              <th className="py-3.5 px-4 text-center w-32">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800">
            {infracciones.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-14 text-center text-slate-500">
                  <div className="max-w-xs mx-auto space-y-2">
                    <ShieldAlert className="w-8 h-8 mx-auto text-slate-400 stroke-1" />
                    <p className="font-semibold text-slate-700 text-xs">No se encontraron reportes de infracción</p>
                    <p className="text-[11px] text-slate-500">Intenta con otros criterios de búsqueda o registra un nuevo reporte disciplinario.</p>
                  </div>
                </td>
              </tr>
            ) : (
              infraccionesPaginadas.map((item, idx) => {
                const isPerpol = item.empresaId === 'EMP-PERPOL';
                return (
                  <tr key={item.id ? `${item.id}-${idx}` : `inf-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-mono font-bold text-slate-900 block">{item.numeroReporte}</span>
                      {item.numeroInspeccionOrigen && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-100 text-amber-900 border border-amber-300 mt-0.5">
                          Origen: {item.numeroInspeccionOrigen}
                        </span>
                      )}
                      <span className="text-[11px] text-slate-600 font-medium flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        {item.fechaHora.replace('T', ' ')}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 block text-xs">{item.trabajadorNombre}</span>
                      <span className="text-[11px] text-slate-600 font-medium font-mono">DNI: {item.dni} · {item.cargo}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold mb-0.5 border ${
                        isPerpol ? 'bg-emerald-100 text-emerald-900 border-emerald-300' : 'bg-blue-100 text-blue-900 border-blue-300'
                      }`}>
                        {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
                      </span>
                      <span className="text-[11px] text-slate-700 font-medium block">{item.lugarZona}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="text-xs text-slate-800 font-medium leading-relaxed max-w-[280px]">
                        {Array.isArray(item.eppsOmitidos) && item.eppsOmitidos.length > 0
                          ? item.eppsOmitidos.join(', ')
                          : '—'}
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                        item.gravedad === 'Muy Grave'
                          ? 'bg-rose-100 text-rose-900 border-rose-300'
                          : item.gravedad === 'Grave'
                          ? 'bg-orange-100 text-orange-900 border-orange-300'
                          : 'bg-amber-100 text-amber-900 border-amber-300'
                      }`}>
                        {item.gravedad}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span className={`text-[11px] font-bold block ${
                        item.reincidencia === 'Primera vez' ? 'text-slate-700' : 'text-rose-700'
                      }`}>
                        {item.reincidencia}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 block text-xs">{item.tipoSancion}</span>
                      <span className="text-[11px] text-slate-600 block mt-0.5 leading-snug font-medium" title={item.medidaCorrectivaInmediata}>
                        {item.medidaCorrectivaInmediata}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setInfraccionDetalle(item)}
                          aria-label={`Ver desglose detallado de la infracción ${item.numeroReporte} de ${item.trabajadorNombre}`}
                          className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400"
                          title="Ver desglose detallado de la infracción"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onVerPDF(item)}
                          aria-label={`Ver y descargar acta oficial en PDF de ${item.trabajadorNombre}`}
                          className="p-1.5 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400"
                          title="Ver y descargar acta oficial en PDF"
                        >
                          <FileText className="w-4 h-4 text-rose-600" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onSolicitarEliminar(item)}
                          aria-label={`Eliminar reporte de infracción de ${item.trabajadorNombre}`}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                          title="Eliminar reporte"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Paginación idéntica al Padrón de Trabajadores */}
      <TablePagination
        totalRegistros={infracciones.length}
        paginaActual={paginaActual}
        setPaginaActual={setPaginaActual}
        porPagina={porPagina}
        setPorPagina={setPorPagina}
        nombreEntidadPlural="reportes de infracción"
      />

      {/* Modal: Desglose Detallado de Reporte de Infracción */}
      {infraccionDetalle && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-100">
          <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            {/* Encabezado del modal */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center font-bold">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <span>Desglose de Infracción: {infraccionDetalle.numeroReporte}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-800 border border-rose-200 font-mono">
                      {infraccionDetalle.codigoPlantilla || 'FO-SST-INF-001'}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    {infraccionDetalle.trabajadorNombre} • DNI {infraccionDetalle.dni} • Fecha: {infraccionDetalle.fechaHora.replace('T', ' ')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInfraccionDetalle(null)}
                className="w-8 h-8 rounded-lg hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
                title="Cerrar modal"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs">
              {/* Tarjetas resumen KPI */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Gravedad</span>
                  <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold mt-0.5 ${
                    infraccionDetalle.gravedad === 'Muy Grave'
                      ? 'bg-rose-100 text-rose-900 border border-rose-300'
                      : infraccionDetalle.gravedad === 'Grave'
                      ? 'bg-orange-100 text-orange-900 border border-orange-300'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}>
                    {infraccionDetalle.gravedad}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Reincidencia</span>
                  <span className={`font-bold block mt-0.5 ${
                    infraccionDetalle.reincidencia === 'Primera vez' ? 'text-slate-800' : 'text-rose-700'
                  }`}>
                    {infraccionDetalle.reincidencia}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Sanción Aplicada</span>
                  <span className="font-bold text-slate-800 block mt-0.5">
                    {infraccionDetalle.tipoSancion}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Estado</span>
                  <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200 mt-0.5">
                    {infraccionDetalle.estado}
                  </span>
                </div>
              </div>

              {/* Datos de Empresa, Ubicación y Puesto */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Empresa</span>
                    <span className="font-semibold text-slate-800 block">{infraccionDetalle.empresaNombre}</span>
                    <span className="text-slate-500 font-mono text-[10px] block">RUC: {infraccionDetalle.ruc}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Área / Cargo</span>
                    <span className="font-semibold text-slate-800 block">{infraccionDetalle.area}</span>
                    <span className="text-slate-500 text-[10px] block">{infraccionDetalle.cargo}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Lugar / Zona de Infracción</span>
                    <span className="font-semibold text-slate-800 block">{infraccionDetalle.lugarZona}</span>
                  </div>
                </div>

                {infraccionDetalle.numeroInspeccionOrigen && (
                  <div className="pt-2 border-t border-slate-200 flex items-center gap-1.5 text-amber-900 font-semibold text-[11px]">
                    <span className="px-1.5 py-0.5 rounded bg-amber-100 border border-amber-300 font-mono text-[10px]">
                      Origen: {infraccionDetalle.numeroInspeccionOrigen}
                    </span>
                    <span>Reporte disciplinario originado en una inspección periódica de seguridad.</span>
                  </div>
                )}
              </div>

              {/* EPPs Omitidos / No Portados */}
              <div>
                <h4 className="font-bold text-slate-800 mb-2 uppercase tracking-wider text-[11px]">
                  Equipos de Protección Personal Omitidos ({infraccionDetalle.eppsOmitidos?.length || 0})
                </h4>
                <div className="flex flex-wrap gap-2 p-3 bg-rose-50/50 rounded-xl border border-rose-100">
                  {(Array.isArray(infraccionDetalle.eppsOmitidos) ? infraccionDetalle.eppsOmitidos : []).map((epp, idx) => (
                    <span key={idx} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-100 text-rose-900 border border-rose-200 text-xs font-semibold">
                      <span className="text-rose-600 font-bold">✕</span> {epp}
                    </span>
                  ))}
                </div>
              </div>

              {/* Descripción de los Hechos */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Descripción Circunstanciada de los Hechos:
                </span>
                <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-700 leading-relaxed">
                  {infraccionDetalle.descripcionHechos}
                </p>
              </div>

              {/* Descargo / Justificación del Trabajador */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Descargo / Justificación del Trabajador:
                </span>
                <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-700 leading-relaxed italic">
                  {infraccionDetalle.justificacionTrabajador || 'El trabajador no presentó justificación verbal o escrita al momento de la intervención.'}
                </p>
              </div>

              {/* Medida Correctiva Inmediata */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  Medida Correctiva Inmediata Aplicada:
                </span>
                <p className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200 text-emerald-900 leading-relaxed font-medium">
                  {infraccionDetalle.medidaCorrectivaInmediata}
                </p>
              </div>

              {/* Supervisión y Notificación */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div>
                  <strong className="text-slate-800">Supervisor SST que reporta:</strong>
                  <p className="text-slate-600 mt-0.5">{infraccionDetalle.supervisorReporta} — {infraccionDetalle.cargoSupervisor}</p>
                </div>
                <div>
                  <strong className="text-slate-800">Estado de Notificación / Firma:</strong>
                  <div className="text-slate-600 mt-0.5">
                    {infraccionDetalle.seNegoAFirmar ? (
                      <span className="text-rose-700 font-bold">
                        Negativa a firmar (Testigo: {infraccionDetalle.testigoNombre || 'Registrado'} · DNI {infraccionDetalle.testigoDni || '-'})
                      </span>
                    ) : (
                      <span className="text-emerald-700 font-semibold">Notificado conforme / Firma registrada</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Evidencias fotográficas si existiesen */}
              {infraccionDetalle.evidenciasUrls && infraccionDetalle.evidenciasUrls.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Evidencias Fotográficas Adjuntas:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {infraccionDetalle.evidenciasUrls.map((url, i) => (
                      <img
                        key={i}
                        src={url}
                        alt={`Evidencia ${i + 1}`}
                        className="w-24 h-24 object-cover rounded-lg border border-slate-200 shadow-2xs"
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Botones de acción del modal */}
            <div className="p-4 border-t border-slate-100 flex items-center justify-end gap-2 bg-slate-50">
              <button
                type="button"
                onClick={() => {
                  onVerPDF(infraccionDetalle);
                  setInfraccionDetalle(null);
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors shadow-2xs"
              >
                <FileText className="w-4 h-4 text-rose-400" />
                <span>Ver y descargar acta oficial en PDF</span>
              </button>
              <button
                type="button"
                onClick={() => setInfraccionDetalle(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
