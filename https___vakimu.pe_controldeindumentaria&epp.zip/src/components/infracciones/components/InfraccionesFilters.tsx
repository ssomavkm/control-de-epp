import React from 'react';
import { ModuleFilterBar } from '../../common/ModuleFilterBar';

interface InfraccionesFiltersProps {
  busqueda: string;
  setBusqueda: (q: string) => void;
  filtroGravedad: string;
  setFiltroGravedad: (g: string) => void;
  filtroEstado: string;
  setFiltroEstado: (e: string) => void;
  totalFiltrados?: number;
}

export const InfraccionesFilters: React.FC<InfraccionesFiltersProps> = ({
  busqueda,
  setBusqueda,
  filtroGravedad,
  setFiltroGravedad,
  filtroEstado,
  setFiltroEstado,
  totalFiltrados
}) => {
  const hayFiltrosActivos = busqueda !== '' || filtroGravedad !== 'TODOS' || filtroEstado !== 'TODOS';

  return (
    <ModuleFilterBar
      busqueda={busqueda}
      onBusquedaChange={setBusqueda}
      placeholder="Buscar por trabajador, DNI, N° reporte, zona, EPP omitido..."
      totalResultados={totalFiltrados}
      etiquetaPlural="reportes de infracción"
      etiquetaSingular="reporte de infracción"
      hayFiltrosActivos={hayFiltrosActivos}
      onLimpiarFiltros={() => {
        setBusqueda('');
        setFiltroGravedad('TODOS');
        setFiltroEstado('TODOS');
      }}
    >
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-slate-500 font-medium">Gravedad:</span>
          <select
            value={filtroGravedad}
            onChange={(e) => setFiltroGravedad(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-rose-500 cursor-pointer"
          >
            <option value="TODOS">Todas las Gravedades</option>
            <option value="Leve">Leve</option>
            <option value="Grave">Grave</option>
            <option value="Muy Grave">Muy Grave</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-xs text-slate-500 font-medium">Estado:</span>
          <select
            value={filtroEstado}
            onChange={(e) => setFiltroEstado(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-rose-500 cursor-pointer"
          >
            <option value="TODOS">Todos</option>
            <option value="Registrada">Registrada</option>
            <option value="Enviada a RRHH">Enviada a RRHH</option>
            <option value="Cerrada">Cerrada</option>
          </select>
        </div>
      </div>
    </ModuleFilterBar>
  );
};
