import React from 'react';
import { FileCheck2, FileText, ReceiptText, AlertTriangle, Scale } from 'lucide-react';
import { ConteosTiposDocumento } from '../types';

interface DocumentosStatsProps {
  conteos: ConteosTiposDocumento;
}

export const DocumentosStats: React.FC<DocumentosStatsProps> = ({ conteos }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
          <FileCheck2 className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Actas Archivadas</p>
          <p className="text-xl font-bold text-slate-900 font-mono-numbers">{conteos.TODOS}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
          <FileText className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Entregas (050)</p>
          <p className="text-xl font-bold text-blue-800 font-mono-numbers">{conteos.ENTREGA}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
          <ReceiptText className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Descuentos (DES)</p>
          <p className="text-xl font-bold text-amber-800 font-mono-numbers">{conteos.DESCUENTO}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
          <AlertTriangle className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Infracciones (INF)</p>
          <p className="text-xl font-bold text-rose-800 font-mono-numbers">{conteos.INFRACCION}</p>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs flex items-center gap-3.5 col-span-2 sm:col-span-1">
        <div className="w-10 h-10 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
          <Scale className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">Liquidaciones (LIQ)</p>
          <p className="text-xl font-bold text-purple-800 font-mono-numbers">{conteos.LIQUIDACION}</p>
        </div>
      </div>
    </div>
  );
};
