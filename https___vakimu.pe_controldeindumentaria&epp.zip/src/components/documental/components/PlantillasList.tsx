import React from 'react';
import { ShieldCheck, Lock, Eye, Edit3, EyeOff } from 'lucide-react';
import { PlantillaFormato } from '../../../types';

interface PlantillasListProps {
  plantillas: PlantillaFormato[];
  pinAutenticado: boolean;
  onBloquearEdicion: () => void;
  onPrevisualizarPDF: (plantilla: PlantillaFormato, empresaId: 'EMP-PERPOL' | 'EMP-TR3') => void;
  onSolicitarEditar: (plantilla: PlantillaFormato) => void;
}

export const PlantillasList: React.FC<PlantillasListProps> = ({
  plantillas,
  pinAutenticado,
  onBloquearEdicion,
  onPrevisualizarPDF,
  onSolicitarEditar
}) => {
  const listaActiva = plantillas.filter(p => p.estado === 'Activa');

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <span>Formatos Oficiales Homologados (Ley 29783 / ISO 45001)</span>
            </h2>
            <p className="text-[11px] text-slate-400">
              Plantillas legales configurables con control de tipografía, logo, items y cláusulas inmutables
            </p>
          </div>
        </div>

        {/* Indicador y Switch de Seguridad PIN */}
        <div className="flex items-center gap-2">
          {pinAutenticado ? (
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200/90 rounded-xl px-3 py-1.5 text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-semibold text-emerald-800 text-[11px]">
                Modo Editor Activo
              </span>
              <button
                type="button"
                onClick={onBloquearEdicion}
                className="ml-1 px-2 py-1 hover:bg-emerald-100 rounded-lg text-emerald-700 hover:text-emerald-900 transition-colors cursor-pointer flex items-center gap-1 font-semibold text-[11px]"
                title="Bloquear edición de formatos"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Bloquear</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[11px] font-medium">Edición protegida con PIN</span>
            </div>
          )}
        </div>
      </div>

      {/* Tarjetas de plantillas con botón de corrección / edición */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 text-xs">
        {listaActiva.map((p, idx) => {
          const fuenteLabel = p.tipografia === 'times' ? 'Times New Roman' : p.tipografia === 'courier' ? 'Courier' : 'Helvetica';
          return (
            <div
              key={p.id ? `${p.id}-${idx}` : `plantilla-${idx}`}
              className="p-4 rounded-xl border border-slate-200/90 bg-slate-50/50 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between group shadow-2xs"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-800 shadow-2xs flex items-center gap-1.5">
                    <span 
                      className="w-2.5 h-2.5 rounded-full inline-block shrink-0" 
                      style={{ backgroundColor: p.colorPrimarioHex || '#166534' }}
                    />
                    {p.codigo} v{p.version}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
                    {p.estado}
                  </span>
                </div>
                <h4 className="font-semibold text-slate-900 mb-1 leading-snug">{p.nombre}</h4>
                <p className="text-slate-500 text-[11px] leading-relaxed mb-2.5 line-clamp-2">{p.descripcion}</p>

                <div className="grid grid-cols-2 gap-1.5 mb-2 text-[10px] text-slate-600 bg-slate-100/70 p-2 rounded-lg font-medium">
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase">Tipografía:</span>
                    <span className="font-mono font-semibold">{fuenteLabel}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase">Límite Ítems:</span>
                    <span className="font-mono font-semibold">{p.maxItemsPorPagina || 10} por hoja</span>
                  </div>
                </div>

                {/* Estado de logos independientes para PERPOL y TR3 */}
                <div className="flex flex-wrap items-center gap-1.5 mb-2.5 text-[10px]">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                    PERPOL: {p.logoPerpol ? 'Logo Oficial' : 'Estándar'}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                    TR3: {p.logoTr3 ? 'Logo Oficial' : 'Estándar'}
                  </span>
                </div>

                {/* Indicador de textos inhabilitados en la plantilla si los hay */}
                {(p.inhabilitarDeclaracionCompromiso || p.inhabilitarLemaPiePagina || p.inhabilitarTituloSistemaGestion || p.inhabilitarReferenciaNormativa || p.inhabilitarSubtituloMembrete) && (
                  <div className="flex flex-wrap items-center gap-1 mb-2.5 text-[9px]">
                    <span className="font-bold text-slate-500 uppercase flex items-center gap-0.5">
                      <EyeOff className="w-2.5 h-2.5 text-amber-600" />
                      <span>Omitidos:</span>
                    </span>
                    {p.inhabilitarTituloSistemaGestion && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        Sin Título Sistema
                      </span>
                    )}
                    {p.inhabilitarReferenciaNormativa && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        Sin Ref. Legal
                      </span>
                    )}
                    {p.inhabilitarDeclaracionCompromiso && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        Sin Cláusula
                      </span>
                    )}
                    {p.inhabilitarLemaPiePagina && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        Sin Lema
                      </span>
                    )}
                    {p.inhabilitarSubtituloMembrete && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        Sin Subtítulo
                      </span>
                    )}
                    {p.inhabilitarCargoResponsable && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        Sin Cargo
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-200/70 space-y-2">
                <div className="text-[10px] font-mono text-slate-400 flex items-center justify-between">
                  <span>Aprobado: {p.fechaAprobacion}</span>
                  <span>Formato A4</span>
                </div>

                {/* Botones de Previsualización Oficial en Blanco / Muestra */}
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => onPrevisualizarPDF(p, 'EMP-PERPOL')}
                    className="py-1 px-2 rounded-lg text-[10px] font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                    title="Vista previa con membrete de PERPOL"
                  >
                    <Eye className="w-3 h-3 text-emerald-600" />
                    <span>PDF PERPOL</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onPrevisualizarPDF(p, 'EMP-TR3')}
                    className="py-1 px-2 rounded-lg text-[10px] font-semibold bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                    title="Vista previa con membrete de TR3"
                  >
                    <Eye className="w-3 h-3 text-blue-600" />
                    <span>PDF TR3</span>
                  </button>
                </div>

                {/* Botón para Corregir / Configurar el Formato */}
                <button
                  type="button"
                  onClick={() => onSolicitarEditar(p)}
                  className={`w-full py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs ${
                    pinAutenticado
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {pinAutenticado ? (
                    <>
                      <Edit3 className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Editar Formato</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-3.5 h-3.5 text-slate-400" />
                      <span>Editar Formato</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
