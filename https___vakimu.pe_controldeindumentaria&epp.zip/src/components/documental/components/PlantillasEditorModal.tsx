import React, { useState, useRef } from 'react';
import {
  Edit3,
  X,
  FileCheck2,
  Image as ImageIcon,
  Type,
  ShieldCheck,
  Eye,
  EyeOff,
  Upload,
  Trash2,
  Check,
  QrCode,
  Save
} from 'lucide-react';
import { PlantillaFormato, TipoFuentePDF } from '../../../types';
import { useToast } from '../../../context/ToastContext';
import { LOGO_PERPOL_IDEAS_PNG, LOGO_TR3_ALIMENTOS_PNG } from '../../../data/assets/logos';

interface PlantillasEditorModalProps {
  isOpen: boolean;
  plantillaParaEditar: PlantillaFormato | null;
  onClose: () => void;
  onGuardar: (plantillaActualizada: PlantillaFormato) => void;
  onPrevisualizarPDF: (plantilla: PlantillaFormato, empresaId: 'EMP-PERPOL' | 'EMP-TR3') => void;
}

export const PlantillasEditorModal: React.FC<PlantillasEditorModalProps> = ({
  isOpen,
  plantillaParaEditar,
  onClose,
  onGuardar,
  onPrevisualizarPDF
}) => {
  const toast = useToast();
  const [tabEditor, setTabEditor] = useState<'general' | 'identidad' | 'tipografia' | 'legal'>('general');
  const [formEditPlantilla, setFormEditPlantilla] = useState<Partial<PlantillaFormato>>(() => {
    if (!plantillaParaEditar) return {};
    return {
      ...plantillaParaEditar,
      logoPerpol: plantillaParaEditar.logoPerpol || LOGO_PERPOL_IDEAS_PNG,
      logoTr3: plantillaParaEditar.logoTr3 || LOGO_TR3_ALIMENTOS_PNG,
      logoPersonalizado: plantillaParaEditar.logoPersonalizado,
      tipografia: plantillaParaEditar.tipografia || 'helvetica',
      maxItemsPorPagina: plantillaParaEditar.maxItemsPorPagina || 10,
      mostrarPreciosValores: plantillaParaEditar.mostrarPreciosValores !== false,
      mostrarColumnaTalla: plantillaParaEditar.mostrarColumnaTalla !== false,
      mostrarFechaRenovacion: plantillaParaEditar.mostrarFechaRenovacion !== false,
      mostrarCodigoQR: plantillaParaEditar.mostrarCodigoQR !== false,
      orientacionPagina: plantillaParaEditar.orientacionPagina || 'portrait',
      colorPrimarioHex: plantillaParaEditar.colorPrimarioHex || '#166534',
      textoSubtituloMembrete: plantillaParaEditar.textoSubtituloMembrete ?? '',
      tituloSistemaGestion: plantillaParaEditar.tituloSistemaGestion ?? '',
      referenciaNormativa: plantillaParaEditar.referenciaNormativa ?? '',
      inhabilitarTituloSistemaGestion: Boolean(plantillaParaEditar.inhabilitarTituloSistemaGestion),
      inhabilitarSubtituloMembrete: Boolean(plantillaParaEditar.inhabilitarSubtituloMembrete),
      inhabilitarReferenciaNormativa: Boolean(plantillaParaEditar.inhabilitarReferenciaNormativa),
      inhabilitarDeclaracionCompromiso: Boolean(plantillaParaEditar.inhabilitarDeclaracionCompromiso),
      inhabilitarLemaPiePagina: Boolean(plantillaParaEditar.inhabilitarLemaPiePagina),
      inhabilitarCargoResponsable: Boolean(plantillaParaEditar.inhabilitarCargoResponsable)
    };
  });

  const [empresaPrevisualizacionEncabezado, setEmpresaPrevisualizacionEncabezado] = useState<'EMP-PERPOL' | 'EMP-TR3'>('EMP-PERPOL');

  const fileInputPerpolRef = useRef<HTMLInputElement>(null);
  const fileInputTr3Ref = useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (plantillaParaEditar) {
      setFormEditPlantilla({
        ...plantillaParaEditar,
        logoPerpol: plantillaParaEditar.logoPerpol || LOGO_PERPOL_IDEAS_PNG,
        logoTr3: plantillaParaEditar.logoTr3 || LOGO_TR3_ALIMENTOS_PNG,
        logoPersonalizado: plantillaParaEditar.logoPersonalizado,
        tipografia: plantillaParaEditar.tipografia || 'helvetica',
        maxItemsPorPagina: plantillaParaEditar.maxItemsPorPagina || 10,
        mostrarPreciosValores: plantillaParaEditar.mostrarPreciosValores !== false,
        mostrarColumnaTalla: plantillaParaEditar.mostrarColumnaTalla !== false,
        mostrarFechaRenovacion: plantillaParaEditar.mostrarFechaRenovacion !== false,
        mostrarCodigoQR: plantillaParaEditar.mostrarCodigoQR !== false,
        orientacionPagina: plantillaParaEditar.orientacionPagina || 'portrait',
        colorPrimarioHex: plantillaParaEditar.colorPrimarioHex || '#166534',
        textoSubtituloMembrete: plantillaParaEditar.textoSubtituloMembrete ?? '',
        tituloSistemaGestion: plantillaParaEditar.tituloSistemaGestion ?? '',
        referenciaNormativa: plantillaParaEditar.referenciaNormativa ?? '',
        inhabilitarTituloSistemaGestion: Boolean(plantillaParaEditar.inhabilitarTituloSistemaGestion),
        inhabilitarSubtituloMembrete: Boolean(plantillaParaEditar.inhabilitarSubtituloMembrete),
        inhabilitarReferenciaNormativa: Boolean(plantillaParaEditar.inhabilitarReferenciaNormativa),
        inhabilitarDeclaracionCompromiso: Boolean(plantillaParaEditar.inhabilitarDeclaracionCompromiso),
        inhabilitarLemaPiePagina: Boolean(plantillaParaEditar.inhabilitarLemaPiePagina),
        inhabilitarCargoResponsable: Boolean(plantillaParaEditar.inhabilitarCargoResponsable)
      });
      setTabEditor('general');
    }
  }, [plantillaParaEditar]);

  if (!isOpen || !plantillaParaEditar) return null;

  const handleCargarLogoPerpol = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.show('Por favor seleccione un archivo de imagen válido para PERPOL (PNG, JPG o WEBP).', 'error');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.show('La imagen de logo no debe superar los 2 MB.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setFormEditPlantilla(prev => ({ ...prev, logoPerpol: dataUrl }));
      toast.show('Logo para PERPOL IDEAS S.A.C. cargado exitosamente.', 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleCargarLogoTr3 = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.show('Por favor seleccione un archivo de imagen válido para TR3 (PNG, JPG o WEBP).', 'error');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.show('La imagen de logo no debe superar los 2 MB.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setFormEditPlantilla(prev => ({ ...prev, logoTr3: dataUrl }));
      toast.show('Logo para TR3 ALIMENTOS S.A.C. cargado exitosamente.', 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleGuardarCambiosFormato = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formEditPlantilla.codigo) {
      toast.show('Error: Datos del formato incompletos.', 'error');
      return;
    }

    const plantillaActualizada: PlantillaFormato = {
      ...plantillaParaEditar,
      codigo: (formEditPlantilla.codigo || '').trim().toUpperCase(),
      version: (formEditPlantilla.version || '01').trim(),
      nombre: (formEditPlantilla.nombre || plantillaParaEditar.nombre).trim(),
      fechaAprobacion: (formEditPlantilla.fechaAprobacion || plantillaParaEditar.fechaAprobacion).trim(),
      estado: (formEditPlantilla.estado as 'Activa' | 'Histórica') || 'Activa',
      descripcion: (formEditPlantilla.descripcion || '').trim(),
      referenciaNormativa: (formEditPlantilla.referenciaNormativa || '').trim(),
      declaracionCompromiso: (formEditPlantilla.declaracionCompromiso || '').trim(),
      tipoDocumento: formEditPlantilla.tipoDocumento || plantillaParaEditar.tipoDocumento || 'Dotación',
      logoPerpol: formEditPlantilla.logoPerpol || LOGO_PERPOL_IDEAS_PNG,
      logoTr3: formEditPlantilla.logoTr3 || LOGO_TR3_ALIMENTOS_PNG,
      logoPersonalizado: formEditPlantilla.logoPersonalizado,
      textoSubtituloMembrete: (formEditPlantilla.textoSubtituloMembrete || '').trim(),
      colorPrimarioHex: formEditPlantilla.colorPrimarioHex || '#166534',
      tipografia: formEditPlantilla.tipografia || 'helvetica',
      tamanoFuenteBase: formEditPlantilla.tamanoFuenteBase || 'normal',
      maxItemsPorPagina: Number(formEditPlantilla.maxItemsPorPagina) || 10,
      mostrarPreciosValores: formEditPlantilla.mostrarPreciosValores !== false,
      mostrarColumnaTalla: formEditPlantilla.mostrarColumnaTalla !== false,
      mostrarFechaRenovacion: formEditPlantilla.mostrarFechaRenovacion !== false,
      mostrarCodigoQR: formEditPlantilla.mostrarCodigoQR !== false,
      orientacionPagina: formEditPlantilla.orientacionPagina || 'portrait',
      lemaPiePagina: (formEditPlantilla.lemaPiePagina || '').trim(),
      cargoResponsablePorDefecto: (formEditPlantilla.cargoResponsablePorDefecto || '').trim(),
      tituloSistemaGestion: (formEditPlantilla.tituloSistemaGestion || '').trim(),
      inhabilitarTituloSistemaGestion: Boolean(formEditPlantilla.inhabilitarTituloSistemaGestion),
      inhabilitarSubtituloMembrete: Boolean(formEditPlantilla.inhabilitarSubtituloMembrete),
      inhabilitarReferenciaNormativa: Boolean(formEditPlantilla.inhabilitarReferenciaNormativa),
      inhabilitarDeclaracionCompromiso: Boolean(formEditPlantilla.inhabilitarDeclaracionCompromiso),
      inhabilitarLemaPiePagina: Boolean(formEditPlantilla.inhabilitarLemaPiePagina),
      inhabilitarCargoResponsable: Boolean(formEditPlantilla.inhabilitarCargoResponsable)
    };

    onGuardar(plantillaActualizada);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-3xl w-full p-6 text-slate-900 my-6 space-y-5">
        {/* Header del Modal */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-200">
              <Edit3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Configuración Avanzada del Formato Oficial
              </h3>
              <p className="text-xs text-slate-500">
                Ajuste de código correlativo, identidad gráfica, tipografía, cantidad de ítems y marco legal
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pestañas de navegación interna del editor */}
        <div className="flex items-center gap-1.5 border-b border-slate-200 overflow-x-auto pb-1 text-xs">
          <button
            type="button"
            onClick={() => setTabEditor('general')}
            className={`px-3 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              tabEditor === 'general'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>1. General & Código</span>
          </button>
          <button
            type="button"
            onClick={() => setTabEditor('identidad')}
            className={`px-3 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              tabEditor === 'identidad'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>2. Logo & Colores</span>
          </button>
          <button
            type="button"
            onClick={() => setTabEditor('tipografia')}
            className={`px-3 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              tabEditor === 'tipografia'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Type className="w-3.5 h-3.5" />
            <span>3. Tipografía & Ítems</span>
          </button>
          <button
            type="button"
            onClick={() => setTabEditor('legal')}
            className={`px-3 py-2 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              tabEditor === 'legal'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>4. Marco Legal & Cláusulas</span>
          </button>
        </div>

        <form onSubmit={handleGuardarCambiosFormato} className="space-y-4 text-xs">
          {/* Pestaña 1: General & Código */}
          {tabEditor === 'general' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Código del Formato:
                  </label>
                  <input
                    type="text"
                    required
                    value={formEditPlantilla.codigo || ''}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, codigo: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:bg-white"
                    placeholder="FO-SST-GEN-050"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Versión Homologada:
                  </label>
                  <input
                    type="text"
                    required
                    value={formEditPlantilla.version || ''}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, version: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:bg-white"
                    placeholder="02"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Fecha de Aprobación:
                  </label>
                  <input
                    type="text"
                    required
                    value={formEditPlantilla.fechaAprobacion || ''}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, fechaAprobacion: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:bg-white"
                    placeholder="02/01/2026"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Título Superior del Encabezado (Sistema de Gestión):
                  </label>
                  <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] select-none bg-white px-2 py-0.5 rounded-lg border border-slate-200 shadow-2xs hover:bg-slate-50 transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(formEditPlantilla.inhabilitarTituloSistemaGestion)}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, inhabilitarTituloSistemaGestion: e.target.checked })}
                      className="w-3.5 h-3.5 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
                    />
                    <span className={formEditPlantilla.inhabilitarTituloSistemaGestion ? 'font-bold text-amber-700 flex items-center gap-1' : 'text-slate-600'}>
                      {formEditPlantilla.inhabilitarTituloSistemaGestion ? (
                        <>
                          <EyeOff className="w-3 h-3 text-amber-600" />
                          <span>Texto Inhabilitado en Formato</span>
                        </>
                      ) : (
                        <span>Inhabilitar este texto</span>
                      )}
                    </span>
                  </label>
                </div>

                <input
                  type="text"
                  disabled={Boolean(formEditPlantilla.inhabilitarTituloSistemaGestion)}
                  value={formEditPlantilla.tituloSistemaGestion || ''}
                  onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, tituloSistemaGestion: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg font-semibold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-all ${
                    formEditPlantilla.inhabilitarTituloSistemaGestion
                      ? 'bg-amber-50/70 border-amber-300 text-slate-400 italic line-through'
                      : 'bg-white border-slate-300'
                  }`}
                  placeholder="SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA"
                />

                {formEditPlantilla.inhabilitarTituloSistemaGestion ? (
                  <p className="text-[10px] text-amber-800 font-medium flex items-center gap-1">
                    <span>⚠️ Este texto está <strong>inhabilitado</strong>: la cabecera del formato no imprimirá la línea del sistema de gestión, centrando el título principal del documento.</span>
                  </p>
                ) : (
                  <p className="text-[10px] text-slate-500">
                    Aparece centrado en la fila superior del encabezado oficial (por defecto: <em>"SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA"</em> o el nombre de su sistema de gestión SGSST).
                  </p>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nombre Oficial del Formato:
                </label>
                <input
                  type="text"
                  required
                  value={formEditPlantilla.nombre || ''}
                  onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, nombre: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:bg-white"
                  placeholder="REGISTRO DE ENTREGA DE EQUIPOS DE PROTECCIÓN PERSONAL..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Estado del Formato:
                  </label>
                  <select
                    value={formEditPlantilla.estado || 'Activa'}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, estado: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value="Activa">Activa (Vigente en emisiones)</option>
                    <option value="Histórica">Histórica (Solo archivo)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Tipo de Operación SST:
                  </label>
                  <select
                    value={formEditPlantilla.tipoDocumento || 'Dotación'}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, tipoDocumento: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value="Dotación">Dotación y Entrega de EPP</option>
                    <option value="Descuento">Autorización de Descuento</option>
                    <option value="Disciplina">Infracción Disciplinaria</option>
                    <option value="Inspección">Inspección de Seguridad</option>
                    <option value="Liquidación">Liquidación de EPP por Cese</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Descripción y Control de Cambios:
                </label>
                <textarea
                  rows={2}
                  value={formEditPlantilla.descripcion || ''}
                  onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, descripcion: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:bg-white"
                  placeholder="Justificación del cambio de versión o especificaciones homologadas..."
                />
              </div>
            </div>
          )}

          {/* Pestaña 2: Identidad Visual & Logos Corporativos Homologados */}
          {tabEditor === 'identidad' && (
            <div className="space-y-5 animate-in fade-in">
              <div className="p-3.5 bg-slate-100/90 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Formatos Oficiales Homologados (Ley 29783 / ISO 45001)</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Conforme al marco legal de Seguridad y Salud en el Trabajo, debe definirse y subirse un logotipo específico para cada razón social: uno para <strong>PERPOL IDEAS S.A.C.</strong> y otro para <strong>TR3 ALIMENTOS S.A.C.</strong> El sistema aplicará automáticamente el logo correspondiente en cada formato, acta de entrega e inspección.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Logo PERPOL */}
                <div className="p-4 rounded-xl border-2 border-emerald-200 bg-emerald-50/30 space-y-3 relative">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-600"></div>
                      <span className="text-xs font-bold text-emerald-950 uppercase tracking-wide">
                        Logo PERPOL IDEAS S.A.C.
                      </span>
                    </div>
                    {formEditPlantilla.logoPerpol ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        Personalizado
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                        Estándar
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-slate-600">
                    RUC: 20392729977 • Razón social para pasteurización, envasado y quesos.
                  </p>

                    <div className="flex items-center gap-3">
                    <div className="w-32 h-20 rounded-xl border border-slate-300 bg-white flex items-center justify-center p-2 overflow-hidden shadow-2xs shrink-0">
                      {(formEditPlantilla.logoPerpol || LOGO_PERPOL_IDEAS_PNG) ? (
                        <img
                          src={formEditPlantilla.logoPerpol || LOGO_PERPOL_IDEAS_PNG}
                          alt="Logo PERPOL"
                          className="max-w-full max-h-full object-contain"
                        />
                      ) : (
                        <div className="text-center text-slate-500 text-[10px]">
                          <div className="font-extrabold text-emerald-800 text-xs">PERPOL</div>
                          <div className="text-[8px] text-slate-600">IDEAS S.A.C.</div>
                          <span className="text-[8px] text-slate-400 block mt-0.5">(Estándar)</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2 flex-1">
                      <input
                        type="file"
                        ref={fileInputPerpolRef}
                        accept="image/*"
                        onChange={handleCargarLogoPerpol}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputPerpolRef.current?.click()}
                        className="w-full px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Subir Logo PERPOL</span>
                      </button>

                      {formEditPlantilla.logoPerpol && (
                        <button
                          type="button"
                          onClick={() => setFormEditPlantilla(prev => ({ ...prev, logoPerpol: LOGO_PERPOL_IDEAS_PNG }))}
                          className="w-full text-[11px] text-rose-600 hover:text-rose-700 font-semibold flex items-center justify-center gap-1 cursor-pointer py-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Restablecer estándar</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Logo TR3 */}
                <div className="p-4 rounded-xl border-2 border-blue-200 bg-blue-50/30 space-y-3 relative">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-blue-600"></div>
                      <span className="text-xs font-bold text-blue-950 uppercase tracking-wide">
                        Logo TR3 ALIMENTOS S.A.C.
                      </span>
                    </div>
                    {formEditPlantilla.logoTr3 ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-300">
                        Personalizado
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                        Estándar
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-slate-600">
                    RUC: 20550842891 • Razón social para derivados lácteos y distribución.
                  </p>

                  <div className="flex items-center gap-3">
                    <div className="w-32 h-20 rounded-xl border border-slate-300 bg-white flex items-center justify-center p-2 overflow-hidden shadow-2xs shrink-0">
                      {(formEditPlantilla.logoTr3 || LOGO_TR3_ALIMENTOS_PNG) ? (
                        <img
                          src={formEditPlantilla.logoTr3 || LOGO_TR3_ALIMENTOS_PNG}
                          alt="Logo TR3"
                          className="max-w-full max-h-full object-contain"
                        />
                      ) : (
                        <div className="text-center text-slate-500 text-[10px]">
                          <div className="font-extrabold text-blue-800 text-xs">TR3</div>
                          <div className="text-[8px] text-slate-600">ALIMENTOS S.A.C.</div>
                          <span className="text-[8px] text-slate-400 block mt-0.5">(Estándar)</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2 flex-1">
                      <input
                        type="file"
                        ref={fileInputTr3Ref}
                        accept="image/*"
                        onChange={handleCargarLogoTr3}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputTr3Ref.current?.click()}
                        className="w-full px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Subir Logo TR3</span>
                      </button>

                      {formEditPlantilla.logoTr3 && (
                        <button
                          type="button"
                          onClick={() => setFormEditPlantilla(prev => ({ ...prev, logoTr3: LOGO_TR3_ALIMENTOS_PNG }))}
                          className="w-full text-[11px] text-rose-600 hover:text-rose-700 font-semibold flex items-center justify-center gap-1 cursor-pointer py-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Restablecer estándar</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Simulador de Encabezado ISO */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-slate-600" />
                    Simulador de Encabezado Oficial FO-SST-GEN-050
                  </span>
                  <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-[11px]">
                    <button
                      type="button"
                      onClick={() => setEmpresaPrevisualizacionEncabezado('EMP-PERPOL')}
                      className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                        empresaPrevisualizacionEncabezado === 'EMP-PERPOL'
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Ver PERPOL
                    </button>
                    <button
                      type="button"
                      onClick={() => setEmpresaPrevisualizacionEncabezado('EMP-TR3')}
                      className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                        empresaPrevisualizacionEncabezado === 'EMP-TR3'
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Ver TR3
                    </button>
                  </div>
                </div>

                <div className="border border-slate-300 rounded-lg overflow-hidden grid grid-cols-12 text-[10px] bg-slate-50">
                  <div className="col-span-3 border-r border-slate-300 p-2 flex flex-col items-center justify-center bg-white text-center min-h-[75px]">
                    {empresaPrevisualizacionEncabezado === 'EMP-PERPOL' ? (
                      (formEditPlantilla.logoPerpol || LOGO_PERPOL_IDEAS_PNG) ? (
                        <img src={formEditPlantilla.logoPerpol || LOGO_PERPOL_IDEAS_PNG} alt="Logo PERPOL" className="max-h-12 max-w-full object-contain" />
                      ) : (
                        <div>
                          <div className="font-extrabold text-emerald-800 text-xs">PERPOL</div>
                          <div className="text-[9px] text-slate-700 font-semibold">IDEAS S.A.C.</div>
                          {!formEditPlantilla.inhabilitarSubtituloMembrete && Boolean(formEditPlantilla.textoSubtituloMembrete?.trim()) && (
                            <div className="text-[8px] text-slate-400">{formEditPlantilla.textoSubtituloMembrete!.trim()}</div>
                          )}
                        </div>
                      )
                    ) : (
                      (formEditPlantilla.logoTr3 || LOGO_TR3_ALIMENTOS_PNG) ? (
                        <img src={formEditPlantilla.logoTr3 || LOGO_TR3_ALIMENTOS_PNG} alt="Logo TR3" className="max-h-12 max-w-full object-contain" />
                      ) : (
                        <div>
                          <div className="font-extrabold text-blue-800 text-xs">TR3</div>
                          <div className="text-[9px] text-slate-700 font-semibold">ALIMENTOS S.A.C.</div>
                          {!formEditPlantilla.inhabilitarSubtituloMembrete && Boolean(formEditPlantilla.textoSubtituloMembrete?.trim()) && (
                            <div className="text-[8px] text-slate-400">{formEditPlantilla.textoSubtituloMembrete!.trim()}</div>
                          )}
                        </div>
                      )
                    )}
                  </div>

                  <div className="col-span-6 border-r border-slate-300 p-2 flex flex-col items-center justify-center text-center bg-white">
                    {!formEditPlantilla.inhabilitarTituloSistemaGestion && Boolean(formEditPlantilla.tituloSistemaGestion?.trim()) && (
                      <div className="font-bold text-slate-900 text-[10px] tracking-tight">
                        {formEditPlantilla.tituloSistemaGestion!.trim()}
                      </div>
                    )}
                    <div 
                      className="font-extrabold text-[11px] my-0.5 line-clamp-2"
                      style={{ color: formEditPlantilla.colorPrimarioHex || '#166534' }}
                    >
                      {formEditPlantilla.nombre || 'REGISTRO DE ENTREGA DE EQUIPOS DE PROTECCIÓN PERSONAL (EPP)'}
                    </div>
                    {!formEditPlantilla.inhabilitarReferenciaNormativa && Boolean(formEditPlantilla.referenciaNormativa?.trim()) && (
                      <div className="text-[8px] text-slate-500">
                        {formEditPlantilla.referenciaNormativa!.trim()}
                      </div>
                    )}
                  </div>

                  <div className="col-span-3 bg-white text-[9px] divide-y divide-slate-200 flex flex-col justify-between">
                    <div className="p-1 px-2 flex justify-between">
                      <span className="font-bold text-slate-600">CÓDIGO:</span>
                      <span className="font-mono">{formEditPlantilla.codigo || 'FO-SST-GEN-050'}</span>
                    </div>
                    <div className="p-1 px-2 flex justify-between">
                      <span className="font-bold text-slate-600">VERSIÓN:</span>
                      <span className="font-mono">{formEditPlantilla.version || '02'}</span>
                    </div>
                    <div className="p-1 px-2 flex justify-between">
                      <span className="font-bold text-slate-600">F. EMISIÓN:</span>
                      <span className="font-mono">{formEditPlantilla.fechaAprobacion || '02/01/2026'}</span>
                    </div>
                    <div className="p-1 px-2 flex justify-between">
                      <span className="font-bold text-slate-600">PÁGINA:</span>
                      <span className="font-mono">1 de 1</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Subtítulo y selector de color */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                      Texto de Subtítulo / División de Planta:
                    </label>
                    <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] select-none bg-white px-2 py-0.5 rounded-lg border border-slate-200 shadow-2xs hover:bg-slate-50 transition-colors">
                      <input
                        type="checkbox"
                        checked={Boolean(formEditPlantilla.inhabilitarSubtituloMembrete)}
                        onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, inhabilitarSubtituloMembrete: e.target.checked })}
                        className="w-3.5 h-3.5 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
                      />
                      <span className={formEditPlantilla.inhabilitarSubtituloMembrete ? 'font-bold text-amber-700 flex items-center gap-1' : 'text-slate-600'}>
                        {formEditPlantilla.inhabilitarSubtituloMembrete ? (
                          <>
                            <EyeOff className="w-3 h-3 text-amber-600" />
                            <span>Subtítulo Inhabilitado</span>
                          </>
                        ) : (
                          <span>Inhabilitar subtítulo</span>
                        )}
                      </span>
                    </label>
                  </div>

                  <input
                    type="text"
                    disabled={Boolean(formEditPlantilla.inhabilitarSubtituloMembrete)}
                    value={formEditPlantilla.textoSubtituloMembrete || ''}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, textoSubtituloMembrete: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-all ${
                      formEditPlantilla.inhabilitarSubtituloMembrete
                        ? 'bg-amber-50/70 border-amber-300 text-slate-400 italic line-through'
                        : 'bg-white border-slate-300'
                    }`}
                    placeholder="DIVISIÓN INDUSTRIAL / SSOMA"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Color Primario de Cabeceras (HEX):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={formEditPlantilla.colorPrimarioHex || '#166534'}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, colorPrimarioHex: e.target.value })}
                      className="w-10 h-9 p-0.5 border border-slate-300 rounded-lg cursor-pointer bg-white"
                    />
                    <input
                      type="text"
                      value={formEditPlantilla.colorPrimarioHex || '#166534'}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, colorPrimarioHex: e.target.value })}
                      className="flex-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 uppercase"
                      placeholder="#166534"
                    />
                  </div>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    {[
                      { hex: '#166534', label: 'Verde SSOMA' },
                      { hex: '#1E40AF', label: 'Azul Marino' },
                      { hex: '#0F172A', label: 'Slate Oscuro' },
                      { hex: '#991B1B', label: 'Rojo Alerta' }
                    ].map((c) => (
                      <button
                        key={c.hex}
                        type="button"
                        onClick={() => setFormEditPlantilla({ ...formEditPlantilla, colorPrimarioHex: c.hex })}
                        className="px-2 py-0.5 rounded text-[10px] font-semibold text-white cursor-pointer shadow-2xs"
                        style={{ backgroundColor: c.hex }}
                      >
                        {c.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Pestaña 3: Tipografía & Ítems */}
          {tabEditor === 'tipografia' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Tipografía de Letra del Formato:
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { id: 'helvetica', nombre: 'Helvetica / Arial', desc: 'Estándar técnico industrial, limpio y moderno' },
                      { id: 'times', nombre: 'Times New Roman', desc: 'Estricto formal notarial y jurídico legal' },
                      { id: 'courier', nombre: 'Courier / Monospace', desc: 'Técnico mecanografiado de alta precisión' }
                    ].map((t) => {
                      const seleccionado = (formEditPlantilla.tipografia || 'helvetica') === t.id;
                      return (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setFormEditPlantilla({ ...formEditPlantilla, tipografia: t.id as TipoFuentePDF })}
                          className={`w-full p-2.5 rounded-xl border text-left flex items-start gap-2.5 transition-all cursor-pointer ${
                            seleccionado
                              ? 'border-emerald-500 bg-emerald-50/50 ring-1 ring-emerald-500/30'
                              : 'border-slate-200 bg-white hover:bg-slate-50'
                          }`}
                        >
                          <div className={`w-4 h-4 rounded-full mt-0.5 border flex items-center justify-center shrink-0 ${
                            seleccionado ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-slate-300'
                          }`}>
                            {seleccionado && <Check className="w-2.5 h-2.5" />}
                          </div>
                          <div>
                            <div className={`font-semibold text-xs ${seleccionado ? 'text-emerald-950 font-bold' : 'text-slate-800'}`}>
                              {t.nombre}
                            </div>
                            <div className="text-[11px] text-slate-500">{t.desc}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Número Máximo de Ítems por Hoja / Documento:
                    </label>
                    <select
                      value={formEditPlantilla.maxItemsPorPagina || 10}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, maxItemsPorPagina: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={5}>5 ítems por hoja (Alta holgura para firmas)</option>
                      <option value={8}>8 ítems por hoja (Recomendado estándar)</option>
                      <option value={10}>10 ítems por hoja (Formato completo)</option>
                      <option value={12}>12 ítems por hoja (Compacto / Múltiples EPP)</option>
                      <option value={15}>15 ítems por hoja (Máxima densidad)</option>
                    </select>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Controla cuándo el generador crea automáticamente una segunda hoja numerada (*Página 1 de 2*).
                    </p>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Orientación de Hoja:
                    </label>
                    <select
                      value={formEditPlantilla.orientacionPagina || 'portrait'}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, orientacionPagina: e.target.value as any })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value="portrait">Vertical (A4 Portrait - 210 x 297 mm)</option>
                      <option value="landscape">Horizontal (A4 Landscape - 297 x 210 mm)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Columnas opcionales */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 space-y-2.5">
                <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider block">
                  Columnas y Módulos Visibles en la Tabla de Ítems:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formEditPlantilla.mostrarPreciosValores !== false}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, mostrarPreciosValores: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                    />
                    <span className="text-slate-700 font-medium">Mostrar columna de Costo / Importe (S/.)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formEditPlantilla.mostrarColumnaTalla !== false}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, mostrarColumnaTalla: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                    />
                    <span className="text-slate-700 font-medium">Mostrar columna de Talla</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formEditPlantilla.mostrarFechaRenovacion !== false}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, mostrarFechaRenovacion: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                    />
                    <span className="text-slate-700 font-medium">Mostrar fecha de renovación estimada</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formEditPlantilla.mostrarCodigoQR !== false}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, mostrarCodigoQR: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                    />
                    <span className="text-slate-700 font-medium flex items-center gap-1">
                      <QrCode className="w-3.5 h-3.5 text-slate-500" />
                      <span>Código QR de verificación criptográfica</span>
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Pestaña 4: Marco Legal & Cláusulas */}
          {tabEditor === 'legal' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Referencia Legal y Normativa:
                  </label>
                  <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] select-none bg-white px-2 py-0.5 rounded-lg border border-slate-200 shadow-2xs hover:bg-slate-50 transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(formEditPlantilla.inhabilitarReferenciaNormativa)}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, inhabilitarReferenciaNormativa: e.target.checked })}
                      className="w-3.5 h-3.5 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
                    />
                    <span className={formEditPlantilla.inhabilitarReferenciaNormativa ? 'font-bold text-amber-700 flex items-center gap-1' : 'text-slate-600'}>
                      {formEditPlantilla.inhabilitarReferenciaNormativa ? (
                        <>
                          <EyeOff className="w-3 h-3 text-amber-600" />
                          <span>Texto Inhabilitado</span>
                        </>
                      ) : (
                        <span>Inhabilitar este texto</span>
                      )}
                    </span>
                  </label>
                </div>
                <input
                  type="text"
                  disabled={Boolean(formEditPlantilla.inhabilitarReferenciaNormativa)}
                  value={formEditPlantilla.referenciaNormativa || ''}
                  onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, referenciaNormativa: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-all ${
                    formEditPlantilla.inhabilitarReferenciaNormativa
                      ? 'bg-amber-50/70 border-amber-300 text-slate-400 italic line-through'
                      : 'bg-white border-slate-300'
                  }`}
                  placeholder="Conforme a la Ley N° 29783, D.S. N° 005-2012-TR y R.M. N° 050-2013-TR"
                />
                {formEditPlantilla.inhabilitarReferenciaNormativa ? (
                  <p className="text-[10px] text-amber-800 font-medium">
                    ⚠️ Referencia normativa <strong>inhabilitada</strong>: no se imprimirá la línea legal bajo el título oficial en el encabezado.
                  </p>
                ) : (
                  <p className="text-[10px] text-slate-500">
                    Aparece debajo del título del documento en el encabezado oficial de todos los formatos.
                  </p>
                )}
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Cláusula de Compromiso y Declaración Jurada (Pie de Documento):
                  </label>
                  <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] select-none bg-white px-2 py-0.5 rounded-lg border border-slate-200 shadow-2xs hover:bg-slate-50 transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(formEditPlantilla.inhabilitarDeclaracionCompromiso)}
                      onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, inhabilitarDeclaracionCompromiso: e.target.checked })}
                      className="w-3.5 h-3.5 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
                    />
                    <span className={formEditPlantilla.inhabilitarDeclaracionCompromiso ? 'font-bold text-amber-700 flex items-center gap-1' : 'text-slate-600'}>
                      {formEditPlantilla.inhabilitarDeclaracionCompromiso ? (
                        <>
                          <EyeOff className="w-3 h-3 text-amber-600" />
                          <span>Cláusula Inhabilitada</span>
                        </>
                      ) : (
                        <span>Inhabilitar este texto</span>
                      )}
                    </span>
                  </label>
                </div>
                <textarea
                  rows={4}
                  disabled={Boolean(formEditPlantilla.inhabilitarDeclaracionCompromiso)}
                  value={formEditPlantilla.declaracionCompromiso || ''}
                  onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, declaracionCompromiso: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 leading-relaxed transition-all ${
                    formEditPlantilla.inhabilitarDeclaracionCompromiso
                      ? 'bg-amber-50/70 border-amber-300 text-slate-400 italic line-through'
                      : 'bg-white border-slate-300'
                  }`}
                  placeholder="Texto formal suscrito por el trabajador con su firma..."
                />
                {formEditPlantilla.inhabilitarDeclaracionCompromiso ? (
                  <p className="text-[10px] text-amber-800 font-medium">
                    ⚠️ Cláusula de compromiso <strong>inhabilitada</strong>: no se imprimirá el recuadro de compromiso/declaración jurada en el PDF final.
                  </p>
                ) : (
                  <p className="text-[10px] text-slate-500">
                    Texto de compromiso suscrito por el trabajador en actas de entrega, autorizaciones de descuento o directivas de amonestación.
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                      Cargo Responsable Emisión:
                    </label>
                    <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] select-none bg-white px-2 py-0.5 rounded-lg border border-slate-200 shadow-2xs hover:bg-slate-50 transition-colors">
                      <input
                        type="checkbox"
                        checked={Boolean(formEditPlantilla.inhabilitarCargoResponsable)}
                        onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, inhabilitarCargoResponsable: e.target.checked })}
                        className="w-3.5 h-3.5 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
                      />
                      <span className={formEditPlantilla.inhabilitarCargoResponsable ? 'font-bold text-amber-700 flex items-center gap-1' : 'text-slate-600'}>
                        {formEditPlantilla.inhabilitarCargoResponsable ? (
                          <>
                            <EyeOff className="w-3 h-3 text-amber-600" />
                            <span>Inhabilitado</span>
                          </>
                        ) : (
                          <span>Inhabilitar</span>
                        )}
                      </span>
                    </label>
                  </div>
                  <input
                    type="text"
                    disabled={Boolean(formEditPlantilla.inhabilitarCargoResponsable)}
                    value={formEditPlantilla.cargoResponsablePorDefecto || ''}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, cargoResponsablePorDefecto: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-all ${
                      formEditPlantilla.inhabilitarCargoResponsable
                        ? 'bg-amber-50/70 border-amber-300 text-slate-400 italic line-through'
                        : 'bg-white border-slate-300'
                    }`}
                    placeholder="Jefe de Seguridad y Salud en el Trabajo (SSOMA)"
                  />
                  {formEditPlantilla.inhabilitarCargoResponsable && (
                    <p className="text-[10px] text-amber-800 font-medium">
                      ⚠️ Cargo inhabilitado: el casillero de firma no imprimirá cargo predeterminado.
                    </p>
                  )}
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                      Lema Institucional al Pie:
                    </label>
                    <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] select-none bg-white px-2 py-0.5 rounded-lg border border-slate-200 shadow-2xs hover:bg-slate-50 transition-colors">
                      <input
                        type="checkbox"
                        checked={Boolean(formEditPlantilla.inhabilitarLemaPiePagina)}
                        onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, inhabilitarLemaPiePagina: e.target.checked })}
                        className="w-3.5 h-3.5 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
                      />
                      <span className={formEditPlantilla.inhabilitarLemaPiePagina ? 'font-bold text-amber-700 flex items-center gap-1' : 'text-slate-600'}>
                        {formEditPlantilla.inhabilitarLemaPiePagina ? (
                          <>
                            <EyeOff className="w-3 h-3 text-amber-600" />
                            <span>Inhabilitado</span>
                          </>
                        ) : (
                          <span>Inhabilitar</span>
                        )}
                      </span>
                    </label>
                  </div>
                  <input
                    type="text"
                    disabled={Boolean(formEditPlantilla.inhabilitarLemaPiePagina)}
                    value={formEditPlantilla.lemaPiePagina || ''}
                    onChange={(e) => setFormEditPlantilla({ ...formEditPlantilla, lemaPiePagina: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-all ${
                      formEditPlantilla.inhabilitarLemaPiePagina
                        ? 'bg-amber-50/70 border-amber-300 text-slate-400 italic line-through'
                        : 'bg-white border-slate-300'
                    }`}
                    placeholder="La Seguridad y Salud en el Trabajo es Tarea de Todos"
                  />
                  {formEditPlantilla.inhabilitarLemaPiePagina && (
                    <p className="text-[10px] text-amber-800 font-medium">
                      ⚠️ Lema al pie inhabilitado: se omitirá la línea de lema en el pie de página de las hojas.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Botones de acción del Modal */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 pt-3 border-t border-slate-200">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-semibold text-slate-500 mr-1">Probar diseño:</span>
              <button
                type="button"
                onClick={() => onPrevisualizarPDF(formEditPlantilla as PlantillaFormato, 'EMP-PERPOL')}
                className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5 text-emerald-600" />
                <span>Muestra PERPOL</span>
              </button>
              <button
                type="button"
                onClick={() => onPrevisualizarPDF(formEditPlantilla as PlantillaFormato, 'EMP-TR3')}
                className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5 text-blue-600" />
                <span>Muestra TR3</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Guardar Cambios del Formato</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
