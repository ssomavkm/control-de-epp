import React from 'react';
import {
  Search,
  X,
  FilterX,
  RotateCcw,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { TablePagination } from '../../common/TablePagination';
import { DocumentoUnificado, TipoDocumentoFiltro, ConteosTiposDocumento } from '../types';
import { googleDriveService } from '../../../services/drive/googleDriveService';

interface DocumentosTableProps {
  busqueda: string;
  setBusqueda: (q: string) => void;
  filtroTipo: TipoDocumentoFiltro;
  setFiltroTipo: (tipo: TipoDocumentoFiltro) => void;
  conteosTipos: ConteosTiposDocumento;
  documentosFiltrados: DocumentoUnificado[];
  documentosPaginados: DocumentoUnificado[];
  paginaActual: number;
  setPaginaActual: React.Dispatch<React.SetStateAction<number>>;
  porPagina: number;
  setPorPagina: (n: number) => void;
  totalPaginas: number;
  indiceInicio: number;
  paginaAjustada: number;
  cargando: boolean;
  onAbrirDocumento: (doc: DocumentoUnificado) => void;
}

export const DocumentosTable: React.FC<DocumentosTableProps> = ({
  busqueda,
  setBusqueda,
  filtroTipo,
  setFiltroTipo,
  conteosTipos,
  documentosFiltrados,
  documentosPaginados,
  paginaActual,
  setPaginaActual,
  porPagina,
  setPorPagina,
  totalPaginas,
  indiceInicio,
  paginaAjustada,
  cargando,
  onAbrirDocumento
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden space-y-0">
      {/* Cabecera con Búsqueda y Chips de Tipo de Documento */}
      <div className="p-4 border-b border-slate-200 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Archivo Central de Actas Emitidas (Trazabilidad Inmutable)
            </h2>
            <p className="text-xs text-slate-500">
              Consulta y apertura de actas de entrega, autorizaciones de descuento, infracciones y actas de liquidación por cese
            </p>
          </div>

          {/* Búsqueda rápida */}
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar por N° acta, trabajador o DNI..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
            />
            {busqueda && (
              <button
                type="button"
                onClick={() => setBusqueda('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                title="Limpiar búsqueda"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Chips de filtro por tipo de documento */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1 hidden sm:inline">
              Filtrar Formato:
            </span>
            <div className="inline-flex items-center p-1 bg-slate-100/90 rounded-xl border border-slate-200/90 gap-1">
              {[
                { id: 'TODOS', label: 'Todos los Formatos', count: conteosTipos.TODOS },
                { id: 'ENTREGA', label: 'Entregas (FO-SST-GEN-050)', count: conteosTipos.ENTREGA },
                { id: 'DESCUENTO', label: 'Descuentos (FO-SST-DES-001)', count: conteosTipos.DESCUENTO },
                { id: 'INFRACCION', label: 'Infracciones (FO-SST-INF-001)', count: conteosTipos.INFRACCION },
                { id: 'LIQUIDACION', label: 'Liquidaciones (FO-SST-LIQ-001)', count: conteosTipos.LIQUIDACION }
              ].map((chip) => {
                const activo = filtroTipo === chip.id;
                return (
                  <button
                    key={chip.id}
                    type="button"
                    onClick={() => setFiltroTipo(chip.id as TipoDocumentoFiltro)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                      activo
                        ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                    }`}
                  >
                    <span>{chip.label}</span>
                    <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono leading-none ${
                      activo ? 'bg-slate-900 text-white font-bold' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {chip.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <span className="text-xs text-slate-500 font-mono-numbers">
            {documentosFiltrados.length === 1
              ? '1 acta encontrada'
              : `${documentosFiltrados.length} actas encontradas`}
          </span>
        </div>
      </div>

      {/* Tabla centralizada de actas */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs min-w-[950px]">
          <thead>
            <tr className="bg-slate-50/90 text-slate-700 border-b border-slate-200 font-bold text-[11px] uppercase tracking-wider">
              <th className="py-3.5 px-4 w-36">Fecha Emisión</th>
              <th className="py-3.5 px-3 w-40">Formato Oficial</th>
              <th className="py-3.5 px-3 w-36">N° Registro</th>
              <th className="py-3.5 px-4 min-w-[200px]">Trabajador</th>
              <th className="py-3.5 px-3 w-36">Empresa</th>
              <th className="py-3.5 px-3 min-w-[150px]">Responsable</th>
              <th className="py-3.5 px-3 text-center w-32">Estado</th>
              <th className="py-3.5 px-4 text-center w-28">Acción</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {documentosFiltrados.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-14 px-4 text-center">
                  <div className="max-w-md mx-auto space-y-3">
                    <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500">
                      <FilterX className="w-6 h-6 text-slate-500" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        No se encontraron actas en este archivo
                      </h4>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                        {busqueda || filtroTipo !== 'TODOS'
                          ? 'No hay actas que coincidan con los filtros seleccionados. Restablece la búsqueda para ver todas las actas archivadas.'
                          : 'Aún no se han emitido actas para esta razón social.'}
                      </p>
                    </div>
                    {(busqueda || filtroTipo !== 'TODOS') && (
                      <button
                        type="button"
                        onClick={() => {
                          setBusqueda('');
                          setFiltroTipo('TODOS');
                        }}
                        className="px-3.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-slate-600" />
                        Restablecer filtros
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              documentosPaginados.map((doc, idx) => {
                const isPerpol = doc.empresaId === 'EMP-PERPOL' || (Boolean(doc.empresaNombre) && doc.empresaNombre.toUpperCase().includes('PERPOL'));

                return (
                  <tr key={doc.id ? `${doc.id}-${idx}` : `doc-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-medium text-slate-800 whitespace-nowrap">
                      {doc.fechaHoraEmision || '-'}
                    </td>

                    <td className="py-3.5 px-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold font-mono border ${
                        doc.tipo === 'ENTREGA'
                          ? 'bg-blue-100 text-blue-900 border-blue-300'
                          : doc.tipo === 'DESCUENTO'
                          ? 'bg-amber-100 text-amber-900 border-amber-300'
                          : doc.tipo === 'INFRACCION'
                          ? 'bg-rose-100 text-rose-900 border-rose-300'
                          : 'bg-purple-100 text-purple-900 border-purple-300'
                      }`}>
                        {doc.formatoCodigo} v{doc.formatoVersion}
                      </span>
                      <div className="text-[11px] text-slate-600 font-medium truncate max-w-[140px] mt-0.5">
                        {doc.formatoNombre}
                      </div>
                    </td>

                    <td className="py-3.5 px-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                      {doc.numeroRegistro}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 tracking-tight">{doc.trabajador}</div>
                      <div className="text-[11px] font-mono font-medium text-slate-600 mt-0.5">DNI: {doc.dni || '-'}</div>
                    </td>

                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold border ${
                        isPerpol 
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-300' 
                          : 'bg-blue-100 text-blue-900 border-blue-300'
                      }`}>
                        {isPerpol ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS'}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-slate-700">
                      <div className="font-medium text-slate-800 text-[11px] truncate max-w-[140px]">
                        {doc.responsable || '-'}
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-center whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                        <span>{doc.estado}</span>
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onAbrirDocumento(doc)}
                          disabled={cargando}
                          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer disabled:opacity-50"
                          title="Abrir acta oficial en visor PDF para imprimir o descargar"
                        >
                          <FileText className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Ver PDF</span>
                        </button>

                        {(() => {
                          const vinculoDrive = googleDriveService.getVinculoGuardado(doc.numeroRegistro) || 
                            googleDriveService.getVinculoGuardado(doc.id) ||
                            googleDriveService.getVinculoGuardado(doc.idRef);
                          if (!vinculoDrive) return null;
                          return (
                            <a
                              href={vinculoDrive.webViewLink}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg inline-flex items-center transition-colors shadow-2xs"
                              title="Abrir este documento guardado en Google Drive"
                            >
                              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                                <path fill="#4285F4" d="M12.01 1.5L4.5 14.5h6l7.51-13h-6z" />
                                <path fill="#FBBC05" d="M4.5 14.5L1.5 19.5h15l3-5H4.5z" />
                                <path fill="#34A853" d="M22.5 19.5l-3-5-7.5 13h6l4.5-8z" />
                              </svg>
                            </a>
                          );
                        })()}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Paginación */}
      <TablePagination
        totalRegistros={documentosFiltrados.length}
        paginaActual={paginaActual}
        setPaginaActual={setPaginaActual}
        porPagina={porPagina}
        setPorPagina={setPorPagina}
        nombreEntidadPlural="actas y registros"
      />
    </div>
  );
};
