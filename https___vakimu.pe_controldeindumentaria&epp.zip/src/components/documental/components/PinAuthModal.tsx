import React, { useState } from 'react';
import { KeyRound, Unlock } from 'lucide-react';
import { useToast } from '../../../context/ToastContext';

interface PinAuthModalProps {
  isOpen: boolean;
  pinAutorizado?: string;
  onSuccess: () => void;
  onClose: () => void;
}

export const PinAuthModal: React.FC<PinAuthModalProps> = ({
  isOpen,
  pinAutorizado = '2295',
  onSuccess,
  onClose
}) => {
  const toast = useToast();
  const [pinInput, setPinInput] = useState<string>('');
  const [errorPin, setErrorPin] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleVerificarPin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pinInput === pinAutorizado) {
      try {
        sessionStorage.setItem('ssoma_pin_control_doc', 'true');
      } catch {}
      setErrorPin(null);
      setPinInput('');
      toast.show('Acceso autorizado para edición de formatos.', 'success');
      onSuccess();
    } else {
      setErrorPin('PIN incorrecto. Ingrese el código de 4 dígitos de seguridad.');
      setPinInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-sm w-full p-6 text-slate-900 space-y-4">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center border border-slate-200 shadow-2xs">
            <KeyRound className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-base text-slate-900">
            Acceso Restringido - Control Documental
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Ingrese el PIN de seguridad de 4 dígitos para editar la configuración de los formatos oficiales.
          </p>
        </div>

        {errorPin && (
          <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 text-center font-medium animate-in shake">
            {errorPin}
          </div>
        )}

        <form onSubmit={handleVerificarPin} className="space-y-4">
          <div>
            <input
              type="password"
              maxLength={4}
              autoFocus
              placeholder="••••"
              value={pinInput}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                setPinInput(val);
                if (errorPin) setErrorPin(null);
                if (val.length === 4 && val === pinAutorizado) {
                  try {
                    sessionStorage.setItem('ssoma_pin_control_doc', 'true');
                  } catch {}
                  setErrorPin(null);
                  setPinInput('');
                  toast.show('Acceso autorizado.', 'success');
                  onSuccess();
                }
              }}
              className="w-full text-center tracking-[0.6em] font-mono font-bold text-2xl py-3 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all shadow-2xs"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setErrorPin(null);
                setPinInput('');
                onClose();
              }}
              className="flex-1 py-2.5 px-3 border border-slate-200 text-slate-700 hover:bg-slate-100 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={pinInput.length < 4}
              className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>Desbloquear</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
