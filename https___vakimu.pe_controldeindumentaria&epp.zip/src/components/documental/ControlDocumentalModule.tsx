import React from 'react';
import { X } from 'lucide-react';
import { PlantillaFormato, DocumentoEmitido, EntregaEPP, DescuentoEPP, InfraccionEPP, LiquidacionEPP } from '../../types';
import { PDFViewerModal } from '../common/PDFViewerModal';
import { DocumentosStats } from './components/DocumentosStats';
import { PlantillasList } from './components/PlantillasList';
import { DocumentosTable } from './components/DocumentosTable';
import { PinAuthModal } from './components/PinAuthModal';
import { PlantillasEditorModal } from './components/PlantillasEditorModal';
import { useDocumental } from './hooks/useDocumental';

export * from './types';

interface ControlDocumentalModuleProps {
  plantillas?: PlantillaFormato[];
  documentos?: DocumentoEmitido[];
  entregas?: EntregaEPP[];
  descuentos?: DescuentoEPP[];
  infracciones?: InfraccionEPP[];
  liquidaciones?: LiquidacionEPP[];
  empresaFiltro?: string;
  onGuardarPlantilla?: (plantilla: PlantillaFormato) => void;
}

export const ControlDocumentalModule: React.FC<ControlDocumentalModuleProps> = ({
  plantillas = [],
  documentos = [],
  entregas = [],
  descuentos = [],
  infracciones = [],
  liquidaciones = [],
  empresaFiltro = 'TODAS',
  onGuardarPlantilla
}) => {
  const {
    busqueda,
    setBusqueda,
    filtroTipo,
    setFiltroTipo,
    paginaActual,
    setPaginaActual,
    porPagina,
    setPorPagina,
    viewerUrl,
    setViewerUrl,
    viewerArrayBuffer,
    viewerFileName,
    viewerTitulo,
    cargando,
    errorDoc,
    setErrorDoc,
    pinAutenticado,
    modalPinAbierto,
    setModalPinAbierto,
    plantillaParaEditar,
    modalEditorAbierto,
    setModalEditorAbierto,
    conteosTipos,
    documentosFiltrados,
    totalPaginas,
    paginaAjustada,
    indiceInicio,
    documentosPaginados,
    abrirDocumentoHistorico,
    handleSolicitarEditarPlantilla,
    handlePinSuccess,
    handleBloquearEdicion,
    handlePrevisualizarPlantillaPDF,
    handleGuardarPlantilla,
    PIN_AUTORIZADO
  } = useDocumental({
    plantillas,
    documentos,
    entregas,
    descuentos,
    infracciones,
    liquidaciones,
    empresaFiltro,
    onGuardarPlantilla
  });

  return (
    <div className="space-y-6">
      {/* Alerta de error no intrusiva */}
      {errorDoc && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="font-bold">Aviso del Sistema:</span>
            <span>{errorDoc}</span>
          </div>
          <button
            onClick={() => setErrorDoc(null)}
            className="p-1 hover:bg-rose-100 rounded-lg text-rose-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Tarjetas KPI de Resumen Documental */}
      <DocumentosStats conteos={conteosTipos} />

      {/* Bloque 1: Formatos Oficiales Homologados */}
      <PlantillasList
        plantillas={plantillas}
        pinAutenticado={pinAutenticado}
        onBloquearEdicion={handleBloquearEdicion}
        onPrevisualizarPDF={handlePrevisualizarPlantillaPDF}
        onSolicitarEditar={handleSolicitarEditarPlantilla}
      />

      {/* Bloque 2: Repositorio Central de Documentos Emitidos */}
      <DocumentosTable
        busqueda={busqueda}
        setBusqueda={setBusqueda}
        filtroTipo={filtroTipo}
        setFiltroTipo={setFiltroTipo}
        conteosTipos={conteosTipos}
        documentosFiltrados={documentosFiltrados}
        documentosPaginados={documentosPaginados}
        paginaActual={paginaActual}
        setPaginaActual={setPaginaActual}
        porPagina={porPagina}
        setPorPagina={setPorPagina}
        totalPaginas={totalPaginas}
        indiceInicio={indiceInicio}
        paginaAjustada={paginaAjustada}
        cargando={cargando}
        onAbrirDocumento={abrirDocumentoHistorico}
      />

      {/* Modal 1: Autenticación por PIN */}
      <PinAuthModal
        isOpen={modalPinAbierto}
        pinAutorizado={PIN_AUTORIZADO}
        onSuccess={handlePinSuccess}
        onClose={() => setModalPinAbierto(false)}
      />

      {/* Modal 2: Editor Avanzado de Formato Oficial */}
      <PlantillasEditorModal
        isOpen={modalEditorAbierto}
        plantillaParaEditar={plantillaParaEditar}
        onClose={() => setModalEditorAbierto(false)}
        onGuardar={handleGuardarPlantilla}
        onPrevisualizarPDF={handlePrevisualizarPlantillaPDF}
      />

      {/* Modal Visor Universal de Actas Oficiales */}
      <PDFViewerModal
        isOpen={Boolean(viewerUrl)}
        onClose={() => setViewerUrl(null)}
        pdfBlobUrl={viewerUrl}
        pdfArrayBuffer={viewerArrayBuffer}
        fileName={viewerFileName}
        titulo={viewerTitulo || 'Archivo Histórico Oficial'}
        esBorrador={false}
      />
    </div>
  );
};
