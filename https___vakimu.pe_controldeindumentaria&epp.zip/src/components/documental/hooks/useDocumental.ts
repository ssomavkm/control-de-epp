import { useState, useMemo, useEffect } from 'react';
import { PlantillaFormato, DocumentoEmitido, EntregaEPP, DescuentoEPP, InfraccionEPP, LiquidacionEPP } from '../../../types';
import { DocumentoUnificado, TipoDocumentoFiltro, ConteosTiposDocumento } from '../types';
import { PDFGeneratorService } from '../../../services/pdfGenerator';
import { useToast } from '../../../context/ToastContext';

const PIN_AUTORIZADO = '2295';

interface UseDocumentalProps {
  plantillas?: PlantillaFormato[];
  documentos?: DocumentoEmitido[];
  entregas?: EntregaEPP[];
  descuentos?: DescuentoEPP[];
  infracciones?: InfraccionEPP[];
  liquidaciones?: LiquidacionEPP[];
  empresaFiltro?: string;
  onGuardarPlantilla?: (plantilla: PlantillaFormato) => void;
}

export function useDocumental({
  plantillas = [],
  entregas = [],
  descuentos = [],
  infracciones = [],
  liquidaciones = [],
  empresaFiltro = 'TODAS',
  onGuardarPlantilla
}: UseDocumentalProps) {
  const toast = useToast();

  const [busqueda, setBusqueda] = useState<string>('');
  const [filtroTipo, setFiltroTipo] = useState<TipoDocumentoFiltro>('TODOS');
  
  // Paginación
  const [paginaActual, setPaginaActual] = useState<number>(1);
  const [porPagina, setPorPagina] = useState<number>(10);

  // Visor PDF
  const [viewerUrl, setViewerUrl] = useState<string | null>(null);
  const [viewerArrayBuffer, setViewerArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [viewerFileName, setViewerFileName] = useState<string>('');
  const [viewerTitulo, setViewerTitulo] = useState<string>('');
  const [cargando, setCargando] = useState<boolean>(false);
  const [errorDoc, setErrorDoc] = useState<string | null>(null);

  // Estado de Seguridad PIN
  const [pinAutenticado, setPinAutenticado] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('ssoma_pin_control_doc') === 'true';
    } catch {
      return false;
    }
  });
  const [modalPinAbierto, setModalPinAbierto] = useState<boolean>(false);
  const [plantillaParaEditar, setPlantillaParaEditar] = useState<PlantillaFormato | null>(null);
  const [modalEditorAbierto, setModalEditorAbierto] = useState<boolean>(false);

  // Resetear paginación al cambiar filtros
  useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, filtroTipo, empresaFiltro, porPagina]);

  // Consolidación de documentos
  const todosLosDocumentos = useMemo<DocumentoUnificado[]>(() => {
    const lista: DocumentoUnificado[] = [];

    // 1. Actas de Entrega de EPP (FO-SST-GEN-050)
    if (Array.isArray(entregas)) {
      entregas.forEach((e) => {
        if (!e) return;
        const nombreEmpresa = e.razonSocial || (e.empresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.');
        lista.push({
          id: `ENT_${e.id || e.numeroRegistro || Math.random().toString()}`,
          tipo: 'ENTREGA',
          formatoCodigo: e.codigoPlantilla || 'FO-SST-GEN-050',
          formatoVersion: e.versionPlantilla || '02',
          formatoNombre: 'Entrega y Dotación de EPP',
          numeroRegistro: e.numeroRegistro || 'REG-S/N',
          fechaHoraEmision: e.fechaEntrega || '',
          trabajador: e.trabajadorNombre || 'Sin asignar',
          dni: e.dni || '',
          empresaId: e.empresaId || 'EMP-PERPOL',
          empresaNombre: nombreEmpresa,
          responsable: e.responsableEntrega || 'Responsable SSOMA',
          estado: e.estado === 'Confirmada' ? 'Firmado / Conforme' : 'Borrador',
          idRef: e.id || e.numeroRegistro
        });
      });
    }

    // 2. Autorizaciones de Descuento por Pérdida (FO-SST-DES-001)
    if (Array.isArray(descuentos)) {
      descuentos.forEach((d) => {
        if (!d) return;
        const nombreEmpresa = d.empresaNombre || (d.empresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.');
        lista.push({
          id: `DESC_${d.id || d.numeroRegistro || Math.random().toString()}`,
          tipo: 'DESCUENTO',
          formatoCodigo: d.codigoPlantilla || 'FO-SST-DES-001',
          formatoVersion: d.versionPlantilla || '01',
          formatoNombre: 'Autorización de Descuento por Pérdida',
          numeroRegistro: d.numeroRegistro || 'AUT-S/N',
          fechaHoraEmision: d.fechaSolicitud || d.fechaIncidente || '',
          trabajador: d.trabajadorNombre || 'Sin asignar',
          dni: d.dni || '',
          empresaId: d.empresaId || 'EMP-PERPOL',
          empresaNombre: nombreEmpresa,
          responsable: d.responsableNombre || 'Jefatura SSOMA',
          estado: d.estado || 'Autorizado',
          idRef: d.id || d.numeroRegistro
        });
      });
    }

    // 3. Reportes de Infracción y Sanción Disciplinaria (FO-SST-INF-001)
    if (Array.isArray(infracciones)) {
      infracciones.forEach((inf) => {
        if (!inf) return;
        const nombreEmpresa = inf.empresaNombre || (inf.empresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.');
        lista.push({
          id: `INF_${inf.id || inf.numeroReporte || Math.random().toString()}`,
          tipo: 'INFRACCION',
          formatoCodigo: inf.codigoPlantilla || 'FO-SST-INF-001',
          formatoVersion: inf.versionPlantilla || '01',
          formatoNombre: 'Reporte de Infracción Disciplinaria',
          numeroRegistro: inf.numeroReporte || 'INF-S/N',
          fechaHoraEmision: inf.fechaHora || inf.fechaCreacion || '',
          trabajador: inf.trabajadorNombre || 'Sin asignar',
          dni: inf.dni || '',
          empresaId: inf.empresaId || 'EMP-PERPOL',
          empresaNombre: nombreEmpresa,
          responsable: inf.supervisorReporta || 'Supervisor SST',
          estado: inf.estado || 'Registrada',
          idRef: inf.id || inf.numeroReporte
        });
      });
    }

    // 4. Actas de Liquidación y Devolución de EPP por Cese (FO-SST-LIQ-001)
    if (Array.isArray(liquidaciones)) {
      liquidaciones.forEach((liq) => {
        if (!liq) return;
        const nombreEmpresa = liq.empresaNombre || (liq.empresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.');
        lista.push({
          id: `LIQ_${liq.id || liq.numeroRegistro || Math.random().toString()}`,
          tipo: 'LIQUIDACION',
          formatoCodigo: liq.codigoPlantilla || 'FO-SST-LIQ-001',
          formatoVersion: liq.versionPlantilla || '01',
          formatoNombre: 'Acta de Liquidación de EPP por Cese',
          numeroRegistro: liq.numeroRegistro || 'ACTA-LIQ-S/N',
          fechaHoraEmision: liq.fechaLiquidacion || liq.fechaCreacion || '',
          trabajador: liq.trabajadorNombre || 'Sin asignar',
          dni: liq.dni || '',
          empresaId: liq.empresaId || 'EMP-PERPOL',
          empresaNombre: nombreEmpresa,
          responsable: liq.supervisorResponsable || 'Supervisor SST',
          estado: liq.estado || 'Emitida',
          idRef: liq.id || liq.numeroRegistro
        });
      });
    }

    return lista.sort((a, b) => (b.fechaHoraEmision || '').localeCompare(a.fechaHoraEmision || ''));
  }, [entregas, descuentos, infracciones, liquidaciones]);

  // Conteos calculados en una sola pasada O(N)
  const conteosTipos = useMemo<ConteosTiposDocumento>(() => {
    const counts: ConteosTiposDocumento = {
      TODOS: 0,
      ENTREGA: 0,
      DESCUENTO: 0,
      INFRACCION: 0,
      LIQUIDACION: 0
    };

    todosLosDocumentos.forEach((d) => {
      if (empresaFiltro && empresaFiltro !== 'TODAS' && d.empresaId !== empresaFiltro) return;
      counts.TODOS++;
      if (d.tipo === 'ENTREGA') counts.ENTREGA++;
      else if (d.tipo === 'DESCUENTO') counts.DESCUENTO++;
      else if (d.tipo === 'INFRACCION') counts.INFRACCION++;
      else if (d.tipo === 'LIQUIDACION') counts.LIQUIDACION++;
    });

    return counts;
  }, [todosLosDocumentos, empresaFiltro]);

  // Documentos filtrados
  const documentosFiltrados = useMemo(() => {
    return todosLosDocumentos.filter((d) => {
      if (empresaFiltro && empresaFiltro !== 'TODAS' && d.empresaId !== empresaFiltro) return false;
      if (filtroTipo !== 'TODOS' && d.tipo !== filtroTipo) return false;
      if (busqueda && busqueda.trim()) {
        const q = busqueda.toLowerCase().trim();
        return (
          String(d.numeroRegistro || '').toLowerCase().includes(q) ||
          String(d.trabajador || '').toLowerCase().includes(q) ||
          String(d.dni || '').toLowerCase().includes(q) ||
          String(d.empresaNombre || '').toLowerCase().includes(q) ||
          String(d.responsable || '').toLowerCase().includes(q) ||
          String(d.formatoCodigo || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [todosLosDocumentos, empresaFiltro, filtroTipo, busqueda]);

  // Paginación
  const totalPaginas = Math.max(1, Math.ceil(documentosFiltrados.length / porPagina));
  const paginaAjustada = Math.min(Math.max(1, paginaActual), totalPaginas);
  const indiceInicio = (paginaAjustada - 1) * porPagina;
  const documentosPaginados = useMemo(() => {
    return documentosFiltrados.slice(indiceInicio, indiceInicio + porPagina);
  }, [documentosFiltrados, indiceInicio, porPagina]);

  // Manejador centralizado para abrir cualquier formato PDF oficial
  const abrirDocumentoHistorico = async (doc: DocumentoUnificado) => {
    setErrorDoc(null);
    setCargando(true);
    try {
      const plantillaAsociada = plantillas.find(p => p.codigo === doc.formatoCodigo && p.estado === 'Activa');

      if (doc.tipo === 'ENTREGA') {
        const ent = entregas.find(e => e.id === doc.idRef || e.numeroRegistro === doc.numeroRegistro);
        if (!ent) throw new Error('No se encontró el registro de entrega en la base de datos.');
        const res = await PDFGeneratorService.generarFormatoEntregaPDF(ent, plantillaAsociada);
        setViewerUrl(res.blobUrl);
        setViewerArrayBuffer(res.arrayBuffer);
        setViewerFileName(res.fileName);
        setViewerTitulo(`Acta Oficial de Entrega de EPP - ${doc.numeroRegistro}`);
      } else if (doc.tipo === 'DESCUENTO') {
        const desc = descuentos.find(d => d.id === doc.idRef || d.numeroRegistro === doc.numeroRegistro);
        if (!desc) throw new Error('No se encontró el registro de descuento en la base de datos.');
        const res = await PDFGeneratorService.generarDocumentoDescuentoPDF(desc, plantillaAsociada);
        setViewerUrl(res.blobUrl);
        setViewerArrayBuffer(res.arrayBuffer);
        setViewerFileName(res.fileName);
        setViewerTitulo(`Autorización Oficial de Descuento - ${doc.numeroRegistro}`);
      } else if (doc.tipo === 'INFRACCION') {
        const inf = infracciones.find(i => i.id === doc.idRef || i.numeroReporte === doc.numeroRegistro);
        if (!inf) throw new Error('No se encontró el reporte de infracción en la base de datos.');
        const res = await PDFGeneratorService.generarReporteInfraccionPDF(inf, plantillaAsociada);
        setViewerUrl(res.blobUrl);
        setViewerArrayBuffer(res.arrayBuffer);
        setViewerFileName(res.fileName);
        setViewerTitulo(`Reporte Oficial de Infracción - ${doc.numeroRegistro}`);
      } else if (doc.tipo === 'LIQUIDACION') {
        const liq = liquidaciones.find(l => l.id === doc.idRef || l.numeroRegistro === doc.numeroRegistro);
        if (!liq) throw new Error('No se encontró el registro de liquidación en la base de datos.');
        const res = await PDFGeneratorService.generarDocumentoLiquidacionPDF(liq, plantillaAsociada);
        setViewerUrl(res.blobUrl);
        setViewerArrayBuffer(res.arrayBuffer);
        setViewerFileName(res.fileName);
        setViewerTitulo(`Acta Oficial de Liquidación de EPP - ${doc.numeroRegistro}`);
      }
    } catch (e: any) {
      setErrorDoc('Error al abrir documento: ' + (e.message || 'Error desconocido'));
    } finally {
      setCargando(false);
    }
  };

  const handleSolicitarEditarPlantilla = (p: PlantillaFormato) => {
    setPlantillaParaEditar(p);
    if (pinAutenticado) {
      setModalEditorAbierto(true);
    } else {
      setModalPinAbierto(true);
    }
  };

  const handlePinSuccess = () => {
    setPinAutenticado(true);
    setModalPinAbierto(false);
    setModalEditorAbierto(true);
  };

  const handleBloquearEdicion = () => {
    setPinAutenticado(false);
    try {
      sessionStorage.removeItem('ssoma_pin_control_doc');
    } catch {}
    toast.show('Edición de formatos bloqueada.', 'info');
  };

  const handlePrevisualizarPlantillaPDF = async (
    plantilla: PlantillaFormato, 
    empresaId: 'EMP-PERPOL' | 'EMP-TR3' = 'EMP-PERPOL'
  ) => {
    setCargando(true);
    setErrorDoc(null);
    try {
      const isPerpol = empresaId === 'EMP-PERPOL';
      let res: any;

      const esLiquidacion = plantilla.codigo === 'FO-SST-LIQ-001' || plantilla.tipoDocumento === 'Liquidación';
      const esDescuento = !esLiquidacion && (plantilla.codigo === 'FO-SST-DES-001' || plantilla.tipoDocumento === 'Descuento');
      const esInfraccion = plantilla.codigo === 'FO-SST-INF-001' || plantilla.tipoDocumento === 'Disciplina';

      if (esLiquidacion) {
        const dummyLiquidacion: LiquidacionEPP = {
          id: `MUESTRA-${plantilla.codigo}`,
          numeroRegistro: 'ACTA-LIQ-0001',
          codigoPlantilla: plantilla.codigo,
          versionPlantilla: plantilla.version,
          fechaLiquidacion: new Date().toISOString().slice(0, 10),
          fechaCese: new Date().toISOString().slice(0, 10),
          motivoCese: 'Término de Contrato',
          codigoTrabajador: isPerpol ? 'PER-001' : 'TR3-001',
          dni: isPerpol ? '45892134' : '71234567',
          trabajadorNombre: isPerpol ? 'JUAN PÉREZ ROJAS (TRABAJADOR MODELO)' : 'MARÍA FLORES CASTILLO (TRABAJADORA MODELO)',
          empresaId: empresaId,
          empresaNombre: isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.',
          ruc: isPerpol ? '20392729977' : '20550842891',
          area: 'PLANTA PRODUCCIÓN',
          cargo: 'OPERARIO DE PLANTA',
          fechaIngreso: '2024-03-01',
          items: [
            {
              idItem: 'LIQ-ITEM-M1',
              idEntregaOrigen: 'ENT-2025-001',
              numeroRegistroOrigen: 'REG-0001',
              fechaEntrega: '2025-06-15',
              codigoEPP: 'EPP-CAL-002',
              articulo: 'Botas de Seguridad de Jebe con Puntera de Acero',
              tipo: 'EPP',
              talla: '42',
              unidad: 'Par',
              cantidadEntregada: 1,
              cantidadDevuelta: 0,
              cantidadVencida: 1,
              cantidadALiquidar: 0,
              costoUnitario: 65.0,
              importeTotalEntregado: 65.0,
              montoALiquidar: 0.0,
              vidaUtilDias: 180,
              fechaVencimiento: '2025-12-12',
              estadoItem: 'Vencido',
              observaciones: 'Cumplió vida útil de 6 meses. Amortizado 100% por desgaste reglamentario.'
            },
            {
              idItem: 'LIQ-ITEM-M2',
              idEntregaOrigen: 'ENT-2025-002',
              numeroRegistroOrigen: 'REG-0002',
              fechaEntrega: '2025-10-01',
              codigoEPP: 'UNI-CHAQ-001',
              articulo: 'Casaca Térmica Industrial Impermeable',
              tipo: 'Uniforme',
              talla: 'L',
              unidad: 'Unidad',
              cantidadEntregada: 1,
              cantidadDevuelta: 1,
              cantidadVencida: 0,
              cantidadALiquidar: 0,
              costoUnitario: 140.0,
              importeTotalEntregado: 140.0,
              montoALiquidar: 0.0,
              vidaUtilDias: 365,
              fechaVencimiento: '2026-10-01',
              estadoItem: 'Devuelto',
              observaciones: 'Prenda devuelta limpia e inspeccionada en almacén general.'
            },
            {
              idItem: 'LIQ-ITEM-M3',
              idEntregaOrigen: 'ENT-2026-001',
              numeroRegistroOrigen: 'REG-0003',
              fechaEntrega: '2026-01-10',
              codigoEPP: 'EPP-CAS-001',
              articulo: 'Casco de Seguridad Tipo I Clase E con Barboquejo',
              tipo: 'EPP',
              talla: 'Estándar',
              unidad: 'Unidad',
              cantidadEntregada: 1,
              cantidadDevuelta: 0,
              cantidadVencida: 0,
              cantidadALiquidar: 1,
              costoUnitario: 38.0,
              importeTotalEntregado: 38.0,
              montoALiquidar: 38.0,
              vidaUtilDias: 730,
              fechaVencimiento: '2028-01-10',
              estadoItem: 'Pendiente',
              observaciones: 'Equipo con vida útil vigente no retornado. Autorizado para deducción en liquidación.'
            }
          ],
          totalItemsEntregados: 3,
          totalItemsDevueltos: 1,
          totalItemsVencidos: 1,
          totalItemsALiquidar: 1,
          montoTotalEntregado: 243.0,
          montoDescontadoVencidosYDevueltos: 205.0,
          montoNetoALiquidar: 38.0,
          observacionesGenerales: 'Muestra oficial de formato homologado de liquidación de EPP conforme a la Ley N° 29783 y el D.S. N° 005-2012-TR.',
          supervisorResponsable: 'Ing. Jhon Rojas',
          cargoSupervisor: 'Supervisor SSOMA',
          responsableRRHH: 'Lic. Ana Paredes',
          cargoRRHH: 'Jefatura de Recursos Humanos',
          estado: 'Emitida',
          fechaCreacion: new Date().toISOString()
        };
        res = await PDFGeneratorService.generarDocumentoLiquidacionPDF(dummyLiquidacion, plantilla);
      } else if (esDescuento) {
        const dummyDescuento: DescuentoEPP = {
          id: `MUESTRA-${plantilla.codigo}`,
          numeroRegistro: 'DESC-0001',
          codigoPlantilla: plantilla.codigo,
          versionPlantilla: plantilla.version,
          fechaSolicitud: new Date().toISOString().slice(0, 10),
          fechaIncidente: new Date().toISOString().slice(0, 10),
          codigoTrabajador: isPerpol ? 'PER-001' : 'TR3-001',
          dni: isPerpol ? '45892134' : '71234567',
          trabajadorNombre: isPerpol ? 'JUAN PÉREZ ROJAS (TRABAJADOR MODELO)' : 'MARÍA FLORES CASTILLO (TRABAJADORA MODELO)',
          empresaId: empresaId,
          empresaNombre: isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.',
          ruc: isPerpol ? '20392729977' : '20550842891',
          area: 'PLANTA PRODUCCIÓN',
          cargo: 'OPERARIO DE PLANTA',
          fechaIngreso: '2024-03-01',
          motivoDescuento: 'Pérdida en planta',
          descripcionHechos: 'Extravío involuntario de equipo de protección personal reportado oportunamente durante la jornada laboral.',
          items: [
            {
              idItem: 'ITEM-MUESTRA-1',
              codigoEPP: 'EPP-CAL-002',
              articulo: 'Botas de Seguridad de Jebe con Puntera de Acero',
              categoria: 'Calzado de Seguridad',
              marca: 'Segurindustria',
              talla: '42',
              unidad: 'Par',
              cantidadPerdida: 1,
              costoUnitario: 65.0,
              importeTotal: 65.0
            }
          ],
          montoTotalDescuento: 65.0,
          modalidadPago: '1 cuota fin de mes',
          cuotas: 1,
          montoPorCuota: 65.0,
          autorizaDescuento: true,
          responsableNombre: 'Ing. Jhon Rojas',
          responsableCargo: 'Supervisor SSOMA',
          estado: 'Autorizado',
          reponerInmediatamente: true,
          fechaCreacion: new Date().toISOString(),
          observaciones: 'Muestra oficial de formato homologado conforme al Art. 40 del D.S. N° 003-97-TR y Ley 29783.'
        };
        res = await PDFGeneratorService.generarDocumentoDescuentoPDF(dummyDescuento, plantilla);
      } else if (esInfraccion) {
        const dummyInfraccion: InfraccionEPP = {
          id: `MUESTRA-${plantilla.codigo}`,
          numeroReporte: 'REP-INF-0001',
          codigoPlantilla: plantilla.codigo,
          versionPlantilla: plantilla.version,
          fechaHora: new Date().toISOString().slice(0, 16).replace('T', ' '),
          codigoTrabajador: isPerpol ? 'PER-001' : 'TR3-001',
          dni: isPerpol ? '45892134' : '71234567',
          trabajadorNombre: isPerpol ? 'JUAN PÉREZ ROJAS (TRABAJADOR MODELO)' : 'MARÍA FLORES CASTILLO (TRABAJADORA MODELO)',
          empresaId: empresaId,
          empresaNombre: isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.',
          ruc: isPerpol ? '20392729977' : '20550842891',
          area: 'PLANTA PRODUCCIÓN',
          cargo: 'OPERARIO DE PLANTA',
          lugarZona: 'Área de Pasteurización / Envasado',
          eppsOmitidos: ['Casco de Seguridad Tipo I Clase E', 'Lentes de Seguridad Anti-empañantes'],
          gravedad: 'Leve',
          tipoSancion: 'Amonestación Verbal',
          reincidencia: 'Primera vez',
          descripcionHechos: 'Trabajador detectado realizando labores operativas en planta sin portar el casco de seguridad reglamentario.',
          justificacionTrabajador: 'Olvidó colocarse el equipo tras retornar de la pausa de hidratación.',
          medidaCorrectivaInmediata: 'Colocación inmediata del equipo de protección y retroalimentación técnica de seguridad preventiva.',
          supervisorReporta: 'Ing. Jhon Rojas',
          cargoSupervisor: 'Supervisor SSOMA',
          seNegoAFirmar: false,
          estado: 'Registrada',
          fechaCreacion: new Date().toISOString(),
          observaciones: 'Muestra oficial de amonestación disciplinaria bajo la Ley N° 29783 y el Reglamento Interno de SST.'
        };
        res = await PDFGeneratorService.generarReporteInfraccionPDF(dummyInfraccion, plantilla);
      } else {
        const dummyEntrega: EntregaEPP = {
          id: `MUESTRA-${plantilla.codigo}`,
          numeroRegistro: 'REG-0001',
          fechaEntrega: new Date().toISOString().slice(0, 10),
          codigoTrabajador: isPerpol ? 'PER-001' : 'TR3-001',
          dni: isPerpol ? '45892134' : '71234567',
          trabajadorNombre: isPerpol ? 'JUAN PÉREZ ROJAS (TRABAJADOR MODELO)' : 'MARÍA FLORES CASTILLO (TRABAJADORA MODELO)',
          empresaId: empresaId,
          razonSocial: isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.',
          ruc: isPerpol ? '20392729977' : '20550842891',
          direccion: isPerpol 
            ? 'CAL.LOS BRILLANTES NRO. 096 FND. PARCELACION RUSTICA Y SEMIRUSTICA LA CAPITANA-SANTA MARIA DE HUACHIPA - LIMA – LURIGANCHO'
            : 'LOS BRILLANTES MZA. B1 LOTE. 11B PARCELA LA CAPITANA DEL FUNDO DE HUACHIPA - LIMA - LURIGANCHO',
          actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
          area: 'PLANTA PRODUCCIÓN',
          cargo: 'OPERARIO DE PLANTA',
          numTrabajadoresActivosCalculado: 24,
          fechaHoraCalculoTrabajadores: new Date().toISOString().replace('T', ' ').slice(0, 19),
          responsableEntrega: 'Ing. Jhon Rojas (Supervisor SSOMA)',
          tipoEntregaGeneral: 'Entrega inicial',
          observacionesGenerales: 'Formato modelo oficial homologado conforme a la Ley 29783 / ISO 45001.',
          estado: 'Confirmada',
          totalUnidades: 4,
          importeTotal: 125.0,
          detalles: [
            {
              idDetalle: 'DET-MUESTRA-1',
              codigoEPP: 'EPP-CAS-001',
              articulo: 'Casco de Seguridad Tipo I Clase E',
              categoria: 'Protección Craneal',
              tipo: 'EPP',
              talla: 'Estándar',
              unidad: 'Unidad',
              cantidad: 1,
              costoUnitario: 35.0,
              importe: 35.0,
              motivo: 'Entrega inicial',
              fechaRenovacion: '2027-01-02',
              observaciones: 'Conforme'
            },
            {
              idDetalle: 'DET-MUESTRA-2',
              codigoEPP: 'EPP-CAL-002',
              articulo: 'Botas de Seguridad de Jebe con Puntera de Acero',
              categoria: 'Calzado de Seguridad',
              tipo: 'EPP',
              talla: '42',
              unidad: 'Par',
              cantidad: 1,
              costoUnitario: 65.0,
              importe: 65.0,
              motivo: 'Entrega inicial',
              fechaRenovacion: '2026-07-02',
              observaciones: 'Conforme'
            },
            {
              idDetalle: 'DET-MUESTRA-3',
              codigoEPP: 'EPP-GUA-003',
              articulo: 'Guantes de Nitrilo Verde Grado Alimentario',
              categoria: 'Protección Manual',
              tipo: 'EPP',
              talla: 'M',
              unidad: 'Par',
              cantidad: 2,
              costoUnitario: 12.5,
              importe: 25.0,
              motivo: 'Entrega inicial',
              fechaRenovacion: '2026-04-02',
              observaciones: 'Conforme'
            }
          ],
          codigoPlantilla: plantilla.codigo,
          versionPlantilla: plantilla.version,
          pdfFileName: `MUESTRA_${plantilla.codigo}_v${plantilla.version}_${empresaId}.pdf`,
          fechaCreacion: new Date().toISOString().replace('T', ' ').slice(0, 19),
          operationId: `MUESTRA-OP-${Date.now()}`
        };
        res = await PDFGeneratorService.generarFormatoEntregaPDF(dummyEntrega, plantilla);
      }

      setViewerUrl(res.blobUrl);
      setViewerArrayBuffer(res.arrayBuffer);
      setViewerFileName(res.fileName);
      setViewerTitulo(`Vista Previa Oficial: ${plantilla.codigo} v${plantilla.version} (${isPerpol ? 'PERPOL' : 'TR3'})`);
    } catch (err: any) {
      setErrorDoc('Error al generar vista previa: ' + (err.message || 'Error desconocido'));
    } finally {
      setCargando(false);
    }
  };

  const handleGuardarPlantilla = (plantillaActualizada: PlantillaFormato) => {
    if (onGuardarPlantilla) {
      onGuardarPlantilla(plantillaActualizada);
    }
    setModalEditorAbierto(false);
    toast.show(`Formato ${plantillaActualizada.codigo} v${plantillaActualizada.version} actualizado exitosamente con logos homologados.`, 'success');
  };

  return {
    busqueda,
    setBusqueda,
    filtroTipo,
    setFiltroTipo,
    paginaActual,
    setPaginaActual,
    porPagina,
    setPorPagina,
    viewerUrl,
    setViewerUrl,
    viewerArrayBuffer,
    viewerFileName,
    viewerTitulo,
    cargando,
    errorDoc,
    setErrorDoc,
    pinAutenticado,
    modalPinAbierto,
    setModalPinAbierto,
    plantillaParaEditar,
    modalEditorAbierto,
    setModalEditorAbierto,
    conteosTipos,
    documentosFiltrados,
    totalPaginas,
    paginaAjustada,
    indiceInicio,
    documentosPaginados,
    abrirDocumentoHistorico,
    handleSolicitarEditarPlantilla,
    handlePinSuccess,
    handleBloquearEdicion,
    handlePrevisualizarPlantillaPDF,
    handleGuardarPlantilla,
    PIN_AUTORIZADO
  };
}
