export type TipoDocumentoFiltro = 'TODOS' | 'ENTREGA' | 'DESCUENTO' | 'INFRACCION' | 'LIQUIDACION';

export interface DocumentoUnificado {
  id: string;
  tipo: 'ENTREGA' | 'DESCUENTO' | 'INFRACCION' | 'LIQUIDACION';
  formatoCodigo: string;
  formatoVersion: string;
  formatoNombre: string;
  numeroRegistro: string;
  fechaHoraEmision: string;
  trabajador: string;
  dni: string;
  empresaId: string;
  empresaNombre: string;
  responsable: string;
  estado: string;
  idRef: string;
}

export interface ConteosTiposDocumento {
  TODOS: number;
  ENTREGA: number;
  DESCUENTO: number;
  INFRACCION: number;
  LIQUIDACION: number;
}
