import React, { createContext, useContext, useState, useCallback } from 'react';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastItem {
  id: string;
  type: ToastType;
  message: string;
  title?: string;
  durationMs?: number;
}

interface ToastContextValue {
  showToast: (type: ToastType, message: string, title?: string, durationMs?: number) => void;
  show: (message: string, type?: ToastType) => void;
  success: (message: string, title?: string) => void;
  error: (message: string, title?: string) => void;
  warning: (message: string, title?: string) => void;
  info: (message: string, title?: string) => void;
  dismiss: (id: string) => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const dismiss = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const showToast = useCallback((type: ToastType, message: string, title?: string, durationMs: number = 4000) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    const newToast: ToastItem = { id, type, message, title, durationMs };

    setToasts(prev => [newToast, ...prev].slice(0, 5)); // máximo 5 toasts simultáneos

    if (durationMs > 0) {
      setTimeout(() => {
        dismiss(id);
      }, durationMs);
    }
  }, [dismiss]);

  const success = useCallback((message: string, title?: string) => {
    showToast('success', message, title || 'Operación Exitosa');
  }, [showToast]);

  const error = useCallback((message: string, title?: string) => {
    showToast('error', message, title || 'Atención / Error', 5000);
  }, [showToast]);

  const warning = useCallback((message: string, title?: string) => {
    showToast('warning', message, title || 'Advertencia');
  }, [showToast]);

  const info = useCallback((message: string, title?: string) => {
    showToast('info', message, title || 'Información');
  }, [showToast]);

  const show = useCallback((message: string, type: ToastType = 'info') => {
    showToast(type, message);
  }, [showToast]);

  return (
    <ToastContext.Provider value={{ showToast, show, success, error, warning, info, dismiss }}>
      {children}

      {/* Contenedor flotante de Notificaciones */}
      <div 
        role="region"
        aria-label="Notificaciones del sistema"
        aria-live="polite" 
        aria-atomic="true"
        className="fixed top-4 right-4 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none"
      >
        {toasts.map(toast => {
          const isSuccess = toast.type === 'success';
          const isError = toast.type === 'error';
          const isWarning = toast.type === 'warning';

          const bgColor = isSuccess 
            ? 'bg-emerald-900/95 border-emerald-700/80 text-white' 
            : isError 
            ? 'bg-rose-950/95 border-rose-800/80 text-white' 
            : isWarning 
            ? 'bg-amber-950/95 border-amber-800/80 text-white' 
            : 'bg-slate-900/95 border-slate-700/80 text-white';

          const IconComponent = isSuccess 
            ? CheckCircle2 
            : isError 
            ? AlertCircle 
            : isWarning 
            ? AlertTriangle 
            : Info;

          const iconColor = isSuccess 
            ? 'text-emerald-400' 
            : isError 
            ? 'text-rose-400' 
            : isWarning 
            ? 'text-amber-400' 
            : 'text-blue-400';

          return (
            <div
              key={toast.id}
              role={toast.type === 'error' ? 'alert' : 'status'}
              className={`pointer-events-auto p-3.5 rounded-xl border shadow-xl flex items-start gap-3 backdrop-blur-md transition-all animate-in slide-in-from-top-3 fade-in duration-200 ${bgColor}`}
            >
              <div className="shrink-0 mt-0.5">
                <IconComponent className={`w-5 h-5 ${iconColor}`} />
              </div>
              <div className="flex-1 min-w-0">
                {toast.title && (
                  <h4 className="text-xs font-bold tracking-tight text-white mb-0.5">
                    {toast.title}
                  </h4>
                )}
                <p className="text-xs text-slate-200 leading-relaxed font-normal">
                  {toast.message}
                </p>
              </div>
              <button
                type="button"
                onClick={() => dismiss(toast.id)}
                className="shrink-0 text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
                title="Cerrar notificación"
                aria-label="Cerrar notificación"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = (): ToastContextValue => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast debe ser utilizado dentro de un ToastProvider');
  }
  return context;
};
