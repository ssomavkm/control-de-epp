import { InfraccionEPP } from '../../types';

/**
 * Registro inicial de reportes de infracciones disciplinarias limpio.
 * Los datos se sincronizan y pueblan directamente desde Google Sheets (GAS).
 */
export const INFRACCIONES_SEED: InfraccionEPP[] = [];
