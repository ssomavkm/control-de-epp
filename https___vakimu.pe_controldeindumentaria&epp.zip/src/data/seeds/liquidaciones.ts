import { LiquidacionEPP } from '../../types';

/**
 * Registro inicial de liquidaciones de EPP por cese laboral limpio.
 * Los datos se sincronizan y pueblan directamente desde Google Sheets (GAS).
 */
export const LIQUIDACIONES_SEED: LiquidacionEPP[] = [];
