import { EntregaEPP } from '../../types';

/**
 * Registro inicial de entregas de EPP limpio.
 * Los datos se sincronizan y pueblan directamente desde Google Sheets (GAS).
 */
export const ENTREGAS_SEED: EntregaEPP[] = [];
