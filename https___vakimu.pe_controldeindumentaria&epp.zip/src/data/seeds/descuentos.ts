import { DescuentoEPP } from '../../types';

/**
 * Registro inicial de autorizaciones de descuento limpio.
 * Los datos se sincronizan y pueblan directamente desde Google Sheets (GAS).
 */
export const DESCUENTOS_SEED: DescuentoEPP[] = [];
