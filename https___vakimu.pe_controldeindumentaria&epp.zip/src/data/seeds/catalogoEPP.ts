import { EPPItem } from '../../types';

/**
 * Catálogo inicial de EPP limpio (0 artículos).
 * Todos los artículos de protección personal e indumentaria se registran directamente
 * desde la aplicación o se sincronizan desde Google Sheets.
 */
export const CATALOGO_EPP_SEED: EPPItem[] = [];
