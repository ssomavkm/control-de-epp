import { DocumentoEmitido } from '../../types';

/**
 * Registro histórico inicial de documentos emitidos limpio.
 * Los datos se sincronizan y pueblan dinámicamente desde los módulos operativos y Google Sheets.
 */
export const DOCUMENTOS_HISTORICOS_SEED: DocumentoEmitido[] = [];
