import { Trabajador } from '../../types';

/**
 * Padrón maestro inicial limpio.
 * Los datos se sincronizan y pueblan directamente desde Google Sheets (GAS).
 */
export const TRABAJADORES_SEED: Trabajador[] = [];
