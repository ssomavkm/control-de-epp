import { InspeccionEPP } from '../../types';

/**
 * Registro inicial de inspecciones de EPP limpio.
 * Los datos se sincronizan y pueblan directamente desde Google Sheets (GAS).
 */
export const INSPECCIONES_SEED: InspeccionEPP[] = [];
