import { Empresa } from '../../types';
import { LOGO_PERPOL_IDEAS_PNG, LOGO_TR3_ALIMENTOS_PNG } from '../assets/logos';

export const EMPRESAS_SEED: Empresa[] = [
  {
    id: 'EMP-PERPOL',
    ruc: '20392729977',
    razonSocial: 'PERPOL IDEAS S.A.C.',
    direccion: 'CAL.LOS BRILLANTES NRO. 096 FND. PARCELACION RUSTICA Y SEMIRUSTICA LA CAPITANA-SANTA MARIA DE HUACHIPA (SUB PARCELA 30F-2) - LIMA – LURIGANCHO',
    actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
    codigoPlantilla: 'FO-SST-GEN-050',
    versionPlantilla: '02',
    fechaEmisionPlantilla: '02/01/2026',
    logoUrl: LOGO_PERPOL_IDEAS_PNG,
    estado: 'Activo'
  },
  {
    id: 'EMP-TR3',
    ruc: '20550842891',
    razonSocial: 'TR3 ALIMENTOS S.A.C.',
    direccion: 'LOS BRILLANTES MZA. B1 LOTE. 11B PARCELA LA CAPITANA DEL FUNDO DE HUACHIPA - LIMA - LURIGANCHO',
    actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
    codigoPlantilla: 'FO-SST-GEN-050',
    versionPlantilla: '02',
    fechaEmisionPlantilla: '02/01/2026',
    logoUrl: LOGO_TR3_ALIMENTOS_PNG,
    estado: 'Activo'
  }
];
