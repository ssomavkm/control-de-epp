import { ConfiguracionApp } from '../../types';

const envGasUrl = (typeof import.meta !== 'undefined' && import.meta.env && (import.meta.env.VITE_GAS_API_URL || import.meta.env.VITE_GAS_WEB_APP_URL))
  ? String(import.meta.env.VITE_GAS_API_URL || import.meta.env.VITE_GAS_WEB_APP_URL).trim()
  : '';

export const OFICIAL_GAS_WEB_APP_URL = envGasUrl || 'https://script.google.com/macros/s/AKfycbwr5Fj-UtlVwG39BpDP0vOW3aajj1vddHf9lncxkoD3OH1tc6C5j0zaARodvGXi-fA-/exec';

export const OFICIAL_DRIVE_FOLDER_ID = 
  (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_DRIVE_FOLDER_ID)
    ? String(import.meta.env.VITE_DRIVE_FOLDER_ID).trim()
    : '13IbmZ67P3XyGpys1vlILWig2QIkmHiOG';

export const OFICIAL_SPREADSHEET_ID =
  (typeof import.meta !== 'undefined' && import.meta.env && (import.meta.env.VITE_SPREADSHEET_ID || import.meta.env.VITE_GOOGLE_SHEETS_ID))
    ? String(import.meta.env.VITE_SPREADSHEET_ID || import.meta.env.VITE_GOOGLE_SHEETS_ID).trim()
    : '1JFT9K59kCJNoC4LHPnE155dDgxcZ8LzSeZMc2oqlIMQ';

export const CONFIG_SEED: ConfiguracionApp = {
  gasWebAppUrl: OFICIAL_GAS_WEB_APP_URL,
  spreadsheetId: OFICIAL_SPREADSHEET_ID,
  driveFolderId: OFICIAL_DRIVE_FOLDER_ID,
  intervaloActualizacionSegundos: 240,
  actualizacionAutomaticaActiva: false,
  ultimaActualizacion: new Date().toLocaleTimeString(),
  estadoConexion: 'conectado',
  formatoActivo: {
    codigo: 'FO-SST-GEN-050',
    version: '02',
    fechaEmision: '02/01/2026',
    tamanoPagina: 'A4',
    orientacion: 'portrait'
  }
};
