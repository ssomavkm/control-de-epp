import { describe, it, expect } from 'vitest';
import {
  empresaSchema,
  trabajadorSchema,
  validateEmpresas,
  validateTrabajadores,
  validateEPPItems
} from '../schemas';
import { EMPRESAS_SEED } from '../../seeds/empresas';
import { TRABAJADORES_SEED } from '../../seeds/trabajadores';
import { CATALOGO_EPP_SEED } from '../../seeds/catalogoEPP';

describe('Zod Validation Schemas', () => {
  it('debería validar con éxito una empresa válida', () => {
    const valida = {
      id: 'EMP-TEST',
      ruc: '20392729977',
      razonSocial: 'EMPRESA PRUEBA S.A.C.',
      direccion: 'Av. Industrial 123',
      actividadEconomica: 'Manufactura'
    };
    const res = empresaSchema.safeParse(valida);
    expect(res.success).toBe(true);
  });

  it('debería rechazar un RUC con longitud distinta a 11 dígitos', () => {
    const invalida = {
      id: 'EMP-TEST',
      ruc: '12345',
      razonSocial: 'EMPRESA PRUEBA S.A.C.'
    };
    const res = empresaSchema.safeParse(invalida);
    expect(res.success).toBe(false);
  });

  it('debería validar un trabajador con DNI de 8 dígitos', () => {
    const trabValido = {
      codigo: 'TRAB-001',
      dni: '12345678',
      nombreCompleto: 'Juan Carlos',
      empresaId: 'EMP-PERPOL',
      empresaNombre: 'PERPOL IDEAS S.A.C.',
      cargo: 'OPERARIO',
      area: 'PRODUCCIÓN',
      fechaIngreso: '2024-01-15',
      estado: 'Activo'
    };
    const res = trabajadorSchema.safeParse(trabValido);
    expect(res.success).toBe(true);
  });

  it('debería rechazar un trabajador con DNI inválido', () => {
    const trabInvalido = {
      codigo: 'TRAB-001',
      dni: '123',
      nombreCompleto: 'Juan Carlos',
      empresaId: 'EMP-PERPOL',
      empresaNombre: 'PERPOL',
      cargo: 'OPERARIO',
      area: 'PRODUCCIÓN',
      fechaIngreso: '2024-01-15',
      estado: 'Activo'
    };
    const res = trabajadorSchema.safeParse(trabInvalido);
    expect(res.success).toBe(false);
  });

  it('debería validar que los datos semilla del sistema pasen la validación', () => {
    const resEmpresas = validateEmpresas(EMPRESAS_SEED);
    expect(resEmpresas.success).toBe(true);

    const resTrabajadores = validateTrabajadores(TRABAJADORES_SEED);
    expect(resTrabajadores.success).toBe(true);

    const resEpps = validateEPPItems(CATALOGO_EPP_SEED);
    expect(resEpps.success).toBe(true);
  });
});
