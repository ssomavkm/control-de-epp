import { z } from 'zod';

export const empresaSchema = z.object({
  id: z.string().min(1, 'ID de empresa requerido'),
  ruc: z.string().regex(/^\d{11}$/, 'RUC debe tener 11 dígitos'),
  razonSocial: z.string().min(2, 'Razón social requerida'),
  direccion: z.string().min(3, 'Dirección requerida'),
  actividadEconomica: z.string().min(2, 'Actividad económica requerida'),
  codigoPlantilla: z.string().optional(),
  versionPlantilla: z.string().optional(),
  fechaEmisionPlantilla: z.string().optional(),
  estado: z.enum(['Activo', 'Inactivo']).default('Activo'),
  logoUrl: z.string().optional()
});

export const trabajadorSchema = z.object({
  codigo: z.string().min(1, 'Código de trabajador requerido'),
  dni: z.string().regex(/^\d{8,12}$/, 'DNI/Carnet de Extranjería debe tener entre 8 y 12 caracteres'),
  nombreCompleto: z.string().min(2, 'Nombre completo requerido'),
  empresaId: z.string().min(1, 'Empresa ID requerida'),
  empresaNombre: z.string().min(1, 'Nombre de empresa requerido'),
  area: z.string().min(1, 'Área requerida'),
  cargo: z.string().min(1, 'Cargo requerido'),
  fechaIngreso: z.string(),
  fechaNacimiento: z.string().optional(),
  sexo: z.enum(['M', 'F']).optional(),
  estado: z.enum(['Activo', 'Cesado', 'Inactivo']).default('Activo'),
  telefono: z.string().optional(),
  email: z.string().optional()
});

export const eppItemSchema = z.object({
  codigo: z.string().min(1, 'Código requerido'),
  articulo: z.string().min(2, 'Nombre de artículo requerido'),
  categoria: z.string().min(2, 'Categoría requerida'),
  tipo: z.enum(['EPP', 'Uniforme']),
  marca: z.string().default('Genérico'),
  modelo: z.string().default('Estándar'),
  norma: z.string().default('N/A'),
  talla: z.string().default('Estándar'),
  unidad: z.string().default('Unidad'),
  vidaUtilDias: z.number().nonnegative(),
  costoUnitario: z.number().nonnegative(),
  stockActual: z.number().int().nonnegative(),
  stockMinimo: z.number().int().nonnegative(),
  estado: z.enum(['Disponible', 'Stock Crítico', 'Agotado', 'Inactivo'])
});

export const detalleEntregaSchema = z.object({
  idDetalle: z.string().min(1),
  idEntrega: z.string().min(1),
  codigoEPP: z.string().min(1),
  articulo: z.string().min(1),
  tipo: z.enum(['EPP', 'Uniforme']),
  talla: z.string(),
  unidad: z.string(),
  cantidad: z.number().positive(),
  costoUnitario: z.number().nonnegative(),
  importe: z.number().nonnegative(),
  motivo: z.string(),
  fechaRenovacion: z.string(),
  observaciones: z.string().optional()
});

export const entregaSchema = z.object({
  id: z.string().min(1),
  numeroRegistro: z.string().min(1),
  fechaEntrega: z.string(),
  codigoTrabajador: z.string().min(1),
  dni: z.string().min(8),
  trabajadorNombre: z.string().min(2),
  empresaId: z.string().min(1),
  razonSocial: z.string().min(1),
  ruc: z.string(),
  direccion: z.string(),
  actividadEconomica: z.string(),
  area: z.string(),
  cargo: z.string(),
  numTrabajadoresActivosCalculado: z.number().int().nonnegative(),
  fechaHoraCalculoTrabajadores: z.string(),
  responsableEntrega: z.string(),
  tipoEntregaGeneral: z.string(),
  observacionesGenerales: z.string(),
  totalUnidades: z.number().nonnegative(),
  importeTotal: z.number().nonnegative(),
  detalles: z.array(detalleEntregaSchema).min(1),
  estado: z.enum(['Borrador', 'Confirmada', 'Observada']),
  codigoPlantilla: z.string(),
  versionPlantilla: z.string(),
  pdfUrl: z.string().optional(),
  pdfFileName: z.string().optional(),
  fechaCreacion: z.string(),
  firmaTrabajador: z.string().optional(),
  firmaResponsable: z.string().optional(),
  operationId: z.string().optional()
});

export const detalleInspeccionSchema = z.object({
  idDetalle: z.string().min(1),
  idInspeccion: z.string().min(1),
  codigoEPP: z.string().min(1),
  articulo: z.string().min(1),
  talla: z.string(),
  idEntregaOrigen: z.string().optional(),
  idDetalleEntregaOrigen: z.string().optional(),
  fechaEntregaReferencia: z.string().optional(),
  cantidadReferencia: z.number().optional(),
  fechaRenovacionReferencia: z.string().optional(),
  resultado: z.enum(['Buen estado', 'Desgastado', 'Deteriorado o dañado', 'Inadecuado o no cumple', 'No presentado']),
  hallazgo: z.string(),
  accion: z.enum(['Sin acción requerida', 'Reposición', 'Mantenimiento o limpieza', 'Retiro de uso', 'Evaluación adicional']),
  responsableAccion: z.string().optional(),
  fechaLimiteAccion: z.string().optional(),
  estadoAccion: z.enum(['Pendiente', 'En proceso', 'Cerrada'])
});

export const inspeccionSchema = z.object({
  id: z.string().min(1),
  numeroInspeccion: z.string().min(1),
  fechaHora: z.string(),
  codigoTrabajador: z.string().min(1),
  dni: z.string().min(8),
  trabajadorNombre: z.string().min(2),
  empresaId: z.string().min(1),
  empresaNombre: z.string().min(1),
  area: z.string(),
  cargo: z.string(),
  inspectorResponsable: z.string(),
  lugarInspeccion: z.string(),
  observacionesGenerales: z.string(),
  estado: z.enum(['Borrador', 'Confirmado']),
  detalles: z.array(detalleInspeccionSchema),
  fechaCreacion: z.string(),
  operationId: z.string().optional()
});

export const plantillaSchema = z.object({
  id: z.string().min(1),
  codigo: z.string().min(1),
  version: z.string().min(1),
  nombre: z.string().min(1),
  fechaAprobacion: z.string(),
  estado: z.enum(['Activa', 'Histórica', 'Borrador']),
  tipoDocumento: z.enum(['Dotación', 'Reposición', 'Descuento', 'Disciplina', 'Personalizado']),
  referenciaNormativa: z.string().optional(),
  declaracionCompromiso: z.string().optional(),
  descripcion: z.string().optional(),
  tipografia: z.enum(['helvetica', 'times', 'courier']).default('helvetica')
});

export const documentoSchema = z.object({
  id: z.string().min(1),
  idEntrega: z.string().min(1),
  numeroRegistro: z.string().min(1),
  codigoTrabajador: z.string().min(1),
  dni: z.string().min(8),
  trabajador: z.string().min(1),
  empresaId: z.string().min(1),
  empresaNombre: z.string().min(1),
  ruc: z.string(),
  codigoPlantilla: z.string(),
  versionPlantilla: z.string(),
  versionDocumento: z.string(),
  fechaHoraEmision: z.string(),
  responsable: z.string(),
  estadoDocumental: z.enum(['Emitido', 'Firmado', 'Anulado', 'Observado']),
  fileName: z.string()
});

export const itemDescuentoSchema = z.object({
  idItem: z.string().min(1),
  codigoEPP: z.string().min(1),
  articulo: z.string().min(1),
  categoria: z.string(),
  marca: z.string().optional(),
  talla: z.string().optional(),
  unidad: z.string().optional(),
  cantidadPerdida: z.number().positive(),
  costoUnitario: z.number().nonnegative(),
  importeTotal: z.number().nonnegative(),
  fechaEntregaOriginal: z.string().optional()
});

export const descuentoSchema = z.object({
  id: z.string().min(1),
  numeroRegistro: z.string().min(1),
  codigoPlantilla: z.string(),
  versionPlantilla: z.string(),
  fechaSolicitud: z.string(),
  fechaIncidente: z.string(),
  codigoTrabajador: z.string().min(1),
  dni: z.string().min(8),
  trabajadorNombre: z.string().min(2),
  empresaId: z.string().min(1),
  empresaNombre: z.string().min(1),
  ruc: z.string(),
  area: z.string(),
  cargo: z.string(),
  fechaIngreso: z.string(),
  motivoDescuento: z.string(),
  descripcionHechos: z.string(),
  items: z.array(itemDescuentoSchema),
  montoTotalDescuento: z.number().nonnegative(),
  modalidadPago: z.string(),
  cuotas: z.number().int().positive(),
  montoPorCuota: z.number().nonnegative(),
  autorizaDescuento: z.boolean(),
  responsableNombre: z.string(),
  responsableCargo: z.string(),
  estado: z.enum(['Borrador', 'Pendiente de Aprobación', 'Autorizado', 'Aplicado en Planilla', 'Rechazado', 'Cancelado']),
  reponerInmediatamente: z.boolean(),
  idEntregaReposicion: z.string().optional(),
  pdfFileName: z.string().optional(),
  fechaCreacion: z.string(),
  observaciones: z.string().optional()
});

export const infraccionSchema = z.object({
  id: z.string().min(1),
  numeroReporte: z.string().min(1),
  codigoPlantilla: z.string(),
  versionPlantilla: z.string(),
  fechaHora: z.string(),
  codigoTrabajador: z.string().min(1),
  dni: z.string().min(8),
  trabajadorNombre: z.string().min(2),
  empresaId: z.string().min(1),
  empresaNombre: z.string().min(1),
  ruc: z.string(),
  area: z.string(),
  cargo: z.string(),
  lugarZona: z.string(),
  eppsOmitidos: z.array(z.string()),
  gravedad: z.enum(['Leve', 'Grave', 'Muy Grave']),
  tipoSancion: z.enum(['Amonestación Verbal', 'Amonestación Escrita', 'Suspensión sin goce', 'Desvinculación']),
  diasSuspension: z.number().optional(),
  reincidencia: z.string(),
  descripcionHechos: z.string(),
  justificacionTrabajador: z.string().optional(),
  medidaCorrectivaInmediata: z.string(),
  supervisorReporta: z.string(),
  cargoSupervisor: z.string(),
  testigoNombre: z.string().optional(),
  testigoDni: z.string().optional(),
  seNegoAFirmar: z.boolean().default(false),
  estado: z.enum(['Borrador', 'Emitida', 'Enviada a RRHH', 'Cerrada', 'Anulada']),
  pdfFileName: z.string().optional(),
  fechaCreacion: z.string(),
  observaciones: z.string().optional()
});

export const itemLiquidacionSchema = z.object({
  idItem: z.string().min(1),
  idEntregaOrigen: z.string().default(''),
  numeroRegistroOrigen: z.string().default(''),
  fechaEntrega: z.string().default(''),
  codigoEPP: z.string().min(1),
  articulo: z.string().min(1),
  tipo: z.enum(['EPP', 'Uniforme']),
  talla: z.string().default('Estándar'),
  unidad: z.string().default('Unidad'),
  cantidadEntregada: z.number().positive(),
  cantidadDevuelta: z.number().nonnegative(),
  cantidadVencida: z.number().nonnegative(),
  cantidadALiquidar: z.number().nonnegative(),
  costoUnitario: z.number().nonnegative(),
  importeTotalEntregado: z.number().nonnegative(),
  montoALiquidar: z.number().nonnegative(),
  vidaUtilDias: z.number().nonnegative().default(180),
  fechaVencimiento: z.string().default(''),
  estadoItem: z.enum(['Devuelto', 'Vencido', 'Pendiente', 'Exonerado']),
  motivoExoneracion: z.string().optional(),
  observaciones: z.string().optional()
});

export const liquidacionSchema = z.object({
  id: z.string().min(1),
  numeroRegistro: z.string().min(1),
  codigoPlantilla: z.string().default('FO-SST-LIQ-001'),
  versionPlantilla: z.string().default('01'),
  fechaLiquidacion: z.string(),
  fechaCese: z.string(),
  motivoCese: z.string().optional(),
  codigoTrabajador: z.string().min(1),
  dni: z.string().min(8),
  trabajadorNombre: z.string().min(2),
  empresaId: z.string().min(1),
  empresaNombre: z.string().min(1),
  ruc: z.string(),
  area: z.string(),
  cargo: z.string(),
  fechaIngreso: z.string().optional(),
  items: z.array(itemLiquidacionSchema),
  totalItemsEntregados: z.number().nonnegative(),
  totalItemsDevueltos: z.number().nonnegative(),
  totalItemsVencidos: z.number().nonnegative(),
  totalItemsALiquidar: z.number().nonnegative(),
  montoTotalEntregado: z.number().nonnegative(),
  montoDescontadoVencidosYDevueltos: z.number().nonnegative(),
  montoNetoALiquidar: z.number().nonnegative(),
  observacionesGenerales: z.string().optional(),
  supervisorResponsable: z.string(),
  cargoSupervisor: z.string(),
  responsableRRHH: z.string().optional(),
  cargoRRHH: z.string().optional(),
  areaRRHH: z.string().optional(),
  estado: z.enum(['Borrador', 'Emitida', 'Enviada a RRHH', 'Liquidada en Planilla', 'Anulada']),
  pdfFileName: z.string().optional(),
  fechaCreacion: z.string()
});

export const configuracionSchema = z.object({
  gasWebAppUrl: z.string().url().or(z.literal('')),
  spreadsheetId: z.string().optional().default(''),
  driveFolderId: z.string().default(''),
  intervaloActualizacionSegundos: z.number().positive(),
  actualizacionAutomaticaActiva: z.boolean(),
  ultimaActualizacion: z.string(),
  estadoConexion: z.enum(['conectado', 'desconectado', 'error', 'actualizando']),
  formatoActivo: z.object({
    codigo: z.string(),
    version: z.string(),
    fechaEmision: z.string(),
    tamanoPagina: z.enum(['A4', 'Letter']),
    orientacion: z.enum(['portrait', 'landscape'])
  })
});

export const validateEmpresas = (data: unknown[]) => z.array(empresaSchema).safeParse(data);
export const validateTrabajadores = (data: unknown[]) => z.array(trabajadorSchema).safeParse(data);
export const validateEPPItems = (data: unknown[]) => z.array(eppItemSchema).safeParse(data);
export const validateEntregas = (data: unknown[]) => z.array(entregaSchema).safeParse(data);
export const validateInspecciones = (data: unknown[]) => z.array(inspeccionSchema).safeParse(data);
export const validatePlantillas = (data: unknown[]) => z.array(plantillaSchema).safeParse(data);
export const validateDocumentos = (data: unknown[]) => z.array(documentoSchema).safeParse(data);
export const validateDescuentos = (data: unknown[]) => z.array(descuentoSchema).safeParse(data);
export const validateInfracciones = (data: unknown[]) => z.array(infraccionSchema).safeParse(data);
export const validateLiquidaciones = (data: unknown[]) => z.array(liquidacionSchema).safeParse(data);
export const validateConfiguracion = (data: unknown) => configuracionSchema.safeParse(data);

export const validators = {
  validarEmpresas: validateEmpresas,
  validarTrabajadores: validateTrabajadores,
  validarCatalogoEPP: validateEPPItems,
  validarEntregas: validateEntregas,
  validarInspecciones: validateInspecciones,
  validarPlantillas: validatePlantillas,
  validarDocumentos: validateDocumentos,
  validarDescuentos: validateDescuentos,
  validarInfracciones: validateInfracciones,
  validarLiquidaciones: validateLiquidaciones,
  validarConfiguracion: validateConfiguracion
};
