import { describe, it, expect, vi, beforeEach } from 'vitest';
import { googleDriveService } from '../googleDriveService';

describe('GoogleDriveService', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('converts base64 data to Blob correctly', () => {
    const sampleBase64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    const blob = googleDriveService.base64ToBlob(sampleBase64);

    expect(blob).toBeDefined();
    expect(blob.type).toBe('image/png');
    expect(blob.size).toBeGreaterThan(0);
  });

  it('manages local index of saved drive files', () => {
    expect(googleDriveService.getVinculoGuardado('ACTA-001')).toBeNull();

    // Directly simulate saved links in localStorage
    localStorage.setItem('ssoma_drive_vinculos_v1', JSON.stringify({
      'ACTA-001': {
        id: 'drive-file-123',
        name: 'ENTREGA_REG_0001.pdf',
        webViewLink: 'https://drive.google.com/file/d/drive-file-123/view',
        fechaSubida: new Date().toISOString()
      }
    }));

    // Re-check
    const link = googleDriveService.getVinculoGuardado('ACTA-001');
    expect(link).toBeDefined();
    expect(link?.id).toBe('drive-file-123');
    expect(link?.webViewLink).toContain('drive.google.com');
  });

  it('uploads to drive using text/plain to avoid CORS preflight', async () => {
    const { DriveStorageService } = await import('../driveStorageService');

    // Mock fetch
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        success: true,
        fileId: 'file-xyz-999',
        fileUrl: 'https://drive.google.com/uc?id=file-xyz-999&export=view',
        fileName: 'test.jpg'
      })
    });
    global.fetch = mockFetch;

    const sampleBase64 = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=';

    const res = await DriveStorageService.uploadToDrive(
      sampleBase64,
      { modulo: 'test', fileName: 'test.jpg' },
      'https://script.google.com/macros/s/AKfycb.../exec'
    );

    expect(res.fileId).toBe('file-xyz-999');
    expect(res.fileUrl).toContain('file-xyz-999');
    expect(mockFetch).toHaveBeenCalledTimes(1);

    // Verify critical text/plain header to bypass CORS preflight
    const fetchArgs = mockFetch.mock.calls[0];
    expect(fetchArgs[1].headers['Content-Type']).toBe('text/plain;charset=utf-8');
    const sentPayload = JSON.parse(fetchArgs[1].body);
    expect(sentPayload.action).toBe('uploadDriveFile');
    expect(sentPayload.fileData.fileName).toBe('test.jpg');
  });
});
