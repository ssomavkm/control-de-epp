/**
 * Servicio de Almacenamiento Desacoplado en Google Drive
 * 
 * Arquitectura en 4 etapas:
 * 1. Cliente: Compresión inteligente en Canvas HTML5 (máx 1200px, JPEG 80%, fondo blanco anti-transparencia)
 * 2. Transmisión: HTTP POST con 'Content-Type: text/plain;charset=utf-8' para evitar preflight CORS (OPTIONS)
 * 3. Backend (GAS): Decodificación de Base64, creación física en Google Drive y permisos ANYONE_WITH_LINK
 * 4. Persistencia: Guarda únicamente el enlace corto directo en lugar de cadenas Base64 pesadas
 */

import { OFICIAL_DRIVE_FOLDER_ID } from '../../data/seeds/config';

export interface UploadOptions {
  fileName?: string;
  modulo: string;
  maxDimension?: number; // 1200 px por defecto
  quality?: number;      // 0.82 por defecto
  driveFolderId?: string; // Opcional para especificar carpeta en Drive
  descripcion?: string;
}

export class DriveStorageService {
  /**
   * 1. Comprime cualquier imagen (File o DataURL de firma/evidencia) en el navegador
   * Convierte imágenes pesadas de 8-10MB en JPEG ligeros de ~150KB en ~50ms.
   */
  public static async compressImage(
    fileOrDataUrl: File | string,
    options: { maxDimension?: number; quality?: number } = {}
  ): Promise<{ base64: string; mimeType: string; dataUrl: string }> {
    const maxDimension = options.maxDimension || 1200;
    const quality = options.quality ?? 0.82;

    return new Promise((resolve, reject) => {
      let resolved = false;

      // Timeout defensivo de 1 segundo (útil en Node.js o navegadores con decode bloqueado)
      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          const raw = typeof fileOrDataUrl === 'string'
            ? (fileOrDataUrl.includes(',') ? fileOrDataUrl.split(',')[1] : fileOrDataUrl)
            : '';
          resolve({
            base64: raw,
            mimeType: 'image/jpeg',
            dataUrl: typeof fileOrDataUrl === 'string' ? fileOrDataUrl : ''
          });
        }
      }, 800);

      const img = new Image();
      img.onload = () => {
        if (resolved) return;
        resolved = true;
        clearTimeout(timer);
        let width = img.width;
        let height = img.height;

        // Mantener proporción de aspecto
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, width);
        canvas.height = Math.max(1, height);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          const raw = typeof fileOrDataUrl === 'string'
            ? (fileOrDataUrl.includes(',') ? fileOrDataUrl.split(',')[1] : fileOrDataUrl)
            : '';
          resolve({ base64: raw, mimeType: 'image/jpeg', dataUrl: typeof fileOrDataUrl === 'string' ? fileOrDataUrl : '' });
          return;
        }

        // Fondo blanco para imágenes transparentes (evita fondos negros en firmas PNG a JPEG)
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const mimeType = 'image/jpeg';
        const dataUrl = canvas.toDataURL(mimeType, quality);
        const base64Data = dataUrl.split(',')[1] || dataUrl;

        resolve({
          base64: base64Data,
          mimeType,
          dataUrl
        });
      };

      img.onerror = (err) => reject(new Error('Error al procesar la imagen: ' + err));

      if (typeof fileOrDataUrl === 'string') {
        img.src = fileOrDataUrl;
      } else {
        const reader = new FileReader();
        reader.onload = (e) => {
          img.src = e.target?.result as string;
        };
        reader.onerror = (e) => reject(e);
        reader.readAsDataURL(fileOrDataUrl);
      }
    });
  }

  /**
   * Comprime una firma digital en canvas manteniendo legibilidad y bajo peso
   */
  public static async compressSignature(
    signatureDataUrl: string,
    maxDimension = 800,
    quality = 0.85
  ): Promise<string> {
    if (!signatureDataUrl || !signatureDataUrl.startsWith('data:')) {
      return signatureDataUrl;
    }
    try {
      const res = await this.compressImage(signatureDataUrl, { maxDimension, quality });
      return res.dataUrl;
    } catch {
      return signatureDataUrl;
    }
  }

  /**
   * 2. Envía la imagen o firma comprimida a Google Apps Script usando text/plain (CORS Safelisted)
   */
  public static async uploadToDrive(
    source: File | string,
    options: UploadOptions,
    gasWebAppUrl: string
  ): Promise<{ fileUrl: string; fileId: string; fileName: string; folderName?: string }> {
    if (!gasWebAppUrl || !gasWebAppUrl.startsWith('https://script.google.com')) {
      throw new Error('URL de Google Apps Script no configurada o inválida.');
    }

    // A. Comprimir en cliente
    const { base64, mimeType } = await this.compressImage(source, {
      maxDimension: options.maxDimension,
      quality: options.quality
    });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const safeName = options.fileName
      ? options.fileName.replace(/[^a-zA-Z0-9_.-]/g, '_')
      : `evidencia_${options.modulo}_${timestamp}.jpg`;

    const payload = {
      action: 'uploadDriveFile',
      driveFolderId: options.driveFolderId || OFICIAL_DRIVE_FOLDER_ID,
      fileData: {
        base64,
        mimeType,
        fileName: safeName,
        modulo: options.modulo,
        descripcion: options.descripcion || `Evidencia ${options.modulo}`
      }
    };

    // B. Enviar por POST usando 'text/plain' para evitar el error CORS preflight (HTTP OPTIONS)
    const response = await fetch(gasWebAppUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Error en servidor Google Apps Script: HTTP ${response.status}`);
    }

    const result = await response.json();

    if (!result.success && result.estado !== 'ok') {
      throw new Error(result.error || result.mensaje || 'Error al guardar archivo en Google Drive');
    }

    const fileId = result.fileId || (result.archivo && result.archivo.id);
    const fileUrl = result.fileUrl || (result.archivo && result.archivo.webViewLink) || `https://drive.google.com/uc?id=${fileId}&export=view`;

    return {
      fileUrl,
      fileId,
      fileName: result.fileName || safeName,
      folderName: result.folderName
    };
  }

  /**
   * Sube un documento PDF físico directamente a Google Drive vía Apps Script sin saturar memoria ni localStorage
   */
  public static async uploadPdfToDrive(
    pdfBlob: Blob,
    fileName: string,
    gasWebAppUrl: string,
    driveFolderId?: string,
    subcarpeta: string = '01_Actas_Entrega'
  ): Promise<{ fileUrl: string; fileId: string; fileName: string; folderName?: string }> {
    if (!gasWebAppUrl || !gasWebAppUrl.startsWith('https://script.google.com')) {
      throw new Error('URL de Google Apps Script no configurada o inválida.');
    }

    // Convertir Blob a Base64
    const base64Str = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        resolve(res.includes(',') ? res.split(',')[1] : res);
      };
      reader.onerror = reject;
      reader.readAsDataURL(pdfBlob);
    });

    const safeName = fileName.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const payload = {
      action: 'uploadDriveFile',
      driveFolderId: driveFolderId || OFICIAL_DRIVE_FOLDER_ID,
      subcarpeta,
      fileData: {
        base64: base64Str,
        mimeType: 'application/pdf',
        fileName: safeName,
        modulo: subcarpeta,
        descripcion: `Acta Oficial SSOMA: ${fileName}`
      }
    };

    try {
      const response = await fetch(gasWebAppUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        return { fileUrl: '', fileId: '', fileName: safeName };
      }

      const result = await response.json();
      if (!result.success && result.estado !== 'ok') {
        return { fileUrl: '', fileId: '', fileName: safeName };
      }

      const fileId = result.fileId || (result.archivo && result.archivo.id) || '';
      const fileUrl = result.fileUrl || (result.archivo && result.archivo.webViewLink) || (fileId ? `https://drive.google.com/file/d/${fileId}/view` : '');

      return {
        fileUrl,
        fileId,
        fileName: result.fileName || safeName,
        folderName: result.folderName || (result.archivo && result.archivo.folderName)
      };
    } catch {
      return {
        fileUrl: '',
        fileId: '',
        fileName: safeName
      };
    }
  }
}
