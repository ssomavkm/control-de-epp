import { getAccessToken, googleSignIn } from './googleAuth';
import { configStorage } from '../storage/configStorage';
import { DriveStorageService } from './driveStorageService';

export interface ArchivoDriveSubido {
  id: string;
  name: string;
  webViewLink: string;
  webContentLink?: string;
  carpetaId?: string;
  tipoDocumento?: string;
  fechaSubida: string;
}

export type TipoCarpetaDrive = 
  | '01_Actas_Entrega'
  | '02_Inspecciones_EPP'
  | '03_Descuentos_EPP'
  | '04_Infracciones_Evidencias'
  | '05_Liquidaciones_EPP'
  | '06_Imagenes_Fotos_Firmas';

const CARPETA_RAIZ_NOMBRE = 'SSOMA - GESTIÓN INTEGRAL DE ENTREGA DE EPP';
const STORAGE_KEY_DRIVE_LINKS = 'ssoma_drive_vinculos_v1';

class GoogleDriveService {
  private carpetaRaizId: string | null = null;
  private subcarpetasMap: Map<string, string> = new Map();
  private vinculosDrive: Record<string, ArchivoDriveSubido> = {};

  constructor() {
    this.cargarVinculosLocales();
  }

  private cargarVinculosLocales() {
    try {
      const data = localStorage.getItem(STORAGE_KEY_DRIVE_LINKS);
      if (data) {
        this.vinculosDrive = JSON.parse(data);
      }
    } catch (e) {
      this.vinculosDrive = {};
    }
  }

  private guardarVinculosLocales() {
    try {
      localStorage.setItem(STORAGE_KEY_DRIVE_LINKS, JSON.stringify(this.vinculosDrive));
    } catch (e) {
      console.warn('Error al persistir vínculos de Drive en localStorage:', e);
    }
  }

  /**
   * Obtiene el vínculo guardado en Drive para un nombre o identificador de archivo
   */
  public getVinculoGuardado(claveIdentificador: string): ArchivoDriveSubido | null {
    if (!this.vinculosDrive[claveIdentificador]) {
      this.cargarVinculosLocales();
    }
    return this.vinculosDrive[claveIdentificador] || null;
  }

  /**
   * Obtiene todos los vínculos guardados
   */
  public getTodosLosVinculos(): Record<string, ArchivoDriveSubido> {
    return { ...this.vinculosDrive };
  }

  /**
   * Asegura que exista un token de acceso válido; si no, solicita inicio de sesión
   */
  public async asegurarToken(): Promise<string> {
    let token = await getAccessToken();
    if (!token) {
      const loginRes = await googleSignIn();
      if (!loginRes || !loginRes.accessToken) {
        throw new Error('Debe iniciar sesión con Google para guardar archivos en Drive.');
      }
      token = loginRes.accessToken;
    }
    return token;
  }

  /**
   * Busca o crea la carpeta raíz "SSOMA - GESTIÓN INTEGRAL DE ENTREGA DE EPP"
   */
  public async asegurarCarpetaRaiz(token: string): Promise<string> {
    if (this.carpetaRaizId) return this.carpetaRaizId;

    // Priorizar ID configurado personalizado
    const cfg = configStorage.get();
    const folderIdConfig = cfg.driveFolderId || '';
    if (folderIdConfig && folderIdConfig.trim().length > 10) {
      this.carpetaRaizId = folderIdConfig.trim();
      return this.carpetaRaizId;
    }

    // Buscar si ya existe por nombre
    const q = `name = '${CARPETA_RAIZ_NOMBRE}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name,webViewLink)`;
    
    const res = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al buscar carpeta raíz en Google Drive (${res.status}): ${errText}`);
    }

    const data = await res.json();
    if (data.files && data.files.length > 0) {
      this.carpetaRaizId = data.files[0].id;
      return this.carpetaRaizId!;
    }

    // Crear carpeta raíz
    const createUrl = 'https://www.googleapis.com/drive/v3/files?fields=id,name,webViewLink';
    const createRes = await fetch(createUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: CARPETA_RAIZ_NOMBRE,
        mimeType: 'application/vnd.google-apps.folder',
        description: 'Carpeta centralizada del Sistema SSOMA para Actas de Entrega de EPP, Inspecciones, Descuentos e Infracciones'
      })
    });

    if (!createRes.ok) {
      const errText = await createRes.text();
      throw new Error(`Error al crear carpeta raíz en Google Drive: ${errText}`);
    }

    const newFolder = await createRes.json();
    this.carpetaRaizId = newFolder.id;
    return this.carpetaRaizId!;
  }

  /**
   * Busca o crea una subcarpeta dentro de la carpeta raíz
   */
  public async asegurarSubcarpeta(subcarpeta: TipoCarpetaDrive, token: string): Promise<string> {
    if (this.subcarpetasMap.has(subcarpeta)) {
      return this.subcarpetasMap.get(subcarpeta)!;
    }

    const raizId = await this.asegurarCarpetaRaiz(token);

    // Buscar subcarpeta dentro de la raíz
    const q = `name = '${subcarpeta}' and '${raizId}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)`;

    const res = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.ok) {
      const data = await res.json();
      if (data.files && data.files.length > 0) {
        const id = data.files[0].id;
        this.subcarpetasMap.set(subcarpeta, id);
        return id;
      }
    }

    // Crear subcarpeta
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files?fields=id,name', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: subcarpeta,
        mimeType: 'application/vnd.google-apps.folder',
        parents: [raizId]
      })
    });

    if (!createRes.ok) {
      const errText = await createRes.text();
      throw new Error(`Error al crear subcarpeta "${subcarpeta}" en Google Drive: ${errText}`);
    }

    const nuevaSub = await createRes.json();
    this.subcarpetasMap.set(subcarpeta, nuevaSub.id);
    return nuevaSub.id;
  }

  public async blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  /**
   * Sube un archivo (PDF o Imagen) a Google Drive en la subcarpeta correspondiente.
   * Utiliza la arquitectura desacoplada de 4 etapas (text/plain, cero saturación de localStorage).
   */
  public async subirArchivo({
    nombreArchivo,
    mimeType,
    datosBlob,
    subcarpeta = '01_Actas_Entrega',
    claveIdentificador,
    descripcion
  }: {
    nombreArchivo: string;
    mimeType: string;
    datosBlob: Blob;
    subcarpeta?: TipoCarpetaDrive;
    claveIdentificador?: string;
    descripcion?: string;
  }): Promise<ArchivoDriveSubido> {
    const cfg = configStorage.get();

    // 1. Priorizar el canal optimizado de Google Apps Script con text/plain
    if (cfg.gasWebAppUrl && cfg.gasWebAppUrl.startsWith('https://script.google.com')) {
      try {
        let uploadRes: { fileUrl: string; fileId: string; fileName: string };

        if (mimeType === 'application/pdf') {
          uploadRes = await DriveStorageService.uploadPdfToDrive(
            datosBlob,
            nombreArchivo,
            cfg.gasWebAppUrl,
            cfg.driveFolderId || '',
            subcarpeta
          );
        } else {
          uploadRes = await DriveStorageService.uploadToDrive(
            datosBlob as any,
            {
              fileName: nombreArchivo,
              modulo: subcarpeta,
              driveFolderId: cfg.driveFolderId || '',
              descripcion
            },
            cfg.gasWebAppUrl
          );
        }

        if (uploadRes && uploadRes.fileId) {
          const resultado: ArchivoDriveSubido = {
            id: uploadRes.fileId,
            name: uploadRes.fileName || nombreArchivo,
            webViewLink: uploadRes.fileUrl,
            webContentLink: `https://drive.google.com/uc?id=${uploadRes.fileId}&export=download`,
            carpetaId: subcarpeta,
            tipoDocumento: subcarpeta,
            fechaSubida: new Date().toISOString()
          };
          const clave = claveIdentificador || nombreArchivo;
          this.vinculosDrive[clave] = resultado;
          this.guardarVinculosLocales();
          return resultado;
        }
      } catch (errGas) {
        console.warn('Subida directa vía Google Apps Script falló, probando canal alternativo:', errGas);
      }
    }

    // 2. Si hay token de Google OAuth activo en memoria, usar Drive REST API v3 directamente
    const token = await getAccessToken();
    if (token) {
      const activeToken = token;
      const carpetaDestinoId = await this.asegurarSubcarpeta(subcarpeta, activeToken);

    // Metadata del archivo para Drive API
    const metadata = {
      name: nombreArchivo,
      parents: [carpetaDestinoId],
      description: descripcion || `Documento oficial SSOMA emitido el ${new Date().toLocaleString()}`,
      mimeType: mimeType
    };

    // Subida Multipart (Metadatos + Contenido binario)
    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const metadataPart = delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata);

    const mediaHeader = delimiter +
      `Content-Type: ${mimeType}\r\n\r\n`;

    const arrayBuffer = await datosBlob.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);

    const multipartBlob = new Blob([
      metadataPart,
      mediaHeader,
      bytes,
      closeDelimiter
    ], { type: `multipart/related; boundary=${boundary}` });

    const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,webContentLink';
    const uploadRes = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${activeToken}`
      },
      body: multipartBlob
    });

    if (!uploadRes.ok) {
      const errText = await uploadRes.text();
      throw new Error(`Error al subir archivo a Google Drive (${uploadRes.status}): ${errText}`);
    }

    const archivoRes = await uploadRes.json();
    const resultado: ArchivoDriveSubido = {
      id: archivoRes.id,
      name: archivoRes.name || nombreArchivo,
      webViewLink: archivoRes.webViewLink || `https://drive.google.com/file/d/${archivoRes.id}/view`,
      webContentLink: archivoRes.webContentLink,
      carpetaId: carpetaDestinoId,
      tipoDocumento: subcarpeta,
      fechaSubida: new Date().toISOString()
    };

      return resultado;
    }

    // 3. Respaldo directo: Enlace hacia la carpeta oficial en Google Drive
    const resultadoFallback: ArchivoDriveSubido = {
      id: `DRIVE-${Date.now()}`,
      name: nombreArchivo,
      webViewLink: this.carpetaRaizId ? `https://drive.google.com/drive/folders/${this.carpetaRaizId}` : '#',
      tipoDocumento: subcarpeta,
      fechaSubida: new Date().toISOString()
    };
    const claveFallback = claveIdentificador || nombreArchivo;
    this.vinculosDrive[claveFallback] = resultadoFallback;
    this.guardarVinculosLocales();
    return resultadoFallback;
  }

  /**
   * Convierte un dataURL Base64 a Blob
   */
  public base64ToBlob(base64Data: string, mimeTypeDefault = 'image/png'): Blob {
    let base64 = base64Data;
    let mimeType = mimeTypeDefault;

    if (base64.startsWith('data:')) {
      const partes = base64.split(',');
      const match = partes[0].match(/:(.*?);/);
      if (match) mimeType = match[1];
      base64 = partes[1];
    }

    const byteCharacters = atob(base64);
    const byteArrays: Uint8Array[] = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      byteArrays.push(new Uint8Array(byteNumbers));
    }

    return new Blob(byteArrays as any, { type: mimeType });
  }

  /**
   * Sube una imagen Base64 (foto de evidencia o firma) a Google Drive
   */
  public async subirImagenBase64({
    base64Data,
    nombreArchivo,
    subcarpeta = '06_Imagenes_Fotos_Firmas',
    claveIdentificador,
    descripcion
  }: {
    base64Data: string;
    nombreArchivo: string;
    subcarpeta?: TipoCarpetaDrive;
    claveIdentificador?: string;
    descripcion?: string;
  }): Promise<ArchivoDriveSubido> {
    // Comprimir en cliente en Canvas HTML5 para evitar saturación de red y memoria
    let dataToUpload = base64Data;
    let mime = 'image/jpeg';
    try {
      const comp = await DriveStorageService.compressImage(base64Data, { maxDimension: 1200, quality: 0.82 });
      dataToUpload = comp.dataUrl;
      mime = comp.mimeType;
    } catch {
      // Fallback a imagen original
    }

    const blob = this.base64ToBlob(dataToUpload, mime);
    return this.subirArchivo({
      nombreArchivo,
      mimeType: mime,
      datosBlob: blob,
      subcarpeta,
      claveIdentificador,
      descripcion
    });
  }

  /**
   * Obtener enlace a la carpeta raíz en Google Drive
   */
  public async getEnlaceCarpetaRaiz(): Promise<string> {
    const cfg = configStorage.get();
    const folderId = cfg.driveFolderId || this.carpetaRaizId;
    if (folderId && folderId.trim().length > 10) {
      return `https://drive.google.com/drive/folders/${folderId.trim()}`;
    }
    const token = await this.asegurarToken();
    const raizId = await this.asegurarCarpetaRaiz(token);
    return `https://drive.google.com/drive/folders/${raizId}`;
  }

  /**
   * Prueba la conectividad y permisos de escritura con la carpeta de Google Drive configurada
   */
  public async probarConexionCarpeta(folderIdEspecifico?: string): Promise<{ success: boolean; mensaje: string; folderName?: string }> {
    const cfg = configStorage.get();
    const folderId = (folderIdEspecifico && folderIdEspecifico.trim().length > 3)
      ? folderIdEspecifico.trim()
      : (cfg.driveFolderId || '');

    if (!folderId || folderId.trim().length < 5) {
      return {
        success: false,
        mensaje: 'Por favor ingresa un ID de carpeta válido.'
      };
    }

    if (!cfg.gasWebAppUrl || !cfg.gasWebAppUrl.startsWith('https://script.google.com')) {
      return {
        success: false,
        mensaje: 'La URL de Google Apps Script no está configurada o es inválida.'
      };
    }

    try {
      // Creamos un PDF mínimo de prueba (1x1 pt)
      const testContent = '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n3 0 obj<</Type/Page/MediaBox[0 0 1 1]/Parent 2 0 R>>endobj\nxref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n0000000052 00000 n\n0000000101 00000 n\ntrailer<</Size 4/Root 1 0 R>>\nstartxref\n162\n%%EOF';
      const testBlob = new Blob([testContent], { type: 'application/pdf' });
      const testFileName = `_test_conexion_ssoma_${Date.now()}.pdf`;

      const res = await DriveStorageService.uploadPdfToDrive(
        testBlob,
        testFileName,
        cfg.gasWebAppUrl,
        folderId,
        '00_Verificacion'
      );

      if (res && res.fileId) {
        return {
          success: true,
          mensaje: `¡Conexión verificada con éxito! Carpeta activa en Google Drive: "${res.folderName || folderId}"`,
          folderName: res.folderName || folderId
        };
      } else {
        return {
          success: false,
          mensaje: 'El servidor de Google Apps Script respondió pero no se pudo escribir en la carpeta. Verifica los permisos de acceso de la carpeta en Google Drive.'
        };
      }
    } catch (e: any) {
      return {
        success: false,
        mensaje: e.message || 'Error al conectar con la carpeta de Google Drive.'
      };
    }
  }
}

/**
 * Extrae el ID de una carpeta de Google Drive si el usuario pega una URL completa o el ID directo
 */
export function extraerFolderIdDeDrive(valor: string): string {
  if (!valor) return '';
  const val = valor.trim();
  const matchFolder = val.match(/\/folders\/([a-zA-Z0-9_-]+)/);
  if (matchFolder && matchFolder[1]) return matchFolder[1];
  const matchId = val.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (matchId && matchId[1]) return matchId[1];
  return val.split('?')[0].replace(/\/+$/, '');
}

export const googleDriveService = new GoogleDriveService();
export { DriveStorageService };
