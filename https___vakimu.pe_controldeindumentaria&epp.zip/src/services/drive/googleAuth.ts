import { initializeApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User, 
  signOut 
} from 'firebase/auth';
import firebaseConfig from '../../../firebase-applet-config.json';

// Scopes requeridos para Google Drive
export const DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive.file'
];

// Inicializar la aplicación de Firebase si aún no ha sido creada
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
DRIVE_SCOPES.forEach(scope => provider.addScope(scope));
provider.setCustomParameters({
  prompt: 'select_account'
});

// Cache en memoria para el token de acceso OAuth (NUNCA en localStorage/sessionStorage)
let isSigningIn = false;
let cachedAccessToken: string | null = null;
let currentUser: User | null = null;

// Suscriptores de cambio de estado de autenticación
type AuthCallback = (user: User | null, token: string | null) => void;
const subscribers = new Set<AuthCallback>();

export const notifyAuthSubscribers = () => {
  subscribers.forEach(cb => {
    try {
      cb(currentUser, cachedAccessToken);
    } catch (e) {
      console.warn('Error en suscriptor de auth:', e);
    }
  });
};

export const subscribeToAuth = (callback: AuthCallback): (() => void) => {
  subscribers.add(callback);
  callback(currentUser, cachedAccessToken);
  return () => {
    subscribers.delete(callback);
  };
};

/**
 * Inicializador del listener de estado de autenticación.
 * Borra el token en memoria cuando el usuario cierra sesión.
 */
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    currentUser = user;
    if (user && cachedAccessToken) {
      if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      notifyAuthSubscribers();
    } else if (!isSigningIn) {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
      notifyAuthSubscribers();
    }
  });
};

/**
 * Iniciar sesión con Google para obtener el Access Token con permisos de Google Drive
 */
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    
    if (!credential?.accessToken) {
      throw new Error('No se pudo obtener el token de acceso de Google Drive.');
    }

    cachedAccessToken = credential.accessToken;
    currentUser = result.user;
    notifyAuthSubscribers();
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Error al iniciar sesión con Google:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Obtener el token de acceso en memoria
 */
export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

/**
 * Usuario actual
 */
export const getCurrentGoogleUser = (): User | null => {
  return currentUser || auth.currentUser;
};

/**
 * Cierre de sesión y limpieza de credenciales en memoria
 */
export const googleLogout = async () => {
  await signOut(auth);
  cachedAccessToken = null;
  currentUser = null;
  notifyAuthSubscribers();
};
