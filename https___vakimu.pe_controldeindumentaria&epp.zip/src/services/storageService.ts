/**
 * Re-exportación unificada desde src/services/storage/index.ts
 * Provee retrocompatibilidad transparente con imports directos:
 * import { storageService } from '../services/storageService';
 * así como la nueva estructura modularizada en /services/storage/
 */
export * from './storage';
