import { empresasStorage } from './empresasStorage';
import { trabajadoresStorage } from './trabajadoresStorage';
import { eppItemsStorage } from './eppItemsStorage';
import { entregasStorage } from './entregasStorage';
import { inspeccionesStorage } from './inspeccionesStorage';
import { plantillasStorage } from './plantillasStorage';
import { documentosStorage } from './documentosStorage';
import { renovacionesStorage } from './renovacionesStorage';
import { descuentosStorage } from './descuentosStorage';
import { infraccionesStorage } from './infraccionesStorage';
import { liquidacionesStorage } from './liquidacionesStorage';
import { kardexStorage } from './kardexStorage';
import { configStorage } from './configStorage';
import { syncManager } from './sync/syncManager';
import { offlineQueue } from './sync/offlineQueue';
import { storageEvents } from './eventEmitter';
import { validators } from '../../data/validation/schemas';

import {
  Empresa,
  EmpresaId,
  Trabajador,
  EPPItem,
  EntregaEPP,
  DetalleEntrega,
  InspeccionEPP,
  PlantillaFormato,
  DocumentoEmitido,
  ConfiguracionApp,
  ItemRenovacion,
  DescuentoEPP,
  InfraccionEPP,
  LiquidacionEPP,
  MovimientoKardex,
  IngresoStock
} from '../../types';

/**
 * StorageService modularizado:
 * Expone tanto el nuevo patrón de acceso por dominio (storageService.entregas, storageService.trabajadores, etc.)
 * como la API legacy delegada para mantener compatibilidad 100% con todos los componentes existentes.
 */
class UnifiedStorageService {
  // --- Módulos especializados por entidad ---
  public readonly empresas = empresasStorage;
  public readonly trabajadores = trabajadoresStorage;
  public readonly eppItems = eppItemsStorage;
  public readonly catalogoEPP = eppItemsStorage;
  public readonly entregas = entregasStorage;
  public readonly inspecciones = inspeccionesStorage;
  public readonly plantillas = plantillasStorage;
  public readonly documentos = documentosStorage;
  public readonly renovaciones = renovacionesStorage;
  public readonly descuentos = descuentosStorage;
  public readonly infracciones = infraccionesStorage;
  public readonly liquidaciones = liquidacionesStorage;
  public readonly kardex = kardexStorage;
  public readonly config = configStorage;
  public readonly sync = syncManager;
  public readonly offlineQueue = offlineQueue;
  public readonly validators = validators;

  // --- Suscripción reactiva para componentes React ---
  public suscribir(listener: () => void): () => void {
    return storageEvents.subscribe(listener);
  }

  // =========================================================================
  // FACHADA DE COMPATIBILIDAD (Delegación directa a submódulos)
  // =========================================================================

  public limpiarAlmacenamientoLocalOculto(): void {
    this.sync.limpiarAlmacenamientoLocalOculto();
  }

  // --- Empresas ---
  public getEmpresas(): Empresa[] {
    return this.empresas.getAll();
  }

  public getEmpresaPorId(id: EmpresaId): Empresa | undefined {
    return this.empresas.getById(id);
  }

  // --- Trabajadores ---
  public getTrabajadores(empresaId?: string): Trabajador[] {
    return this.trabajadores.getAll(empresaId);
  }

  public getTrabajadorPorCodigo(codigo: string): Trabajador | undefined {
    return this.trabajadores.getByCodigo(codigo);
  }

  public calcularNumTrabajadoresActivos(empresaId: EmpresaId): number {
    return this.trabajadores.calcularNumActivos(empresaId);
  }

  public async guardarTrabajador(trabajador: Trabajador): Promise<void> {
    return this.trabajadores.save(trabajador);
  }

  public async eliminarTrabajador(codigo: string): Promise<void> {
    return this.trabajadores.delete(codigo);
  }

  // --- Catálogo EPP ---
  public getCatalogoEPP(): EPPItem[] {
    return this.eppItems.getAll();
  }

  public getEPPPorCodigo(codigo: string): EPPItem | undefined {
    return this.eppItems.getByCodigo(codigo);
  }

  public async guardarEPP(epp: EPPItem): Promise<void> {
    return this.eppItems.save(epp);
  }

  // --- Entregas ---
  public getEntregas(empresaId?: string): EntregaEPP[] {
    return this.entregas.getAll(empresaId);
  }

  public generarNuevoNumeroRegistro(): string {
    return this.entregas.generarNuevoNumeroRegistro();
  }

  public generarNuevoIdEntrega(): string {
    return this.entregas.generarNuevoIdEntrega();
  }

  public getUltimosEPPEntregadosPorTrabajador(codigoTrabajador: string, dni?: string, soloUltimoPorTipo: boolean = false): DetalleEntrega[] {
    return this.entregas.getUltimosEPPEntregadosPorTrabajador(codigoTrabajador, dni, soloUltimoPorTipo);
  }

  public async registrarEntrega(entrega: EntregaEPP): Promise<{ success: boolean; mensaje: string }> {
    return this.entregas.registrar(entrega);
  }

  // --- Inspecciones ---
  public getInspecciones(): InspeccionEPP[] {
    return this.inspecciones.getAll();
  }

  public generarNuevoNumeroInspeccion(): string {
    return this.inspecciones.generarNuevoNumeroInspeccion();
  }

  public generarNuevoIdInspeccion(): string {
    return this.inspecciones.generarNuevoIdInspeccion();
  }

  public async registrarInspeccion(inspeccion: InspeccionEPP): Promise<{ success: boolean; mensaje: string }> {
    return this.inspecciones.registrar(inspeccion);
  }

  public async eliminarInspeccion(idOrNumero: string): Promise<{ success: boolean; mensaje: string }> {
    return this.inspecciones.delete(idOrNumero);
  }

  // --- Plantillas ---
  public getPlantillas(): PlantillaFormato[] {
    return this.plantillas.getAll();
  }

  public getPlantillaPorCodigo(codigo: string): PlantillaFormato | undefined {
    return this.plantillas.getByCodigo(codigo);
  }

  public getPlantillaActivaParaEntrega(): PlantillaFormato {
    return this.plantillas.getActivaParaEntrega();
  }

  public getPlantillaActivaParaDescuento(): PlantillaFormato {
    return this.plantillas.getActivaParaDescuento();
  }

  public getPlantillaActivaParaInfraccion(): PlantillaFormato {
    return this.plantillas.getActivaParaInfraccion();
  }

  public getPlantillaActivaParaLiquidacion(): PlantillaFormato {
    return this.plantillas.getActivaParaLiquidacion();
  }

  public guardarPlantilla(plantilla: PlantillaFormato): void {
    this.plantillas.save(plantilla);
  }

  // --- Documentos ---
  public getDocumentos(): DocumentoEmitido[] {
    return this.documentos.getAll();
  }

  // --- Descuentos ---
  public getDescuentos(): DescuentoEPP[] {
    return this.descuentos.getAll();
  }

  public generarNuevoNumeroDescuento(): string {
    return this.descuentos.generarNuevoNumero();
  }

  public generarNuevoIdDescuento(): string {
    return this.descuentos.generarNuevoId();
  }

  public async registrarDescuento(
    descuento: DescuentoEPP,
    reponerInmediato?: boolean
  ): Promise<{ success: boolean; mensaje: string; entregaReposicionId?: string }> {
    return this.descuentos.registrar(descuento, reponerInmediato);
  }

  public actualizarEstadoDescuento(id: string, nuevoEstado: DescuentoEPP['estado']): void {
    this.descuentos.updateEstado(id, nuevoEstado);
  }

  public eliminarDescuento(id: string): void {
    this.descuentos.delete(id);
  }

  // --- Infracciones ---
  public getInfracciones(): InfraccionEPP[] {
    return this.infracciones.getAll();
  }

  public generarNuevoNumeroInfraccion(): string {
    return this.infracciones.generarNuevoNumero();
  }

  public generarNuevoIdInfraccion(): string {
    return this.infracciones.generarNuevoId();
  }

  public contarInfraccionesPorTrabajador(codigoTrabajador: string): number {
    return this.infracciones.contarPorTrabajador(codigoTrabajador);
  }

  public async registrarInfraccion(infraccion: InfraccionEPP): Promise<{ success: boolean; mensaje: string }> {
    return this.infracciones.registrar(infraccion);
  }

  public actualizarEstadoInfraccion(id: string, nuevoEstado: InfraccionEPP['estado']): void {
    this.infracciones.updateEstado(id, nuevoEstado);
  }

  public eliminarInfraccion(id: string): void {
    this.infracciones.delete(id);
  }

  // --- Liquidaciones por Cese ---
  public getLiquidaciones(): LiquidacionEPP[] {
    return this.liquidaciones.getAll();
  }

  public generarNuevoNumeroLiquidacion(): string {
    return this.liquidaciones.generarNuevoNumero();
  }

  public generarNuevoIdLiquidacion(): string {
    return this.liquidaciones.generarNuevoId();
  }

  public prepararAuditoriaCese(codigoTrabajador: string, fechaCese?: string) {
    return this.liquidaciones.prepararAuditoriaCese(codigoTrabajador, fechaCese);
  }

  public async registrarLiquidacion(liquidacion: LiquidacionEPP): Promise<{ success: boolean; mensaje: string }> {
    return this.liquidaciones.registrar(liquidacion);
  }

  public actualizarEstadoLiquidacion(id: string, nuevoEstado: LiquidacionEPP['estado']): void {
    this.liquidaciones.updateEstado(id, nuevoEstado);
  }

  public eliminarLiquidacion(id: string): void {
    this.liquidaciones.delete(id);
  }

  // --- Renovaciones ---
  public getItemsRenovacion(): ItemRenovacion[] {
    return this.renovaciones.getAll();
  }

  // --- Configuración ---
  public getConfig(): ConfiguracionApp {
    return this.config.get();
  }

  public guardarConfig(nueva: Partial<ConfiguracionApp>): void {
    this.config.set(nueva);
  }

  // --- Sincronización y Utilidades ---
  public async sincronizarConGoogleSheets(): Promise<{ success: boolean; mensaje: string }> {
    return this.sync.syncNow();
  }

  public async sincronizarTodoHaciaGoogleSheets(): Promise<{ success: boolean; mensaje: string }> {
    return this.sync.pushAll();
  }

  public exportarDatosCSV(tipo: 'entregas' | 'renovaciones' | 'costos' | 'inspecciones'): string {
    return this.sync.exportarCSV(tipo);
  }

  public restablecerDatosFabrica(): void {
    this.sync.resetToFactory();
  }

  // --- Kardex e Ingresos de Stock ---
  public getMovimientosKardex(): MovimientoKardex[] {
    return this.kardex.getAllMovimientos();
  }

  public getIngresosStock(): IngresoStock[] {
    return this.kardex.getAllIngresos();
  }

  public generarNuevoIdIngreso(): string {
    return this.kardex.generarNuevoIdIngreso();
  }

  public async registrarIngresoStock(ingreso: IngresoStock): Promise<{ success: boolean; mensaje: string }> {
    return this.eppItems.registrarIngresoStock(ingreso);
  }

  public aumentarStock(codigoEPP: string, cantidad: number, costoUnitario?: number, docRef?: string): void {
    this.eppItems.aumentarStock(codigoEPP, cantidad, costoUnitario, docRef);
  }

  public descontarStock(codigoEPP: string, cantidad: number, docRef?: string, trabajadorNombre?: string): void {
    this.eppItems.descontarStock(codigoEPP, cantidad, docRef, trabajadorNombre);
  }
}

export const storageService = new UnifiedStorageService();

// Re-exportar submódulos individuales para acceso directo
export {
  empresasStorage,
  trabajadoresStorage,
  eppItemsStorage,
  entregasStorage,
  inspeccionesStorage,
  plantillasStorage,
  documentosStorage,
  renovacionesStorage,
  descuentosStorage,
  infraccionesStorage,
  liquidacionesStorage,
  kardexStorage,
  configStorage,
  syncManager,
  offlineQueue,
  validators
};
