import { DocumentoEmitido } from '../../types';
import { DOCUMENTOS_HISTORICOS_SEED } from '../../data/seeds/documentos';
import { notifyStorageChange } from './eventEmitter';

export const STORAGE_KEY_DOCUMENTOS = 'ssoma_documentos_v1';

class DocumentosStorage {
  private documentos: DocumentoEmitido[] = [];

  constructor() {
    this.cargarPersistidos();
  }

  private cargarPersistidos(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_DOCUMENTOS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((d: any) => d.dni === '45892134' || (d.trabajador && d.trabajador.includes('Juan Carlos')));
          if (!tieneMocksAntiguos) {
            this.documentos = parsed;
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer documentos de localStorage:', e);
    }
    this.documentos = [...DOCUMENTOS_HISTORICOS_SEED];
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_DOCUMENTOS, JSON.stringify(this.documentos));
    } catch (e) {
      console.warn('Error al persistir documentos en localStorage:', e);
    }
  }

  public getAll(): DocumentoEmitido[] {
    return [...this.documentos];
  }

  public setAll(docs: DocumentoEmitido[]): void {
    const idsUsados = new Set<string>();
    this.documentos = (Array.isArray(docs) ? docs : []).map((doc, idx) => {
      let id = doc.id ? String(doc.id).trim() : `DOC-${idx + 1}`;
      if (idsUsados.has(id)) {
        id = `${id}-${idx + 1}`;
      }
      idsUsados.add(id);
      return { ...doc, id };
    });
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(docs: DocumentoEmitido[]): void {
    this.setAll(docs);
  }

  public add(doc: DocumentoEmitido): void {
    this.documentos.unshift(doc);
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public reset(): void {
    this.documentos = [...DOCUMENTOS_HISTORICOS_SEED];
    try {
      localStorage.removeItem(STORAGE_KEY_DOCUMENTOS);
    } catch (e) {
      console.warn('Error al limpiar documentos de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const documentosStorage = new DocumentosStorage();
