import { EntregaEPP, DetalleEntrega, DocumentoEmitido } from '../../types';
import { ENTREGAS_SEED } from '../../data/seeds/entregas';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { eppItemsStorage } from './eppItemsStorage';
import { documentosStorage } from './documentosStorage';
import { notifyStorageChange } from './eventEmitter';
import { normalizarEmpresaId, RAZON_SOCIAL_PERPOL, RAZON_SOCIAL_TR3, RUC_PERPOL, RUC_TR3 } from '../../utils/empresaResolver';
import { compararFechasDesc } from '../../utils/formatters';

export const STORAGE_KEY_ENTREGAS = 'ssoma_entregas_v1';

class EntregasStorage {
  private entregas: EntregaEPP[] = [];

  constructor() {
    this.cargarPersistidas();
  }

  private cargarPersistidas(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_ENTREGAS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((e: any) => e.codigoTrabajador === 'TRAB-P001' || e.dni === '45892134');
          if (!tieneMocksAntiguos) {
            this.entregas = parsed.sort((a: any, b: any) =>
              compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro)
            );
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer entregas de localStorage:', e);
    }
    this.entregas = [...ENTREGAS_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro)
    );
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_ENTREGAS, JSON.stringify(this.entregas));
    } catch (e) {
      console.warn('Error al persistir entregas en localStorage:', e);
    }
  }

  public getAll(empresaId?: string): EntregaEPP[] {
    const list = [...this.entregas].sort((a, b) =>
      compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro)
    );
    if (!empresaId || empresaId === 'TODAS') {
      return list;
    }
    const targetNorm = normalizarEmpresaId(empresaId);
    return list.filter(e => e.empresaId === empresaId || normalizarEmpresaId(e.empresaId) === targetNorm);
  }

  public setAll(entregas: EntregaEPP[]): void {
    const idsUsados = new Set<string>();
    this.entregas = (Array.isArray(entregas) ? entregas : []).map((e, idx) => {
      let id = e.id ? String(e.id).trim() : `ENT-${idx + 1}`;
      if (idsUsados.has(id)) {
        id = `${id}-${idx + 1}`;
      }
      idsUsados.add(id);

      const rawAny = e as any;
      const empresaIdNormalizado = normalizarEmpresaId({
        empresaId: e.empresaId || rawAny.empresa,
        empresa: rawAny.empresa,
        empresaNombre: rawAny.empresaNombre,
        razonSocial: e.razonSocial,
        ruc: e.ruc
      });
      const isPerpol = empresaIdNormalizado === 'EMP-PERPOL' || empresaIdNormalizado === 'PERPOL';
      const razonSocialOficial = isPerpol ? RAZON_SOCIAL_PERPOL : RAZON_SOCIAL_TR3;
      const rucOficial = isPerpol ? RUC_PERPOL : RUC_TR3;
      const regNum = (e.numeroRegistro || '').replace(/^REG-?/i, '') || String(idx + 1).padStart(4, '0');
      const detallesNormalizados = (e.detalles || []).map((det, dIdx) => ({
        ...det,
        idDetalle: (det.idDetalle && !det.idDetalle.match(/^DET-\d{12,}/))
          ? det.idDetalle
          : `DET-${regNum}-${dIdx + 1}`
      }));

      const sumUnidades = detallesNormalizados.reduce((acc, d) => acc + (Number(d.cantidad) || 0), 0);
      const sumImporte = detallesNormalizados.reduce((acc, d) => acc + (Number(d.importe) || 0), 0);

      const totalUnidades = sumUnidades > 0 ? sumUnidades : (Number(e.totalUnidades) || 0);
      const importeTotal = sumImporte > 0 ? Number(sumImporte.toFixed(2)) : (Number(e.importeTotal) || 0);

      return {
        ...e,
        id,
        dni: String(e.dni || '').trim(),
        codigoTrabajador: String(e.codigoTrabajador || '').trim(),
        numeroRegistro: String(e.numeroRegistro || '').trim(),
        trabajadorNombre: String(e.trabajadorNombre || '').trim(),
        area: String(e.area || '').trim(),
        cargo: String(e.cargo || '').trim(),
        fechaEntrega: String(e.fechaEntrega || '').trim(),
        empresa: razonSocialOficial,
        empresaId: empresaIdNormalizado,
        razonSocial: e.razonSocial || razonSocialOficial,
        ruc: e.ruc || rucOficial,
        detalles: detallesNormalizados,
        totalUnidades,
        importeTotal
      };
    }).sort((a, b) => compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro));
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(entregas: EntregaEPP[]): void {
    this.setAll(entregas);
  }

  public generarNuevoNumeroRegistro(): string {
    const year = new Date().getFullYear();
    const regexYear = new RegExp(`^REG-${year}-(\\d+)$`, 'i');
    
    // Buscar correlativo del año actual, o extraer números en general si vienen con otros formatos
    const numsDelAnio = this.entregas
      .map(e => {
        const match = (e.numeroRegistro || '').match(regexYear);
        if (match) return parseInt(match[1], 10);
        return NaN;
      })
      .filter(n => !isNaN(n));

    let next: number;
    if (numsDelAnio.length > 0) {
      next = Math.max(...numsDelAnio) + 1;
    } else {
      // Si no hay con formato año, verificar correlativo general
      const numsGenerales = this.entregas
        .map(e => {
          const parts = (e.numeroRegistro || '').split('-');
          return parseInt(parts[parts.length - 1], 10);
        })
        .filter(n => !isNaN(n));
      next = numsGenerales.length > 0 ? Math.max(...numsGenerales) + 1 : 1;
    }

    return `REG-${year}-${String(next).padStart(4, '0')}`;
  }

  public generarNuevoIdEntrega(): string {
    const year = new Date().getFullYear();
    const regexYear = new RegExp(`^ENT-${year}-(\\d+)$`, 'i');
    
    const numsDelAnio = this.entregas
      .map(e => {
        const match = (e.id || '').match(regexYear);
        if (match) return parseInt(match[1], 10);
        return NaN;
      })
      .filter(n => !isNaN(n));

    let next: number;
    if (numsDelAnio.length > 0) {
      next = Math.max(...numsDelAnio) + 1;
    } else {
      const numsGenerales = this.entregas
        .map(e => {
          const parts = (e.id || '').split('-');
          return parseInt(parts[parts.length - 1], 10);
        })
        .filter(n => !isNaN(n));
      next = numsGenerales.length > 0 ? Math.max(...numsGenerales) + 1 : 1;
    }

    return `ENT-${year}-${String(next).padStart(4, '0')}`;
  }

  public getUltimosEPPEntregadosPorTrabajador(
    codigoTrabajador: string,
    dni?: string,
    soloUltimoPorTipo: boolean = false
  ): DetalleEntrega[] {
    const codTarget = (codigoTrabajador || '').trim().toLowerCase();
    const dniTarget = (dni || '').trim().toLowerCase();

    const entregasTrab = this.entregas
      .filter(e => {
        const eCod = (e.codigoTrabajador || '').trim().toLowerCase();
        const eDni = (e.dni || '').trim().toLowerCase();
        const matchPorCodigo = codTarget ? (eCod === codTarget || eDni === codTarget) : false;
        const matchPorDni = dniTarget ? (eCod === dniTarget || eDni === dniTarget) : false;
        return matchPorCodigo || matchPorDni;
      })
      .sort((a, b) => compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro));

    if (soloUltimoPorTipo) {
      const eppsMap = new Map<string, DetalleEntrega>();
      entregasTrab.forEach(entrega => {
        (entrega.detalles || []).forEach(det => {
          if (!eppsMap.has(det.codigoEPP)) {
            eppsMap.set(det.codigoEPP, {
              ...det,
              idEntrega: det.idEntrega || entrega.id,
              fechaEntrega: (det as any).fechaEntrega || entrega.fechaEntrega
            } as any);
          }
        });
      });
      return Array.from(eppsMap.values());
    }

    // Regla de unicidad eliminada: devolver todas las entregas individuales realizadas al trabajador
    const lista: DetalleEntrega[] = [];
    entregasTrab.forEach(entrega => {
      (entrega.detalles || []).forEach((det, dIdx) => {
        lista.push({
          ...det,
          idEntrega: det.idEntrega || entrega.id,
          idDetalle: det.idDetalle || `DET-${(entrega.numeroRegistro || entrega.id).replace(/^REG-?/i, '')}-${dIdx + 1}`,
          fechaEntrega: (det as any).fechaEntrega || entrega.fechaEntrega
        } as any);
      });
    });

    return lista;
  }

  public async registrar(entrega: EntregaEPP): Promise<{ success: boolean; mensaje: string }> {
    const existe = this.entregas.find(
      e => e.operationId === entrega.operationId || e.numeroRegistro === entrega.numeroRegistro
    );
    if (existe) {
      return { success: true, mensaje: 'Entrega ya registrada previamente.' };
    }

    const catalogo = eppItemsStorage.getAll();
    const detalles = Array.isArray(entrega.detalles) ? entrega.detalles : [];
    for (const det of detalles) {
      const art = catalogo.find(e => e.codigo === det.codigoEPP);
      if (!art) {
        throw new Error(`El artículo con código ${det.codigoEPP} no existe en el catálogo.`);
      }
      if (art.stockActual < det.cantidad) {
        throw new Error(
          `Stock insuficiente para "${art.articulo}" (${art.codigo}). Solicitado: ${det.cantidad}, Disponible: ${art.stockActual}`
        );
      }
    }

    const regCodigo = (entrega.numeroRegistro || '').replace(/^REG-?/i, '');
    const detallesNormalizados = detalles.map((det, idx) => ({
      ...det,
      idDetalle: `DET-${regCodigo}-${idx + 1}`
    }));

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      try {
        const empresaOficial = entrega.empresa || entrega.razonSocial || (entrega.empresaId === 'PERPOL' || entrega.empresaId === 'EMP-PERPOL' ? RAZON_SOCIAL_PERPOL : RAZON_SOCIAL_TR3);
        await GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'guardarEntrega',
          entrega: {
            ...entrega,
            detalles: detallesNormalizados,
            empresa: empresaOficial,
            firmaTrabajador: entrega.firmaTrabajador ? '[Firma Capturada]' : '',
            firmaResponsable: entrega.firmaResponsable ? '[Firma Capturada]' : ''
          }
        });
      } catch (gasErr: any) {
        console.warn('Advertencia en transmisión a Google Sheets:', gasErr);
      }
    }

    eppItemsStorage.descontarStockBatch(
      detallesNormalizados.map(det => ({ codigoEPP: det.codigoEPP, cantidad: det.cantidad })),
      `Acta ${entrega.numeroRegistro}`,
      entrega.trabajadorNombre
    );

    const entregaFinal: EntregaEPP = {
      ...entrega,
      detalles: detallesNormalizados
    };

    this.entregas.unshift(entregaFinal);

    const nuevoDoc: DocumentoEmitido = {
      id: `DOC-${new Date().getTime()}`,
      idEntrega: entrega.id,
      numeroRegistro: entrega.numeroRegistro,
      codigoTrabajador: entrega.codigoTrabajador,
      dni: entrega.dni,
      trabajador: entrega.trabajadorNombre,
      empresaId: entrega.empresaId,
      empresaNombre: entrega.razonSocial,
      ruc: entrega.ruc,
      codigoPlantilla: entrega.codigoPlantilla || 'FO-SST-GEN-050',
      versionPlantilla: entrega.versionPlantilla || '02',
      versionDocumento: '1.0',
      fechaHoraEmision: entrega.fechaCreacion,
      responsable: entrega.responsableEntrega,
      estadoDocumental: 'Emitido',
      fileName: entrega.pdfFileName || `ENTREGA_EPP_${entrega.numeroRegistro}_${entrega.ruc}_${entrega.dni}_${entrega.fechaEntrega.replace(/-/g, '')}.pdf`
    };
    documentosStorage.add(nuevoDoc);

    this.guardarEnLocalStorage();
    notifyStorageChange();
    return { success: true, mensaje: 'Entrega registrada e inventario actualizado exitosamente.' };
  }

  public reset(): void {
    this.entregas = [...ENTREGAS_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaEntrega, b.fechaEntrega, a.numeroRegistro, b.numeroRegistro)
    );
    try {
      localStorage.removeItem(STORAGE_KEY_ENTREGAS);
    } catch (e) {
      console.warn('Error al limpiar entregas de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const entregasStorage = new EntregasStorage();
