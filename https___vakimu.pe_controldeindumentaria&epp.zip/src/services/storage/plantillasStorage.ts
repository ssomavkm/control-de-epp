import { PlantillaFormato } from '../../types';
import { PLANTILLAS_SEED } from '../../data/seeds/plantillas';
import { LOGO_PERPOL_IDEAS_PNG, LOGO_TR3_ALIMENTOS_PNG } from '../../data/assets/logos';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { empresasStorage } from './empresasStorage';
import { notifyStorageChange } from './eventEmitter';

export const STORAGE_KEY_PLANTILLAS = 'ssoma_plantillas_v4';

class PlantillasStorage {
  private plantillas: PlantillaFormato[] = [...PLANTILLAS_SEED];

  constructor() {
    this.cargarPlantillasPersistidas();
  }

  private cargarPlantillasPersistidas() {
    try {
      const plantillasRaw = localStorage.getItem(STORAGE_KEY_PLANTILLAS);
      if (plantillasRaw) {
        const parsed: PlantillaFormato[] = JSON.parse(plantillasRaw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Asegurar que plantillas del seed como FO-SST-LIQ-001 se incorporen si no existen en la persistencia previa
          const codigosExistentes = new Set(parsed.map(p => p.codigo));
          const seedsFaltantes = PLANTILLAS_SEED.filter(seed => !codigosExistentes.has(seed.codigo));
          const listaBase = [...parsed, ...seedsFaltantes];

          this.plantillas = listaBase.map(p => {
            if (
              p.codigo === 'FO-SST-GEN-050' ||
              p.codigo === 'FO-SST-DES-001' ||
              p.codigo === 'FO-SST-INF-001' ||
              p.codigo === 'FO-SST-LIQ-001'
            ) {
              const nombreActualizado = p.codigo === 'FO-SST-LIQ-001' && p.nombre.includes('DEVOLUCIÓN')
                ? 'ACTA DE LIQUIDACIÓN DE EPP POR CESE LABORAL'
                : p.nombre;

              return {
                ...p,
                nombre: nombreActualizado,
                logoPerpol: p.logoPerpol || LOGO_PERPOL_IDEAS_PNG,
                logoTr3: p.logoTr3 || LOGO_TR3_ALIMENTOS_PNG,
                inhabilitarTituloSistemaGestion: true,
                inhabilitarSubtituloMembrete: true,
                inhabilitarReferenciaNormativa: true,
                referenciaNormativa: '',
                textoSubtituloMembrete: '',
                tituloSistemaGestion: ''
              };
            }
            return p;
          });
          localStorage.setItem(STORAGE_KEY_PLANTILLAS, JSON.stringify(this.plantillas));
        }
      } else {
        this.plantillas = [...PLANTILLAS_SEED];
        localStorage.setItem(STORAGE_KEY_PLANTILLAS, JSON.stringify(this.plantillas));
      }
    } catch (err) {
      console.warn('Aviso al leer plantillas persistidas:', err);
    }

    // Sincronizar logos oficiales en empresas
    empresasStorage.updateLogo('PERPOL', LOGO_PERPOL_IDEAS_PNG);
    empresasStorage.updateLogo('TR3', LOGO_TR3_ALIMENTOS_PNG);
  }

  public getAll(): PlantillaFormato[] {
    return [...this.plantillas];
  }

  public getByCodigo(codigo: string): PlantillaFormato | undefined {
    if (!codigo) return undefined;
    return this.plantillas.find(p => p.codigo.trim().toUpperCase() === codigo.trim().toUpperCase());
  }

  public getActivaParaEntrega(): PlantillaFormato {
    const activaFO50 = this.plantillas.find(p => p.codigo === 'FO-SST-GEN-050' && p.estado === 'Activa');
    if (activaFO50) return activaFO50;
    const cualquierFO50 = this.plantillas.find(p => p.codigo === 'FO-SST-GEN-050');
    if (cualquierFO50) return cualquierFO50;
    const tipoDotacion = this.plantillas.find(p => p.tipoDocumento === 'Dotación' && p.estado === 'Activa');
    if (tipoDotacion) return tipoDotacion;
    return this.plantillas[0] || PLANTILLAS_SEED[0];
  }

  public getActivaParaDescuento(): PlantillaFormato {
    const activaFO001 = this.plantillas.find(p => p.codigo === 'FO-SST-DES-001' && p.estado === 'Activa');
    if (activaFO001) return activaFO001;
    const cualquierFO001 = this.plantillas.find(p => p.codigo === 'FO-SST-DES-001');
    if (cualquierFO001) return cualquierFO001;
    const tipoDescuento = this.plantillas.find(p => p.tipoDocumento === 'Descuento' && p.estado === 'Activa');
    if (tipoDescuento) return tipoDescuento;
    return this.plantillas[1] || PLANTILLAS_SEED[1];
  }

  public getActivaParaInfraccion(): PlantillaFormato {
    const activaINF = this.plantillas.find(p => p.codigo === 'FO-SST-INF-001' && p.estado === 'Activa');
    if (activaINF) return activaINF;
    const cualquierINF = this.plantillas.find(p => p.codigo === 'FO-SST-INF-001');
    if (cualquierINF) return cualquierINF;
    const tipoDisciplina = this.plantillas.find(p => p.tipoDocumento === 'Disciplina' && p.estado === 'Activa');
    if (tipoDisciplina) return tipoDisciplina;
    return this.plantillas[2] || PLANTILLAS_SEED[2];
  }

  public getActivaParaLiquidacion(): PlantillaFormato {
    const activaLIQ = this.plantillas.find(p => p.codigo === 'FO-SST-LIQ-001' && p.estado === 'Activa');
    if (activaLIQ) return activaLIQ;
    const cualquierLIQ = this.plantillas.find(p => p.codigo === 'FO-SST-LIQ-001');
    if (cualquierLIQ) return cualquierLIQ;
    const tipoLiquidacion = this.plantillas.find(p => p.tipoDocumento === 'Liquidación' && p.estado === 'Activa');
    if (tipoLiquidacion) return tipoLiquidacion;
    return PLANTILLAS_SEED.find(p => p.codigo === 'FO-SST-LIQ-001') || this.plantillas[0];
  }

  public setAll(plantillas: PlantillaFormato[]): void {
    this.plantillas = [...plantillas];
    try {
      localStorage.setItem(STORAGE_KEY_PLANTILLAS, JSON.stringify(this.plantillas));
    } catch {}
    notifyStorageChange();
  }

  public saveAll(plantillas: PlantillaFormato[]): void {
    this.setAll(plantillas);
  }

  public fusionarRemotas(remotas: PlantillaFormato[]): void {
    const plantillasFusionadas = [...this.plantillas];
    remotas.forEach((remota: PlantillaFormato) => {
      const idx = plantillasFusionadas.findIndex(p => p.codigo === remota.codigo || p.id === remota.id);
      const esTresFormatos = remota.codigo === 'FO-SST-GEN-050' || remota.codigo === 'FO-SST-DES-001' || remota.codigo === 'FO-SST-INF-001';
      
      if (idx !== -1) {
        plantillasFusionadas[idx] = {
          ...remota,
          logoPerpol: esTresFormatos ? LOGO_PERPOL_IDEAS_PNG : (remota.logoPerpol || plantillasFusionadas[idx].logoPerpol),
          logoTr3: esTresFormatos ? LOGO_TR3_ALIMENTOS_PNG : (remota.logoTr3 || plantillasFusionadas[idx].logoTr3),
          logoPersonalizado: remota.logoPersonalizado || plantillasFusionadas[idx].logoPersonalizado,
          declaracionCompromiso: remota.declaracionCompromiso || plantillasFusionadas[idx].declaracionCompromiso,
          tituloSistemaGestion: esTresFormatos ? '' : (remota.tituloSistemaGestion || plantillasFusionadas[idx].tituloSistemaGestion),
          textoSubtituloMembrete: esTresFormatos ? '' : (remota.textoSubtituloMembrete || plantillasFusionadas[idx].textoSubtituloMembrete),
          referenciaNormativa: esTresFormatos ? '' : (remota.referenciaNormativa || plantillasFusionadas[idx].referenciaNormativa),
          inhabilitarTituloSistemaGestion: esTresFormatos ? true : remota.inhabilitarTituloSistemaGestion,
          inhabilitarSubtituloMembrete: esTresFormatos ? true : remota.inhabilitarSubtituloMembrete,
          inhabilitarReferenciaNormativa: esTresFormatos ? true : remota.inhabilitarReferenciaNormativa,
          lemaPiePagina: remota.lemaPiePagina || plantillasFusionadas[idx].lemaPiePagina
        };
      } else {
        plantillasFusionadas.push(
          esTresFormatos ? {
            ...remota,
            logoPerpol: LOGO_PERPOL_IDEAS_PNG,
            logoTr3: LOGO_TR3_ALIMENTOS_PNG,
            tituloSistemaGestion: '',
            textoSubtituloMembrete: '',
            referenciaNormativa: '',
            inhabilitarTituloSistemaGestion: true,
            inhabilitarSubtituloMembrete: true,
            inhabilitarReferenciaNormativa: true
          } : remota
        );
      }
    });

    this.plantillas = plantillasFusionadas;
    try {
      localStorage.setItem(STORAGE_KEY_PLANTILLAS, JSON.stringify(this.plantillas));
    } catch {}
    notifyStorageChange();
  }

  public save(plantilla: PlantillaFormato): void {
    const index = this.plantillas.findIndex(p => p.id === plantilla.id || p.codigo === plantilla.codigo);
    if (index >= 0) {
      this.plantillas[index] = { ...this.plantillas[index], ...plantilla };
    } else {
      this.plantillas.push(plantilla);
    }

    if (plantilla.logoPerpol) empresasStorage.updateLogo('PERPOL', plantilla.logoPerpol);
    if (plantilla.logoTr3) empresasStorage.updateLogo('TR3', plantilla.logoTr3);

    try {
      localStorage.setItem(STORAGE_KEY_PLANTILLAS, JSON.stringify(this.plantillas));
    } catch (e) {
      console.warn('Error al guardar plantillas en localStorage:', e);
    }

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      GasService.enviarPost(cfg.gasWebAppUrl, {
        action: 'guardarPlantilla',
        plantilla
      }).catch(e => console.warn('Sync plantilla GAS error:', e));
    }

    notifyStorageChange();
  }

  public reset(): void {
    this.plantillas = [...PLANTILLAS_SEED];
    try {
      localStorage.removeItem(STORAGE_KEY_PLANTILLAS);
    } catch {}
    notifyStorageChange();
  }
}

export const plantillasStorage = new PlantillasStorage();
