type Listener = () => void;

export class EventEmitter {
  private listeners: Listener[] = [];

  public subscribe(fn: Listener): () => void {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter(l => l !== fn);
    };
  }

  public emit(): void {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (err) {
        console.error('Error in storage listener:', err);
      }
    });
  }
}

export const storageEvents = new EventEmitter();

let notificacionPendiente = false;

/**
 * Notificación optimizada y agrupada (batching vía microtask).
 * Evita ráfagas de múltiples re-renders consecutivos al procesar entregas,
 * ingresos de stock o sincronizaciones de múltiples colecciones.
 */
export const notifyStorageChange = (): void => {
  if (notificacionPendiente) return;
  notificacionPendiente = true;

  if (typeof queueMicrotask === 'function') {
    queueMicrotask(() => {
      notificacionPendiente = false;
      storageEvents.emit();
    });
  } else {
    setTimeout(() => {
      notificacionPendiente = false;
      storageEvents.emit();
    }, 0);
  }
};
