import { ConfiguracionApp } from '../../types';
import { CONFIG_SEED, OFICIAL_GAS_WEB_APP_URL, OFICIAL_DRIVE_FOLDER_ID, OFICIAL_SPREADSHEET_ID } from '../../data/seeds/config';
import { extraerSpreadsheetId } from '../gasService';
import { notifyStorageChange } from './eventEmitter';

export const STORAGE_KEY_CONFIG = 'ssoma_config_v2';
const CURRENT_VERSION = '2026_11_10_v14_speed_opt';

const esUrlDemoAntigua = (url?: string): boolean => {
  if (!url) return false;
  return url.includes('AKfycbzjgoxu2') || url.includes('AKfycbwVqDnu');
};

class ConfigStorage {
  private config: ConfiguracionApp = CONFIG_SEED;

  constructor() {
    this.cargarConfiguracionConexion();
  }

  private cargarConfiguracionConexion() {
    try {
      try {
        localStorage.removeItem('ssoma_config');
      } catch {}

      const cfgRaw = localStorage.getItem(STORAGE_KEY_CONFIG);
      const parsed = cfgRaw ? JSON.parse(cfgRaw) : {};
      
      // Si la versión guardada es anterior a la configuración oficial o contiene URL demo antigua,
      // inicializar con CONFIG_SEED oficial
      if (parsed.gasWebAppVersion !== CURRENT_VERSION || esUrlDemoAntigua(parsed.gasWebAppUrl)) {
        this.config = {
          ...CONFIG_SEED,
          gasWebAppUrl: OFICIAL_GAS_WEB_APP_URL,
          spreadsheetId: OFICIAL_SPREADSHEET_ID,
          driveFolderId: OFICIAL_DRIVE_FOLDER_ID,
          estadoConexion: 'conectado'
        };

        localStorage.setItem(
          STORAGE_KEY_CONFIG,
          JSON.stringify({
            ...this.config,
            gasWebAppVersion: CURRENT_VERSION
          })
        );
        return;
      }

      let urlConfigurada = (parsed.gasWebAppUrl && String(parsed.gasWebAppUrl).trim().startsWith('https://script.google.com'))
        ? String(parsed.gasWebAppUrl).trim()
        : OFICIAL_GAS_WEB_APP_URL;

      if (esUrlDemoAntigua(urlConfigurada)) {
        urlConfigurada = OFICIAL_GAS_WEB_APP_URL;
      }

      const intervalo = (!parsed.intervaloActualizacionSegundos || parsed.intervaloActualizacionSegundos <= 30)
        ? 240
        : parsed.intervaloActualizacionSegundos;

      let folderIdConfigurado = (parsed.driveFolderId && String(parsed.driveFolderId).trim().length > 3)
        ? String(parsed.driveFolderId).trim()
        : OFICIAL_DRIVE_FOLDER_ID;

      const sheetIdConfigurado = (parsed.spreadsheetId && String(parsed.spreadsheetId).trim().length > 3)
        ? extraerSpreadsheetId(String(parsed.spreadsheetId).trim())
        : OFICIAL_SPREADSHEET_ID;

      this.config = {
        ...CONFIG_SEED,
        ...parsed,
        intervaloActualizacionSegundos: intervalo,
        gasWebAppUrl: urlConfigurada,
        spreadsheetId: sheetIdConfigurado,
        driveFolderId: folderIdConfigurado,
        estadoConexion: urlConfigurada ? (parsed.estadoConexion || 'conectado') : 'desconectado'
      };

      localStorage.setItem(
        STORAGE_KEY_CONFIG,
        JSON.stringify({
          ...this.config,
          intervaloActualizacionSegundos: intervalo,
          gasWebAppUrl: urlConfigurada,
          spreadsheetId: sheetIdConfigurado,
          driveFolderId: folderIdConfigurado,
          gasWebAppVersion: CURRENT_VERSION
        })
      );
    } catch {
      this.config = {
        ...CONFIG_SEED,
        gasWebAppUrl: OFICIAL_GAS_WEB_APP_URL,
        spreadsheetId: OFICIAL_SPREADSHEET_ID,
        driveFolderId: OFICIAL_DRIVE_FOLDER_ID,
        estadoConexion: 'conectado'
      };
    }
  }

  public get(): ConfiguracionApp {
    const rawUrl = this.config.gasWebAppUrl ? String(this.config.gasWebAppUrl).trim() : '';
    const urlAsegurada = (rawUrl.startsWith('https://script.google.com') && !esUrlDemoAntigua(rawUrl))
      ? rawUrl
      : OFICIAL_GAS_WEB_APP_URL;

    const rawFolder = this.config.driveFolderId ? String(this.config.driveFolderId).trim() : '';
    const folderIdAsegurado = rawFolder.length > 3 ? rawFolder : OFICIAL_DRIVE_FOLDER_ID;

    const sheetIdAsegurado =
      this.config.spreadsheetId && String(this.config.spreadsheetId).trim().length > 3
        ? extraerSpreadsheetId(String(this.config.spreadsheetId).trim())
        : OFICIAL_SPREADSHEET_ID;

    return {
      ...this.config,
      gasWebAppUrl: urlAsegurada,
      spreadsheetId: sheetIdAsegurado,
      driveFolderId: folderIdAsegurado,
      actualizacionAutomaticaActiva: false
    };
  }

  public set(nueva: Partial<ConfiguracionApp>): void {
    let urlAsegurada =
      nueva.gasWebAppUrl !== undefined
        ? String(nueva.gasWebAppUrl).trim()
        : (this.config.gasWebAppUrl || OFICIAL_GAS_WEB_APP_URL);

    if (esUrlDemoAntigua(urlAsegurada)) {
      urlAsegurada = OFICIAL_GAS_WEB_APP_URL;
    }

    let folderIdAsegurado =
      nueva.driveFolderId !== undefined
        ? String(nueva.driveFolderId).trim()
        : (this.config.driveFolderId || OFICIAL_DRIVE_FOLDER_ID);

    const sheetIdAsegurado =
      nueva.spreadsheetId !== undefined
        ? extraerSpreadsheetId(String(nueva.spreadsheetId).trim())
        : (this.config.spreadsheetId || OFICIAL_SPREADSHEET_ID);

    this.config = {
      ...this.config,
      ...nueva,
      gasWebAppUrl: urlAsegurada,
      spreadsheetId: sheetIdAsegurado,
      driveFolderId: folderIdAsegurado
    };

    try {
      localStorage.setItem(
        STORAGE_KEY_CONFIG,
        JSON.stringify({ ...this.config, gasWebAppVersion: CURRENT_VERSION })
      );
    } catch (e) {
      console.warn('Error al guardar configuración de Google Sheets y Drive:', e);
    }

    notifyStorageChange();
  }

  public reset(): void {
    this.config = { ...CONFIG_SEED };
    try {
      localStorage.removeItem(STORAGE_KEY_CONFIG);
    } catch {}
    notifyStorageChange();
  }
}

export const configStorage = new ConfigStorage();
