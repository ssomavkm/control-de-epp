import { InspeccionEPP } from '../../types';
import { INSPECCIONES_SEED } from '../../data/seeds/inspecciones';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { notifyStorageChange } from './eventEmitter';
import { compararFechasDesc } from '../../utils/formatters';

export const STORAGE_KEY_INSPECCIONES = 'ssoma_inspecciones_v1';

class InspeccionesStorage {
  private inspecciones: InspeccionEPP[] = [];

  constructor() {
    this.cargarPersistidas();
  }

  private cargarPersistidas(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_INSPECCIONES);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((i: any) => i.codigoTrabajador === 'TRAB-P001' || i.dni === '45892134');
          if (!tieneMocksAntiguos) {
            this.inspecciones = parsed.sort((a: any, b: any) =>
              compararFechasDesc(a.fechaHora || a.fechaCreacion, b.fechaHora || b.fechaCreacion, a.numeroInspeccion, b.numeroInspeccion)
            );
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer inspecciones de localStorage:', e);
    }
    this.inspecciones = [...INSPECCIONES_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaHora || a.fechaCreacion, b.fechaHora || b.fechaCreacion, a.numeroInspeccion, b.numeroInspeccion)
    );
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_INSPECCIONES, JSON.stringify(this.inspecciones));
    } catch (e) {
      console.warn('Error al persistir inspecciones en localStorage:', e);
    }
  }

  public getAll(): InspeccionEPP[] {
    return [...this.inspecciones].sort((a, b) =>
      compararFechasDesc(a.fechaHora || a.fechaCreacion, b.fechaHora || b.fechaCreacion, a.numeroInspeccion, b.numeroInspeccion)
    );
  }

  public setAll(inspecciones: InspeccionEPP[]): void {
    const idsUsados = new Set<string>();
    this.inspecciones = (Array.isArray(inspecciones) ? inspecciones : []).map((insp, idx) => {
      let id = insp.id ? String(insp.id).trim() : `INSP-${idx + 1}`;
      if (idsUsados.has(id)) {
        id = `${id}-${idx + 1}`;
      }
      idsUsados.add(id);
      return { ...insp, id };
    }).sort((a, b) =>
      compararFechasDesc(a.fechaHora || a.fechaCreacion, b.fechaHora || b.fechaCreacion, a.numeroInspeccion, b.numeroInspeccion)
    );
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(inspecciones: InspeccionEPP[]): void {
    this.setAll(inspecciones);
  }

  public generarNuevoNumeroInspeccion(): string {
    const nums = this.inspecciones
      .map(i => parseInt(i.numeroInspeccion.replace(/\D/g, ''), 10))
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `INS-${String(next).padStart(4, '0')}`;
  }

  public generarNuevoIdInspeccion(): string {
    const nums = this.inspecciones
      .map(i => {
        const parts = i.id.split('-');
        return parseInt(parts[parts.length - 1], 10);
      })
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `INSP-${new Date().getFullYear()}-${String(next).padStart(4, '0')}`;
  }

  public async registrar(inspeccion: InspeccionEPP): Promise<{ success: boolean; mensaje: string }> {
    const existe = this.inspecciones.find(
      i => i.operationId === inspeccion.operationId || i.numeroInspeccion === inspeccion.numeroInspeccion
    );
    if (existe) {
      return { success: true, mensaje: 'Inspección ya registrada previamente.' };
    }

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      try {
        const empresaIdCanonica = inspeccion.empresaId === 'EMP-PERPOL' || inspeccion.empresaId === 'PERPOL' ? 'PERPOL' : 'TR3';
        await GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'guardarInspeccion',
          inspeccion: {
            ...inspeccion,
            empresaId: empresaIdCanonica
          }
        });
      } catch (err) {
        console.warn('Aviso en envío a Google Sheets:', err);
      }
    }

    this.inspecciones.unshift(inspeccion);
    this.guardarEnLocalStorage();
    notifyStorageChange();
    return { success: true, mensaje: 'Inspección de EPP guardada con éxito.' };
  }

  public async delete(idOrNumero: string): Promise<{ success: boolean; mensaje: string }> {
    const target = (idOrNumero || '').trim();
    const inspeccion = this.inspecciones.find(
      i => (i.id && i.id.trim() === target) || (i.numeroInspeccion && i.numeroInspeccion.trim() === target)
    );
    if (!inspeccion) {
      return { success: false, mensaje: 'Inspección no encontrada.' };
    }

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      try {
        await GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'eliminarInspeccion',
          id: inspeccion.id,
          numeroInspeccion: inspeccion.numeroInspeccion
        });
      } catch (err) {
        console.warn('Aviso en eliminación de inspección en Google Sheets:', err);
      }
    }

    this.inspecciones = this.inspecciones.filter(
      i => i.id !== inspeccion.id && i.numeroInspeccion !== inspeccion.numeroInspeccion
    );
    this.guardarEnLocalStorage();
    notifyStorageChange();
    return { success: true, mensaje: `Inspección ${inspeccion.numeroInspeccion} eliminada con éxito.` };
  }

  public reset(): void {
    this.inspecciones = [...INSPECCIONES_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaHora || a.fechaCreacion, b.fechaHora || b.fechaCreacion, a.numeroInspeccion, b.numeroInspeccion)
    );
    try {
      localStorage.removeItem(STORAGE_KEY_INSPECCIONES);
    } catch (e) {
      console.warn('Error al limpiar inspecciones de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const inspeccionesStorage = new InspeccionesStorage();
