import { EPPItem, IngresoStock, MovimientoKardex } from '../../types';
import { CATALOGO_EPP_SEED } from '../../data/seeds/catalogoEPP';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { notifyStorageChange } from './eventEmitter';
import { kardexStorage } from './kardexStorage';

export const STORAGE_KEY_CATALOGO_EPP = 'ssoma_catalogo_epp_v2';

class EPPItemsStorage {
  private catalogoEPP: EPPItem[] = [];

  constructor() {
    this.cargarCatalogoPersistido();
  }

  private cargarCatalogoPersistido() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_CATALOGO_EPP);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          const tieneMocksAntiguos = parsed.some((e: any) => e.codigo === 'EPP-CAS-01' && e.modelo === 'H-700 Series');
          if (!tieneMocksAntiguos) {
            this.catalogoEPP = parsed;
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer catálogo EPP de localStorage:', e);
    }
    this.catalogoEPP = [...CATALOGO_EPP_SEED];
    this.guardarEnLocalStorage();
  }

  private guardarEnLocalStorage() {
    try {
      localStorage.setItem(STORAGE_KEY_CATALOGO_EPP, JSON.stringify(this.catalogoEPP));
    } catch (e) {
      console.warn('Error al persistir catálogo EPP en localStorage:', e);
    }
  }

  public getAll(): EPPItem[] {
    return [...this.catalogoEPP];
  }

  public getByCodigo(codigo: string): EPPItem | undefined {
    if (!codigo) return undefined;
    return this.catalogoEPP.find(e => e.codigo.trim().toUpperCase() === codigo.trim().toUpperCase());
  }

  public setAll(items: EPPItem[]): void {
    const codigosUsados = new Set<string>();
    this.catalogoEPP = (Array.isArray(items) ? items : []).map((item, idx) => {
      let codigo = item.codigo ? String(item.codigo).trim() : '';
      if (!codigo) {
        const esUniforme = String(item.tipo || '').toUpperCase() === 'UNIFORME' || String(item.categoria || '').toUpperCase().includes('INDUMENTARIA');
        const prefijo = esUniforme ? 'UNI' : 'EPP';
        codigo = `${prefijo}-${String(idx + 1).padStart(3, '0')}`;
      }
      if (codigosUsados.has(codigo)) {
        let suffix = 2;
        while (codigosUsados.has(`${codigo}-${suffix}`)) {
          suffix++;
        }
        codigo = `${codigo}-${suffix}`;
      }
      codigosUsados.add(codigo);

      const stockActual = Number(item.stockActual) || 0;
      const stockMinimo = Number(item.stockMinimo) || 0;
      let estado = item.estado || 'Disponible';
      if (stockActual === 0) {
        estado = 'Agotado';
      } else if (stockActual <= stockMinimo) {
        estado = 'Stock Crítico';
      } else if (estado !== 'Inactivo') {
        estado = 'Disponible';
      }

      return {
        ...item,
        codigo,
        stockActual,
        stockMinimo,
        costoUnitario: Number(item.costoUnitario) || 0,
        vidaUtilDias: Number(item.vidaUtilDias) || 180,
        estado
      };
    });
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(items: EPPItem[]): void {
    this.setAll(items);
  }

  /**
   * Resta automática de inventario (consumo por entrega oficial)
   */
  public descontarStock(
    codigoEPP: string,
    cantidad: number,
    documentoReferencia: string = 'Entrega de EPP',
    trabajadorNombre?: string
  ): void {
    this.descontarStockBatch([{ codigoEPP, cantidad }], documentoReferencia, trabajadorNombre);
  }

  /**
   * Descuento atómico por lote de inventario (evita múltiples escrituras y re-renders consecutivos)
   */
  public descontarStockBatch(
    itemsDescontar: Array<{ codigoEPP: string; cantidad: number }>,
    documentoReferencia: string = 'Entrega de EPP',
    trabajadorNombre?: string
  ): void {
    const movimientos: MovimientoKardex[] = [];
    const fechaHora = new Date().toISOString().replace('T', ' ').slice(0, 16);
    let huboCambios = false;

    itemsDescontar.forEach(it => {
      const idx = this.catalogoEPP.findIndex(
        e => e.codigo.trim().toUpperCase() === it.codigoEPP.trim().toUpperCase()
      );
      if (idx !== -1) {
        huboCambios = true;
        const item = this.catalogoEPP[idx];
        const stockAnterior = item.stockActual;
        const nuevoStock = Math.max(0, stockAnterior - it.cantidad);
        item.stockActual = nuevoStock;

        if (nuevoStock === 0) {
          item.estado = 'Agotado';
        } else if (nuevoStock <= item.stockMinimo) {
          item.estado = 'Stock Crítico';
        } else if (item.estado !== 'Inactivo') {
          item.estado = 'Disponible';
        }

        movimientos.push({
          id: `MOV-SAL-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          fechaHora,
          tipo: 'SALIDA',
          codigoEPP: item.codigo,
          articulo: item.articulo,
          documentoReferencia,
          trabajadorNombre,
          cantidad: it.cantidad,
          stockAnterior,
          stockResultante: nuevoStock,
          costoUnitario: item.costoUnitario,
          importeTotal: Number((it.cantidad * item.costoUnitario).toFixed(2))
        });
      }
    });

    if (huboCambios) {
      this.guardarEnLocalStorage();
      kardexStorage.registrarMovimientosBatch(movimientos);
      notifyStorageChange();
    }
  }

  /**
   * Suma automática de inventario (recepción de stock / compra)
   */
  public aumentarStock(
    codigoEPP: string,
    cantidad: number,
    costoUnitario?: number,
    documentoReferencia: string = 'Ingreso de Stock'
  ): void {
    const idx = this.catalogoEPP.findIndex(
      e => e.codigo.trim().toUpperCase() === codigoEPP.trim().toUpperCase()
    );
    if (idx !== -1) {
      const item = this.catalogoEPP[idx];
      const stockAnterior = item.stockActual;
      const nuevoStock = stockAnterior + cantidad;
      item.stockActual = nuevoStock;

      if (costoUnitario !== undefined && costoUnitario > 0) {
        item.costoUnitario = costoUnitario;
      }

      // Recalcular estado
      if (nuevoStock === 0) {
        item.estado = 'Agotado';
      } else if (nuevoStock <= item.stockMinimo) {
        item.estado = 'Stock Crítico';
      } else if (item.estado !== 'Inactivo') {
        item.estado = 'Disponible';
      }

      // Registrar movimiento de entrada en el Kardex
      kardexStorage.registrarMovimiento({
        id: `MOV-ENT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        fechaHora: new Date().toISOString().replace('T', ' ').slice(0, 16),
        tipo: 'ENTRADA',
        codigoEPP: item.codigo,
        articulo: item.articulo,
        documentoReferencia,
        cantidad,
        stockAnterior,
        stockResultante: nuevoStock,
        costoUnitario: costoUnitario || item.costoUnitario,
        importeTotal: Number((cantidad * (costoUnitario || item.costoUnitario)).toFixed(2))
      });

      this.guardarEnLocalStorage();
      notifyStorageChange();
    }
  }

  /**
   * Registro integral de un Ingreso de Stock con múltiples ítems (procesado en lote atómico)
   */
  public async registrarIngresoStock(ingreso: IngresoStock): Promise<{ success: boolean; mensaje: string }> {
    if (!ingreso || !Array.isArray(ingreso.items) || ingreso.items.length === 0) {
      return { success: false, mensaje: 'No hay ítems detallados en el ingreso.' };
    }

    const movimientos: MovimientoKardex[] = [];
    const fechaHora = new Date().toISOString().replace('T', ' ').slice(0, 16);
    let huboCambios = false;

    ingreso.items.forEach(it => {
      const idx = this.catalogoEPP.findIndex(
        e => e.codigo.trim().toUpperCase() === it.codigoEPP.trim().toUpperCase()
      );
      if (idx !== -1) {
        huboCambios = true;
        const item = this.catalogoEPP[idx];
        const stockAnterior = item.stockActual;
        const cantidad = Number(it.cantidad) || 0;
        const nuevoStock = stockAnterior + cantidad;
        item.stockActual = nuevoStock;

        const costo = it.costoUnitario ? Number(it.costoUnitario) : item.costoUnitario;
        if (it.costoUnitario && Number(it.costoUnitario) > 0) {
          item.costoUnitario = Number(it.costoUnitario);
        }

        if (nuevoStock === 0) {
          item.estado = 'Agotado';
        } else if (nuevoStock <= item.stockMinimo) {
          item.estado = 'Stock Crítico';
        } else if (item.estado !== 'Inactivo') {
          item.estado = 'Disponible';
        }

        movimientos.push({
          id: `MOV-ENT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          fechaHora,
          tipo: 'ENTRADA',
          codigoEPP: item.codigo,
          articulo: item.articulo,
          documentoReferencia: `Ingreso ${ingreso.numeroComprobante}`,
          cantidad,
          stockAnterior,
          stockResultante: nuevoStock,
          costoUnitario: costo,
          importeTotal: Number((cantidad * costo).toFixed(2))
        });
      }
    });

    if (huboCambios) {
      this.guardarEnLocalStorage();
      kardexStorage.registrarMovimientosBatch(movimientos);
    }

    kardexStorage.registrarIngreso(ingreso);

    // Sincronizar de forma remota a Google Apps Script si está configurado
    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      try {
        await GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'guardarIngresoStock',
          ingreso
        }, {
          tipo: 'entrega',
          descripcion: `Ingreso Stock ${ingreso.numeroComprobante} (${ingreso.totalUnidades} uds)`
        });
      } catch (e) {
        console.warn('Ingreso de stock encolado para sincronización:', e);
      }
    }

    notifyStorageChange();
    return {
      success: true,
      mensaje: `Ingreso ${ingreso.numeroComprobante} registrado con éxito (${ingreso.totalUnidades} unidades sumadas al inventario).`
    };
  }

  public async save(epp: EPPItem): Promise<void> {
    const idx = this.catalogoEPP.findIndex(e => e.codigo === epp.codigo);
    const stockActual = Number(epp.stockActual) || 0;
    const stockMinimo = Number(epp.stockMinimo) || 0;
    let estado = epp.estado || 'Disponible';
    if (stockActual === 0) {
      estado = 'Agotado';
    } else if (stockActual <= stockMinimo) {
      estado = 'Stock Crítico';
    } else if (estado !== 'Inactivo') {
      estado = 'Disponible';
    }

    const eppNormalizado = {
      ...epp,
      stockActual,
      stockMinimo,
      costoUnitario: Number(epp.costoUnitario) || 0,
      vidaUtilDias: Number(epp.vidaUtilDias) || 180,
      estado
    };

    const stockAnterior = idx !== -1 ? (Number(this.catalogoEPP[idx].stockActual) || 0) : 0;
    const diffStock = stockActual - stockAnterior;

    if (idx !== -1) {
      this.catalogoEPP[idx] = eppNormalizado;
    } else {
      this.catalogoEPP.push(eppNormalizado);
    }

    this.guardarEnLocalStorage();

    // Registrar movimiento de ajuste en Kardex si varió el stock físico
    if (diffStock !== 0) {
      const fechaHora = new Date().toISOString().replace('T', ' ').slice(0, 16);
      const absCantidad = Math.abs(diffStock);
      const tipo: 'ENTRADA' | 'SALIDA' = diffStock > 0 ? 'ENTRADA' : 'SALIDA';
      const mov: MovimientoKardex = {
        id: `MOV-AJU-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        fechaHora,
        tipo,
        codigoEPP: eppNormalizado.codigo,
        articulo: eppNormalizado.articulo,
        documentoReferencia: 'Ajuste manual de Catálogo',
        cantidad: absCantidad,
        stockAnterior,
        stockResultante: stockActual,
        costoUnitario: eppNormalizado.costoUnitario,
        importeTotal: Number((absCantidad * eppNormalizado.costoUnitario).toFixed(2))
      };
      kardexStorage.registrarMovimiento(mov);
    }

    notifyStorageChange();

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      GasService.enviarPost(cfg.gasWebAppUrl, {
        action: 'guardarEPP',
        epp: eppNormalizado
      }).catch(e => console.warn('Sync EPP GAS error:', e));
    }
  }

  public reset(): void {
    this.catalogoEPP = [...CATALOGO_EPP_SEED];
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }
}

export const eppItemsStorage = new EPPItemsStorage();
