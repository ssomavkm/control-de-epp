import { LiquidacionEPP, ItemLiquidacionEPP, EstadoLiquidacion, DocumentoEmitido } from '../../types';
import { LIQUIDACIONES_SEED } from '../../data/seeds/liquidaciones';
import { configStorage } from './configStorage';
import { trabajadoresStorage } from './trabajadoresStorage';
import { entregasStorage } from './entregasStorage';
import { eppItemsStorage } from './eppItemsStorage';
import { documentosStorage } from './documentosStorage';
import { notifyStorageChange } from './eventEmitter';
import { compararFechasDesc } from '../../utils/formatters';
import { GasService } from '../gasService';

export const STORAGE_KEY_LIQUIDACIONES = 'ssoma_liquidaciones_v1';

class LiquidacionesStorage {
  private liquidaciones: LiquidacionEPP[] = [];

  constructor() {
    this.cargarLiquidacionesPersistidas();
  }

  private cargarLiquidacionesPersistidas(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_LIQUIDACIONES);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((l: any) => l.codigoTrabajador === 'TRAB-P001' || l.dni === '45892134');
          if (!tieneMocksAntiguos) {
            this.liquidaciones = parsed.sort((a, b) =>
              compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro)
            );
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer liquidaciones de localStorage:', e);
    }
    this.liquidaciones = [...LIQUIDACIONES_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro)
    );
    this.guardarEnLocalStorage();
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_LIQUIDACIONES, JSON.stringify(this.liquidaciones));
    } catch (e) {
      console.warn('Error al persistir liquidaciones en localStorage:', e);
    }
  }

  public getAll(): LiquidacionEPP[] {
    return this.liquidaciones
      .map((liq) => ({
        ...liq,
        items: Array.isArray(liq.items) ? liq.items : []
      }))
      .sort((a, b) =>
        compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro)
      );
  }

  public getById(id: string): LiquidacionEPP | undefined {
    return this.liquidaciones.find((l) => l.id === id || l.numeroRegistro === id);
  }

  public getByTrabajador(codigoTrabajador: string): LiquidacionEPP[] {
    return this.liquidaciones
      .filter((l) => l.codigoTrabajador === codigoTrabajador)
      .sort((a, b) =>
        compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro)
      );
  }

  public setAll(liquidaciones: LiquidacionEPP[]): void {
    const idsUsados = new Set<string>();
    this.liquidaciones = (Array.isArray(liquidaciones) ? liquidaciones : []).map((liq, idx) => {
      let id = liq.id ? String(liq.id).trim() : `LIQ-${idx + 1}`;
      if (idsUsados.has(id)) {
        id = `${id}-${idx + 1}`;
      }
      idsUsados.add(id);

      let itemsNormalizados: ItemLiquidacionEPP[] = [];
      const anyLiq = liq as any;
      const rawItems = anyLiq.items ?? anyLiq.itemsJson ?? anyLiq.items_json;
      if (Array.isArray(rawItems)) {
        itemsNormalizados = rawItems;
      } else if (typeof rawItems === 'string' && rawItems.trim()) {
        try {
          const parsed = JSON.parse(rawItems);
          if (Array.isArray(parsed)) {
            itemsNormalizados = parsed;
          }
        } catch {
          itemsNormalizados = [];
        }
      }

      const totalItemsEntregados = itemsNormalizados.reduce((acc, it) => acc + (Number(it.cantidadEntregada) || 0), 0);
      const totalItemsDevueltos = itemsNormalizados.reduce((acc, it) => acc + (Number(it.cantidadDevuelta) || 0), 0);
      const totalItemsVencidos = itemsNormalizados.reduce((acc, it) => acc + (Number(it.cantidadVencida) || 0), 0);
      const totalItemsALiquidar = itemsNormalizados.reduce((acc, it) => acc + (Number(it.cantidadALiquidar) || 0), 0);
      const montoTotalEntregado = itemsNormalizados.reduce((acc, it) => acc + (Number(it.importeTotalEntregado) || 0), 0);
      const montoNetoALiquidar = itemsNormalizados.reduce((acc, it) => acc + (Number(it.montoALiquidar) || 0), 0);
      const montoDescontado = Math.max(0, montoTotalEntregado - montoNetoALiquidar);

      return {
        ...liq,
        id,
        items: itemsNormalizados,
        totalItemsEntregados: Number(liq.totalItemsEntregados) || totalItemsEntregados,
        totalItemsDevueltos: Number(liq.totalItemsDevueltos) || totalItemsDevueltos,
        totalItemsVencidos: Number(liq.totalItemsVencidos) || totalItemsVencidos,
        totalItemsALiquidar: Number(liq.totalItemsALiquidar) || totalItemsALiquidar,
        montoTotalEntregado: Number(liq.montoTotalEntregado) || montoTotalEntregado,
        montoDescontadoVencidosYDevueltos: Number(liq.montoDescontadoVencidosYDevueltos) || montoDescontado,
        montoNetoALiquidar: Number(liq.montoNetoALiquidar) !== undefined ? Number(liq.montoNetoALiquidar) : montoNetoALiquidar
      };
    }).sort((a, b) =>
      compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro)
    );

    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(liquidaciones: LiquidacionEPP[]): void {
    this.setAll(liquidaciones);
  }

  public generarNuevoNumero(): string {
    const nums = this.liquidaciones
      .map((l) => parseInt(l.numeroRegistro.replace(/\D/g, ''), 10))
      .filter((n) => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `ACTA-LIQ-${String(next).padStart(4, '0')}`;
  }

  public generarNuevoId(): string {
    const nums = this.liquidaciones
      .map((l) => {
        const parts = l.id.split('-');
        return parseInt(parts[parts.length - 1], 10);
      })
      .filter((n) => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `LIQ-${new Date().getFullYear()}-${String(next).padStart(4, '0')}`;
  }

  /**
   * Genera el inventario preliminar de todos los EPP entregados al trabajador
   * evaluando automáticamente la amortización por vida útil vs vigencia.
   */
  public prepararAuditoriaCese(codigoTrabajador: string, fechaCese?: string): {
    trabajador?: any;
    items: ItemLiquidacionEPP[];
    totalEntregados: number;
    montoTotal: number;
  } {
    const trab = trabajadoresStorage.getByCodigo(codigoTrabajador);
    if (!trab) {
      return { items: [], totalEntregados: 0, montoTotal: 0 };
    }

    const fechaReferencia = fechaCese || new Date().toISOString().slice(0, 10);

    // Obtener todas las entregas históricas del trabajador
    const entregasTrabajador = entregasStorage
      .getAll()
      .filter(
        (e) =>
          String(e.codigoTrabajador || '').trim() === codigoTrabajador ||
          (trab.dni && String(e.dni || '').trim() === trab.dni)
      );

    const itemsAuditoria: ItemLiquidacionEPP[] = [];

    entregasTrabajador.forEach((ent) => {
      (ent.detalles || []).forEach((det, dIdx) => {
        const cant = Number(det.cantidad) || 1;
        const costo = Number(det.costoUnitario) || (Number(det.importe) && cant > 0 ? Number(det.importe) / cant : 0);
        const importeTotal = Number(det.importe) || (cant * costo);

        // Buscar información en catálogo para vida útil
        const itemCat = eppItemsStorage.getByCodigo(det.codigoEPP);
        const vidaUtilDias = itemCat?.vidaUtilDias || (det.tipo === 'Uniforme' ? 365 : 180);

        // Calcular fecha estimada de vencimiento si no viene explícita
        let fechaVenc = det.fechaRenovacion;
        if (!fechaVenc && ent.fechaEntrega) {
          const fEnt = new Date(ent.fechaEntrega);
          if (!isNaN(fEnt.getTime())) {
            const fV = new Date(fEnt.getTime() + vidaUtilDias * 24 * 60 * 60 * 1000);
            fechaVenc = fV.toISOString().slice(0, 10);
          }
        }
        if (!fechaVenc) {
          fechaVenc = ent.fechaEntrega;
        }

        // Determinar condición inicial según vida útil
        const estaVencido = Boolean(fechaVenc && fechaVenc <= fechaReferencia);

        let estadoInicial: 'Vencido' | 'Devuelto' = estaVencido ? 'Vencido' : 'Devuelto';
        let cantDevuelta = estaVencido ? 0 : cant;
        let cantVencida = estaVencido ? cant : 0;
        let cantALiquidar = 0;
        let montoALiquidar = 0;

        itemsAuditoria.push({
          idItem: `AUDIT-${ent.numeroRegistro || ent.id}-${dIdx + 1}-${Date.now() % 10000}`,
          idEntregaOrigen: ent.id,
          numeroRegistroOrigen: ent.numeroRegistro,
          fechaEntrega: ent.fechaEntrega,
          codigoEPP: det.codigoEPP,
          articulo: det.articulo,
          categoria: det.categoria || itemCat?.categoria,
          tipo: det.tipo,
          talla: det.talla || 'Estándar',
          unidad: det.unidad || 'Unidad',
          cantidadEntregada: cant,
          cantidadDevuelta: cantDevuelta,
          cantidadVencida: cantVencida,
          cantidadALiquidar: cantALiquidar,
          costoUnitario: costo,
          importeTotalEntregado: importeTotal,
          montoALiquidar: montoALiquidar,
          vidaUtilDias,
          fechaVencimiento: fechaVenc,
          estadoItem: estadoInicial,
          observaciones: estaVencido
            ? 'Amortizado 100% por tiempo de vida útil cumplido. No genera costo al trabajador.'
            : 'Equipo con vida útil vigente disponible para devolución al almacén.'
        });
      });
    });

    const totalEntregados = itemsAuditoria.reduce((acc, it) => acc + it.cantidadEntregada, 0);
    const montoTotal = itemsAuditoria.reduce((acc, it) => acc + it.importeTotalEntregado, 0);

    return {
      trabajador: trab,
      items: itemsAuditoria,
      totalEntregados,
      montoTotal
    };
  }

  public async registrar(
    liquidacion: LiquidacionEPP
  ): Promise<{ success: boolean; mensaje: string }> {
    const existeIndex = this.liquidaciones.findIndex(
      (l) => l.id === liquidacion.id || l.numeroRegistro === liquidacion.numeroRegistro
    );

    if (existeIndex !== -1) {
      this.liquidaciones[existeIndex] = liquidacion;
    } else {
      this.liquidaciones.unshift(liquidacion);
    }

    // Registrar en Control Documental unificado
    try {
      const docEmitido: DocumentoEmitido = {
        id: `DOC-LIQ-${liquidacion.numeroRegistro}`,
        idEntrega: liquidacion.id,
        numeroRegistro: liquidacion.numeroRegistro,
        codigoTrabajador: liquidacion.codigoTrabajador,
        dni: liquidacion.dni,
        trabajador: liquidacion.trabajadorNombre,
        empresaId: liquidacion.empresaId,
        empresaNombre: liquidacion.empresaNombre,
        ruc: liquidacion.ruc,
        codigoPlantilla: liquidacion.codigoPlantilla || 'FO-SST-LIQ-001',
        versionPlantilla: liquidacion.versionPlantilla || '01',
        versionDocumento: '1.0',
        fechaHoraEmision: `${liquidacion.fechaLiquidacion} ${new Date().toLocaleTimeString().slice(0, 5)}`,
        responsable: liquidacion.supervisorResponsable,
        estadoDocumental: 'Emitido',
        fileName: liquidacion.pdfFileName || `LIQUIDACION_EPP_${liquidacion.numeroRegistro}_${liquidacion.dni}.pdf`
      };
      documentosStorage.add(docEmitido);
    } catch (e) {
      console.warn('Error al reflejar liquidación en documentosStorage:', e);
    }

    this.guardarEnLocalStorage();
    notifyStorageChange();

    // Transmitir a Google Sheets en segundo plano con resguardo en cola offline
    try {
      const cfg = configStorage.get();
      if (cfg.gasWebAppUrl) {
        GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'guardarLiquidacion',
          liquidacion
        }, {
          tipo: 'generico',
          descripcion: `Liquidación EPP ${liquidacion.numeroRegistro} (${liquidacion.trabajadorNombre})`
        }).catch(err => console.warn('Aviso sincronización remota liquidación:', err));
      }
    } catch (e) {
      console.warn('Error enviando liquidación a Google Sheets:', e);
    }

    return {
      success: true,
      mensaje: `Acta de Liquidación de EPP ${liquidacion.numeroRegistro} guardada exitosamente.`
    };
  }

  public updateEstado(id: string, nuevoEstado: EstadoLiquidacion): void {
    const item = this.liquidaciones.find((l) => l.id === id);
    if (item) {
      item.estado = nuevoEstado;
      this.guardarEnLocalStorage();
      notifyStorageChange();
    }
  }

  public delete(id: string): void {
    this.liquidaciones = this.liquidaciones.filter((l) => l.id !== id);
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public reset(): void {
    this.liquidaciones = [...LIQUIDACIONES_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaCese || a.fechaLiquidacion, b.fechaCese || b.fechaLiquidacion, a.numeroRegistro, b.numeroRegistro)
    );
    try {
      localStorage.removeItem(STORAGE_KEY_LIQUIDACIONES);
    } catch (e) {
      console.warn('Error al limpiar liquidaciones de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const liquidacionesStorage = new LiquidacionesStorage();
