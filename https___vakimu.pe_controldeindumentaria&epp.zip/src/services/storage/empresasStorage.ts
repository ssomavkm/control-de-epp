import { Empresa, EmpresaId } from '../../types';
import { EMPRESAS_SEED } from '../../data/seeds/empresas';
import { notifyStorageChange } from './eventEmitter';
import { normalizarEmpresaId } from '../../utils/empresaResolver';

class EmpresasStorage {
  private empresas: Empresa[] = [...EMPRESAS_SEED];

  public getAll(): Empresa[] {
    return this.empresas.map(e => this.normalizarEmpresa(e));
  }

  public getById(id: EmpresaId): Empresa | undefined {
    const targetNorm = normalizarEmpresaId(id);
    const encontrada = this.empresas.find(e => {
      const norm = this.normalizarEmpresa(e);
      return norm.id === id || norm.id === targetNorm;
    });
    if (encontrada) return this.normalizarEmpresa(encontrada);
    return EMPRESAS_SEED.find(e => e.id === id || normalizarEmpresaId(e.id) === targetNorm);
  }

  private normalizarEmpresa(raw: Partial<Empresa>): Empresa {
    const rucStr = String(raw.ruc || '').trim();
    const razonSocialStr = String(raw.razonSocial || '').trim();
    const id: EmpresaId = normalizarEmpresaId({
      empresaId: raw.id,
      razonSocial: razonSocialStr,
      ruc: rucStr
    });
    const seed = EMPRESAS_SEED.find(s => s.id === id || normalizarEmpresaId(s.id) === id) || EMPRESAS_SEED[0];

    return {
      id,
      ruc: rucStr || seed.ruc,
      razonSocial: razonSocialStr || seed.razonSocial,
      direccion: String(raw.direccion || '').trim() || seed.direccion,
      actividadEconomica: String(raw.actividadEconomica || '').trim() || seed.actividadEconomica,
      codigoPlantilla: String(raw.codigoPlantilla || seed.codigoPlantilla || 'FO-SST-GEN-050'),
      versionPlantilla: String(raw.versionPlantilla || seed.versionPlantilla || '02'),
      fechaEmisionPlantilla: String(raw.fechaEmisionPlantilla || seed.fechaEmisionPlantilla || '02/01/2026'),
      logoUrl: raw.logoUrl || seed.logoUrl,
      estado: 'Activo'
    };
  }

  public setAll(empresas: Empresa[]): void {
    if (!Array.isArray(empresas) || empresas.length === 0) {
      this.empresas = [...EMPRESAS_SEED];
    } else {
      const normalizadas = empresas.map(e => this.normalizarEmpresa(e));
      const tienePerpol = normalizadas.some(e => e.id === 'EMP-PERPOL' || e.id === 'PERPOL');
      const tieneTr3 = normalizadas.some(e => e.id === 'EMP-TR3' || e.id === 'TR3');

      if (!tienePerpol) {
        const seedPerpol = EMPRESAS_SEED.find(s => s.id === 'EMP-PERPOL' || s.id === 'PERPOL');
        if (seedPerpol) normalizadas.push(seedPerpol);
      }
      if (!tieneTr3) {
        const seedTr3 = EMPRESAS_SEED.find(s => s.id === 'EMP-TR3' || s.id === 'TR3');
        if (seedTr3) normalizadas.push(seedTr3);
      }

      this.empresas = normalizadas;
    }
    notifyStorageChange();
  }

  public saveAll(empresas: Empresa[]): void {
    this.setAll(empresas);
  }

  public updateLogo(empresaId: EmpresaId, logoUrl: string): void {
    const targetNorm = normalizarEmpresaId(empresaId);
    const idx = this.empresas.findIndex(e => e.id === empresaId || normalizarEmpresaId(e.id) === targetNorm);
    if (idx !== -1) {
      this.empresas[idx].logoUrl = logoUrl;
      notifyStorageChange();
    }
  }

  public reset(): void {
    this.empresas = [...EMPRESAS_SEED];
    notifyStorageChange();
  }
}

export const empresasStorage = new EmpresasStorage();
