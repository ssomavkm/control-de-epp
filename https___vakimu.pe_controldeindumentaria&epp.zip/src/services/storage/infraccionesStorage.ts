import { InfraccionEPP } from '../../types';
import { INFRACCIONES_SEED } from '../../data/seeds/infracciones';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { notifyStorageChange } from './eventEmitter';
import { compararFechasDesc } from '../../utils/formatters';

export const STORAGE_KEY_INFRACCIONES = 'ssoma_infracciones_v1';

class InfraccionesStorage {
  private infracciones: InfraccionEPP[] = [];

  constructor() {
    this.cargarPersistidas();
  }

  private cargarPersistidas(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_INFRACCIONES);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((inf: any) => inf.codigoTrabajador === 'TRAB-P001' || inf.dni === '45892134');
          if (!tieneMocksAntiguos) {
            this.infracciones = parsed.sort((a: any, b: any) =>
              compararFechasDesc(a.fechaHora, b.fechaHora, a.numeroReporte, b.numeroReporte)
            );
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer infracciones de localStorage:', e);
    }
    this.infracciones = [...INFRACCIONES_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaHora, b.fechaHora, a.numeroReporte, b.numeroReporte)
    );
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_INFRACCIONES, JSON.stringify(this.infracciones));
    } catch (e) {
      console.warn('Error al persistir infracciones en localStorage:', e);
    }
  }

  public getAll(): InfraccionEPP[] {
    return this.infracciones
      .map(inf => ({
        ...inf,
        eppsOmitidos: Array.isArray(inf.eppsOmitidos) ? inf.eppsOmitidos : []
      }))
      .sort((a, b) =>
        compararFechasDesc(a.fechaHora, b.fechaHora, a.numeroReporte, b.numeroReporte)
      );
  }

  public setAll(infracciones: InfraccionEPP[]): void {
    const idsUsados = new Set<string>();
    this.infracciones = (Array.isArray(infracciones) ? infracciones : []).map((inf, idx) => {
      let id = inf.id ? String(inf.id).trim() : `INF-${idx + 1}`;
      if (idsUsados.has(id)) {
        id = `${id}-${idx + 1}`;
      }
      idsUsados.add(id);

      let eppsOmitidos: string[] = [];
      const anyInf = inf as any;
      const rawEpps = anyInf.eppsOmitidos ?? anyInf.epps_omitidos;
      if (Array.isArray(rawEpps)) {
        eppsOmitidos = rawEpps;
      } else if (typeof rawEpps === 'string' && rawEpps.trim()) {
        try {
          const parsed = JSON.parse(rawEpps);
          if (Array.isArray(parsed)) {
            eppsOmitidos = parsed;
          } else {
            eppsOmitidos = rawEpps.split(',').map(s => s.trim()).filter(Boolean);
          }
        } catch {
          eppsOmitidos = rawEpps.split(',').map(s => s.trim()).filter(Boolean);
        }
      }

      return {
        ...inf,
        id,
        eppsOmitidos
      };
    }).sort((a, b) =>
      compararFechasDesc(a.fechaHora, b.fechaHora, a.numeroReporte, b.numeroReporte)
    );
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(infracciones: InfraccionEPP[]): void {
    this.setAll(infracciones);
  }

  public generarNuevoNumero(): string {
    const nums = this.infracciones
      .map(i => parseInt(i.numeroReporte.replace(/\D/g, ''), 10))
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `REP-INF-${String(next).padStart(4, '0')}`;
  }

  public generarNuevoId(): string {
    const nums = this.infracciones
      .map(i => {
        const parts = i.id.split('-');
        return parseInt(parts[parts.length - 1], 10);
      })
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `INF-${new Date().getFullYear()}-${String(next).padStart(4, '0')}`;
  }

  public contarPorTrabajador(codigoTrabajador: string): number {
    return this.infracciones.filter(
      i => i.codigoTrabajador === codigoTrabajador && i.estado !== 'Anulada'
    ).length;
  }

  public async registrar(infraccion: InfraccionEPP): Promise<{ success: boolean; mensaje: string }> {
    const existeIdx = this.infracciones.findIndex(
      i => i.id === infraccion.id || i.numeroReporte === infraccion.numeroReporte
    );
    if (existeIdx !== -1) {
      this.infracciones[existeIdx] = infraccion;
    } else {
      this.infracciones.unshift(infraccion);
    }

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      const empresaIdCanonica = infraccion.empresaId === 'EMP-PERPOL' || infraccion.empresaId === 'PERPOL' ? 'PERPOL' : 'TR3';
      GasService.enviarPost(cfg.gasWebAppUrl, {
        action: 'guardarInfraccion',
        infraccion: {
          ...infraccion,
          empresaId: empresaIdCanonica
        }
      }).catch(e => console.warn('Sync infraccion GAS error:', e));
    }

    this.guardarEnLocalStorage();
    notifyStorageChange();
    return {
      success: true,
      mensaje: `Reporte de infracción ${infraccion.numeroReporte} registrado exitosamente.`
    };
  }

  public updateEstado(id: string, nuevoEstado: InfraccionEPP['estado']): void {
    const idx = this.infracciones.findIndex(i => i.id === id);
    if (idx !== -1) {
      this.infracciones[idx] = { ...this.infracciones[idx], estado: nuevoEstado };
      const cfg = configStorage.get();
      if (cfg.gasWebAppUrl) {
        GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'guardarInfraccion',
          infraccion: this.infracciones[idx]
        }).catch(e => console.warn('Sync update infraccion error:', e));
      }
      this.guardarEnLocalStorage();
      notifyStorageChange();
    }
  }

  public delete(id: string): void {
    this.infracciones = this.infracciones.filter(i => i.id !== id);
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public reset(): void {
    this.infracciones = [...INFRACCIONES_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaHora, b.fechaHora, a.numeroReporte, b.numeroReporte)
    );
    try {
      localStorage.removeItem(STORAGE_KEY_INFRACCIONES);
    } catch (e) {
      console.warn('Error al limpiar infracciones de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const infraccionesStorage = new InfraccionesStorage();
