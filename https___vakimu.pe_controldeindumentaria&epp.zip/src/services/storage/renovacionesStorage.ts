import { ItemRenovacion } from '../../types';
import { entregasStorage } from './entregasStorage';

class RenovacionesStorage {
  public getAll(): ItemRenovacion[] {
    const entregas = entregasStorage.getAll();
    const items: ItemRenovacion[] = [];
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    entregas.forEach(entrega => {
      if (!entrega) return;
      (entrega.detalles || []).forEach(det => {
        if (!det || !det.fechaRenovacion) return;

        const fRenov = new Date(det.fechaRenovacion + 'T00:00:00');
        const diffTiempo = fRenov.getTime() - hoy.getTime();
        const diasRestantes = Math.ceil(diffTiempo / (1000 * 60 * 60 * 24));

        let estadoRenovacion: 'Vencido' | 'Próximo a vencer' | 'Vigente';
        if (diasRestantes <= 0) {
          estadoRenovacion = 'Vencido';
        } else if (diasRestantes <= 15) {
          estadoRenovacion = 'Próximo a vencer';
        } else {
          estadoRenovacion = 'Vigente';
        }

        items.push({
          idDetalle: det.idDetalle,
          idEntrega: entrega.id,
          numeroRegistro: entrega.numeroRegistro,
          codigoTrabajador: entrega.codigoTrabajador,
          trabajadorNombre: entrega.trabajadorNombre,
          dni: entrega.dni,
          empresaId: entrega.empresaId,
          empresaNombre: entrega.razonSocial,
          area: entrega.area,
          cargo: entrega.cargo,
          codigoEPP: det.codigoEPP,
          articulo: det.articulo,
          tipo: det.tipo,
          talla: det.talla,
          cantidad: det.cantidad,
          fechaEntrega: entrega.fechaEntrega,
          fechaRenovacion: det.fechaRenovacion,
          diasRestantes,
          estadoRenovacion
        });
      });
    });

    return items;
  }
}

export const renovacionesStorage = new RenovacionesStorage();
