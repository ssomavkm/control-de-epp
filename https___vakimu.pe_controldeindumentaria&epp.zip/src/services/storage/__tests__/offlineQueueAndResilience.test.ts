import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { offlineQueue } from '../sync/offlineQueue';
import { GasService } from '../../gasService';

describe('Mejoras Inmediatas de Conexión en Frontend (Resiliencia Local-First)', () => {
  beforeEach(() => {
    localStorage.clear();
    offlineQueue.limpiar();
    vi.restoreAllMocks();
  });

  afterEach(() => {
    localStorage.clear();
    offlineQueue.limpiar();
  });

  describe('D. Cola de Mutaciones Offline (Local-First Sync Queue)', () => {
    it('inicia con 0 elementos en cola', () => {
      expect(offlineQueue.obtenerCantidadPendientes()).toBe(0);
      expect(offlineQueue.obtenerPendientes()).toEqual([]);
    });

    it('encola una mutación y la guarda en localStorage con timestamp e id único', () => {
      const mutacion = offlineQueue.encolar({
        tipo: 'entrega',
        descripcion: 'Entrega EPP-001 Juan Perez',
        action: 'guardarEntrega',
        payload: { entrega: { numeroRegistro: 'EPP-001', dni: '12345678' } }
      });

      expect(mutacion.id).toMatch(/^MUT-/);
      expect(mutacion.timestamp).toBeGreaterThan(0);
      expect(offlineQueue.obtenerCantidadPendientes()).toBe(1);

      const items = offlineQueue.obtenerPendientes();
      expect(items[0].descripcion).toBe('Entrega EPP-001 Juan Perez');
      expect(items[0].tipo).toBe('entrega');
    });

    it('permite eliminar un elemento de la cola por ID', () => {
      const mut1 = offlineQueue.encolar({
        tipo: 'entrega',
        descripcion: 'Entrega 1',
        action: 'guardarEntrega',
        payload: {}
      });
      const mut2 = offlineQueue.encolar({
        tipo: 'inspeccion',
        descripcion: 'Inspeccion 1',
        action: 'guardarInspeccion',
        payload: {}
      });

      expect(offlineQueue.obtenerCantidadPendientes()).toBe(2);
      offlineQueue.eliminar(mut1.id);
      expect(offlineQueue.obtenerCantidadPendientes()).toBe(1);
      expect(offlineQueue.obtenerPendientes()[0].id).toBe(mut2.id);
    });

    it('notifica a los suscriptores cuando cambia el tamaño de la cola', () => {
      const listener = vi.fn();
      const unsub = offlineQueue.suscribir(listener);

      expect(listener).toHaveBeenCalledWith(0);

      offlineQueue.encolar({
        tipo: 'trabajador',
        descripcion: 'Nuevo trabajador',
        action: 'guardarTrabajador',
        payload: {}
      });

      expect(listener).toHaveBeenCalledWith(1);
      unsub();

      offlineQueue.encolar({
        tipo: 'descuento',
        descripcion: 'Descuento reposicion',
        action: 'guardarDescuento',
        payload: {}
      });

      // Ya desuscrito, no debería llamarse de nuevo
      expect(listener).toHaveBeenCalledTimes(2); // llamada inicial + 1er encole
    });

    it('procesa y vacía la cola exitosamente cuando hay conexión a Google Sheets', async () => {
      offlineQueue.encolar({
        tipo: 'entrega',
        descripcion: 'Entrega #100',
        action: 'guardarEntrega',
        payload: { action: 'guardarEntrega' }
      });
      offlineQueue.encolar({
        tipo: 'inspeccion',
        descripcion: 'Inspección Planta #200',
        action: 'guardarInspeccion',
        payload: { action: 'guardarInspeccion' }
      });

      vi.spyOn(GasService, 'enviarPostDirecto').mockResolvedValue({ estado: 'ok' });

      const resultado = await offlineQueue.procesarCola('https://script.google.com/macros/s/test/exec');

      expect(resultado.procesados).toBe(2);
      expect(resultado.fallidos).toBe(0);
      expect(offlineQueue.obtenerCantidadPendientes()).toBe(0);
    });
  });

  describe('C. Reintentos Automáticos y Fallback a Cola Offline', () => {
    it('GasService.enviarPost resguarda en cola automáticamente ante fallo o modo offline', async () => {
      // Simular fallo en llamada directa
      vi.spyOn(GasService, 'enviarPostDirecto').mockRejectedValue(new Error('Network error'));

      const respuesta = await GasService.enviarPost(
        'https://script.google.com/macros/s/test/exec',
        { action: 'guardarEntrega', entrega: { numeroRegistro: 'REG-999' } }
      );

      expect(respuesta.estado).toBe('ok');
      expect(respuesta.encolado).toBe(true);
      expect(offlineQueue.obtenerCantidadPendientes()).toBe(1);
      expect(offlineQueue.obtenerPendientes()[0].descripcion).toContain('REG-999');
    });
  });
});
