import { describe, it, expect, beforeEach } from 'vitest';
import { liquidacionesStorage } from '../liquidacionesStorage';
import { eppItemsStorage } from '../eppItemsStorage';
import { kardexStorage } from '../kardexStorage';
import { useEPPStore } from '../../../store/useEPPStore';
import { EPPItem, LiquidacionEPP } from '../../../types';

describe('Auditoría de Comunicación de Datos - Verificación de Correcciones (H-01, H-03, H-04)', () => {
  beforeEach(() => {
    localStorage.clear();
    liquidacionesStorage.reset();
  });

  describe('H-01: Persistencia de Liquidaciones en LocalStorage', () => {
    it('persiste liquidaciones en localStorage y las restaura tras reinicio o recarga', async () => {
      const num = liquidacionesStorage.generarNuevoNumero();
      const id = liquidacionesStorage.generarNuevoId();

      const nuevaLiq: LiquidacionEPP = {
        id,
        numeroRegistro: num,
        codigoPlantilla: 'FO-SST-LIQ-001',
        versionPlantilla: '01',
        fechaLiquidacion: '2026-03-15',
        fechaCese: '2026-03-14',
        motivoCese: 'Renuncia Voluntaria',
        codigoTrabajador: 'TRAB-001',
        dni: '70105321',
        trabajadorNombre: 'Rojas Alderete Jhon Piero',
        empresaId: 'EMP-TR3',
        empresaNombre: 'TR3 ALIMENTOS S.A.C.',
        ruc: '20550842891',
        area: 'PRODUCCION',
        cargo: 'SUPERVISOR DE SSOMA',
        items: [],
        totalItemsEntregados: 0,
        totalItemsDevueltos: 0,
        totalItemsVencidos: 0,
        totalItemsALiquidar: 0,
        montoTotalEntregado: 0,
        montoDescontadoVencidosYDevueltos: 0,
        montoNetoALiquidar: 0,
        supervisorResponsable: 'Ing. Jhon Rojas',
        cargoSupervisor: 'Supervisor SSOMA',
        estado: 'Emitida',
        fechaCreacion: new Date().toISOString()
      };

      await liquidacionesStorage.registrar(nuevaLiq);

      // Comprobar que está en localStorage
      const guardadoEnLS = localStorage.getItem('ssoma_liquidaciones_v1');
      expect(guardadoEnLS).not.toBeNull();
      const parsed = JSON.parse(guardadoEnLS!);
      expect(parsed.some((l: LiquidacionEPP) => l.id === id)).toBe(true);

      // Comprobar persistencia ante actualización de estado
      liquidacionesStorage.updateEstado(id, 'Liquidada en Planilla');
      const parsedUpdated = JSON.parse(localStorage.getItem('ssoma_liquidaciones_v1')!);
      const liqActualizada = parsedUpdated.find((l: LiquidacionEPP) => l.id === id);
      expect(liqActualizada.estado).toBe('Liquidada en Planilla');

      // Comprobar persistencia ante eliminación
      liquidacionesStorage.delete(id);
      const parsedDeleted = JSON.parse(localStorage.getItem('ssoma_liquidaciones_v1')!);
      expect(parsedDeleted.find((l: LiquidacionEPP) => l.id === id)).toBeUndefined();
    });
  });

  describe('H-03: Sincronización Automática Catálogo - Kardex', () => {
    beforeEach(() => {
      eppItemsStorage.setAll([
        {
          codigo: 'EPP-CAS-01',
          articulo: 'Casco de Seguridad Blanco',
          categoria: 'Protección Craneal',
          tipo: 'EPP',
          marca: '3M',
          modelo: 'H-700',
          norma: 'ANSI Z89.1',
          talla: 'Estándar',
          unidad: 'Unidad',
          vidaUtilDias: 365,
          costoUnitario: 35.5,
          stockActual: 20,
          stockMinimo: 5,
          estado: 'Disponible'
        }
      ]);
    });

    it('genera un asiento en Kardex cuando se modifica el stock de un EPP en el catálogo', async () => {
      const epps = eppItemsStorage.getAll();
      const targetEPP = epps[0];
      expect(targetEPP).toBeDefined();

      const stockInicial = targetEPP.stockActual;
      const nuevoStock = stockInicial + 15;
      const kardexAntes = kardexStorage.getMovimientosPorEPP(targetEPP.codigo).length;

      // Actualizar stock del EPP mediante eppItemsStorage.save
      const eppModificado: EPPItem = {
        ...targetEPP,
        stockActual: nuevoStock
      };
      await eppItemsStorage.save(eppModificado);

      // Verificar que se haya registrado un movimiento de entrada en Kardex
      const kardexDespues = kardexStorage.getMovimientosPorEPP(targetEPP.codigo);
      expect(kardexDespues.length).toBe(kardexAntes + 1);

      // Los movimientos en kardexStorage se agregan al inicio (unshift), por lo que kardexDespues[0] es el más reciente
      const ultimoMov = kardexDespues[0];
      expect(ultimoMov.tipo).toBe('ENTRADA');
      expect(ultimoMov.cantidad).toBe(15);
      expect(ultimoMov.stockResultante).toBe(nuevoStock);
      expect(ultimoMov.documentoReferencia).toContain('Ajuste manual de Catálogo');
    });

    it('genera un movimiento de SALIDA si el stock se reduce manualmente', async () => {
      const epps = eppItemsStorage.getAll();
      const targetEPP = epps[0];
      const stockInicial = targetEPP.stockActual;
      const nuevoStock = Math.max(0, stockInicial - 5);

      await eppItemsStorage.save({
        ...targetEPP,
        stockActual: nuevoStock
      });

      const movimientos = kardexStorage.getMovimientosPorEPP(targetEPP.codigo);
      const ultimoMov = movimientos[0];
      expect(ultimoMov.tipo).toBe('SALIDA');
      expect(ultimoMov.cantidad).toBe(5);
      expect(ultimoMov.stockResultante).toBe(nuevoStock);
      expect(ultimoMov.documentoReferencia).toContain('Ajuste manual de Catálogo');
    });
  });

  describe('H-04: Limpieza de Parámetros Preseleccionados en store', () => {
    it('iniciarEntregaParametrizada y limpiar restablecen correctamente el estado del store', () => {
      const store = useEPPStore.getState();

      store.iniciarEntregaParametrizada('TRAB-001', 'EPP-001');
      expect(useEPPStore.getState().trabajadorPreseleccionado).toBe('TRAB-001');
      expect(useEPPStore.getState().eppPreseleccionado).toBe('EPP-001');

      // Limpieza manual
      useEPPStore.getState().setTrabajadorPreseleccionado(undefined);
      useEPPStore.getState().setEppPreseleccionado(undefined);
      expect(useEPPStore.getState().trabajadorPreseleccionado).toBeUndefined();
      expect(useEPPStore.getState().eppPreseleccionado).toBeUndefined();
    });

    it('iniciarDescuentoParametrizado y limpiar datos preseleccionados', () => {
      const store = useEPPStore.getState();

      store.iniciarDescuentoParametrizado('TRAB-001', 'EPP-001', {
        codigoTrabajador: 'TRAB-001',
        codigoEPP: 'EPP-001',
        motivoDescuento: 'Pérdida en planta'
      });
      expect(useEPPStore.getState().datosDescuentoPreseleccionados).not.toBeNull();
      expect(useEPPStore.getState().trabajadorPreseleccionado).toBe('TRAB-001');

      // Limpiar
      useEPPStore.getState().setDatosDescuentoPreseleccionados(null);
      useEPPStore.getState().setTrabajadorPreseleccionado(undefined);
      useEPPStore.getState().setEppPreseleccionado(undefined);

      expect(useEPPStore.getState().datosDescuentoPreseleccionados).toBeNull();
      expect(useEPPStore.getState().trabajadorPreseleccionado).toBeUndefined();
    });
  });
});
