import { describe, it, expect } from 'vitest';
import { normalizarEmpresaIdParaSheets } from '../../../utils/empresaResolver';
import { inspeccionesStorage } from '../inspeccionesStorage';
import { descuentosStorage } from '../descuentosStorage';
import { infraccionesStorage } from '../infraccionesStorage';

describe('Corrección de empresaId para Google Sheets (PERPOL y TR3)', () => {
  it('normalizarEmpresaIdParaSheets devuelve estrictamente "PERPOL" o "TR3"', () => {
    // Casos PERPOL
    expect(normalizarEmpresaIdParaSheets('EMP-PERPOL')).toBe('PERPOL');
    expect(normalizarEmpresaIdParaSheets('PERPOL')).toBe('PERPOL');
    expect(normalizarEmpresaIdParaSheets({ empresa: 'PERPOL IDEAS S.A.C.' })).toBe('PERPOL');
    expect(normalizarEmpresaIdParaSheets({ ruc: '20392729977' })).toBe('PERPOL');
    expect(normalizarEmpresaIdParaSheets({ empresaId: 'EMP-PERPOL' })).toBe('PERPOL');

    // Casos TR3
    expect(normalizarEmpresaIdParaSheets('EMP-TR3')).toBe('TR3');
    expect(normalizarEmpresaIdParaSheets('TR3')).toBe('TR3');
    expect(normalizarEmpresaIdParaSheets({ empresa: 'TR3 ALIMENTOS S.A.C.' })).toBe('TR3');
    expect(normalizarEmpresaIdParaSheets({ ruc: '20550842891' })).toBe('TR3');
    expect(normalizarEmpresaIdParaSheets({ empresaId: 'EMP-TR3' })).toBe('TR3');
  });

  it('no utiliza prefijo "EMP-" en la salida de hojas de cálculo', () => {
    const resPerpol = normalizarEmpresaIdParaSheets('EMP-PERPOL');
    const resTr3 = normalizarEmpresaIdParaSheets('EMP-TR3');

    expect(resPerpol).toBe('PERPOL');
    expect(resPerpol).not.toBe('EMP-PERPOL');

    expect(resTr3).toBe('TR3');
    expect(resTr3).not.toBe('EMP-TR3');
  });
});
