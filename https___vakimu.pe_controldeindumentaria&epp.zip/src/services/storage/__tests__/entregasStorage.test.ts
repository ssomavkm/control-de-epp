import { describe, it, expect, beforeEach, vi } from 'vitest';
import { entregasStorage } from '../entregasStorage';
import { eppItemsStorage } from '../eppItemsStorage';
import { GasService } from '../../gasService';
import { EntregaEPP } from '../../../types';

describe('EntregasStorage', () => {
  beforeEach(() => {
    entregasStorage.reset();
    eppItemsStorage.reset();
    eppItemsStorage.setAll([
      {
        codigo: 'EPP-TEST-01',
        articulo: 'Casco de Seguridad de Prueba',
        categoria: 'Protección Craneal',
        tipo: 'EPP',
        marca: '3M',
        modelo: 'H-700',
        norma: 'ANSI Z89.1',
        talla: 'Estándar',
        unidad: 'Unidad',
        vidaUtilDias: 365,
        costoUnitario: 50,
        stockActual: 20,
        stockMinimo: 5,
        estado: 'Disponible'
      }
    ]);
    vi.spyOn(GasService, 'enviarPost').mockResolvedValue({ estado: 'ok', mensaje: 'Mock sync ok' });

    entregasStorage.setAll([
      {
        id: 'ENT-2026-0001',
        numeroRegistro: 'REG-0001',
        fechaEntrega: '2026-01-15',
        codigoTrabajador: 'TRAB-P001',
        dni: '45892134',
        trabajadorNombre: 'Juan Carlos Pérez García',
        empresaId: 'EMP-PERPOL',
        razonSocial: 'PERPOL IDEAS S.A.C.',
        ruc: '20392729977',
        direccion: 'CAL.LOS BRILLANTES NRO. 096',
        actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
        area: 'Producción',
        cargo: 'Operario',
        numTrabajadoresActivosCalculado: 10,
        fechaHoraCalculoTrabajadores: '2026-01-15 08:30:00',
        responsableEntrega: 'Supervisor SSOMA',
        tipoEntregaGeneral: 'Entrega inicial',
        observacionesGenerales: '',
        totalUnidades: 1,
        importeTotal: 48.50,
        estado: 'Confirmada',
        codigoPlantilla: 'FO-SST-GEN-050',
        versionPlantilla: '02',
        fechaCreacion: '2026-01-15 08:30:00',
        operationId: 'op-init-1',
        detalles: []
      },
      {
        id: 'ENT-2026-0002',
        numeroRegistro: 'REG-0002',
        fechaEntrega: '2026-01-16',
        codigoTrabajador: 'TRAB-T001',
        dni: '71234567',
        trabajadorNombre: 'Carlos Alva',
        empresaId: 'EMP-TR3',
        razonSocial: 'TR3 ALIMENTOS S.A.C.',
        ruc: '20550842891',
        direccion: 'LOS BRILLANTES MZA. B1 LOTE. 11B',
        actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
        area: 'Envasado',
        cargo: 'Operario',
        numTrabajadoresActivosCalculado: 5,
        fechaHoraCalculoTrabajadores: '2026-01-16 08:30:00',
        responsableEntrega: 'Supervisor SSOMA',
        tipoEntregaGeneral: 'Entrega inicial',
        observacionesGenerales: '',
        totalUnidades: 1,
        importeTotal: 25.00,
        estado: 'Confirmada',
        codigoPlantilla: 'FO-SST-GEN-050',
        versionPlantilla: '02',
        fechaCreacion: '2026-01-16 08:30:00',
        operationId: 'op-init-2',
        detalles: []
      }
    ]);
  });

  it('debería recuperar todas las entregas o filtrar por empresa', () => {
    const todas = entregasStorage.getAll();
    expect(todas.length).toBeGreaterThan(0);

    const soloPerpol = entregasStorage.getAll('EMP-PERPOL');
    expect(soloPerpol.every(e => e.empresaId === 'EMP-PERPOL')).toBe(true);

    const soloTr3 = entregasStorage.getAll('EMP-TR3');
    expect(soloTr3.every(e => e.empresaId === 'EMP-TR3')).toBe(true);
  });

  it('debería guardar y recuperar entregas usando setAll / saveAll', () => {
    const entregaPrueba: EntregaEPP = {
      id: 'ENT-TEST-001',
      numeroRegistro: 'REG-9999',
      fechaEntrega: '2026-03-01',
      codigoTrabajador: 'TRAB-P001',
      dni: '45892134',
      trabajadorNombre: 'Juan Perez',
      empresaId: 'EMP-PERPOL',
      razonSocial: 'PERPOL IDEAS S.A.C.',
      ruc: '20392729977',
      direccion: 'CAL.LOS BRILLANTES NRO. 096',
      actividadEconomica: 'FABRICACIÓN DE PRODUCTOS PLÁSTICOS',
      area: 'PRODUCCIÓN',
      cargo: 'OPERARIO',
      numTrabajadoresActivosCalculado: 10,
      fechaHoraCalculoTrabajadores: '2026-03-01 10:00:00',
      responsableEntrega: 'Supervisor SSOMA',
      tipoEntregaGeneral: 'Entrega inicial',
      observacionesGenerales: '',
      totalUnidades: 0,
      importeTotal: 0,
      estado: 'Confirmada',
      codigoPlantilla: 'FO-SST-GEN-050',
      versionPlantilla: '02',
      detalles: [],
      fechaCreacion: '2026-03-01 10:00:00',
      operationId: 'op-test-1'
    };

    entregasStorage.setAll([entregaPrueba]);
    const resultado = entregasStorage.getAll();
    expect(resultado).toHaveLength(1);
    expect(resultado[0].id).toBe('ENT-TEST-001');
    expect(resultado[0].trabajadorNombre).toBe('Juan Perez');
  });

  it('debería generar nuevos números de correlativo y registro válidos', () => {
    const numReg = entregasStorage.generarNuevoNumeroRegistro();
    expect(numReg).toMatch(/^REG-\d{4}-\d{4}$/);

    const idEnt = entregasStorage.generarNuevoIdEntrega();
    expect(idEnt).toMatch(/^ENT-\d{4}-\d{4}$/);
  });

  it('debería registrar una nueva entrega descontando inventario', async () => {
    const item = eppItemsStorage.getAll()[0];
    const stockInicial = item.stockActual;
    const cantidadEntrega = 1;

    const nuevaEntrega: EntregaEPP = {
      id: 'ENT-2026-9999',
      numeroRegistro: 'REG-9998',
      fechaEntrega: '2026-03-15',
      codigoTrabajador: 'TRAB-P001',
      dni: '45892134',
      trabajadorNombre: 'Juan Carlos Pérez García',
      empresaId: 'EMP-PERPOL',
      razonSocial: 'PERPOL IDEAS S.A.C.',
      ruc: '20392729977',
      direccion: 'CAL.LOS BRILLANTES NRO. 096',
      actividadEconomica: 'FABRICACIÓN DE PRODUCTOS PLÁSTICOS',
      area: 'Producción',
      cargo: 'Operador de Prensa',
      numTrabajadoresActivosCalculado: 12,
      fechaHoraCalculoTrabajadores: '2026-03-15 08:30:00',
      responsableEntrega: 'Ing. Carlos Mendoza',
      tipoEntregaGeneral: 'Entrega inicial',
      observacionesGenerales: 'Entrega regular',
      totalUnidades: cantidadEntrega,
      importeTotal: item.costoUnitario * cantidadEntrega,
      estado: 'Confirmada',
      codigoPlantilla: 'FO-SST-GEN-050',
      versionPlantilla: '02',
      detalles: [
        {
          idDetalle: 'DET-TEST-01',
          codigoEPP: item.codigo,
          articulo: item.articulo,
          categoria: item.categoria,
          tipo: item.tipo,
          talla: item.talla,
          unidad: item.unidad,
          cantidad: cantidadEntrega,
          costoUnitario: item.costoUnitario,
          importe: item.costoUnitario * cantidadEntrega,
          motivo: 'Entrega inicial',
          fechaRenovacion: '2026-09-15'
        }
      ],
      fechaCreacion: '2026-03-15 08:30:00',
      operationId: 'op-unique-reg-test'
    };

    const res = await entregasStorage.registrar(nuevaEntrega);
    expect(res.success).toBe(true);

    const entregasActualizadas = entregasStorage.getAll();
    expect(entregasActualizadas[0].id).toBe('ENT-2026-9999');

    const itemActualizado = eppItemsStorage.getByCodigo(item.codigo);
    expect(itemActualizado?.stockActual).toBe(stockInicial - cantidadEntrega);
  });

  it('debería evitar duplicados por operationId o numeroRegistro', async () => {
    const todas = entregasStorage.getAll();
    const existente = todas[0];

    const duplicada: EntregaEPP = {
      ...existente,
      id: 'ENT-OTRO-ID'
    };

    const res = await entregasStorage.registrar(duplicada);
    expect(res.success).toBe(true);
    expect(res.mensaje).toContain('ya registrada');
  });

  it('debería arrojar error si el stock del catálogo es insuficiente', async () => {
    const item = eppItemsStorage.getAll()[0];
    const exceso = item.stockActual + 999;

    const entregaExcesiva: EntregaEPP = {
      id: 'ENT-EXCESO',
      numeroRegistro: 'REG-9997',
      fechaEntrega: '2026-03-15',
      codigoTrabajador: 'TRAB-P001',
      dni: '45892134',
      trabajadorNombre: 'Juan Carlos',
      empresaId: 'EMP-PERPOL',
      razonSocial: 'PERPOL IDEAS S.A.C.',
      ruc: '20392729977',
      direccion: 'CAL.LOS BRILLANTES NRO. 096',
      actividadEconomica: 'FABRICACIÓN DE PRODUCTOS PLÁSTICOS',
      area: 'Producción',
      cargo: 'Operador',
      numTrabajadoresActivosCalculado: 12,
      fechaHoraCalculoTrabajadores: '2026-03-15 08:30:00',
      responsableEntrega: 'Ing. Carlos',
      tipoEntregaGeneral: 'Entrega inicial',
      observacionesGenerales: '',
      totalUnidades: exceso,
      importeTotal: 10 * exceso,
      estado: 'Confirmada',
      codigoPlantilla: 'FO-SST-GEN-050',
      versionPlantilla: '02',
      detalles: [
        {
          idDetalle: 'DET-EXCESO',
          codigoEPP: item.codigo,
          articulo: item.articulo,
          categoria: item.categoria,
          tipo: item.tipo,
          talla: item.talla,
          unidad: item.unidad,
          cantidad: exceso,
          costoUnitario: 10,
          importe: 10 * exceso,
          motivo: 'Entrega inicial',
          fechaRenovacion: '2026-09-15'
        }
      ],
      fechaCreacion: '2026-03-15',
      operationId: 'op-exceso'
    };

    await expect(entregasStorage.registrar(entregaExcesiva)).rejects.toThrow(
      /Stock insuficiente/
    );
  });

  it('debería calcular totalUnidades e importeTotal a partir de detalles en setAll', () => {
    const entregaConDetalles: any = {
      id: 'ENT-2024-0001',
      numeroRegistro: 'REG-2024-0001',
      fechaEntrega: '2024-08-01',
      codigoTrabajador: '70417956',
      dni: '70417956',
      trabajadorNombre: 'ALLPAS CHANCA JOSE LUIS',
      empresa: 'TR3',
      razonSocial: 'TR3 ALIMENTOS S.A.C.',
      ruc: 20550842891,
      direccion: 'Huachipa',
      actividadEconomica: 'Lácteos',
      area: 'Mantenimiento',
      cargo: 'Técnico',
      responsableEntrega: 'Jhon Rojas',
      tipoEntregaGeneral: 'Entrega inicial',
      estado: 'Confirmada',
      codigoPlantilla: 'FO-SST-GEN-050',
      versionPlantilla: 2,
      detalles: [
        {
          idDetalle: 'DET-2024-0001-1',
          codigoEPP: 'UNI-IND-05-TM',
          articulo: 'Casaca termica color negro',
          tipo: 'Uniforme',
          talla: 'M',
          unidad: 'Unidad',
          cantidad: 2,
          costoUnitario: 50,
          importe: 100,
          motivo: 'Entrega inicial',
          fechaRenovacion: '2025-07-27'
        }
      ]
    };

    entregasStorage.setAll([entregaConDetalles]);
    const res = entregasStorage.getAll();
    expect(res).toHaveLength(1);
    expect(res[0].totalUnidades).toBe(2);
    expect(res[0].importeTotal).toBe(100);
    expect(res[0].detalles[0].idDetalle).toBe('DET-2024-0001-1');
  });

  it('debería corregir y sumar el importe cuando hay múltiples artículos y la cabecera tenía solo el valor del primer ítem', () => {
    const entregaMultiple: any = {
      id: 'ENT-2024-0007',
      numeroRegistro: 'REG-2024-0007',
      fechaEntrega: '2024-08-01',
      codigoTrabajador: '70417956',
      dni: '70417956',
      trabajadorNombre: 'TORRES ROJAS RICARDO GAVINO',
      empresaId: 'EMP-TR3',
      // Valor truncado en la cabecera original (solo primer item 65.65)
      totalUnidades: 1,
      importeTotal: 65.65,
      estado: 'Confirmada',
      detalles: [
        { idDetalle: 'DET-2024-0007-1', articulo: 'Guante', cantidad: 1, costoUnitario: 65.65, importe: 65.65 },
        { idDetalle: 'DET-2024-0007-2', articulo: 'Chompa', cantidad: 1, costoUnitario: 49.51, importe: 49.51 },
        { idDetalle: 'DET-2024-0007-3', articulo: 'Casaca', cantidad: 1, costoUnitario: 97.35, importe: 97.35 }
      ]
    };

    entregasStorage.setAll([entregaMultiple]);
    const res = entregasStorage.getAll();
    expect(res[0].totalUnidades).toBe(3);
    expect(res[0].importeTotal).toBe(212.51);
  });
});
