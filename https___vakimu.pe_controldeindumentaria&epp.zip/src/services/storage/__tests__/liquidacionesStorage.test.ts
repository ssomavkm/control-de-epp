import { describe, it, expect, beforeEach, vi } from 'vitest';
import { storageService } from '../../storageService';
import { liquidacionesStorage } from '../liquidacionesStorage';
import { trabajadoresStorage } from '../trabajadoresStorage';
import { entregasStorage } from '../entregasStorage';
import { GasService } from '../../gasService';
import { LiquidacionEPP } from '../../../types';

describe('Liquidaciones de EPP por Cese Laboral (FO-SST-LIQ-001)', () => {
  beforeEach(() => {
    liquidacionesStorage.reset();
    trabajadoresStorage.setAll([
      {
        codigo: 'TRAB-P001',
        dni: '45892134',
        nombreCompleto: 'Juan Carlos Pérez García',
        empresaId: 'EMP-PERPOL',
        empresaNombre: 'PERPOL IDEAS S.A.C.',
        area: 'Producción',
        cargo: 'Operario',
        fechaIngreso: '2023-03-15',
        estado: 'Activo'
      }
    ]);
    entregasStorage.setAll([
      {
        id: 'ENT-2026-0001',
        numeroRegistro: 'REG-0001',
        fechaEntrega: '2026-01-15',
        codigoTrabajador: 'TRAB-P001',
        dni: '45892134',
        trabajadorNombre: 'Juan Carlos Pérez García',
        empresaId: 'EMP-PERPOL',
        razonSocial: 'PERPOL IDEAS S.A.C.',
        ruc: '20392729977',
        direccion: 'CAL.LOS BRILLANTES NRO. 096',
        actividadEconomica: 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
        area: 'Producción',
        cargo: 'Operario',
        numTrabajadoresActivosCalculado: 10,
        fechaHoraCalculoTrabajadores: '2026-01-15 08:30:00',
        responsableEntrega: 'Supervisor SSOMA',
        tipoEntregaGeneral: 'Entrega inicial',
        observacionesGenerales: '',
        totalUnidades: 1,
        importeTotal: 48.50,
        estado: 'Confirmada',
        codigoPlantilla: 'FO-SST-GEN-050',
        versionPlantilla: '02',
        fechaCreacion: '2026-01-15 08:30:00',
        operationId: 'op-liq-init',
        detalles: [
          {
            idDetalle: 'DET-0001-1',
            idEntrega: 'ENT-2026-0001',
            codigoEPP: 'EPP-CAS-01',
            articulo: 'Casco de Seguridad',
            tipo: 'EPP',
            talla: 'Estándar',
            unidad: 'Unidad',
            cantidad: 1,
            costoUnitario: 48.50,
            importe: 48.50,
            motivo: 'Entrega inicial',
            fechaRenovacion: '2026-06-15'
          }
        ]
      }
    ]);
    vi.spyOn(GasService, 'enviarPost').mockResolvedValue({ estado: 'ok', mensaje: 'Mock sync ok' });
  });

  it('genera numeración e identificadores únicos correlativos', () => {
    const num1 = liquidacionesStorage.generarNuevoNumero();
    const id1 = liquidacionesStorage.generarNuevoId();
    expect(num1).toMatch(/^ACTA-LIQ-\d{4}$/);
    expect(id1).toMatch(/^LIQ-\d{4}-\d{4}$/);
  });

  it('prepara auditoría de cese evaluando amortizaciones por vida útil cumplida', () => {
    // TRAB-P001 tiene entregas históricas en seeds
    const audit = liquidacionesStorage.prepararAuditoriaCese('TRAB-P001', '2026-12-31');
    expect(audit).toBeDefined();
    expect(audit.trabajador).toBeDefined();
    expect(Array.isArray(audit.items)).toBe(true);

    if (audit.items.length > 0) {
      // Todo ítem con fechaVencimiento <= fechaCese debe inicializarse como Vencido
      audit.items.forEach(it => {
        if (it.fechaVencimiento && it.fechaVencimiento <= '2026-12-31') {
          expect(it.estadoItem).toBe('Vencido');
          expect(it.montoALiquidar).toBe(0);
        }
      });
    }
  });

  it('registra una liquidación y calcula deducciones netas correctamente', async () => {
    const num = liquidacionesStorage.generarNuevoNumero();
    const id = liquidacionesStorage.generarNuevoId();

    const liqPrueba: LiquidacionEPP = {
      id,
      numeroRegistro: num,
      codigoPlantilla: 'FO-SST-LIQ-001',
      versionPlantilla: '01',
      fechaLiquidacion: '2026-03-10',
      fechaCese: '2026-03-09',
      motivoCese: 'Renuncia Voluntaria',
      codigoTrabajador: 'TRAB-P001',
      dni: '45892134',
      trabajadorNombre: 'Juan Carlos Pérez García',
      empresaId: 'EMP-PERPOL',
      empresaNombre: 'PERPOL IDEAS S.A.C.',
      ruc: '20392729977',
      area: 'Producción',
      cargo: 'Operario de Envasado',
      items: [
        {
          idItem: 'ITEM-TEST-1',
          idEntregaOrigen: 'ENT-2026-0001',
          numeroRegistroOrigen: 'REG-0001',
          fechaEntrega: '2025-06-01',
          codigoEPP: 'EPP-CALZ-001',
          articulo: 'Botas de Seguridad de Cuero con Puntera de Acero',
          tipo: 'EPP',
          talla: '42',
          unidad: 'Par',
          cantidadEntregada: 1,
          cantidadDevuelta: 0,
          cantidadVencida: 1,
          cantidadALiquidar: 0,
          costoUnitario: 120.00,
          importeTotalEntregado: 120.00,
          montoALiquidar: 0.00,
          vidaUtilDias: 180,
          fechaVencimiento: '2025-11-28',
          estadoItem: 'Vencido'
        },
        {
          idItem: 'ITEM-TEST-2',
          idEntregaOrigen: 'ENT-2026-0001',
          numeroRegistroOrigen: 'REG-0001',
          fechaEntrega: '2026-01-15',
          codigoEPP: 'UNI-CHAQ-001',
          articulo: 'Casaca Térmica Industrial Impermeable',
          tipo: 'Uniforme',
          talla: 'L',
          unidad: 'Unidad',
          cantidadEntregada: 1,
          cantidadDevuelta: 0,
          cantidadVencida: 0,
          cantidadALiquidar: 1,
          costoUnitario: 150.00,
          importeTotalEntregado: 150.00,
          montoALiquidar: 150.00,
          vidaUtilDias: 365,
          fechaVencimiento: '2027-01-15',
          estadoItem: 'Pendiente'
        }
      ],
      totalItemsEntregados: 2,
      totalItemsDevueltos: 0,
      totalItemsVencidos: 1,
      totalItemsALiquidar: 1,
      montoTotalEntregado: 270.00,
      montoDescontadoVencidosYDevueltos: 120.00,
      montoNetoALiquidar: 150.00,
      supervisorResponsable: 'Ing. Jhon Rojas',
      cargoSupervisor: 'Supervisor SSOMA',
      estado: 'Emitida',
      fechaCreacion: new Date().toISOString()
    };

    const res = await liquidacionesStorage.registrar(liqPrueba);
    expect(res.success).toBe(true);

    const guardada = liquidacionesStorage.getById(id);
    expect(guardada).toBeDefined();
    expect(guardada?.montoNetoALiquidar).toBe(150.00);
    expect(guardada?.montoDescontadoVencidosYDevueltos).toBe(120.00);

    // Actualizar estado
    liquidacionesStorage.updateEstado(id, 'Liquidada en Planilla');
    expect(liquidacionesStorage.getById(id)?.estado).toBe('Liquidada en Planilla');

    // Eliminar
    liquidacionesStorage.delete(id);
    expect(liquidacionesStorage.getById(id)).toBeUndefined();
  });
});
