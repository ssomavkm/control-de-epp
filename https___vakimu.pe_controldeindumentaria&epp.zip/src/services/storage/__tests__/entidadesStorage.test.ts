import { describe, it, expect, beforeEach } from 'vitest';
import { empresasStorage } from '../empresasStorage';
import { trabajadoresStorage } from '../trabajadoresStorage';
import { eppItemsStorage } from '../eppItemsStorage';

describe('EmpresasStorage', () => {
  beforeEach(() => {
    empresasStorage.reset();
  });

  it('debería retornar las empresas oficiales', () => {
    const empresas = empresasStorage.getAll();
    expect(empresas.length).toBeGreaterThanOrEqual(2);
    expect(empresas.some(e => e.id === 'EMP-PERPOL')).toBe(true);
    expect(empresas.some(e => e.id === 'EMP-TR3')).toBe(true);
  });

  it('debería obtener empresa por id', () => {
    const perpol = empresasStorage.getById('EMP-PERPOL');
    expect(perpol).toBeDefined();
    expect(perpol?.ruc).toBe('20392729977');
    expect(perpol?.razonSocial).toContain('PERPOL');
  });

  it('debería actualizar el logo de una empresa', () => {
    const nuevoLogo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    empresasStorage.updateLogo('EMP-PERPOL', nuevoLogo);
    const updated = empresasStorage.getById('EMP-PERPOL');
    expect(updated?.logoUrl).toBe(nuevoLogo);
  });
});

describe('TrabajadoresStorage', () => {
  beforeEach(() => {
    trabajadoresStorage.reset();
    trabajadoresStorage.setAll([
      {
        codigo: 'TRAB-P001',
        dni: '45892134',
        nombreCompleto: 'Juan Carlos Pérez García',
        empresaId: 'EMP-PERPOL',
        empresaNombre: 'PERPOL IDEAS S.A.C.',
        area: 'Producción',
        cargo: 'Operario',
        fechaIngreso: '2023-03-15',
        estado: 'Activo'
      },
      {
        codigo: 'TRAB-T001',
        dni: '71234567',
        nombreCompleto: 'Carlos Alva',
        empresaId: 'EMP-TR3',
        empresaNombre: 'TR3 ALIMENTOS S.A.C.',
        area: 'Envasado',
        cargo: 'Operario',
        fechaIngreso: '2023-04-10',
        estado: 'Activo'
      }
    ]);
  });

  it('debería retornar el padrón y filtrar por empresa', () => {
    const todos = trabajadoresStorage.getAll();
    expect(todos.length).toBeGreaterThan(0);

    const perpol = trabajadoresStorage.getAll('EMP-PERPOL');
    expect(perpol.every(t => t.empresaId === 'EMP-PERPOL')).toBe(true);

    const tr3 = trabajadoresStorage.getAll('EMP-TR3');
    expect(tr3.every(t => t.empresaId === 'EMP-TR3')).toBe(true);
  });

  it('debería buscar por código o DNI', () => {
    const t = trabajadoresStorage.getAll()[0];
    const porCodigo = trabajadoresStorage.getByCodigo(t.codigo);
    const porDni = trabajadoresStorage.getByCodigo(t.dni);

    expect(porCodigo).toBeDefined();
    expect(porDni).toBeDefined();
    expect(porCodigo?.codigo).toBe(t.codigo);
    expect(porDni?.dni).toBe(t.dni);
  });

  it('debería calcular el número de trabajadores activos', () => {
    const numActivosPerpol = trabajadoresStorage.calcularNumActivos('EMP-PERPOL');
    expect(numActivosPerpol).toBeGreaterThan(0);
  });
});

describe('EPPItemsStorage', () => {
  beforeEach(() => {
    eppItemsStorage.reset();
    eppItemsStorage.setAll([
      {
        codigo: 'EPP-TEST-01',
        articulo: 'Casco de Seguridad de Prueba',
        categoria: 'Protección Craneal',
        tipo: 'EPP',
        marca: '3M',
        modelo: 'H-700',
        norma: 'ANSI Z89.1',
        talla: 'Estándar',
        unidad: 'Unidad',
        vidaUtilDias: 365,
        costoUnitario: 50,
        stockActual: 20,
        stockMinimo: 5,
        estado: 'Disponible'
      }
    ]);
  });

  it('debería retornar el catálogo maestro de EPP', () => {
    const catalogo = eppItemsStorage.getAll();
    expect(catalogo.length).toBeGreaterThan(0);
    expect(catalogo.some(e => e.codigo === 'EPP-TEST-01')).toBe(true);
  });

  it('debería descontar stock correctamente', () => {
    const item = eppItemsStorage.getAll()[0];
    const stockPrevio = item.stockActual;
    eppItemsStorage.descontarStock(item.codigo, 5);

    const actualizado = eppItemsStorage.getByCodigo(item.codigo);
    expect(actualizado?.stockActual).toBe(stockPrevio - 5);
  });
});
