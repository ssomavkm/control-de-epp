import { Trabajador, EmpresaId } from '../../types';
import { TRABAJADORES_SEED } from '../../data/seeds/trabajadores';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { notifyStorageChange } from './eventEmitter';
import { normalizarEmpresaId, RAZON_SOCIAL_PERPOL, RAZON_SOCIAL_TR3 } from '../../utils/empresaResolver';

export const STORAGE_KEY_TRABAJADORES = 'ssoma_trabajadores_v1';

class TrabajadoresStorage {
  private trabajadores: Trabajador[] = [];

  constructor() {
    this.cargarPersistidos();
  }

  private cargarPersistidos(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_TRABAJADORES);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((t: any) => t.codigo === 'TRAB-P001' || t.dni === '45892134');
          if (!tieneMocksAntiguos) {
            this.trabajadores = parsed;
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer trabajadores de localStorage:', e);
    }
    this.trabajadores = [...TRABAJADORES_SEED];
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_TRABAJADORES, JSON.stringify(this.trabajadores));
    } catch (e) {
      console.warn('Error al persistir trabajadores en localStorage:', e);
    }
  }

  public getAll(empresaId?: string): Trabajador[] {
    if (!empresaId || empresaId === 'TODAS') {
      return [...this.trabajadores];
    }
    const targetNorm = normalizarEmpresaId(empresaId);
    return this.trabajadores.filter(t => t.empresaId === empresaId || normalizarEmpresaId(t.empresaId) === targetNorm);
  }

  public getByCodigo(codigo: string): Trabajador | undefined {
    return this.trabajadores.find(t => t.codigo === codigo || t.dni === codigo);
  }

  public calcularNumActivos(empresaId: EmpresaId): number {
    const targetNorm = normalizarEmpresaId(empresaId);
    return this.trabajadores.filter(t => 
      (t.empresaId === empresaId || normalizarEmpresaId(t.empresaId) === targetNorm) && 
      t.estado === 'Activo'
    ).length;
  }

  public setAll(trabajadores: Trabajador[]): void {
    const codigosUsados = new Set<string>();
    this.trabajadores = (Array.isArray(trabajadores) ? trabajadores : []).map((t, idx) => {
      let codigo = t.codigo ? String(t.codigo).trim() : '';
      if (!codigo) {
        codigo = t.dni ? String(t.dni).trim() : `TRAB-${String(idx + 1).padStart(4, '0')}`;
      }
      if (codigosUsados.has(codigo)) {
        let suffix = 2;
        while (codigosUsados.has(`${codigo}-${suffix}`)) {
          suffix++;
        }
        codigo = `${codigo}-${suffix}`;
      }
      codigosUsados.add(codigo);

      // Normalizar inmediatamente la razón social oficial analizando RUC o nombre
      const empresaIdFinal = normalizarEmpresaId({
        empresaId: t.empresaId,
        empresa: t.empresa,
        empresaNombre: t.empresaNombre
      });
      const isPerpol = empresaIdFinal === 'EMP-PERPOL' || empresaIdFinal === 'PERPOL';
      const razonSocialOficial = isPerpol ? RAZON_SOCIAL_PERPOL : RAZON_SOCIAL_TR3;

      return {
        ...t,
        codigo,
        dni: String(t.dni || '').trim(),
        nombreCompleto: String(t.nombreCompleto || '').trim(),
        area: String(t.area || '').trim(),
        cargo: String(t.cargo || '').trim(),
        empresaId: empresaIdFinal,
        empresaNombre: razonSocialOficial,
        empresa: razonSocialOficial
      };
    });
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(trabajadores: Trabajador[]): void {
    this.setAll(trabajadores);
  }

  public async save(trabajador: Trabajador): Promise<void> {
    let edadFinal = trabajador.edad;
    if ((edadFinal === undefined || edadFinal === null || edadFinal === '') && trabajador.fechaNacimiento) {
      const b = new Date(trabajador.fechaNacimiento);
      if (!isNaN(b.getTime())) {
        const today = new Date();
        let age = today.getFullYear() - b.getFullYear();
        const m = today.getMonth() - b.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < b.getDate())) age--;
        if (age >= 0 && age < 120) edadFinal = age;
      }
    }

    const empresaIdFinal = normalizarEmpresaId({
      empresaId: trabajador.empresaId,
      empresa: trabajador.empresa,
      empresaNombre: trabajador.empresaNombre
    });
    const isPerpol = empresaIdFinal === 'EMP-PERPOL' || empresaIdFinal === 'PERPOL';
    const razonSocialOficial = isPerpol ? RAZON_SOCIAL_PERPOL : RAZON_SOCIAL_TR3;

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      GasService.enviarPost(cfg.gasWebAppUrl, {
        action: 'guardarTrabajador',
        trabajador: {
          dni: trabajador.dni,
          apellidosNombres: trabajador.apellidosNombres || trabajador.nombreCompleto,
          empresa: razonSocialOficial,
          puesto: trabajador.puesto || trabajador.cargo,
          area: trabajador.area,
          condicion: trabajador.condicion || trabajador.estado,
          sexo: trabajador.sexo || 'M',
          fechaNacimiento: trabajador.fechaNacimiento || '',
          edad: edadFinal !== undefined && edadFinal !== null ? edadFinal : '',
          fechaIngreso: trabajador.fechaIngreso,
          telefono: trabajador.telefono || '',
          correo: trabajador.correo || trabajador.email || '',
          codigo: trabajador.codigo || trabajador.dni,
          nombreCompleto: trabajador.nombreCompleto,
          empresaId: trabajador.empresaId,
          empresaNombre: trabajador.empresaNombre,
          cargo: trabajador.cargo,
          estado: trabajador.estado
        }
      }).catch(e => console.warn('Sync trabajador GAS error:', e));
    }

    const idx = this.trabajadores.findIndex(t => t.codigo === trabajador.codigo || t.dni === trabajador.dni);
    const trabajadorActualizado = { ...trabajador, edad: edadFinal };
    if (idx !== -1) {
      this.trabajadores[idx] = trabajadorActualizado;
    } else {
      this.trabajadores.push(trabajadorActualizado);
    }
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public async delete(codigo: string): Promise<void> {
    const trab = this.trabajadores.find(t => t.codigo === codigo || t.dni === codigo);
    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      GasService.enviarPost(cfg.gasWebAppUrl, {
        action: 'eliminarTrabajador',
        codigo,
        dni: trab?.dni || codigo
      }).catch(e => console.warn('Delete trabajador GAS error:', e));
    }

    this.trabajadores = this.trabajadores.filter(t => t.codigo !== codigo && t.dni !== codigo);
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public reset(): void {
    this.trabajadores = [...TRABAJADORES_SEED];
    try {
      localStorage.removeItem(STORAGE_KEY_TRABAJADORES);
    } catch (e) {
      console.warn('Error al limpiar trabajadores de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const trabajadoresStorage = new TrabajadoresStorage();
