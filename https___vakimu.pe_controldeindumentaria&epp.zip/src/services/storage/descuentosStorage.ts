import { DescuentoEPP, DetalleEntrega, EntregaEPP } from '../../types';
import { DESCUENTOS_SEED } from '../../data/seeds/descuentos';
import { GasService } from '../gasService';
import { configStorage } from './configStorage';
import { eppItemsStorage } from './eppItemsStorage';
import { empresasStorage } from './empresasStorage';
import { trabajadoresStorage } from './trabajadoresStorage';
import { entregasStorage } from './entregasStorage';
import { notifyStorageChange } from './eventEmitter';
import { compararFechasDesc } from '../../utils/formatters';

export const STORAGE_KEY_DESCUENTOS = 'ssoma_descuentos_v1';

class DescuentosStorage {
  private descuentos: DescuentoEPP[] = [];

  constructor() {
    this.cargarPersistidos();
  }

  private cargarPersistidos(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_DESCUENTOS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const tieneMocksAntiguos = parsed.some((d: any) => d.codigoTrabajador === 'TRAB-P001' || d.dni === '45892134');
          if (!tieneMocksAntiguos) {
            this.descuentos = parsed.sort((a: any, b: any) =>
              compararFechasDesc(a.fechaSolicitud || a.fechaIncidente, b.fechaSolicitud || b.fechaIncidente, a.numeroRegistro, b.numeroRegistro)
            );
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Error al leer descuentos de localStorage:', e);
    }
    this.descuentos = [...DESCUENTOS_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaSolicitud || a.fechaIncidente, b.fechaSolicitud || b.fechaIncidente, a.numeroRegistro, b.numeroRegistro)
    );
  }

  private guardarEnLocalStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_DESCUENTOS, JSON.stringify(this.descuentos));
    } catch (e) {
      console.warn('Error al persistir descuentos en localStorage:', e);
    }
  }

  public getAll(): DescuentoEPP[] {
    return this.descuentos
      .map(d => ({
        ...d,
        items: Array.isArray(d.items) ? d.items : []
      }))
      .sort((a, b) =>
        compararFechasDesc(a.fechaSolicitud || a.fechaIncidente, b.fechaSolicitud || b.fechaIncidente, a.numeroRegistro, b.numeroRegistro)
      );
  }

  public setAll(descuentos: DescuentoEPP[]): void {
    const idsUsados = new Set<string>();
    this.descuentos = (Array.isArray(descuentos) ? descuentos : []).map((desc, idx) => {
      let id = desc.id ? String(desc.id).trim() : `DESC-${idx + 1}`;
      if (idsUsados.has(id)) {
        id = `${id}-${idx + 1}`;
      }
      idsUsados.add(id);

      // Normalizar items desde array directo o campo itemsJson/items_json
      let itemsNormalizados = [];
      const anyDesc = desc as any;
      const rawItems = anyDesc.items ?? anyDesc.itemsJson ?? anyDesc.items_json;
      if (Array.isArray(rawItems)) {
        itemsNormalizados = rawItems;
      } else if (typeof rawItems === 'string' && rawItems.trim()) {
        try {
          const parsed = JSON.parse(rawItems);
          if (Array.isArray(parsed)) {
            itemsNormalizados = parsed;
          }
        } catch {
          itemsNormalizados = [];
        }
      }

      return {
        ...desc,
        id,
        items: itemsNormalizados,
        montoTotalDescuento: Number(desc.montoTotalDescuento) || (itemsNormalizados.reduce((acc: number, it: any) => acc + (Number(it.importeTotal) || 0), 0)),
        cuotas: Number(desc.cuotas) || 1,
        montoPorCuota: Number(desc.montoPorCuota) || Number(desc.montoTotalDescuento) || 0
      };
    }).sort((a, b) =>
      compararFechasDesc(a.fechaSolicitud || a.fechaIncidente, b.fechaSolicitud || b.fechaIncidente, a.numeroRegistro, b.numeroRegistro)
    );
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public saveAll(descuentos: DescuentoEPP[]): void {
    this.setAll(descuentos);
  }

  public generarNuevoNumero(): string {
    const nums = this.descuentos
      .map(d => parseInt(d.numeroRegistro.replace(/\D/g, ''), 10))
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `DESC-${String(next).padStart(4, '0')}`;
  }

  public generarNuevoId(): string {
    const nums = this.descuentos
      .map(d => {
        const parts = d.id.split('-');
        return parseInt(parts[parts.length - 1], 10);
      })
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return `AUT-DES-${new Date().getFullYear()}-${String(next).padStart(4, '0')}`;
  }

  public async registrar(
    descuento: DescuentoEPP,
    reponerInmediato?: boolean
  ): Promise<{ success: boolean; mensaje: string; entregaReposicionId?: string }> {
    const existeIndex = this.descuentos.findIndex(
      d => d.id === descuento.id || d.numeroRegistro === descuento.numeroRegistro
    );
    if (existeIndex !== -1) {
      this.descuentos[existeIndex] = descuento;
    } else {
      this.descuentos.unshift(descuento);
    }

    let entregaGeneradaId: string | undefined = undefined;

    if (reponerInmediato || descuento.reponerInmediatamente) {
      try {
        const numRegEntrega = entregasStorage.generarNuevoNumeroRegistro();
        const nuevaEntregaId = entregasStorage.generarNuevoIdEntrega();
        const catalogo = eppItemsStorage.getAll();

        const items = Array.isArray(descuento.items) ? descuento.items : [];
        const detallesReposicion: DetalleEntrega[] = items.map((it, idx) => {
          const itemCat = catalogo.find(e => e.codigo === it.codigoEPP);
          const vidaDias = itemCat?.vidaUtilDias || 180;
          const hoy = new Date();
          const fRenov = new Date(hoy.getTime() + vidaDias * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

          return {
            idDetalle: `DET-${numRegEntrega.replace('REG-', '')}-${idx + 1}`,
            idEntrega: nuevaEntregaId,
            codigoEPP: it.codigoEPP,
            articulo: it.articulo,
            categoria: it.categoria,
            tipo: 'EPP',
            talla: it.talla,
            unidad: it.unidad,
            cantidad: it.cantidadPerdida,
            costoUnitario: it.costoUnitario,
            importe: it.importeTotal,
            motivo: 'Reposición',
            fechaRenovacion: fRenov,
            observaciones: `Reposición por extravío/descuento ${descuento.numeroRegistro}`
          };
        });

        const emp = empresasStorage.getById(descuento.empresaId);

        const nuevaEntrega: EntregaEPP = {
          id: nuevaEntregaId,
          numeroRegistro: numRegEntrega,
          fechaEntrega: descuento.fechaSolicitud || new Date().toISOString().split('T')[0],
          codigoTrabajador: descuento.codigoTrabajador,
          dni: descuento.dni,
          trabajadorNombre: descuento.trabajadorNombre,
          empresaId: descuento.empresaId,
          razonSocial: descuento.empresaNombre,
          ruc: descuento.ruc,
          direccion: emp?.direccion || 'Planta Industrial',
          actividadEconomica: emp?.actividadEconomica || 'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
          area: descuento.area,
          cargo: descuento.cargo,
          numTrabajadoresActivosCalculado: trabajadoresStorage.calcularNumActivos(descuento.empresaId),
          fechaHoraCalculoTrabajadores: new Date().toISOString(),
          responsableEntrega: descuento.responsableNombre,
          tipoEntregaGeneral: 'Reposición',
          observacionesGenerales: `Entrega de reposición por pérdida. Autorización de descuento ${descuento.numeroRegistro}.`,
          totalUnidades: detallesReposicion.reduce((acc, curr) => acc + curr.cantidad, 0),
          importeTotal: detallesReposicion.reduce((acc, curr) => acc + curr.importe, 0),
          detalles: detallesReposicion,
          firmaTrabajador: descuento.firmaTrabajador,
          firmaResponsable: descuento.firmaResponsable,
          estado: 'Confirmada',
          codigoPlantilla: 'FO-SST-GEN-050',
          versionPlantilla: '02',
          fechaCreacion: new Date().toISOString(),
          operationId: `OP-REP-${Date.now()}`
        };

        await entregasStorage.registrar(nuevaEntrega);
        entregaGeneradaId = nuevaEntregaId;
        descuento.idEntregaReposicion = nuevaEntregaId;
      } catch (err) {
        console.warn('Aviso: Reposición automática presentó error:', err);
      }
    }

    const cfg = configStorage.get();
    if (cfg.gasWebAppUrl) {
      const empresaIdCanonica = descuento.empresaId === 'EMP-PERPOL' || descuento.empresaId === 'PERPOL' ? 'PERPOL' : 'TR3';
      GasService.enviarPost(cfg.gasWebAppUrl, {
        action: 'guardarDescuento',
        descuento: {
          ...descuento,
          empresaId: empresaIdCanonica
        }
      }).catch(e => console.warn('Sync descuento GAS error:', e));
    }

    this.guardarEnLocalStorage();
    notifyStorageChange();

    return {
      success: true,
      mensaje: `Documento de descuento ${descuento.numeroRegistro} registrado con éxito.`,
      entregaReposicionId: entregaGeneradaId
    };
  }

  public updateEstado(id: string, nuevoEstado: DescuentoEPP['estado']): void {
    const idx = this.descuentos.findIndex(d => d.id === id);
    if (idx !== -1) {
      this.descuentos[idx] = { ...this.descuentos[idx], estado: nuevoEstado };
      const cfg = configStorage.get();
      if (cfg.gasWebAppUrl) {
        const itemActual = this.descuentos[idx];
        const empresaIdCanonica = itemActual.empresaId === 'EMP-PERPOL' || itemActual.empresaId === 'PERPOL' ? 'PERPOL' : 'TR3';
        GasService.enviarPost(cfg.gasWebAppUrl, {
          action: 'guardarDescuento',
          descuento: {
            ...itemActual,
            empresaId: empresaIdCanonica
          }
        }).catch(e => console.warn('Sync update descuento error:', e));
      }
      this.guardarEnLocalStorage();
      notifyStorageChange();
    }
  }

  public delete(id: string): void {
    this.descuentos = this.descuentos.filter(d => d.id !== id);
    this.guardarEnLocalStorage();
    notifyStorageChange();
  }

  public reset(): void {
    this.descuentos = [...DESCUENTOS_SEED].sort((a, b) =>
      compararFechasDesc(a.fechaSolicitud || a.fechaIncidente, b.fechaSolicitud || b.fechaIncidente, a.numeroRegistro, b.numeroRegistro)
    );
    try {
      localStorage.removeItem(STORAGE_KEY_DESCUENTOS);
    } catch (e) {
      console.warn('Error al limpiar descuentos de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const descuentosStorage = new DescuentosStorage();
