import { MovimientoKardex, IngresoStock } from '../../types';
import { notifyStorageChange } from './eventEmitter';
import { compararFechasDesc } from '../../utils/formatters';

export const STORAGE_KEY_KARDEX = 'ssoma_kardex_movimientos_v1';
export const STORAGE_KEY_INGRESOS = 'ssoma_ingresos_stock_v1';

// Registro inicial limpio de movimientos de kardex e ingresos de stock
const KARDEX_SEED: MovimientoKardex[] = [];
const INGRESOS_SEED: IngresoStock[] = [];

class KardexStorage {
  private movimientos: MovimientoKardex[] = [];
  private ingresos: IngresoStock[] = [];

  constructor() {
    this.cargarDatos();
  }

  private cargarDatos() {
    try {
      const movsRaw = localStorage.getItem(STORAGE_KEY_KARDEX);
      if (movsRaw) {
        const parsed = JSON.parse(movsRaw);
        if (Array.isArray(parsed)) {
          // Descartar registros de prueba simulados antiguos
          const tieneMocksAntiguos = parsed.some((m: any) => m.id?.startsWith('MOV-INI-') || m.trabajadorNombre?.includes('Juan Carlos'));
          if (tieneMocksAntiguos) {
            this.movimientos = [];
            localStorage.setItem(STORAGE_KEY_KARDEX, JSON.stringify([]));
          } else {
            this.movimientos = parsed;
          }
        } else {
          this.movimientos = [];
        }
      } else {
        this.movimientos = [];
      }
    } catch {
      this.movimientos = [];
    }

    try {
      const ingRaw = localStorage.getItem(STORAGE_KEY_INGRESOS);
      if (ingRaw) {
        const parsed = JSON.parse(ingRaw);
        if (Array.isArray(parsed)) {
          const tieneMocksAntiguos = parsed.some((ing: any) => ing.id === 'ING-2026-0001' || ing.id === 'ING-2026-0002');
          if (tieneMocksAntiguos) {
            this.ingresos = [];
            localStorage.setItem(STORAGE_KEY_INGRESOS, JSON.stringify([]));
          } else {
            this.ingresos = parsed;
          }
        } else {
          this.ingresos = [];
        }
      } else {
        this.ingresos = [];
      }
    } catch {
      this.ingresos = [];
    }
  }

  public getAllMovimientos(): MovimientoKardex[] {
    return [...this.movimientos].sort((a, b) =>
      compararFechasDesc(a.fechaHora, b.fechaHora, a.id, b.id)
    );
  }

  public getAllIngresos(): IngresoStock[] {
    return [...this.ingresos].sort((a, b) =>
      compararFechasDesc(a.fechaIngreso, b.fechaIngreso, a.id, b.id)
    );
  }

  public getMovimientosPorEPP(codigoEPP: string): MovimientoKardex[] {
    const target = codigoEPP.trim().toUpperCase();
    return this.movimientos.filter(m => m.codigoEPP.trim().toUpperCase() === target);
  }

  public generarNuevoIdIngreso(): string {
    const year = new Date().getFullYear();
    const regex = new RegExp(`^ING-${year}-(\\d+)$`, 'i');
    const nums = this.ingresos
      .map(i => {
        const m = (i.id || '').match(regex);
        return m ? parseInt(m[1], 10) : NaN;
      })
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : this.ingresos.length + 1;
    return `ING-${year}-${String(next).padStart(4, '0')}`;
  }

  public registrarMovimiento(mov: MovimientoKardex): void {
    this.movimientos.unshift(mov);
    try {
      localStorage.setItem(STORAGE_KEY_KARDEX, JSON.stringify(this.movimientos));
    } catch (e) {
      console.warn('Error al guardar kardex en localStorage:', e);
    }
    notifyStorageChange();
  }

  public registrarMovimientosBatch(movs: MovimientoKardex[]): void {
    if (!movs || movs.length === 0) return;
    this.movimientos = [...movs, ...this.movimientos];
    try {
      localStorage.setItem(STORAGE_KEY_KARDEX, JSON.stringify(this.movimientos));
    } catch (e) {
      console.warn('Error al guardar kardex batch en localStorage:', e);
    }
    notifyStorageChange();
  }

  public registrarIngreso(ingreso: IngresoStock): void {
    this.ingresos.unshift(ingreso);
    try {
      localStorage.setItem(STORAGE_KEY_INGRESOS, JSON.stringify(this.ingresos));
    } catch (e) {
      console.warn('Error al guardar ingreso en localStorage:', e);
    }
    notifyStorageChange();
  }

  public reset(): void {
    this.movimientos = [...KARDEX_SEED];
    this.ingresos = [];
    try {
      localStorage.removeItem(STORAGE_KEY_KARDEX);
      localStorage.removeItem(STORAGE_KEY_INGRESOS);
    } catch (e) {
      console.warn('Error al limpiar kardex de localStorage:', e);
    }
    notifyStorageChange();
  }
}

export const kardexStorage = new KardexStorage();
