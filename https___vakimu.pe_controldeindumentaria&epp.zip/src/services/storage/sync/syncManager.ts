import { GoogleSheetsSync } from './googleSheetsSync';
import { configStorage } from '../configStorage';
import { empresasStorage } from '../empresasStorage';
import { trabajadoresStorage } from '../trabajadoresStorage';
import { eppItemsStorage } from '../eppItemsStorage';
import { entregasStorage } from '../entregasStorage';
import { inspeccionesStorage } from '../inspeccionesStorage';
import { plantillasStorage } from '../plantillasStorage';
import { documentosStorage } from '../documentosStorage';
import { renovacionesStorage } from '../renovacionesStorage';
import { descuentosStorage } from '../descuentosStorage';
import { infraccionesStorage } from '../infraccionesStorage';
import { liquidacionesStorage } from '../liquidacionesStorage';
import { kardexStorage } from '../kardexStorage';

export class SyncManager {
  constructor() {
    this.limpiarAlmacenamientoLocalOculto();
  }

  public limpiarAlmacenamientoLocalOculto(): void {
    const PURGE_CLEAN_VERSION_KEY = 'ssoma_clean_storage_v20261109_zero';
    try {
      // 1. Limpieza de pestañas temporales
      const llavesABorrar: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('ssoma_tab_')) {
          llavesABorrar.push(k);
        }
      }
      llavesABorrar.forEach(k => localStorage.removeItem(k));

      // 2. Purga única garantizada de datos operativos, catálogo y credenciales previas para configurar desde cero
      // Conserva ÚNICAMENTE: Las Empresas Oficiales (PERPOL y TR3) y las Plantillas SST normativas
      if (localStorage.getItem(PURGE_CLEAN_VERSION_KEY) !== 'true') {
        const tablasOperativas = [
          'ssoma_catalogo_epp_v2',
          'ssoma_trabajadores',
          'ssoma_entregas_v1',
          'ssoma_inspecciones_v1',
          'ssoma_infracciones_v1',
          'ssoma_descuentos_v1',
          'ssoma_liquidaciones_v1',
          'ssoma_documentos_v1',
          'ssoma_kardex_movimientos_v1',
          'ssoma_kardex_ingresos_v1',
          'ssoma_offline_queue_v2',
          'ssoma_drive_vinculos_v1',
          'ssoma_config_v2'
        ];

        tablasOperativas.forEach(key => {
          try {
            localStorage.removeItem(key);
          } catch {}
        });

        // Resetear en memoria a sus valores limpios vacíos
        trabajadoresStorage.reset();
        eppItemsStorage.reset();
        entregasStorage.reset();
        inspeccionesStorage.reset();
        descuentosStorage.reset();
        infraccionesStorage.reset();
        liquidacionesStorage.reset();
        documentosStorage.reset();
        kardexStorage.reset();
        configStorage.reset();

        localStorage.setItem(PURGE_CLEAN_VERSION_KEY, 'true');
      }
    } catch (e) {
      console.warn('No se pudo acceder a localStorage para limpieza:', e);
    }
  }

  public async syncNow(): Promise<{ success: boolean; mensaje: string }> {
    return GoogleSheetsSync.pull();
  }

  public async pushAll(): Promise<{ success: boolean; mensaje: string }> {
    return GoogleSheetsSync.pushAll();
  }

  public resetToFactory(): void {
    this.limpiarAlmacenamientoLocalOculto();
    empresasStorage.reset();
    trabajadoresStorage.reset();
    eppItemsStorage.reset();
    entregasStorage.reset();
    inspeccionesStorage.reset();
    plantillasStorage.reset();
    documentosStorage.reset();
    descuentosStorage.reset();
    infraccionesStorage.reset();
    liquidacionesStorage.reset();
    kardexStorage.reset();
    configStorage.reset();
  }

  public exportarCSV(tipo: 'entregas' | 'renovaciones' | 'costos' | 'inspecciones'): string {
    if (tipo === 'entregas') {
      const entregas = entregasStorage.getAll();
      const filas: string[] = ['Registro,Fecha,DNI,Trabajador,Empresa,Area,Cargo,Articulo,Cantidad,Importe,Motivo,Renovacion'];
      entregas.forEach(ent => {
        (ent.detalles || []).forEach(det => {
          filas.push(`"${ent.numeroRegistro}","${ent.fechaEntrega}","${ent.dni}","${ent.trabajadorNombre}","${ent.razonSocial}","${ent.area}","${ent.cargo}","${det.articulo}","${det.cantidad}","${det.importe}","${det.motivo}","${det.fechaRenovacion}"`);
        });
      });
      return filas.join('\n');
    }

    if (tipo === 'renovaciones') {
      const items = renovacionesStorage.getAll();
      const filas = ['Trabajador,DNI,Empresa,Area,Articulo,Cantidad,Fecha Entrega,Fecha Renovacion,Dias Restantes,Estado'];
      items.forEach(it => {
        filas.push(`"${it.trabajadorNombre}","${it.dni}","${it.empresaNombre}","${it.area}","${it.articulo}","${it.cantidad}","${it.fechaEntrega}","${it.fechaRenovacion}","${it.diasRestantes}","${it.estadoRenovacion}"`);
      });
      return filas.join('\n');
    }

    if (tipo === 'inspecciones') {
      const inspecciones = inspeccionesStorage.getAll();
      const filas = ['Num Inspeccion,Fecha,DNI,Trabajador,Empresa,Area,Inspector,Articulo,Resultado,Hallazgo,Accion,Estado Accion'];
      inspecciones.forEach(i => {
        (i.detalles || []).forEach(d => {
          filas.push(`"${i.numeroInspeccion}","${i.fechaHora}","${i.dni}","${i.trabajadorNombre}","${i.empresaNombre}","${i.area}","${i.inspectorResponsable}","${d.articulo}","${d.resultado}","${(d.hallazgo || '').replace(/"/g, '""')}","${d.accion}","${d.estadoAccion}"`);
        });
      });
      return filas.join('\n');
    }

    if (tipo === 'costos') {
      const catalogo = eppItemsStorage.getAll();
      const filas = ['Codigo,Articulo,Categoria,Tipo,Marca,Modelo,Norma,Talla,Unidad,Costo Unitario,Stock Actual,Stock Minimo,Valor Total Stock,Estado'];
      catalogo.forEach(item => {
        const valorTotal = (item.stockActual * item.costoUnitario).toFixed(2);
        filas.push(`"${item.codigo}","${item.articulo}","${item.categoria}","${item.tipo}","${item.marca}","${item.modelo}","${item.norma}","${item.talla}","${item.unidad}",${item.costoUnitario},${item.stockActual},${item.stockMinimo},${valorTotal},"${item.estado}"`);
      });
      return filas.join('\n');
    }

    return '';
  }
}

export const syncManager = new SyncManager();
