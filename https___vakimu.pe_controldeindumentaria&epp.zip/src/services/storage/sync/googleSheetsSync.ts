import { GasService } from '../../gasService';
import { EstadoConexion } from '../../../types';
import { configStorage } from '../configStorage';
import { empresasStorage } from '../empresasStorage';
import { trabajadoresStorage } from '../trabajadoresStorage';
import { eppItemsStorage } from '../eppItemsStorage';
import { entregasStorage } from '../entregasStorage';
import { inspeccionesStorage } from '../inspeccionesStorage';
import { plantillasStorage } from '../plantillasStorage';
import { documentosStorage } from '../documentosStorage';
import { descuentosStorage } from '../descuentosStorage';
import { infraccionesStorage } from '../infraccionesStorage';
import { liquidacionesStorage } from '../liquidacionesStorage';
import { notifyStorageChange } from '../eventEmitter';
import { normalizarEmpresaId } from '../../../utils/empresaResolver';
import { offlineQueue } from './offlineQueue';

export class GoogleSheetsSync {
  private static pullEnCurso: Promise<{ success: boolean; mensaje: string }> | null = null;

  public static async pull(): Promise<{ success: boolean; mensaje: string }> {
    if (this.pullEnCurso) {
      return this.pullEnCurso;
    }

    this.pullEnCurso = this.ejecutarPull();
    try {
      return await this.pullEnCurso;
    } finally {
      this.pullEnCurso = null;
    }
  }

  private static async ejecutarPull(): Promise<{ success: boolean; mensaje: string }> {
    const cfg = configStorage.get();
    const url =
      cfg.gasWebAppUrl && cfg.gasWebAppUrl.trim().startsWith('https://script.google.com')
        ? cfg.gasWebAppUrl.trim()
        : '';

    if (!url) {
      return {
        success: false,
        mensaje: 'Sin conexión a Google Apps Script. Por favor ingrese la URL de su Web App en el módulo de Configuración para sincronizar.'
      };
    }

    // Detección reactiva previa: si el navegador reporta estar desconectado
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      configStorage.set({
        gasWebAppUrl: url,
        estadoConexion: 'desconectado',
        latenciaMs: 0,
        ultimaActualizacion: new Date().toLocaleTimeString()
      });
      notifyStorageChange();
      return {
        success: false,
        mensaje: 'Modo fuera de línea: Sin conexión a internet. Los datos locales continúan disponibles.'
      };
    }

    const t0 = performance.now();
    try {
      // 1. Procesar y vaciar cola offline previa si hay conexión
      if (offlineQueue.obtenerCantidadPendientes() > 0) {
        try {
          const resCola = await offlineQueue.procesarCola(url);
          if (resCola.procesados > 0) {
            console.info(`[GoogleSheetsSync] Se procesaron ${resCola.procesados} mutaciones pendientes desde la cola offline.`);
          }
        } catch (queueErr) {
          console.warn('[GoogleSheetsSync] Error al vaciar cola offline previa:', queueErr);
        }
      }

      // 2. Traer datos frescos desde Google Sheets
      const datos = await GasService.obtenerDatosCompletos(url, cfg.spreadsheetId);
      const latenciaMs = Math.round(performance.now() - t0);
      // Calibración adaptada a Google Apps Script / Google Sheets (< 6000 ms es normal y saludable en arquitectura serverless)
      const estadoConexion: EstadoConexion = latenciaMs > 6000 ? 'lento' : 'conectado';

      configStorage.set({
        gasWebAppUrl: url,
        estadoConexion,
        latenciaMs,
        ultimaActualizacion: new Date().toLocaleTimeString()
      });

      if (datos) {
        if (Array.isArray(datos.empresas) && datos.empresas.length > 0) {
          empresasStorage.setAll(datos.empresas);
        }
        if (Array.isArray(datos.trabajadores) && datos.trabajadores.length > 0) {
          const mapeados = datos.trabajadores.map((raw: any) => {
            const getVal = (variantes: string[]): string => {
              for (const v of variantes) {
                if (raw[v] !== undefined && raw[v] !== null && String(raw[v]).trim() !== '') {
                  return String(raw[v]).trim();
                }
              }
              const keys = Object.keys(raw);
              for (const v of variantes) {
                const vNorm = v.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
                for (const k of keys) {
                  const kNorm = k.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
                  if (kNorm === vNorm && raw[k] !== undefined && raw[k] !== null && String(raw[k]).trim() !== '') {
                    return String(raw[k]).trim();
                  }
                }
              }
              return '';
            };

            const normalizarFechaIso = (fStr: string): string => {
              if (!fStr) return '';
              if (/^\d{4}-\d{2}-\d{2}/.test(fStr)) return fStr.slice(0, 10);
              const m = fStr.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
              if (m) {
                return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
              }
              return fStr;
            };

            const isDesfasadoPorCabeceraAntigua = Boolean(
              raw.codigo &&
                /^\d{8}$/.test(String(raw.codigo).trim()) &&
                raw.dni &&
                isNaN(Number(raw.dni))
            );

            let dni = '';
            let nombreCompleto = '';
            let empresaStr = '';
            let condicionStr = '';
            let sexo: 'M' | 'F' = 'M';
            let fechaIngreso = '';
            let fechaNacimiento: string | undefined = undefined;
            let puesto = '';
            let area = '';
            let telefono: string | undefined = undefined;
            let correo: string | undefined = undefined;
            let edadCalc: number | undefined = undefined;

            if (isDesfasadoPorCabeceraAntigua) {
              dni = String(raw.codigo).trim();
              nombreCompleto = String(raw.dni).trim();
              empresaStr = String(raw.nombreCompleto || '').trim();
              condicionStr = String(raw.empresaId || '').trim();
              sexo = String(raw.empresaNombre).toUpperCase() === 'F' ? 'F' : 'M';
              fechaIngreso = normalizarFechaIso(String(raw.area || ''));
              fechaNacimiento = raw.cargo ? normalizarFechaIso(String(raw.cargo)) : undefined;
              puesto = String(raw.fechaIngreso || '').trim();
              area = String(raw.estado || '').trim();
              telefono = raw.telefono ? String(raw.telefono).trim() : undefined;
              correo = raw.email || raw.correo ? String(raw.email || raw.correo).trim() : undefined;
            } else {
              dni = getVal(['dni', 'codigo', 'documento', 'nroDocumento']);
              nombreCompleto = getVal([
                'apellidosNombres',
                'apellidos y nombres',
                'nombreCompleto',
                'trabajadorNombre',
                'nombres',
                'colaborador'
              ]);
              empresaStr = getVal(['empresa', 'empresaNombre', 'razonSocial', 'empresaId']);
              condicionStr = getVal(['condicion', 'condición', 'estado', 'condicionLaboral']) || 'Activo';
              const sexoRaw = getVal(['sexo', 'genero', 'género']).toUpperCase();
              sexo = sexoRaw === 'F' ? 'F' : 'M';

              const fIngRaw = getVal([
                'fechaIngreso',
                'Fecha de entrada',
                'fecha de entrada',
                'ingreso',
                'fechaIngresoSST'
              ]);
              fechaIngreso = normalizarFechaIso(fIngRaw);

              const fNacRaw = getVal([
                'fechaNacimiento',
                'cierreNación',
                'cierrenacion',
                'fecha de nacimiento',
                'nacimiento',
                'fNacimiento'
              ]);
              fechaNacimiento = fNacRaw ? normalizarFechaIso(fNacRaw) : undefined;

              const edadRaw = getVal(['edad', 'Edad', 'age']);
              edadCalc = undefined;
              if (edadRaw) {
                const parsed = parseInt(String(edadRaw).replace(/\D+/g, ''), 10);
                if (!isNaN(parsed)) edadCalc = parsed;
              }
              if (edadCalc === undefined && fechaNacimiento) {
                const b = new Date(fechaNacimiento);
                if (!isNaN(b.getTime())) {
                  const today = new Date();
                  let age = today.getFullYear() - b.getFullYear();
                  const m = today.getMonth() - b.getMonth();
                  if (m < 0 || (m === 0 && today.getDate() < b.getDate())) age--;
                  if (age >= 0 && age < 120) edadCalc = age;
                }
              }

              puesto = getVal(['puesto', 'cargo', 'puesto / cargo', 'puestoCargo', 'ocupacion']);
              area = getVal(['area', 'área', 'departamento', 'seccion']);
              telefono = getVal(['telefono', 'teléfono', 'celular', 'contacto']) || undefined;
              correo = getVal(['correo', 'email', 'correoElectronico', 'correoElectrónico']) || undefined;
            }

            const empresaId = normalizarEmpresaId({
              empresaId: raw.empresaId,
              empresa: empresaStr,
              empresaNombre: raw.empresaNombre,
              razonSocial: raw.razonSocial,
              ruc: raw.ruc || raw.RUC
            });
            const isPerpol = empresaId === 'EMP-PERPOL' || empresaId === 'PERPOL';
            const empresaNombre = isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.';
            const estado =
              condicionStr.toLowerCase() === 'cesado'
                ? ('Cesado' as const)
                : condicionStr.toLowerCase() === 'inactivo'
                ? ('Inactivo' as const)
                : ('Activo' as const);

            return {
              codigo:
                raw.codigo && !/^\d{8}$/.test(String(raw.codigo))
                  ? String(raw.codigo)
                  : dni || `TRAB-${Math.floor(Math.random() * 1000)}`,
              dni: dni || (raw.codigo ? String(raw.codigo) : ''),
              nombreCompleto: nombreCompleto || 'Trabajador',
              apellidosNombres: nombreCompleto || 'Trabajador',
              empresaId,
              empresaNombre,
              empresa: empresaNombre,
              area: area || 'Operaciones',
              cargo: puesto || 'Trabajador',
              puesto: puesto || 'Trabajador',
              fechaIngreso: fechaIngreso || '2023-01-01',
              fechaNacimiento,
              edad: edadCalc,
              sexo,
              estado,
              condicion: estado,
              telefono,
              email: correo,
              correo
            };
          });
          trabajadoresStorage.setAll(mapeados);
        }
        if (Array.isArray(datos.catalogoEPP) && datos.catalogoEPP.length > 0) {
          eppItemsStorage.setAll(datos.catalogoEPP);
        }
        if (Array.isArray(datos.entregas) && datos.entregas.length > 0) {
          const detallesMap = new Map<string, any[]>();
          if (Array.isArray(datos.detallesEntregas)) {
            datos.detallesEntregas.forEach((det: any) => {
              const kId = String(det.idEntrega || det.entregaId || '').trim();
              const kReg = String(det.numeroRegistro || '').trim();
              if (kId) {
                if (!detallesMap.has(kId)) detallesMap.set(kId, []);
                detallesMap.get(kId)!.push(det);
              }
              if (kReg && kReg !== kId) {
                if (!detallesMap.has(kReg)) detallesMap.set(kReg, []);
                detallesMap.get(kReg)!.push(det);
              }
            });
          }

          const entregasProcesadas = datos.entregas.map((rawE: any, idx: number) => {
            const idKey = String(rawE.id || '').trim();
            const regKey = String(rawE.numeroRegistro || '').trim();
            const items = detallesMap.get(idKey) || (regKey ? detallesMap.get(regKey) : []) || [];
            const rawDetalles = Array.isArray(rawE.detalles) && rawE.detalles.length > 0 ? rawE.detalles : items;
            const regNum = (rawE.numeroRegistro || '').replace(/^REG-?/i, '') || String(idx + 1).padStart(4, '0');

            const detallesNormalizados = rawDetalles.map((det: any, dIdx: number) => {
              const cantidad = Number(det.cantidad) || 1;
              const costoUnitario = Number(det.costoUnitario) || 0;
              const importe = Number(det.importe) || (cantidad * costoUnitario);
              const tipoNorm = String(det.tipo || 'EPP').toUpperCase().includes('UNIFORM') ? 'Uniforme' : 'EPP';
              const idDetalleLimpio = (det.idDetalle && !String(det.idDetalle).match(/^DET-\d{12,}/))
                ? String(det.idDetalle).trim()
                : `DET-${regNum}-${dIdx + 1}`;

              return {
                idDetalle: idDetalleLimpio,
                idEntrega: idKey || `ENT-${regNum}`,
                codigoEPP: String(det.codigoEPP || '').trim(),
                articulo: String(det.articulo || '').trim(),
                tipo: tipoNorm,
                talla: String(det.talla || '').trim() || 'Estándar',
                unidad: String(det.unidad || '').trim() || 'Unidad',
                cantidad,
                costoUnitario,
                importe,
                motivo: det.motivo || rawE.tipoEntregaGeneral || 'Entrega inicial',
                fechaRenovacion: det.fechaRenovacion ? String(det.fechaRenovacion).slice(0, 10) : '',
                observaciones: det.observaciones ? String(det.observaciones).trim() : ''
              };
            });

            const sumUnidades = detallesNormalizados.reduce((acc: number, d: any) => acc + (Number(d.cantidad) || 0), 0);
            const sumImporte = detallesNormalizados.reduce((acc: number, d: any) => acc + (Number(d.importe) || 0), 0);

            const totalUnidades = sumUnidades > 0 ? sumUnidades : (Number(rawE.totalUnidades) || 0);
            const importeTotal = sumImporte > 0 ? Number(sumImporte.toFixed(2)) : (Number(rawE.importeTotal) || 0);

            return {
              ...rawE,
              detalles: detallesNormalizados,
              totalUnidades,
              importeTotal
            };
          });

          entregasStorage.setAll(entregasProcesadas);
        }
        if (Array.isArray(datos.inspecciones) && datos.inspecciones.length > 0) {
          const detallesInspMap = new Map<string, any[]>();
          if (Array.isArray(datos.detallesInspecciones)) {
            datos.detallesInspecciones.forEach((det: any) => {
              const kId = String(det.idInspeccion || det.inspeccionId || '').trim();
              if (kId) {
                if (!detallesInspMap.has(kId)) detallesInspMap.set(kId, []);
                detallesInspMap.get(kId)!.push(det);
              }
            });
          }

          const inspeccionesProcesadas = datos.inspecciones.map((insp: any) => {
            const idKey = String(insp.id || '').trim();
            const items = detallesInspMap.get(idKey) || [];
            const rawDetalles = Array.isArray(insp.detalles) && insp.detalles.length > 0 ? insp.detalles : items;
            const empIdNorm = (insp.empresaId === 'EMP-PERPOL' || insp.empresaId === 'PERPOL' || String(insp.empresaNombre || '').toUpperCase().includes('PERPOL')) ? 'PERPOL' : 'TR3';
            return {
              ...insp,
              empresaId: empIdNorm,
              detalles: rawDetalles
            };
          });
          inspeccionesStorage.setAll(inspeccionesProcesadas);
        }
        if (Array.isArray(datos.descuentos) && datos.descuentos.length > 0) {
          const descuentosNormalizados = datos.descuentos.map((d: any) => ({
            ...d,
            empresaId: (d.empresaId === 'EMP-PERPOL' || d.empresaId === 'PERPOL' || String(d.empresaNombre || '').toUpperCase().includes('PERPOL')) ? 'PERPOL' : 'TR3'
          }));
          descuentosStorage.setAll(descuentosNormalizados);
        }
        if (Array.isArray(datos.infracciones) && datos.infracciones.length > 0) {
          const infraccionesNormalizadas = datos.infracciones.map((inf: any) => ({
            ...inf,
            empresaId: (inf.empresaId === 'EMP-PERPOL' || inf.empresaId === 'PERPOL' || String(inf.empresaNombre || '').toUpperCase().includes('PERPOL')) ? 'PERPOL' : 'TR3'
          }));
          infraccionesStorage.setAll(infraccionesNormalizadas);
        }
        if (Array.isArray(datos.liquidaciones) && datos.liquidaciones.length > 0) {
          const liquidacionesNormalizadas = datos.liquidaciones.map((liq: any) => ({
            ...liq,
            empresaId: (liq.empresaId === 'EMP-PERPOL' || liq.empresaId === 'PERPOL' || String(liq.empresaNombre || '').toUpperCase().includes('PERPOL')) ? 'PERPOL' : 'TR3'
          }));
          liquidacionesStorage.setAll(liquidacionesNormalizadas);
        }
        if (Array.isArray(datos.plantillas) && datos.plantillas.length > 0) {
          plantillasStorage.fusionarRemotas(datos.plantillas);
        }
        if (Array.isArray(datos.documentos) && datos.documentos.length > 0) {
          const documentosNormalizados = datos.documentos.map((doc: any) => ({
            ...doc,
            empresaId: (doc.empresaId === 'EMP-PERPOL' || doc.empresaId === 'PERPOL' || String(doc.empresaNombre || '').toUpperCase().includes('PERPOL')) ? 'PERPOL' : 'TR3'
          }));
          documentosStorage.setAll(documentosNormalizados);
        }

        notifyStorageChange();
      }

      const totalEntregas = Array.isArray(datos.entregas) ? datos.entregas.length : 0;
      const totalDetalles = Array.isArray(datos.detallesEntregas) ? datos.detallesEntregas.length : 0;

      return {
        success: true,
        mensaje: `Sincronización en vivo completada exitosamente (${latenciaMs} ms): ${totalEntregas} entregas y ${totalDetalles} ítems de EPP actualizados.`
      };
    } catch (err: any) {
      const latenciaMs = Math.round(performance.now() - t0);
      const estaOffline = typeof navigator !== 'undefined' && !navigator.onLine;
      configStorage.set({
        gasWebAppUrl: url,
        estadoConexion: estaOffline ? 'desconectado' : 'error',
        latenciaMs: estaOffline ? 0 : latenciaMs,
        ultimaActualizacion: new Date().toLocaleTimeString()
      });
      notifyStorageChange();
      return {
        success: false,
        mensaje: estaOffline
          ? 'Dispositivo sin conexión a internet. Los datos continúan disponibles en modo local.'
          : `Conexión con Google Sheets temporalmente no disponible: ${
              err.message || 'Error de red'
            }. Los datos continúan activos en la aplicación.`
      };
    }
  }

  public static async pushAll(): Promise<{ success: boolean; mensaje: string }> {
    const cfg = configStorage.get();
    const url =
      cfg.gasWebAppUrl && cfg.gasWebAppUrl.trim().startsWith('https://script.google.com')
        ? cfg.gasWebAppUrl.trim()
        : '';

    if (!url) {
      return {
        success: false,
        mensaje: 'Sin conexión a Google Apps Script. Por favor configure la URL de su Web App en el módulo de Configuración.'
      };
    }

    try {
      const payload = {
        action: 'sincronizarTodo',
        datos: {
          trabajadores: trabajadoresStorage.getAll().map(t => {
            let edadCalc = t.edad;
            if ((edadCalc === undefined || edadCalc === null || edadCalc === '') && t.fechaNacimiento) {
              const b = new Date(t.fechaNacimiento);
              if (!isNaN(b.getTime())) {
                const today = new Date();
                let age = today.getFullYear() - b.getFullYear();
                const m = today.getMonth() - b.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < b.getDate())) age--;
                if (age >= 0 && age < 120) edadCalc = age;
              }
            }
            return {
              dni: t.dni,
              apellidosNombres: t.apellidosNombres || t.nombreCompleto,
              empresa: t.empresa || t.empresaNombre,
              puesto: t.puesto || t.cargo,
              area: t.area,
              condicion: t.condicion || t.estado,
              sexo: t.sexo || 'M',
              fechaNacimiento: t.fechaNacimiento || '',
              edad: edadCalc !== undefined && edadCalc !== null ? edadCalc : '',
              fechaIngreso: t.fechaIngreso,
              telefono: t.telefono || '',
              correo: t.correo || t.email || ''
            };
          }),
          catalogoEPP: eppItemsStorage.getAll(),
          plantillas: plantillasStorage.getAll()
        }
      };

      await GasService.enviarPost(url, payload);
      return { success: true, mensaje: 'Datos maestros subidos y poblados exitosamente en Google Sheets.' };
    } catch (err: any) {
      console.warn('Error al ejecutar sincronizarTodoHaciaGoogleSheets:', err);
      return { success: false, mensaje: err.message || 'Error al guardar datos en Google Sheets' };
    }
  }
}
