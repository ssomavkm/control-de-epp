import { GasService } from '../../gasService';
import { notifyStorageChange } from '../eventEmitter';

export type TipoMutacion = 
  | 'entrega' 
  | 'inspeccion' 
  | 'descuento' 
  | 'infraccion' 
  | 'trabajador' 
  | 'epp' 
  | 'plantilla' 
  | 'generico';

export interface MutacionPendiente {
  id: string;
  tipo: TipoMutacion;
  descripcion: string;
  action: string;
  payload: any;
  timestamp: number;
  reintentos: number;
  ultimoError?: string;
}

const STORAGE_KEY_QUEUE = 'ssoma_offline_mutation_queue';

class OfflineQueueService {
  private queueListeners: Array<(count: number) => void> = [];

  /**
   * Obtiene todas las mutaciones pendientes guardadas en localStorage
   */
  public obtenerPendientes(): MutacionPendiente[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY_QUEUE);
      if (!data) return [];
      const parsed = JSON.parse(data);
      if (!Array.isArray(parsed)) return [];

      // Auto-depuración: Eliminar de raíz operaciones de Drive, liquidaciones o acciones no reconocidas
      const filtrados = parsed.filter(item => {
        const action = String(item.action || item.payload?.action || '').toLowerCase();
        const desc = String(item.descripcion || '').toLowerCase();
        const err = String(item.ultimoError || '').toLowerCase();
        if (action.includes('liquidacion')) return false;
        if (action.includes('drive') || desc.includes('drive')) return false;
        if (err.includes('acción no reconocida') || err.includes('accion no reconocida')) return false;
        if (err.includes('driveapp')) return false;
        return true;
      });

      if (filtrados.length !== parsed.length) {
        try {
          localStorage.setItem(STORAGE_KEY_QUEUE, JSON.stringify(filtrados));
        } catch (e) {}
      }

      return filtrados;
    } catch (e) {
      console.warn('[OfflineQueue] Error al leer cola offline:', e);
      return [];
    }
  }

  /**
   * Obtiene el número de operaciones en cola pendientes de sincronizar
   */
  public obtenerCantidadPendientes(): number {
    return this.obtenerPendientes().length;
  }

  /**
   * Suscribe un listener para cambios en la cantidad de elementos en cola
   */
  public suscribir(listener: (count: number) => void): () => void {
    this.queueListeners.push(listener);
    listener(this.obtenerCantidadPendientes());
    return () => {
      this.queueListeners = this.queueListeners.filter(l => l !== listener);
    };
  }

  private notificar(): void {
    const count = this.obtenerCantidadPendientes();
    this.queueListeners.forEach(listener => {
      try {
        listener(count);
      } catch (err) {
        console.warn('[OfflineQueue] Error en listener:', err);
      }
    });
    notifyStorageChange();
  }

  private guardarPendientes(items: MutacionPendiente[]): void {
    try {
      localStorage.setItem(STORAGE_KEY_QUEUE, JSON.stringify(items));
    } catch (e) {
      console.warn('[OfflineQueue] Error al guardar en localStorage:', e);
    }
    this.notificar();
  }

  /**
   * Encola una mutación para ser procesada cuando haya conexión
   */
  public encolar(
    mutacion: Omit<MutacionPendiente, 'id' | 'timestamp' | 'reintentos'>
  ): MutacionPendiente {
    // Descartar automáticamente acciones no deseadas (Drive, liquidaciones no soportadas en Sheets)
    const action = String(mutacion.action || (mutacion as any).payload?.action || '').toLowerCase();
    const desc = String(mutacion.descripcion || '').toLowerCase();
    if (action.includes('drive') || desc.includes('drive') || action.includes('liquidacion')) {
      return {
        id: `MUT-DISCARDED-${Date.now()}`,
        timestamp: Date.now(),
        reintentos: 0,
        ...mutacion
      };
    }

    const items = this.obtenerPendientes();
    const nueva: MutacionPendiente = {
      ...mutacion,
      id: `MUT-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
      reintentos: 0
    };

    items.push(nueva);
    this.guardarPendientes(items);
    console.info(`[OfflineQueue] Mutación encolada (${nueva.tipo}): ${nueva.descripcion}. Total en cola: ${items.length}`);
    return nueva;
  }

  /**
   * Elimina una mutación de la cola por ID
   */
  public eliminar(id: string): void {
    const items = this.obtenerPendientes().filter(it => it.id !== id);
    this.guardarPendientes(items);
  }

  /**
   * Limpia toda la cola
   */
  public limpiar(): void {
    this.guardarPendientes([]);
  }

  /**
   * Procesa la cola de mutaciones enviándolas a Google Apps Script en orden FIFO
   */
  public async procesarCola(url: string): Promise<{ procesados: number; fallidos: number; ultimoError?: string }> {
    if (!url || !url.trim().startsWith('http')) {
      return { procesados: 0, fallidos: 0, ultimoError: 'URL de Google Apps Script no configurada' };
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('[OfflineQueue] Sin conexión a internet; postergando procesamiento de cola.');
      return { procesados: 0, fallidos: 0, ultimoError: 'Sin conexión a internet' };
    }

    const items = this.obtenerPendientes();
    if (items.length === 0) {
      return { procesados: 0, fallidos: 0 };
    }

    console.info(`[OfflineQueue] Procesando ${items.length} mutaciones pendientes en cola...`);
    let procesados = 0;
    let fallidos = 0;
    let ultimoError: string | undefined;
    const itemsRestantes: MutacionPendiente[] = [];

    for (const item of items) {
      try {
        await GasService.enviarPostDirecto(url, item.payload);
        procesados++;
      } catch (err: any) {
        const errMsg = String(err?.message || '');
        if (
          errMsg.toLowerCase().includes('acción no reconocida') || 
          errMsg.toLowerCase().includes('accion no reconocida') || 
          errMsg.toLowerCase().includes('driveapp')
        ) {
          // Descartado silenciosamente, no se añade a itemsRestantes
          continue;
        }

        fallidos++;
        item.reintentos = (item.reintentos || 0) + 1;
        item.ultimoError = errMsg || 'Error de red';
        ultimoError = item.ultimoError;
        itemsRestantes.push(item);

        // Si se detecta desconexión durante el bucle, detener y mantener los restantes
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
          const idxActual = items.indexOf(item);
          for (let j = idxActual + 1; j < items.length; j++) {
            itemsRestantes.push(items[j]);
          }
          break;
        }
      }
    }

    this.guardarPendientes(itemsRestantes);
    return { procesados, fallidos, ultimoError };
  }
}

export const offlineQueue = new OfflineQueueService();

// Conectar automáticamente el fallback desacoplado con GasService
GasService.registerQueueFallback((payload: any, meta?: any) => {
  const actionName = payload?.action || 'Operación';
  let desc = meta?.descripcion;
  if (!desc) {
    if (actionName === 'guardarEntrega') {
      desc = `Entrega ${payload?.entrega?.numeroRegistro || ''}`;
    } else if (actionName === 'guardarInspeccion') {
      desc = `Inspección ${payload?.inspeccion?.numeroInspeccion || ''}`;
    } else if (actionName === 'guardarTrabajador') {
      desc = `Trabajador ${payload?.trabajador?.dni || ''}`;
    } else if (actionName === 'guardarDescuento') {
      desc = `Descuento ${payload?.descuento?.numeroDescuento || ''}`;
    } else if (actionName === 'guardarInfraccion') {
      desc = `Infracción ${payload?.infraccion?.numeroInfraccion || ''}`;
    } else {
      desc = actionName;
    }
  }

  offlineQueue.encolar({
    tipo: meta?.tipo || 'generico',
    descripcion: desc.trim(),
    action: actionName,
    payload
  });
});
