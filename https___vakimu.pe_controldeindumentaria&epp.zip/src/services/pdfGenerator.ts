/**
 * =========================================================================
 * ARCHIVO DE RE-EXPORTACIÓN DE COMPATIBILIDAD (PDF GENERATOR)
 * =========================================================================
 * La lógica y módulos PDF han sido modularizados en src/services/pdf/
 * Este archivo re-exporta todas las funciones, tipos y la clase
 * PDFGeneratorService para mantener total retrocompatibilidad.
 */

export * from './pdf';
