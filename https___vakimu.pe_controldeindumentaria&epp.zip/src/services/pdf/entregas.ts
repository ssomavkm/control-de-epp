import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';
import { EntregaEPP, PlantillaFormato } from '../../types';
import { storageService } from '../storageService';
import { PDFResult, getThemeColors, blindarDocPDF } from './utils/pdfStyles';
import { dibujarLogoEnCabecera } from './utils/pdfHeaders';

export async function generarFormatoEntregaPDF(entrega: EntregaEPP, plantilla?: PlantillaFormato): Promise<PDFResult> {
    // Si no se proporcionó plantilla explícita, recuperar la plantilla activa guardada
    if (!plantilla) {
      plantilla = storageService.getPlantillaPorCodigo(entrega.codigoPlantilla || 'FO-SST-GEN-050')
               || storageService.getPlantillaActivaParaEntrega();
    }

    const doc = blindarDocPDF(new jsPDF({
      orientation: plantilla?.orientacionPagina || 'portrait',
      unit: 'mm',
      format: 'a4'
    }));

    const { isPerpol, primaryColor, secondaryColor, accentBorder, darkSlate, slateLabel, grayBorder, textMuted, textMeta, fontFamilia } = getThemeColors(entrega.empresaId, plantilla);

    const codigoFormatoOficial = String(plantilla?.codigo || entrega.codigoPlantilla || 'FO-SST-GEN-050');
    const versionFormatoOficial = String(plantilla?.version || entrega.versionPlantilla || '02');
    const fechaAprobacionOficial = String(plantilla?.fechaAprobacion || '02/01/2026');

    // Generar código QR para trazabilidad y auditoría si está habilitado
    let qrDataUrl: string | null = null;
    if (plantilla?.mostrarCodigoQR !== false) {
      const qrData = `SSOMA|${codigoFormatoOficial}|${versionFormatoOficial}|${entrega.ruc}|${entrega.numeroRegistro}|${entrega.dni}|${entrega.fechaEntrega}`;
      qrDataUrl = await QRCode.toDataURL(qrData, { width: 120, margin: 1 });
    }

    const pageWidth = doc.internal.pageSize.getWidth(); // ~210mm
    const pageHeight = doc.internal.pageSize.getHeight(); // ~297mm
    const margin = 12;
    const contentWidth = pageWidth - margin * 2;

    // Función para dibujar encabezado oficial idéntico en cada página
    const dibujarEncabezado = (paginaActual: number, totalPaginas: number) => {
      // Borde del contenedor de encabezado (3 columnas estilo ISO)
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      doc.setLineWidth(0.4);
      doc.rect(margin, margin, contentWidth, 24);

      // Columna 1: Logo e identidad empresarial (ancho: 48mm)
      doc.line(margin + 48, margin, margin + 48, margin + 24);
      dibujarLogoEnCabecera(doc, entrega.empresaId, margin, margin, 48, 24, plantilla);

      // Columna 2: Título del Formato Oficial (ancho central: 96mm)
      const col2Start = margin + 48;
      const col2Width = contentWidth - 48 - 42;
      doc.line(col2Start + col2Width, margin, col2Start + col2Width, margin + 24);

      const mostrarTituloSistema = !plantilla?.inhabilitarTituloSistemaGestion && Boolean((plantilla?.tituloSistemaGestion || '').trim() !== '') && !plantilla?.nombre?.toUpperCase().includes('REGISTRO DE ENTREGA');
      const tituloSistema = (plantilla?.tituloSistemaGestion || '').trim();
      
      const mostrarNormativa = !plantilla?.inhabilitarReferenciaNormativa && Boolean((plantilla?.referenciaNormativa || '').trim() !== '') && !plantilla?.nombre?.toUpperCase().includes('REGISTRO DE ENTREGA');
      const refNorma = (plantilla?.referenciaNormativa || '').trim();

      if (mostrarTituloSistema) {
        doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
        doc.setFont(fontFamilia, 'bold');
        doc.setFontSize(8);
        doc.text(tituloSistema, col2Start + col2Width / 2, margin + 6.5, { align: 'center' });
      }
      
      doc.setFontSize(9.5);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      const tituloFormato = plantilla?.nombre || 'REGISTRO DE ENTREGA DE EQUIPOS DE PROTECCIÓN PERSONAL (EPP) Y ROPA DE TRABAJO';
      const lineasTitulo = doc.splitTextToSize(tituloFormato.toUpperCase(), col2Width - 6);

      let yBaseTitulo = margin + 12.5;
      if (lineasTitulo.length === 1) {
        yBaseTitulo = !mostrarTituloSistema && !mostrarNormativa ? margin + 13.5 : (!mostrarTituloSistema ? margin + 11.5 : (mostrarNormativa ? margin + 13 : margin + 14));
        doc.text(lineasTitulo[0], col2Start + col2Width / 2, yBaseTitulo, { align: 'center' });
      } else {
        yBaseTitulo = !mostrarTituloSistema && !mostrarNormativa ? margin + 10.5 : (!mostrarTituloSistema ? margin + 9 : (mostrarNormativa ? margin + 12 : margin + 13));
        doc.text(lineasTitulo[0], col2Start + col2Width / 2, yBaseTitulo, { align: 'center' });
        doc.text(lineasTitulo[1], col2Start + col2Width / 2, yBaseTitulo + 4.8, { align: 'center' });
      }

      if (mostrarNormativa) {
        doc.setFont(fontFamilia, 'normal');
        doc.setFontSize(6.2);
        doc.setTextColor(100, 116, 139);
        doc.text(refNorma, col2Start + col2Width / 2, margin + 21.5, { align: 'center' });
      }

      // Columna 3: Control Documentario (ancho derecho: 42mm)
      const col3Start = col2Start + col2Width;
      
      doc.setFontSize(7);
      doc.setTextColor(71, 85, 105);
      doc.setFont(fontFamilia, 'bold');
      
      // Subdivisión de 4 filas
      const hFila = 6;
      for (let i = 1; i < 4; i++) {
        doc.line(col3Start, margin + i * hFila, margin + contentWidth, margin + i * hFila);
      }
      
      // Fila 1: Código (Heredado de la plantilla configurada)
      doc.text('CÓDIGO:', col3Start + 2, margin + 4.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(codigoFormatoOficial, col3Start + 18, margin + 4.2);

      // Fila 2: Versión (Heredado de la plantilla configurada)
      doc.setFont(fontFamilia, 'bold');
      doc.text('VERSIÓN:', col3Start + 2, margin + 10.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(versionFormatoOficial, col3Start + 18, margin + 10.2);

      // Fila 3: Fecha Emisión / Aprobación (Heredado de la plantilla configurada)
      doc.setFont(fontFamilia, 'bold');
      doc.text('F. EMISIÓN:', col3Start + 2, margin + 16.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(fechaAprobacionOficial, col3Start + 18, margin + 16.2);

      // Fila 4: Paginación oficial
      doc.setFont(fontFamilia, 'bold');
      doc.text('PÁGINA:', col3Start + 2, margin + 22.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(`${paginaActual} de ${totalPaginas}`, col3Start + 18, margin + 22.2);
    };

    // 1. Bloque: 1. DATOS DE LA RAZÓN SOCIAL DEL EMPLEADOR
    let currentY = margin + 27;

    const renderDatosEmpresa = () => {
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(margin, currentY, contentWidth, 5, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont(fontFamilia, 'bold');
      doc.setFontSize(7.5);
      doc.text('1. DATOS DEL EMPLEADOR PRINCIPAL / RAZÓN SOCIAL', margin + 3, currentY + 3.6);

      currentY += 5;
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      doc.setLineWidth(0.3);
      doc.rect(margin, currentY, contentWidth, 18);

      // Líneas divisorias internas
      doc.line(margin, currentY + 6, margin + contentWidth, currentY + 6);
      doc.line(margin, currentY + 12, margin + contentWidth, currentY + 12);
      doc.line(margin + 125, currentY, margin + 125, currentY + 6); // RUC divider
      doc.line(margin + 125, currentY + 6, margin + 125, currentY + 12); // N° trabajadores divider

      // Fila 1: Razón Social y RUC
      doc.setFontSize(7);
      doc.setFont(fontFamilia, 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text('RAZÓN SOCIAL:', margin + 2, currentY + 4.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.razonSocial, margin + 28, currentY + 4.2);

      doc.setFont(fontFamilia, 'bold');
      doc.text('RUC:', margin + 127, currentY + 4.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.ruc, margin + 137, currentY + 4.2);

      // Fila 2: Actividad Económica y N° Trabajadores
      doc.setFont(fontFamilia, 'bold');
      doc.text('ACTIVIDAD ECONÓMICA:', margin + 2, currentY + 10.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.actividadEconomica, margin + 38, currentY + 10.2);

      doc.setFont(fontFamilia, 'bold');
      doc.text('N° TRABAJADORES:', margin + 127, currentY + 10.2);
      doc.setFont(fontFamilia, 'normal');
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text(`${entrega.numTrabajadoresActivosCalculado} personas activas`, margin + 158, currentY + 10.2);

      // Fila 3: Dirección de la Planta
      doc.setFont(fontFamilia, 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text('DOMICILIO / PLANTA:', margin + 2, currentY + 16.2);
      doc.setFont(fontFamilia, 'normal');
      doc.setFontSize(6.5);
      const dirText = doc.splitTextToSize(entrega.direccion, contentWidth - 36);
      doc.text(dirText, margin + 34, currentY + 16.2);

      currentY += 21;
    };

    // 2. Bloque: 2. DATOS DEL TRABAJADOR Y REGISTRO DE ENTREGA
    const renderDatosTrabajador = () => {
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(margin, currentY, contentWidth, 5, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont(fontFamilia, 'bold');
      doc.setFontSize(7.5);
      doc.text('2. DATOS DEL TRABAJADOR Y CONTROL DE LA ENTREGA', margin + 3, currentY + 3.6);

      // Badge de Número de Registro en la cabecera
      doc.setFont(fontFamilia, 'bold');
      doc.text(`REGISTRO N°: ${entrega.numeroRegistro}`, margin + contentWidth - 45, currentY + 3.6);

      currentY += 5;
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      doc.setLineWidth(0.3);
      doc.rect(margin, currentY, contentWidth, 20);

      // Divisores
      doc.line(margin, currentY + 6.6, margin + contentWidth, currentY + 6.6);
      doc.line(margin, currentY + 13.3, margin + contentWidth, currentY + 13.3);
      // Divisor vertical en Fila 2 (entre Área y Puesto; en Fila 1 la celda de Nombres abarca hasta margin + 125)
      doc.line(margin + 65, currentY + 6.6, margin + 65, currentY + 13.3);
      // Divisor vertical que separa Nombres de DNI en Fila 1 y Puesto de Motivo en Fila 2
      doc.line(margin + 125, currentY, margin + 125, currentY + 13.3);

      // Fila 1: Apellidos y Nombres (combinado de 125mm) y DNI (reemplaza Código Trab.)
      doc.setFontSize(7);
      doc.setFont(fontFamilia, 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text('APELLIDOS Y NOMBRES:', margin + 2, currentY + 4.6);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.trabajadorNombre, margin + 35, currentY + 4.6);

      doc.setFont(fontFamilia, 'bold');
      doc.text('DNI:', margin + 127, currentY + 4.6);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.dni, margin + 136, currentY + 4.6);

      // Fila 2: Área, Cargo/Puesto, Tipo Entrega
      doc.setFont(fontFamilia, 'bold');
      doc.text('ÁREA / SECCIÓN:', margin + 2, currentY + 11.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.area, margin + 26, currentY + 11.2);

      doc.setFont(fontFamilia, 'bold');
      doc.text('PUESTO / CARGO:', margin + 67, currentY + 11.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.cargo, margin + 93, currentY + 11.2);

      doc.setFont(fontFamilia, 'bold');
      doc.text('MOTIVO ENTREGA:', margin + 127, currentY + 11.2);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.tipoEntregaGeneral, margin + 155, currentY + 11.2);

      // Fila 3: Fecha Entrega, Responsable SST, Total Unidades
      doc.setFont(fontFamilia, 'bold');
      doc.text('FECHA ENTREGA:', margin + 2, currentY + 17.8);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.fechaEntrega, margin + 26, currentY + 17.8);

      doc.setFont(fontFamilia, 'bold');
      doc.text('RESPONSABLE ENTREGA SST:', margin + 67, currentY + 17.8);
      doc.setFont(fontFamilia, 'normal');
      doc.text(entrega.responsableEntrega, margin + 107, currentY + 17.8);

      currentY += 23;
    };

    renderDatosEmpresa();
    renderDatosTrabajador();

    // 3. Bloque: 3. DETALLE DE EQUIPOS DE PROTECCIÓN PERSONAL ENTREGADOS
    const tableBody = (entrega.detalles || []).map((det, index) => [
      String(index + 1),
      String(det.codigoEPP || '-'),
      String(det.articulo || '-') + (det.talla ? ` - ${det.talla}` : ''),
      String(det.unidad || 'Unidad'),
      String(det.cantidad ?? 1),
      String(det.motivo || entrega.tipoEntregaGeneral || 'Dotación Periódica'),
      String(det.fechaRenovacion || '-'),
      String(det.observaciones || 'Conforme')
    ]);

    // Usar autoTable para maquetar la tabla de artículos con estilos formales de auditoría
    autoTable(doc, {
      startY: currentY,
      margin: { left: margin, right: margin },
      head: [[
        'ÍTEM',
        'CÓDIGO',
        'DESCRIPCIÓN DEL EQUIPO DE PROTECCIÓN PERSONAL / TALLA',
        'UNIDAD',
        'CANT.',
        'MOTIVO',
        'F. RENOVACIÓN',
        'OBSERVACIONES'
      ]],
      body: tableBody,
      theme: 'grid',
      styles: {
        font: fontFamilia,
        fontSize: 6.8,
        cellPadding: 1.8,
        lineColor: [203, 213, 225],
        lineWidth: 0.25,
        textColor: [15, 23, 42],
        valign: 'middle'
      },
      headStyles: {
        fillColor: primaryColor as [number, number, number],
        textColor: [255, 255, 255],
        font: fontFamilia,
        fontStyle: 'bold',
        halign: 'center',
        fontSize: 7
      },
      columnStyles: {
        0: { halign: 'center', cellWidth: 10 },
        1: { halign: 'center', cellWidth: 20 },
        2: { halign: 'left', cellWidth: 'auto' },
        3: { halign: 'center', cellWidth: 14 },
        4: { halign: 'center', cellWidth: 12, fontStyle: 'bold' },
        5: { halign: 'center', cellWidth: 22 },
        6: { halign: 'center', cellWidth: 22 },
        7: { halign: 'left', cellWidth: 26 }
      },
      didDrawPage: (data) => {
        // En cada página agregada por desborde, redibujar el encabezado
        // El total final de páginas se actualiza al terminar
      }
    });

    // Posición después de la tabla
    let finalTableY = (doc as any).lastAutoTable.finalY + 3;

    // Verificar si queda suficiente espacio para cláusulas legales y firmas
    const espacioRequerido = !plantilla?.inhabilitarDeclaracionCompromiso ? 70 : 35;
    if (finalTableY + espacioRequerido > pageHeight - margin) {
      doc.addPage();
      finalTableY = margin + 28;
    }

    // 4. Bloque: COMPROMISO DEL TRABAJADOR Y DECLARACIÓN DE CAPACITACIÓN (Opcional según inhabilitar)
    let firmasY = finalTableY;
    if (!plantilla?.inhabilitarDeclaracionCompromiso) {
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      doc.setLineWidth(0.3);
      doc.rect(margin, finalTableY, contentWidth, 36, 'FD');

      // Título Compromiso
      doc.setFont(fontFamilia, 'bold');
      doc.setFontSize(6.8);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text('COMPROMISO DEL TRABAJADOR:', margin + 2.5, finalTableY + 3.8);

      doc.setFont(fontFamilia, 'normal');
      doc.setFontSize(5.6);
      doc.setTextColor(30, 41, 59);
      const textoCompromiso = (plantilla?.declaracionCompromiso && plantilla.declaracionCompromiso.trim().length > 0)
        ? [plantilla.declaracionCompromiso]
        : [
            'Declaro haber recibido los Equipos de Protección Personal (EPP) detallados en el presente documento, en buen estado y condiciones adecuadas de uso, comprometiéndome a:',
            '• Utilizarlos obligatoriamente durante la ejecución de mis actividades laborales, de acuerdo con los riesgos identificados.',
            '• Conservarlos y mantenerlos en buen estado, evitando pérdidas, daños o usos inadecuados, en caso de pérdida, daño o deterioro ocasionado por un uso inadecuado, asumiré la responsabilidad correspondiente.',
            '• Informar oportunamente cualquier deterioro, desgaste o condición que pueda afectar su capacidad de protección.  • No modificar, alterar ni retirar componentes del EPP entregado.'
          ];

      let tY = finalTableY + 6.8;
      textoCompromiso.forEach(p => {
        const splitP = doc.splitTextToSize(p, contentWidth - 5);
        doc.text(splitP, margin + 2.5, tY);
        tY += splitP.length * 2.5;
      });

      tY += 0.8;
      // Título Capacitación
      doc.setFont(fontFamilia, 'bold');
      doc.setFontSize(6.8);
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text('DECLARACIÓN DE CAPACITACIÓN:', margin + 2.5, tY);

      tY += 3;
      doc.setFont(fontFamilia, 'normal');
      doc.setFontSize(5.6);
      doc.setTextColor(30, 41, 59);
      const textoCapacitacion = [
        'Declaro haber recibido capacitación sobre el uso, cuidado y responsabilidades asociadas al Equipo de Protección Personal (EPP) entregado, considerando los siguientes aspectos:',
        '• Uso correcto del EPP durante la ejecución de mis actividades.  • Limitaciones y condiciones de uso del equipo de protección asignado.',
        '• Mantenimiento, limpieza y conservación del EPP para asegurar su adecuado funcionamiento.  • Criterios para la reposición o cambio del EPP en caso de desgaste, deterioro o pérdida de capacidad de protección.'
      ];

      textoCapacitacion.forEach(p => {
        const splitP = doc.splitTextToSize(p, contentWidth - 5);
        doc.text(splitP, margin + 2.5, tY);
        tY += splitP.length * 2.5;
      });

      firmasY = finalTableY + 38;
    } else {
      firmasY = finalTableY + 2;
    }

    // 5. Bloque: SECCIÓN DE FIRMAS Y CONFORMIDAD
    const anchoCajaFirma = (contentWidth - 4) / 2;

    // Caja 1: Firma del Trabajador
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.3);
    doc.setFillColor(255, 255, 255);
    doc.rect(margin, firmasY, anchoCajaFirma, 26, 'FD');

    // Caja 2: Firma del Responsable SST
    doc.rect(margin + anchoCajaFirma + 4, firmasY, anchoCajaFirma, 26, 'FD');

    // Si hay firma capturada en dataURL para trabajador, insertarla
    if (entrega.firmaTrabajador && entrega.firmaTrabajador.startsWith('data:image')) {
      try {
        doc.addImage(entrega.firmaTrabajador, 'PNG', margin + 15, firmasY + 1, anchoCajaFirma - 30, 13);
      } catch (e) {
        console.warn('No se pudo incrustar imagen de firma de trabajador:', e);
      }
    } else {
      doc.setFont(fontFamilia, 'italic');
      doc.setFontSize(6.5);
      doc.setTextColor(148, 163, 184);
      doc.text(
        entrega.estado === 'Pendiente de Firma' ? '[PENDIENTE DE FIRMA EN PLANTA]' : '[DOCUMENTO CONFORMADO]',
        margin + anchoCajaFirma / 2,
        firmasY + 8,
        { align: 'center' }
      );
    }

    // Línea de firma trabajador
    doc.setDrawColor(100, 116, 139);
    doc.setLineDashPattern([1, 1], 0);
    doc.line(margin + 12, firmasY + 16, margin + anchoCajaFirma - 12, firmasY + 16);
    doc.setLineDashPattern([], 0);

    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(6.8);
    doc.setTextColor(15, 23, 42);
    doc.text('FIRMA Y HUELLA DEL TRABAJADOR', margin + anchoCajaFirma / 2, firmasY + 19.5, { align: 'center' });
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(6);
    doc.text(`DNI: ${entrega.dni} | ${entrega.trabajadorNombre}`, margin + anchoCajaFirma / 2, firmasY + 23.5, { align: 'center' });

    // Firma Responsable SST
    if (entrega.firmaResponsable && entrega.firmaResponsable.startsWith('data:image')) {
      try {
        doc.addImage(entrega.firmaResponsable, 'PNG', margin + anchoCajaFirma + 19, firmasY + 1, anchoCajaFirma - 30, 13);
      } catch (e) {
        console.warn('No se pudo incrustar imagen de firma de SST:', e);
      }
    } else {
      doc.setFont(fontFamilia, 'italic');
      doc.setFontSize(6.5);
      doc.setTextColor(148, 163, 184);
      doc.text('[FIRMA Y SELLO DE CONFORMIDAD SST]', margin + anchoCajaFirma + 4 + anchoCajaFirma / 2, firmasY + 8, { align: 'center' });
    }

    doc.setDrawColor(100, 116, 139);
    doc.setLineDashPattern([1, 1], 0);
    doc.line(margin + anchoCajaFirma + 16, firmasY + 16, margin + contentWidth - 12, firmasY + 16);
    doc.setLineDashPattern([], 0);

    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(6.8);
    doc.setTextColor(15, 23, 42);
    if (!plantilla?.inhabilitarCargoResponsable) {
      const matchCargo = (entrega.responsableEntrega || '').match(/\((.*?)\)/);
      const cargoDetectado = matchCargo ? `RESPONSABLE SST / ${matchCargo[1].toUpperCase()}` : '';
      const cargoEntrega = plantilla?.cargoResponsablePorDefecto || cargoDetectado || 'RESPONSABLE DE SEGURIDAD Y SALUD EN EL TRABAJO';
      doc.text(cargoEntrega, margin + anchoCajaFirma + 4 + anchoCajaFirma / 2, firmasY + 19.5, { align: 'center' });
    }
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(6);
    doc.text(entrega.responsableEntrega, margin + anchoCajaFirma + 4 + anchoCajaFirma / 2, firmasY + 23.5, { align: 'center' });

    // 6. Pie de Página con Código QR de Validación y Metadatos de Trazabilidad
    const pieY = pageHeight - margin + 1;
    if (qrDataUrl) {
      doc.addImage(qrDataUrl, 'PNG', margin + contentWidth - 11, pageHeight - margin - 9, 10, 10);
    }

    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Registro Oficial SSOMA: ${entrega.numeroRegistro} | Operación: ${entrega.operationId} | Plantilla: ${codigoFormatoOficial} v${versionFormatoOficial} | Emisión: ${entrega.fechaCreacion}`,
      margin,
      pieY
    );
    if (!plantilla?.inhabilitarLemaPiePagina) {
      doc.setFont(fontFamilia, 'normal');
      doc.text(
        plantilla?.lemaPiePagina || 'Documento generado bajo el estándar oficial de Seguridad y Salud en el Trabajo. Válido para auditorías del Ministerio de Trabajo / SUNAFIL e ISO 45001.',
        margin,
        pieY + 2.5
      );
    }

    // Ajustar encabezados y número de páginas total en todas las páginas
    const totalPages = doc.internal.pages.length - 1;
    for (let p = 1; p <= totalPages; p++) {
      doc.setPage(p);
      dibujarEncabezado(p, totalPages);
    }

    const arrayBuffer = doc.output('arraybuffer');
    const pdfBlob = doc.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const dateFormatted = entrega.fechaEntrega.replace(/-/g, '');
    const fileName = `ENTREGA_EPP_${entrega.numeroRegistro}_${entrega.ruc}_${entrega.dni}_${dateFormatted}.pdf`;

    return {
      blob: pdfBlob,
      blobUrl,
      arrayBuffer,
      fileName
    };
  }

export const generarPDFEntrega = generarFormatoEntregaPDF;
