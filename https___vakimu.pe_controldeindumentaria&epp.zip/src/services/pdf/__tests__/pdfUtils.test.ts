import { describe, it, expect } from 'vitest';
import {
  formatearFechaPDF,
  formatearMonedaPEN,
  truncarTexto,
  sanitizarNombreArchivoPDF
} from '../utils/pdfFormatters';
import { parseHexColor, getThemeColors, getLogoEmpresa } from '../utils/pdfStyles';

describe('PDF Formatters and Utilities', () => {
  it('debería formatear fecha ISO a formato dd/mm/yyyy', () => {
    expect(formatearFechaPDF('2026-03-15')).toBe('15/03/2026');
    expect(formatearFechaPDF('2026-12-31T10:00:00')).toBe('31/12/2026');
    expect(formatearFechaPDF('')).toBe('-');
  });

  it('debería formatear montos a soles peruanos PEN', () => {
    expect(formatearMonedaPEN(45)).toBe('S/ 45.00');
    expect(formatearMonedaPEN(120.5)).toBe('S/ 120.50');
    expect(formatearMonedaPEN(0)).toBe('S/ 0.00');
  });

  it('debería truncar textos largos agregando elipsis', () => {
    expect(truncarTexto('Hola Mundo', 20)).toBe('Hola Mundo');
    expect(truncarTexto('Este texto es sumamente largo y detallado', 10)).toBe('Este te...');
  });

  it('debería sanitizar nombres de archivo para descargas seguras', () => {
    const sucio = 'REPORTE:2026/03*01|TEST?.pdf';
    const limpio = sanitizarNombreArchivoPDF(sucio);
    expect(limpio).toBe('REPORTE_2026_03_01_TEST_.pdf');
    expect(limpio).not.toContain(':');
    expect(limpio).not.toContain('/');
  });

  it('debería parsear colores hexadecimales correctamente', () => {
    expect(parseHexColor('#166534')).toEqual([22, 101, 52]);
    expect(parseHexColor('#ffffff')).toEqual([255, 255, 255]);
    expect(parseHexColor('invalido')).toBeNull();
  });

  it('debería asignar paleta institucional PERPOL vs TR3', () => {
    const coloresPerpol = getThemeColors('EMP-PERPOL');
    expect(coloresPerpol.isPerpol).toBe(true);
    expect(coloresPerpol.primaryColor).toEqual([22, 101, 52]); // Verde corporativo

    const coloresTr3 = getThemeColors('EMP-TR3');
    expect(coloresTr3.isPerpol).toBe(false);
    expect(coloresTr3.primaryColor).toEqual([30, 64, 175]); // Azul corporativo
  });

  it('debería retornar el logo oficial para EMP-PERPOL y EMP-TR3', () => {
    const logoPerpol = getLogoEmpresa('EMP-PERPOL');
    expect(logoPerpol).toBeDefined();
    expect(logoPerpol?.startsWith('data:image/png;base64,')).toBe(true);

    const logoTr3 = getLogoEmpresa('EMP-TR3');
    expect(logoTr3).toBeDefined();
    expect(logoTr3?.startsWith('data:image/png;base64,')).toBe(true);
  });
});
