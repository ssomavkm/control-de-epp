import { describe, it, expect } from 'vitest';
import { PLANTILLAS_SEED } from '../../../data/seeds/plantillas';
import { plantillasStorage } from '../../storage/plantillasStorage';

describe('Eliminación de elementos de cabecera en formatos oficiales', () => {
  it('debería tener inhabilitado el título de sistema, subtítulo de membrete y referencia normativa en las plantillas semilla', () => {
    const fo50 = PLANTILLAS_SEED.find(p => p.codigo === 'FO-SST-GEN-050');
    const foDesc = PLANTILLAS_SEED.find(p => p.codigo === 'FO-SST-DES-001');
    const foInf = PLANTILLAS_SEED.find(p => p.codigo === 'FO-SST-INF-001');

    expect(fo50).toBeDefined();
    expect(fo50?.inhabilitarTituloSistemaGestion).toBe(true);
    expect(fo50?.inhabilitarSubtituloMembrete).toBe(true);
    expect(fo50?.inhabilitarReferenciaNormativa).toBe(true);
    expect(fo50?.referenciaNormativa).toBe('');

    expect(foDesc).toBeDefined();
    expect(foDesc?.inhabilitarTituloSistemaGestion).toBe(true);
    expect(foDesc?.inhabilitarSubtituloMembrete).toBe(true);
    expect(foDesc?.inhabilitarReferenciaNormativa).toBe(true);
    expect(foDesc?.referenciaNormativa).toBe('');

    expect(foInf).toBeDefined();
    expect(foInf?.inhabilitarTituloSistemaGestion).toBe(true);
    expect(foInf?.inhabilitarSubtituloMembrete).toBe(true);
    expect(foInf?.inhabilitarReferenciaNormativa).toBe(true);
    expect(foInf?.referenciaNormativa).toBe('');
  });

  it('debería retornar las plantillas activas con las opciones inhabilitadas en plantillasStorage', () => {
    const entregaPlantilla = plantillasStorage.getActivaParaEntrega();
    const descuentoPlantilla = plantillasStorage.getActivaParaDescuento();
    const infraccionPlantilla = plantillasStorage.getActivaParaInfraccion();

    expect(entregaPlantilla.inhabilitarTituloSistemaGestion).toBe(true);
    expect(entregaPlantilla.inhabilitarSubtituloMembrete).toBe(true);
    expect(entregaPlantilla.inhabilitarReferenciaNormativa).toBe(true);

    expect(descuentoPlantilla.inhabilitarTituloSistemaGestion).toBe(true);
    expect(descuentoPlantilla.inhabilitarSubtituloMembrete).toBe(true);
    expect(descuentoPlantilla.inhabilitarReferenciaNormativa).toBe(true);

    expect(infraccionPlantilla.inhabilitarTituloSistemaGestion).toBe(true);
    expect(infraccionPlantilla.inhabilitarSubtituloMembrete).toBe(true);
    expect(infraccionPlantilla.inhabilitarReferenciaNormativa).toBe(true);
  });

  it('debería tener configurado el logo oficial de PERPOL IDEAS S.A.C. para los 3 formatos', () => {
    const fo50 = plantillasStorage.getActivaParaEntrega();
    const foDesc = plantillasStorage.getActivaParaDescuento();
    const foInf = plantillasStorage.getActivaParaInfraccion();

    expect(fo50.logoPerpol).toBeDefined();
    expect(fo50.logoPerpol?.startsWith('data:image/png;base64,')).toBe(true);

    expect(foDesc.logoPerpol).toBeDefined();
    expect(foDesc.logoPerpol?.startsWith('data:image/png;base64,')).toBe(true);

    expect(foInf.logoPerpol).toBeDefined();
    expect(foInf.logoPerpol?.startsWith('data:image/png;base64,')).toBe(true);
  });

  it('debería tener configurado el logo oficial de TR3 ALIMENTOS S.A.C. para los 3 formatos', () => {
    const fo50 = plantillasStorage.getActivaParaEntrega();
    const foDesc = plantillasStorage.getActivaParaDescuento();
    const foInf = plantillasStorage.getActivaParaInfraccion();

    expect(fo50.logoTr3).toBeDefined();
    expect(fo50.logoTr3?.startsWith('data:image/png;base64,')).toBe(true);

    expect(foDesc.logoTr3).toBeDefined();
    expect(foDesc.logoTr3?.startsWith('data:image/png;base64,')).toBe(true);

    expect(foInf.logoTr3).toBeDefined();
    expect(foInf.logoTr3?.startsWith('data:image/png;base64,')).toBe(true);
  });

  it('debería retornar el logo correcto para PERPOL y TR3 con getLogoEmpresa', async () => {
    const { getLogoEmpresa } = await import('../utils/pdfStyles');
    const logoPerpol = getLogoEmpresa('EMP-PERPOL');
    const logoTr3 = getLogoEmpresa('EMP-TR3');

    expect(logoPerpol).toBeDefined();
    expect(logoPerpol?.startsWith('data:image/png;base64,')).toBe(true);

    expect(logoTr3).toBeDefined();
    expect(logoTr3?.startsWith('data:image/png;base64,')).toBe(true);
    expect(logoTr3).not.toBe(logoPerpol);
  });
});
