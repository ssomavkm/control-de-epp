import jsPDF from 'jspdf';
import { PlantillaFormato } from '../../../types';
import { getThemeColors, getLogoEmpresa } from './pdfStyles';

export interface IsoHeaderConfig {
  empresaId: string;
  codigoPlantilla: string;
  versionPlantilla: string;
  fechaEmision: string;
  tituloLinea1: string;
  tituloLinea2?: string;
  subtitulo?: string;
  plantilla?: PlantillaFormato;
}

/**
 * Dibuja el contenedor de logo oficial en la Columna 1 del encabezado ISO
 */
export function dibujarLogoEnCabecera(
  doc: jsPDF,
  empresaId: string,
  x: number,
  y: number,
  width = 48,
  height = 24,
  plantilla?: PlantillaFormato
) {
  const empIdStr = String(empresaId || '').toUpperCase();
  const isPerpol = empIdStr === 'EMP-PERPOL' || empIdStr.includes('PERPOL') || empIdStr.includes('20392729977');
  const colors = getThemeColors(empIdStr, plantilla);
  const logoUrl = getLogoEmpresa(empIdStr, plantilla);

  // Fondo suave
  doc.setFillColor(colors.secondaryColor[0], colors.secondaryColor[1], colors.secondaryColor[2]);
  doc.rect(x + 0.2, y + 0.2, width - 0.4, height - 0.4, 'F');

  let dibujadoConExito = false;
  if (logoUrl) {
    try {
      const formato = logoUrl.includes('image/jpeg') || logoUrl.includes('image/jpg') ? 'JPEG' : 'PNG';
      // Dimensiones máximas dentro del contenedor respetando márgenes
      const maxW = width - 6; // 42mm
      const maxH = height - 4; // 20mm
      let renderW = maxW;
      let renderH = maxH;
      let posX = x + 3;
      let posY = y + 2;

      try {
        const props = doc.getImageProperties(logoUrl);
        if (props && props.width && props.height) {
          const ratio = props.width / props.height;
          renderW = maxW;
          renderH = renderW / ratio;
          if (renderH > maxH) {
            renderH = maxH;
            renderW = renderH * ratio;
          }
          posX = x + (width - renderW) / 2;
          posY = y + (height - renderH) / 2;
        }
      } catch (errProps) {
        // Fallback a maxW x maxH
      }

      doc.addImage(logoUrl, formato, posX, posY, renderW, renderH, undefined, 'FAST');
      dibujadoConExito = true;
    } catch (e) {
      console.warn('Fallback al texto corporativo debido a error en renderizado de logo:', e);
    }
  }

  const fontFamilia = colors.fontFamilia;
  if (!dibujadoConExito) {
    doc.setTextColor(colors.primaryColor[0], colors.primaryColor[1], colors.primaryColor[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(10);
    const mostrarSubtitulo = !plantilla?.inhabilitarSubtituloMembrete && Boolean((plantilla?.textoSubtituloMembrete || '').trim() !== '');
    const yNombreEmpresa = mostrarSubtitulo ? y + 11 : y + 12.5;
    doc.text(isPerpol ? 'PERPOL' : 'TR3', x + width / 2, yNombreEmpresa, { align: 'center' });
    doc.setFontSize(7.5);
    doc.setFont(fontFamilia, 'normal');
    doc.setTextColor(colors.slateLabel[0], colors.slateLabel[1], colors.slateLabel[2]);
    doc.text(isPerpol ? 'IDEAS S.A.C.' : 'ALIMENTOS S.A.C.', x + width / 2, yNombreEmpresa + 5, { align: 'center' });
    if (mostrarSubtitulo) {
      doc.setFontSize(5.5);
      doc.text(String(plantilla?.textoSubtituloMembrete || '').trim(), x + width / 2, y + 20, { align: 'center' });
    }
  }
}

/**
 * Dibuja el encabezado tripartito estandarizado conforme a normas ISO / OHSAS
 */
export function dibujarEncabezadoISO(
  doc: jsPDF,
  config: IsoHeaderConfig,
  paginaActual: number,
  totalPaginas: number,
  margin = 12,
  contentWidth = 186
) {
  const colors = getThemeColors(config.empresaId, config.plantilla);
  const fontFamilia = config.plantilla?.tipografia || 'helvetica';

  // Contenedor rectangular exterior
  doc.setDrawColor(colors.grayBorder[0], colors.grayBorder[1], colors.grayBorder[2]);
  doc.setLineWidth(0.4);
  doc.rect(margin, margin, contentWidth, 24);

  // Columna 1: Logo e Identidad Razón Social (48mm)
  doc.line(margin + 48, margin, margin + 48, margin + 24);
  dibujarLogoEnCabecera(doc, config.empresaId, margin, margin, 48, 24, config.plantilla);

  // Columna 2: Título Oficial del Formato
  const col2Start = margin + 48;
  const col2Width = contentWidth - 48 - 42;
  doc.line(col2Start + col2Width, margin, col2Start + col2Width, margin + 24);

  // Excluir elementos eliminados para los 3 formatos oficiales de SSOMA
  const esFormatoOficialTres =
    config.codigoPlantilla === 'FO-SST-GEN-050' ||
    config.codigoPlantilla === 'FO-SST-DES-001' ||
    config.codigoPlantilla === 'FO-SST-INF-001' ||
    (config.tituloLinea1 && (
      config.tituloLinea1.toUpperCase().includes('ENTREGA DE EQUIPOS') ||
      config.tituloLinea1.toUpperCase().includes('DESCUENTO POR PÉRDIDA') ||
      config.tituloLinea1.toUpperCase().includes('REPORTE DE INFRACCIÓN')
    ));

  const mostrarTituloSistema = !esFormatoOficialTres && !config.plantilla?.inhabilitarTituloSistemaGestion && Boolean((config.plantilla?.tituloSistemaGestion || '').trim() !== '');
  const mostrarNormativa = !esFormatoOficialTres && !config.plantilla?.inhabilitarReferenciaNormativa && Boolean((config.plantilla?.referenciaNormativa || config.subtitulo || '').trim() !== '');

  if (mostrarTituloSistema) {
    doc.setTextColor(colors.darkSlate[0], colors.darkSlate[1], colors.darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(8);
    doc.text(config.plantilla?.tituloSistemaGestion!.trim() || 'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA', col2Start + col2Width / 2, margin + 6.8, { align: 'center' });
  }

  doc.setFontSize(9.5);
  doc.setTextColor(colors.primaryColor[0], colors.primaryColor[1], colors.primaryColor[2]);
  const yTit1 = !mostrarTituloSistema && !mostrarNormativa 
    ? (config.tituloLinea2 ? margin + 11 : margin + 13) 
    : (!mostrarTituloSistema ? margin + 11 : margin + 12.5);
  doc.text(config.tituloLinea1, col2Start + col2Width / 2, yTit1, { align: 'center' });
  if (config.tituloLinea2) {
    doc.text(config.tituloLinea2, col2Start + col2Width / 2, yTit1 + 5, { align: 'center' });
  }

  if (mostrarNormativa) {
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(colors.textMuted[0], colors.textMuted[1], colors.textMuted[2]);
    const textoNorma = (config.plantilla?.referenciaNormativa || config.subtitulo || '').trim();
    doc.text(textoNorma, col2Start + col2Width / 2, margin + 22, { align: 'center' });
  }

  // Columna 3: Control Documentario (42mm)
  const col3Start = col2Start + col2Width;
  const hFila = 6;
  for (let i = 1; i < 4; i++) {
    doc.line(col3Start, margin + i * hFila, margin + contentWidth, margin + i * hFila);
  }

  doc.setFontSize(7);
  doc.setTextColor(71, 85, 105);
  doc.setFont(fontFamilia, 'bold');

  // Fila 1: Código
  doc.text('CÓDIGO:', col3Start + 2, margin + 4.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(String(config.codigoPlantilla || '-'), col3Start + 18, margin + 4.2);

  // Fila 2: Versión
  doc.setFont(fontFamilia, 'bold');
  doc.text('VERSIÓN:', col3Start + 2, margin + 10.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(String(config.versionPlantilla || '-'), col3Start + 18, margin + 10.2);

  // Fila 3: Fecha Emisión
  doc.setFont(fontFamilia, 'bold');
  doc.text('F. EMISIÓN:', col3Start + 2, margin + 16.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(String(config.fechaEmision || '-'), col3Start + 18, margin + 16.2);

  // Fila 4: Paginación
  doc.setFont(fontFamilia, 'bold');
  doc.text('PÁGINA:', col3Start + 2, margin + 22.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(`${paginaActual} de ${totalPaginas}`, col3Start + 18, margin + 22.2);
}
