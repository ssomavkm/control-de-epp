import jsPDF from 'jspdf';
import { PlantillaFormato } from '../../../types';
import { storageService } from '../../storageService';
import { LOGO_PERPOL_IDEAS_PNG, LOGO_TR3_ALIMENTOS_PNG } from '../../../data/assets/logos';

export interface PDFResult {
  blob: Blob;
  blobUrl: string;
  arrayBuffer: ArrayBuffer;
  fileName: string;
}

export function parseHexColor(hex?: string): [number, number, number] | null {
  if (!hex || !/^#[0-9A-Fa-f]{6}$/.test(hex)) return null;
  const num = parseInt(hex.slice(1), 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

export interface ThemeColors {
  isPerpol: boolean;
  primaryColor: [number, number, number];
  secondaryColor: [number, number, number];
  accentBorder: [number, number, number];
  darkSlate: [number, number, number];
  slateLabel: [number, number, number];
  grayBorder: [number, number, number];
  textMuted: [number, number, number];
  textMeta: [number, number, number];
  fontFamilia: string;
}

export function getThemeColors(empresaId?: string, plantilla?: PlantillaFormato): ThemeColors {
  const empIdStr = String(empresaId || '').toUpperCase();
  const isPerpol = empIdStr === 'EMP-PERPOL' || empIdStr.includes('PERPOL') || empIdStr.includes('20392729977');
  const customPrimary = parseHexColor(plantilla?.colorPrimarioHex);
  // Verde Corporativo Homologado PERPOL vs Azul Corporativo Homologado TR3
  const primaryColor: [number, number, number] = customPrimary || (isPerpol ? [22, 101, 52] : [30, 64, 175]);
  const secondaryColor: [number, number, number] = isPerpol ? [240, 253, 244] : [239, 246, 255];
  const accentBorder: [number, number, number] = isPerpol ? [187, 247, 208] : [191, 219, 254];
  const darkSlate: [number, number, number] = [15, 23, 42]; // #0f172a texto estándar principal
  const slateLabel: [number, number, number] = [51, 65, 85]; // #334155 etiquetas de celdas
  const grayBorder: [number, number, number] = [203, 213, 225]; // #cbd5e1 bordes de tablas y celdas
  const textMuted: [number, number, number] = [100, 116, 139]; // #64748b notas legales
  const textMeta: [number, number, number] = [148, 163, 184]; // #94a3b8 metadatos de pie
  const fontFamilia = plantilla?.tipografia || 'helvetica';

  return {
    isPerpol,
    primaryColor,
    secondaryColor,
    accentBorder,
    darkSlate,
    slateLabel,
    grayBorder,
    textMuted,
    textMeta,
    fontFamilia
  };
}

export function getLogoEmpresa(empresaId?: string, plantilla?: PlantillaFormato): string | undefined {
  const empIdStr = String(empresaId || '').toUpperCase();
  const isPerpol = empIdStr === 'EMP-PERPOL' || empIdStr.includes('PERPOL') || empIdStr.includes('20392729977');
  const p = plantilla || storageService.getPlantillas().find(x => x.codigo === 'FO-SST-GEN-050') || storageService.getPlantillaActivaParaEntrega();
  
  // 1. Si la plantilla actual tiene el logo específico asignado
  if (isPerpol && p?.logoPerpol) return p.logoPerpol;
  if (!isPerpol && p?.logoTr3) return p.logoTr3;

  // 2. Si la empresa en el catálogo maestro tiene logoUrl asignado
  const emp = storageService.getEmpresas().find(e => e.id === (isPerpol ? 'EMP-PERPOL' : 'EMP-TR3'));
  if (emp?.logoUrl) return emp.logoUrl;

  // 3. Buscar en cualquiera de las plantillas oficiales guardadas (herencia cruzada entre los 3 formatos)
  const todasLasPlantillas = storageService.getPlantillas();
  for (const t of todasLasPlantillas) {
    if (isPerpol && t.logoPerpol) return t.logoPerpol;
    if (!isPerpol && t.logoTr3) return t.logoTr3;
  }

  // 4. Fallback de logo personalizado genérico
  if (p?.logoPersonalizado) return p.logoPersonalizado;
  for (const t of todasLasPlantillas) {
    if (t.logoPersonalizado) return t.logoPersonalizado;
  }

  // 5. Fallback oficial directo e incondicional
  if (isPerpol) return LOGO_PERPOL_IDEAS_PNG;
  return LOGO_TR3_ALIMENTOS_PNG;
}

/**
 * Envuelve y blinda una instancia de jsPDF contra cualquier valor no-string en `doc.text`
 * (números como 1, booleanos, null, undefined, arrays de números)
 * y en `doc.splitTextToSize` para prevenir el error:
 * "Type of text must be string or Array. '1' is not recognized."
 */
export function blindarDocPDF(doc: jsPDF): jsPDF {
  const origText = (doc as any).text.bind(doc);
  (doc as any).text = function (text: any, ...args: any[]) {
    let safeText: any = text;
    if (safeText === null || safeText === undefined) {
      safeText = '';
    } else if (Array.isArray(safeText)) {
      safeText = safeText.map((item) => (item === null || item === undefined ? '' : String(item)));
    } else if (typeof safeText !== 'string') {
      safeText = String(safeText);
    }
    return origText(safeText, ...args);
  };

  const origSplit = (doc as any).splitTextToSize.bind(doc);
  (doc as any).splitTextToSize = function (text: any, size: any, options: any) {
    const safeText = text === null || text === undefined ? '' : String(text);
    return origSplit(safeText, size, options);
  };

  return doc;
}
