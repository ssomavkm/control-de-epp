/**
 * Utilidades de formateo para generación de reportes y documentos PDF
 */

export function formatearFechaPDF(fechaStr?: string): string {
  if (!fechaStr) return '-';
  try {
    const parts = fechaStr.slice(0, 10).split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return fechaStr;
  } catch {
    return fechaStr;
  }
}

export function formatearMonedaPEN(monto: number): string {
  return `S/ ${Number(monto || 0).toFixed(2)}`;
}

export function truncarTexto(texto: string, maxLen: number): string {
  if (!texto) return '';
  if (texto.length <= maxLen) return texto;
  return texto.slice(0, maxLen - 3) + '...';
}

export function sanitizarNombreArchivoPDF(nombre: string): string {
  return nombre.replace(/[/\\?%*:|"<>]/g, '_').trim();
}
