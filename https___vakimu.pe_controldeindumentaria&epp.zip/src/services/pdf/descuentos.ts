import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';
import { DescuentoEPP, PlantillaFormato } from '../../types';
import { storageService } from '../storageService';
import { PDFResult, getThemeColors, blindarDocPDF } from './utils/pdfStyles';
import { dibujarLogoEnCabecera } from './utils/pdfHeaders';

export async function generarDocumentoDescuentoPDF(descuento: DescuentoEPP, plantilla?: PlantillaFormato): Promise<PDFResult> {
    if (!plantilla) {
      plantilla = storageService.getPlantillaPorCodigo(descuento.codigoPlantilla || 'FO-SST-DES-001')
               || storageService.getPlantillas().find(p => p.tipoDocumento === 'Descuento');
    }

    const doc = blindarDocPDF(new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    }));

    const { isPerpol, primaryColor, secondaryColor, accentBorder, darkSlate, slateLabel, grayBorder, textMuted, textMeta, fontFamilia } = getThemeColors(descuento.empresaId, plantilla);

    const codigoPlantillaOficial = String(plantilla?.codigo || descuento.codigoPlantilla || 'FO-SST-DES-001');
    const versionPlantillaOficial = String(plantilla?.version || descuento.versionPlantilla || '01');
    const fechaAprobacionOficial = String(plantilla?.fechaAprobacion || descuento.fechaSolicitud || '02/01/2026');

    const tituloSistema = (plantilla?.tituloSistemaGestion || '').trim();
    const tituloPrincipal = plantilla?.nombre || 'AUTORIZACIÓN EXPRESA DE DESCUENTO POR PÉRDIDA O DETERIORO DE EPP';
    const normaReferencia = (plantilla?.referenciaNormativa || '').trim();

    // Código QR de autenticidad y trazabilidad laboral
    const qrData = `SSOMA-DESC|${codigoPlantillaOficial}|${descuento.numeroRegistro}|${descuento.ruc}|${descuento.dni}|S/${descuento.montoTotalDescuento.toFixed(2)}|${descuento.fechaSolicitud}`;
    const qrDataUrl = await QRCode.toDataURL(qrData, { width: 120, margin: 1 });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 12;
    const contentWidth = pageWidth - margin * 2;

    // 1. Encabezado Tripartito Oficial ISO / SST
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.4);
    doc.rect(margin, margin, contentWidth, 24);

    // Columna 1: Logo
    doc.line(margin + 48, margin, margin + 48, margin + 24);
    dibujarLogoEnCabecera(doc, descuento.empresaId, margin, margin, 48, 24, plantilla);

    // Columna 2: Título Oficial Dinámico
    const col2Start = margin + 48;
    const col2Width = contentWidth - 48 - 42;
    doc.line(col2Start + col2Width, margin, col2Start + col2Width, margin + 24);

    const mostrarTituloSistema = !plantilla?.inhabilitarTituloSistemaGestion && Boolean((plantilla?.tituloSistemaGestion || '').trim() !== '') && !plantilla?.nombre?.toUpperCase().includes('DESCUENTO');
    const mostrarNormativa = !plantilla?.inhabilitarReferenciaNormativa && Boolean((plantilla?.referenciaNormativa || '').trim() !== '') && !plantilla?.nombre?.toUpperCase().includes('DESCUENTO');

    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    if (mostrarTituloSistema) {
      doc.setFontSize(8);
      doc.text(tituloSistema, col2Start + col2Width / 2, margin + 6.5, { align: 'center' });
    }
    doc.setFontSize(9.5);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    const lineasTitulo = doc.splitTextToSize(tituloPrincipal.toUpperCase(), col2Width - 6);
    let yBaseDesc = margin + 12.5;
    if (lineasTitulo.length === 1) {
      yBaseDesc = !mostrarTituloSistema && !mostrarNormativa ? margin + 13.5 : (!mostrarTituloSistema ? margin + 11.5 : (mostrarNormativa ? margin + 13 : margin + 14));
      doc.text(lineasTitulo[0], col2Start + col2Width / 2, yBaseDesc, { align: 'center' });
    } else {
      yBaseDesc = !mostrarTituloSistema && !mostrarNormativa ? margin + 10.5 : (!mostrarTituloSistema ? margin + 9 : (mostrarNormativa ? margin + 12 : margin + 13));
      doc.text(lineasTitulo[0], col2Start + col2Width / 2, yBaseDesc, { align: 'center' });
      doc.text(lineasTitulo[1], col2Start + col2Width / 2, yBaseDesc + 4.8, { align: 'center' });
    }
    if (mostrarNormativa) {
      doc.setFont(fontFamilia, 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
      doc.text(normaReferencia, col2Start + col2Width / 2, margin + 21.5, { align: 'center' });
    }

    // Columna 3: Control Documentario
    const col3Start = col2Start + col2Width;
    for (let i = 1; i < 4; i++) {
      doc.line(col3Start, margin + i * 6, margin + contentWidth, margin + i * 6);
    }
    doc.setFontSize(7);
    doc.setTextColor(71, 85, 105);
    doc.setFont(fontFamilia, 'bold');
    doc.text('CÓDIGO:', col3Start + 2, margin + 4.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text(codigoPlantillaOficial, col3Start + 17, margin + 4.2);

    doc.setFont(fontFamilia, 'bold');
    doc.text('VERSIÓN:', col3Start + 2, margin + 10.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text(versionPlantillaOficial, col3Start + 17, margin + 10.2);

    doc.setFont(fontFamilia, 'bold');
    doc.text('F. EMISIÓN:', col3Start + 2, margin + 16.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text(fechaAprobacionOficial, col3Start + 17, margin + 16.2);

    doc.setFont(fontFamilia, 'bold');
    doc.text('PÁGINA:', col3Start + 2, margin + 22.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text('1 de 1', col3Start + 17, margin + 22.2);

    let currentY = margin + 26;

    // 2. Sección: 1. DATOS DE LA EMPRESA EMPLEADORA (Estandarizado a 5mm y homogéneo)
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('1. DATOS DE LA EMPRESA EMPLEADORA', margin + 3, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.3);
    doc.rect(margin, currentY, contentWidth, 11);
    doc.line(margin, currentY + 5.5, margin + contentWidth, currentY + 5.5);
    doc.line(margin + 125, currentY, margin + 125, currentY + 5.5);

    doc.setFontSize(6.8);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.text('RAZÓN SOCIAL:', margin + 2, currentY + 3.8);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.empresaNombre, margin + 25, currentY + 3.8);

    doc.setFont(fontFamilia, 'bold');
    doc.text('RUC:', margin + 127, currentY + 3.8);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.ruc, margin + 137, currentY + 3.8);

    doc.setFont(fontFamilia, 'bold');
    doc.text('SEDE / PLANTA:', margin + 2, currentY + 9.3);
    doc.setFont(fontFamilia, 'normal');
    doc.text('PLANTA INDUSTRIAL HUACHIPA - LURIGANCHO, LIMA', margin + 25, currentY + 9.3);

    currentY += 14;

    // 3. Sección: 2. DATOS DEL TRABAJADOR Y CONTROL DEL DESCUENTO
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('2. DATOS DEL TRABAJADOR Y CONTROL DEL DESCUENTO', margin + 3, currentY + 3.6);
    if (descuento.numeroInspeccionOrigen) {
      doc.text(`ORIGEN: ${descuento.numeroInspeccionOrigen}`, margin + contentWidth - 75, currentY + 3.6);
    }
    doc.text(`REGISTRO: ${descuento.numeroRegistro}`, margin + contentWidth - 36, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.3);
    doc.rect(margin, currentY, contentWidth, 16);
    doc.line(margin, currentY + 5.3, margin + contentWidth, currentY + 5.3);
    doc.line(margin, currentY + 10.6, margin + contentWidth, currentY + 10.6);
    // Divisor vertical en Fila 2 (entre Área y Cargo)
    doc.line(margin + 70, currentY + 5.3, margin + 70, currentY + 10.6);
    // Divisor vertical que separa Nombres de DNI en Fila 1 y Cargo de F. Incidente en Fila 2
    doc.line(margin + 125, currentY, margin + 125, currentY + 10.6);

    // Fila 1: Apellidos y Nombres (combinado 125mm) y DNI (reemplaza Código Trab.)
    doc.setFontSize(6.8);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.text('APELLIDOS Y NOMBRES:', margin + 2, currentY + 3.7);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.trabajadorNombre, margin + 35, currentY + 3.7);

    doc.setFont(fontFamilia, 'bold');
    doc.text('DNI:', margin + 127, currentY + 3.7);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.dni, margin + 136, currentY + 3.7);

    // Fila 2
    doc.setFont(fontFamilia, 'bold');
    doc.text('ÁREA / SECCIÓN:', margin + 2, currentY + 9);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.area, margin + 25, currentY + 9);

    doc.setFont(fontFamilia, 'bold');
    doc.text('CARGO / PUESTO:', margin + 72, currentY + 9);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.cargo, margin + 96, currentY + 9);

    doc.setFont(fontFamilia, 'bold');
    doc.text('F. INCIDENTE:', margin + 127, currentY + 9);
    doc.setFont(fontFamilia, 'normal');
    doc.text(descuento.fechaIncidente || descuento.fechaSolicitud, margin + 148, currentY + 9);

    // Fila 3
    doc.setFont(fontFamilia, 'bold');
    doc.text('MOTIVO DECLARADO:', margin + 2, currentY + 14.3);
    doc.setFont(fontFamilia, 'normal');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(descuento.motivoDescuento, margin + 30, currentY + 14.3);

    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.text('DESCRIPCIÓN:', margin + 72, currentY + 14.3);
    doc.setFont(fontFamilia, 'normal');
    const descText = doc.splitTextToSize(descuento.descripcionHechos || 'Sin observaciones adicionales.', contentWidth - 92);
    doc.text(descText[0] || '', margin + 92, currentY + 14.3);

    currentY += 19;

    // 4. Tabla de Artículos a Descontar
    const items = Array.isArray(descuento.items) ? descuento.items : [];
    const tableBody = items.map((it, idx) => [
      idx + 1,
      it?.codigoEPP || '-',
      it?.articulo || '-',
      `${it?.marca || '-'} / ${it?.talla || 'Estándar'}`,
      it?.unidad || 'Unid',
      it?.cantidadPerdida || 1,
      `S/ ${(Number(it?.costoUnitario) || 0).toFixed(2)}`,
      `S/ ${(Number(it?.importeTotal) || 0).toFixed(2)}`
    ]);

    tableBody.push([
      { content: 'TOTAL GENERAL VALORIZADO A DESCONTAR', colSpan: 7, styles: { halign: 'right', fontStyle: 'bold' } },
      { content: `S/ ${descuento.montoTotalDescuento.toFixed(2)}`, styles: { fontStyle: 'bold', textColor: [185, 28, 28] } }
    ] as any);

    autoTable(doc, {
      startY: currentY,
      margin: { left: margin, right: margin },
      head: [['N°', 'CÓD. EPP', 'DESCRIPCIÓN DEL EQUIPO DE PROTECCIÓN (EPP)', 'MARCA / TALLA', 'UNID', 'CANT', 'P. UNIT', 'TOTAL']],
      body: tableBody,
      theme: 'grid',
      styles: { 
        font: fontFamilia,
        fontSize: 6.8, 
        cellPadding: 1.8, 
        lineColor: grayBorder,
        lineWidth: 0.25,
        textColor: darkSlate,
        valign: 'middle'
      },
      headStyles: { 
        fillColor: primaryColor as [number, number, number], 
        textColor: [255, 255, 255], 
        font: fontFamilia,
        fontStyle: 'bold', 
        fontSize: 7,
        halign: 'center' 
      },
      columnStyles: {
        0: { halign: 'center', cellWidth: 8 },
        1: { halign: 'center', cellWidth: 18 },
        2: { cellWidth: 70 },
        3: { halign: 'center', cellWidth: 30 },
        4: { halign: 'center', cellWidth: 14 },
        5: { halign: 'center', cellWidth: 12 },
        6: { halign: 'right', cellWidth: 16 },
        7: { halign: 'right', cellWidth: 18 }
      }
    });

    currentY = (doc as any).lastAutoTable.finalY + 4;

    // 5. Bloque: CONDICIONES DE DEDUCCIÓN EN PLANILLA
    doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setLineWidth(0.3);
    doc.rect(margin, currentY, contentWidth, 12, 'FD');

    doc.setFontSize(6.8);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.text('CONDICIONES DE PAGO Y LIQUIDACIÓN EN PLANILLA:', margin + 3, currentY + 4);

    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'normal');
    doc.text(`• Modalidad acordada: `, margin + 3, currentY + 8.5);
    doc.setFont(fontFamilia, 'bold');
    doc.text(descuento.modalidadPago, margin + 32, currentY + 8.5);

    doc.setFont(fontFamilia, 'normal');
    doc.text(`• N° de Cuotas: `, margin + 80, currentY + 8.5);
    doc.setFont(fontFamilia, 'bold');
    doc.text(`${descuento.cuotas} cuota(s)`, margin + 100, currentY + 8.5);

    doc.setFont(fontFamilia, 'normal');
    doc.text(`• Monto por cuota: `, margin + 125, currentY + 8.5);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(185, 28, 28);
    doc.text(`S/ ${(descuento.montoPorCuota || descuento.montoTotalDescuento).toFixed(2)}`, margin + 150, currentY + 8.5);

    currentY += 15;

    // 6. Cláusula Legal de Consentimiento Expreso (Opcional según inhabilitar)
    if (!plantilla?.inhabilitarDeclaracionCompromiso) {
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, currentY, contentWidth, 23, 'FD');

      doc.setFontSize(6.2);
      doc.setFont(fontFamilia, 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text('DECLARACIÓN JURADA Y CLÁUSULA DE AUTORIZACIÓN VOLUNTARIA DE RETENCIÓN:', margin + 3, currentY + 3.8);

      doc.setFont(fontFamilia, 'normal');
      doc.setTextColor(71, 85, 105);
      const clausula = (plantilla?.declaracionCompromiso && plantilla.declaracionCompromiso.trim().length > 0)
        ? `${plantilla.declaracionCompromiso} [Trabajador: ${descuento.trabajadorNombre} | DNI: ${descuento.dni} | Empresa: ${descuento.empresaNombre} | Deducción autorizada: S/ ${descuento.montoTotalDescuento.toFixed(2)} | Modalidad: ${descuento.modalidadPago}]`
        : `Yo, ${descuento.trabajadorNombre}, identificado(a) con DNI N° ${descuento.dni}, en mi calidad de trabajador(a) de la empresa ${descuento.empresaNombre}, declaro expresamente bajo juramento que he extraviado/deteriorado por causa no imputable al desgaste normal los Equipos de Protección Personal (EPP) detallados en el presente documento, los cuales me fueron entregados para el ejercicio seguro de mis labores. De conformidad con lo previsto en el Artículo 40° del D.S. N° 003-97-TR (TUO del D.Leg. N° 728) y los Artículos 79° y concordantes de la Ley N° 29783, AUTORIZO LIBRE Y EXPRESAMENTE a la empresa a retener y descontar de mi remuneración de planilla y/o beneficios sociales correspondientes el importe total de S/ ${descuento.montoTotalDescuento.toFixed(2)} según la modalidad de pago convenida, a efectos de proceder con la reposición inmediata de mi equipo de seguridad.`;
      const clausulaLines = doc.splitTextToSize(clausula, contentWidth - 6);
      doc.text(clausulaLines, margin + 3, currentY + 7.5);

      currentY += 26;
    } else {
      currentY += 4;
    }

    // 7. Bloque de Firmas (3 columnas: Trabajador con Huella, Supervisor SSOMA, Administración/Nóminas)
    const firmaBoxW = (contentWidth - 6) / 3;
    const firmaBoxH = 34;

    for (let c = 0; c < 3; c++) {
      const bx = margin + c * (firmaBoxW + 3);
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      doc.setFillColor(255, 255, 255);
      doc.rect(bx, currentY, firmaBoxW, firmaBoxH, 'FD');
      doc.line(bx + 4, currentY + 23, bx + firmaBoxW - 4, currentY + 23);
    }

    // Col 1: Trabajador
    if (descuento.firmaTrabajador) {
      try {
        doc.addImage(descuento.firmaTrabajador, 'PNG', margin + 8, currentY + 2, firmaBoxW - 16, 20);
      } catch (e) {
        console.warn('No se pudo renderizar imagen de firma trabajador en PDF:', e);
      }
    }
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.text('FIRMA DEL TRABAJADOR', margin + firmaBoxW / 2, currentY + 26.5, { align: 'center' });
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.8);
    doc.text(`DNI: ${descuento.dni}`, margin + firmaBoxW / 2, currentY + 30, { align: 'center' });
    doc.text('[ Huella Digital en Físico ]', margin + firmaBoxW / 2, currentY + 32.5, { align: 'center' });

    // Col 2: Responsable SSOMA
    const col2Bx = margin + firmaBoxW + 3;
    if (descuento.firmaResponsable) {
      try {
        doc.addImage(descuento.firmaResponsable, 'PNG', col2Bx + 8, currentY + 2, firmaBoxW - 16, 20);
      } catch (e) {
        console.warn('No se pudo renderizar imagen firma SSOMA en PDF:', e);
      }
    }
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    if (!plantilla?.inhabilitarCargoResponsable) {
      const cargoDescuento = plantilla?.cargoResponsablePorDefecto || 'RESPONSABLE SSOMA';
      doc.text(cargoDescuento, col2Bx + firmaBoxW / 2, currentY + 26.5, { align: 'center' });
    }
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.8);
    doc.text(descuento.responsableNombre, col2Bx + firmaBoxW / 2, currentY + 30, { align: 'center' });
    if (!plantilla?.inhabilitarCargoResponsable) {
      doc.text(descuento.responsableCargo, col2Bx + firmaBoxW / 2, currentY + 32.5, { align: 'center' });
    }

    // Col 3: Administración / Recursos Humanos
    const col3Bx = margin + 2 * (firmaBoxW + 3);
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    doc.text('V°B° ADMINISTRACIÓN / RRHH', col3Bx + firmaBoxW / 2, currentY + 26.5, { align: 'center' });
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.8);
    doc.text('Control de Nóminas y Planillas', col3Bx + firmaBoxW / 2, currentY + 30, { align: 'center' });
    doc.text(`Estado: ${descuento.estado}`, col3Bx + firmaBoxW / 2, currentY + 32.5, { align: 'center' });

    currentY += firmaBoxH + 3;

    // 8. Pie con QR y sello de trazabilidad
    doc.addImage(qrDataUrl, 'PNG', margin + contentWidth - 18, currentY, 18, 18);

    doc.setFontSize(6);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(71, 85, 105);
    let metaY = currentY + 4;
    if (!plantilla?.inhabilitarLemaPiePagina) {
      const lemaPieDescuento = plantilla?.lemaPiePagina || 'SISTEMA DIGITAL DE GESTIÓN SSOMA · SEGURIDAD, SALUD Y MEDIO AMBIENTE';
      doc.text(lemaPieDescuento, margin, currentY + 4);
      metaY = currentY + 8;
    }
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.5);
    doc.setTextColor(textMeta[0], textMeta[1], textMeta[2]);
    doc.text(`Identificador Único: ${descuento.id} · Generado el ${descuento.fechaCreacion || new Date().toLocaleString()}`, margin, metaY);
    doc.text('Documento oficial válido como comprobante de autorización conforme a la normatividad laboral peruana.', margin, metaY + 4);
    if (descuento.idEntregaReposicion) {
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text(`✓ Reposición de EPP asociada e inventariada bajo Entrega N°: ${descuento.idEntregaReposicion}`, margin, metaY + 8);
    }

    const arrayBuffer = doc.output('arraybuffer');
    const pdfBlob = doc.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const fileName = descuento.pdfFileName || `AUT_DESCUENTO_${descuento.numeroRegistro}_${descuento.ruc}_${descuento.dni}_${descuento.fechaSolicitud.replace(/-/g, '')}.pdf`;

    return {
      blob: pdfBlob,
      blobUrl,
      arrayBuffer,
      fileName
    };
  }

export const generarPDFDescuento = generarDocumentoDescuentoPDF;
