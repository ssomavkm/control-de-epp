export * from './utils/pdfStyles';
export * from './utils/pdfHeaders';
export * from './utils/pdfFormatters';

export * from './entregas';
export * from './inspecciones';
export * from './reportes';
export * from './descuentos';
export * from './infracciones';
export * from './liquidaciones';

// Compatibilidad clase PDFGeneratorService
import { generarFormatoEntregaPDF } from './entregas';
import { generarActaInspeccionPDF } from './inspecciones';
import { generarPadronTrabajadoresPDF } from './reportes';
import { generarDocumentoDescuentoPDF } from './descuentos';
import { generarReporteInfraccionPDF } from './infracciones';
import { generarDocumentoLiquidacionPDF } from './liquidaciones';
import { getThemeColors, getLogoEmpresa, PDFResult } from './utils/pdfStyles';
import { IsoHeaderConfig, dibujarLogoEnCabecera, dibujarEncabezadoISO } from './utils/pdfHeaders';

export class PDFGeneratorService {
  public static getThemeColors = getThemeColors;
  public static getLogoEmpresa = getLogoEmpresa;
  public static dibujarLogoEnCabecera = dibujarLogoEnCabecera;
  public static dibujarEncabezadoISO = dibujarEncabezadoISO;

  public static generarFormatoEntregaPDF = generarFormatoEntregaPDF;
  public static generarActaInspeccionPDF = generarActaInspeccionPDF;
  public static generarPadronTrabajadoresPDF = generarPadronTrabajadoresPDF;
  public static generarDocumentoDescuentoPDF = generarDocumentoDescuentoPDF;
  public static generarReporteInfraccionPDF = generarReporteInfraccionPDF;
  public static generarDocumentoLiquidacionPDF = generarDocumentoLiquidacionPDF;
}

export type { PDFResult, IsoHeaderConfig };
