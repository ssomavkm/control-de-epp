import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';
import { InfraccionEPP, PlantillaFormato } from '../../types';
import { storageService } from '../storageService';
import { PDFResult, getThemeColors, blindarDocPDF } from './utils/pdfStyles';
import { dibujarLogoEnCabecera } from './utils/pdfHeaders';

export async function generarReporteInfraccionPDF(infraccion: InfraccionEPP, plantilla?: PlantillaFormato): Promise<PDFResult> {
    if (!plantilla) {
      plantilla = storageService.getPlantillaPorCodigo(infraccion.codigoPlantilla || 'FO-SST-INF-001')
               || storageService.getPlantillas().find(p => p.tipoDocumento === 'Disciplina');
    }

    const doc = blindarDocPDF(new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    }));

    const { isPerpol, primaryColor, secondaryColor, accentBorder, darkSlate, slateLabel, grayBorder, textMuted, textMeta, fontFamilia } = getThemeColors(infraccion.empresaId, plantilla);

    const codigoPlantillaOficial = String(plantilla?.codigo || infraccion.codigoPlantilla || 'FO-SST-INF-001');
    const versionPlantillaOficial = String(plantilla?.version || infraccion.versionPlantilla || '01');
    const fechaAprobacionOficial = String(plantilla?.fechaAprobacion || (infraccion.fechaHora || '').slice(0, 10) || '02/01/2026');

    const tituloSistema = (plantilla?.tituloSistemaGestion || '').trim();
    const tituloPrincipal = plantilla?.nombre || 'REPORTE DE INFRACCIÓN Y SANCIÓN DISCIPLINARIA POR NO USO DE EPP';
    const normaReferencia = (plantilla?.referenciaNormativa || '').trim();

    // QR Data
    const qrData = `SSOMA-INF|${codigoPlantillaOficial}|${infraccion.numeroReporte}|${infraccion.ruc}|${infraccion.dni}|${infraccion.gravedad}|${infraccion.fechaHora}`;
    const qrDataUrl = await QRCode.toDataURL(qrData, { width: 120, margin: 1 });

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 12;
    const contentWidth = pageWidth - margin * 2;

    // 1. Encabezado Oficial Homologado ISO Tripartito
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.4);
    doc.rect(margin, margin, contentWidth, 24);

    // Columna 1: Logo
    doc.line(margin + 48, margin, margin + 48, margin + 24);
    dibujarLogoEnCabecera(doc, infraccion.empresaId, margin, margin, 48, 24, plantilla);

    // Columna 2: Título Oficial Homologado
    const col2Start = margin + 48;
    const col2Width = contentWidth - 48 - 42;
    doc.line(col2Start + col2Width, margin, col2Start + col2Width, margin + 24);

    const mostrarTituloSistema = !plantilla?.inhabilitarTituloSistemaGestion && Boolean((plantilla?.tituloSistemaGestion || '').trim() !== '') && !plantilla?.nombre?.toUpperCase().includes('INFRACCIÓN');
    const mostrarNormativa = !plantilla?.inhabilitarReferenciaNormativa && Boolean((plantilla?.referenciaNormativa || '').trim() !== '') && !plantilla?.nombre?.toUpperCase().includes('INFRACCIÓN');

    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    if (mostrarTituloSistema) {
      doc.setFontSize(8);
      doc.text(tituloSistema, col2Start + col2Width / 2, margin + 6.5, { align: 'center' });
    }
    doc.setFontSize(9.5);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    const lineasTituloInf = doc.splitTextToSize(tituloPrincipal.toUpperCase(), col2Width - 6);
    let yBaseInf = margin + 12.5;
    if (lineasTituloInf.length === 1) {
      yBaseInf = !mostrarTituloSistema && !mostrarNormativa ? margin + 13.5 : (!mostrarTituloSistema ? margin + 11.5 : (mostrarNormativa ? margin + 13 : margin + 14));
      doc.text(lineasTituloInf[0], col2Start + col2Width / 2, yBaseInf, { align: 'center' });
    } else {
      yBaseInf = !mostrarTituloSistema && !mostrarNormativa ? margin + 10.5 : (!mostrarTituloSistema ? margin + 9 : (mostrarNormativa ? margin + 12 : margin + 13));
      doc.text(lineasTituloInf[0], col2Start + col2Width / 2, yBaseInf, { align: 'center' });
      doc.text(lineasTituloInf[1], col2Start + col2Width / 2, yBaseInf + 4.8, { align: 'center' });
    }
    if (mostrarNormativa) {
      doc.setFont(fontFamilia, 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
      doc.text(normaReferencia, col2Start + col2Width / 2, margin + 21.5, { align: 'center' });
    }

    // Columna 3: Control Documentario
    const col3Start = col2Start + col2Width;
    for (let i = 1; i < 4; i++) {
      doc.line(col3Start, margin + i * 6, margin + contentWidth, margin + i * 6);
    }
    doc.setFontSize(7);
    doc.setTextColor(71, 85, 105);
    doc.setFont(fontFamilia, 'bold');
    doc.text('CÓDIGO:', col3Start + 2, margin + 4.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text(codigoPlantillaOficial, col3Start + 17, margin + 4.2);

    doc.setFont(fontFamilia, 'bold');
    doc.text('VERSIÓN:', col3Start + 2, margin + 10.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text(versionPlantillaOficial, col3Start + 17, margin + 10.2);

    doc.setFont(fontFamilia, 'bold');
    doc.text('F. REPORTE:', col3Start + 2, margin + 16.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text(fechaAprobacionOficial, col3Start + 17, margin + 16.2);

    doc.setFont(fontFamilia, 'bold');
    doc.text('PÁGINA:', col3Start + 2, margin + 22.2);
    doc.setFont(fontFamilia, 'normal');
    doc.text('1 de 1', col3Start + 17, margin + 22.2);

    let currentY = margin + 26;

    // 2. Sección: 1. DATOS DE LA EMPRESA EMPLEADORA (Estandarizado a 5mm y homogéneo)
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('1. DATOS DE LA EMPRESA EMPLEADORA', margin + 3, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.3);
    doc.rect(margin, currentY, contentWidth, 11);
    doc.line(margin, currentY + 5.5, margin + contentWidth, currentY + 5.5);
    doc.line(margin + 125, currentY, margin + 125, currentY + 5.5);

    doc.setFontSize(6.8);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.text('RAZÓN SOCIAL:', margin + 2, currentY + 3.8);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.empresaNombre || (isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.'), margin + 25, currentY + 3.8);

    doc.setFont(fontFamilia, 'bold');
    doc.text('RUC:', margin + 127, currentY + 3.8);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.ruc || (isPerpol ? '20392729977' : '20550842891'), margin + 137, currentY + 3.8);

    doc.setFont(fontFamilia, 'bold');
    doc.text('DOMICILIO / PLANTA:', margin + 2, currentY + 9.3);
    doc.setFont(fontFamilia, 'normal');
    const dirPlantaInf = isPerpol 
      ? 'CAL. LOS BRILLANTES NRO. 096 FND. LA CAPITANA - SANTA MARIA DE HUACHIPA, LIMA'
      : 'LOS BRILLANTES MZA. B1 LOTE. 11B FND. LA CAPITANA - SANTA MARIA DE HUACHIPA, LIMA';
    doc.text(dirPlantaInf, margin + 34, currentY + 9.3);

    currentY += 14;

    // 3. Sección: 2. DATOS DEL TRABAJADOR Y CONTROL DE LA INFRACCIÓN (Combinado y Homogéneo)
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('2. DATOS DEL TRABAJADOR Y CONTROL DE LA INFRACCIÓN', margin + 3, currentY + 3.6);
    doc.text(`N° REPORTE: ${infraccion.numeroReporte}`, margin + contentWidth - 48, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setLineWidth(0.3);
    doc.rect(margin, currentY, contentWidth, 16);
    doc.line(margin, currentY + 5.3, margin + contentWidth, currentY + 5.3);
    doc.line(margin, currentY + 10.6, margin + contentWidth, currentY + 10.6);
    // Divisor vertical en Fila 2 (entre Área y Cargo)
    doc.line(margin + 70, currentY + 5.3, margin + 70, currentY + 10.6);
    // Divisor vertical que separa Nombres de DNI en Fila 1 y Cargo de Fecha en Fila 2
    doc.line(margin + 125, currentY, margin + 125, currentY + 10.6);

    // Fila 1: Apellidos y Nombres (combinado 125mm) y DNI (reemplaza Código Trab. de 125mm a contentWidth)
    doc.setFontSize(6.8);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.text('APELLIDOS Y NOMBRES:', margin + 2, currentY + 3.7);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.trabajadorNombre, margin + 35, currentY + 3.7);

    doc.setFont(fontFamilia, 'bold');
    doc.text('DNI:', margin + 127, currentY + 3.7);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.dni, margin + 136, currentY + 3.7);

    // Fila 2: Área, Cargo, Fecha/Hora
    doc.setFont(fontFamilia, 'bold');
    doc.text('ÁREA / SECCIÓN:', margin + 2, currentY + 9);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.area, margin + 25, currentY + 9);

    doc.setFont(fontFamilia, 'bold');
    doc.text('CARGO / PUESTO:', margin + 72, currentY + 9);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.cargo, margin + 96, currentY + 9);

    doc.setFont(fontFamilia, 'bold');
    doc.text('FECHA Y HORA:', margin + 127, currentY + 9);
    doc.setFont(fontFamilia, 'normal');
    doc.text(infraccion.fechaHora.replace('T', ' '), margin + 148, currentY + 9);

    // Fila 3: Ubicación exacta en planta
    doc.setFont(fontFamilia, 'bold');
    doc.text('UBICACIÓN EN PLANTA / ZONA EXACTA:', margin + 2, currentY + 14.3);
    doc.setFont(fontFamilia, 'normal');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(infraccion.lugarZona, margin + 54, currentY + 14.3);

    currentY += 19;

    // 4. Sección: 3. CLASIFICACIÓN DE LA INFRACCIÓN Y SANCIÓN APLICADA
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('3. TIPIFICACIÓN DE LA FALTA Y MEDIDA DISCIPLINARIA', margin + 3, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.rect(margin, currentY, contentWidth, 12);
    doc.line(margin + 60, currentY, margin + 60, currentY + 12);
    doc.line(margin + 125, currentY, margin + 125, currentY + 12);

    // Col 1: Gravedad
    doc.setFontSize(6.5);
    doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.text('NIVEL DE GRAVEDAD:', margin + 3, currentY + 4);
    doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.roundedRect(margin + 3, currentY + 5.5, 42, 5, 1, 1, 'FD');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7);
    doc.text(infraccion.gravedad.toUpperCase(), margin + 24, currentY + 9, { align: 'center' });

    // Col 2: Tipo de Sanción
    doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    doc.text('MEDIDA DISCIPLINARIA / SANCIÓN:', margin + 63, currentY + 4);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setFontSize(7.5);
    doc.text(infraccion.tipoSancion, margin + 63, currentY + 9);

    // Col 3: Reincidencia
    doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    doc.text('CONDICIÓN DE REINCIDENCIA:', margin + 128, currentY + 4);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.setFontSize(7);
    doc.text(infraccion.reincidencia, margin + 128, currentY + 9);

    currentY += 15;

    // 5. Sección: 4. EQUIPOS DE PROTECCIÓN PERSONAL OMITIDOS / NO PORTADOS (Formateado en autoTable oficial)
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('4. EQUIPOS DE PROTECCIÓN PERSONAL (EPP) OBLIGATORIOS NO PORTADOS', margin + 3, currentY + 3.6);

    currentY += 5;

    const eppsOmitidosLista: string[] = Array.isArray(infraccion.eppsOmitidos)
      ? (infraccion.eppsOmitidos.length > 0 ? infraccion.eppsOmitidos : ['EPP reglamentario no especificado en el registro'])
      : (typeof infraccion.eppsOmitidos === 'string' && (infraccion.eppsOmitidos as string).trim())
        ? (infraccion.eppsOmitidos as string).split(',').map(s => s.trim()).filter(Boolean)
        : ['EPP reglamentario no especificado en el registro'];

    const tablaEppsBody = eppsOmitidosLista.map((epp, idx) => [
      String(idx + 1),
      epp,
      'NO PORTADO / OMISIÓN DIRECTA',
      'Art. 79 Ley N° 29783 / RISST',
      'INFRACCIÓN'
    ]);

    autoTable(doc, {
      startY: currentY,
      margin: { left: margin, right: margin },
      head: [['ÍTEM', 'EQUIPO DE PROTECCIÓN (EPP) OBLIGATORIO', 'CONDICIÓN EN INSPECCIÓN', 'EXIGENCIA LEGAL', 'CALIFICACIÓN']],
      body: tablaEppsBody,
      theme: 'grid',
      styles: {
        font: fontFamilia,
        fontSize: 6.8,
        cellPadding: 1.8,
        lineColor: grayBorder,
        lineWidth: 0.25,
        textColor: darkSlate,
        valign: 'middle'
      },
      headStyles: {
        fillColor: primaryColor as [number, number, number],
        textColor: [255, 255, 255],
        font: fontFamilia,
        fontStyle: 'bold',
        halign: 'center',
        fontSize: 7
      },
      columnStyles: {
        0: { halign: 'center', cellWidth: 10 },
        1: { halign: 'left', cellWidth: 'auto', fontStyle: 'bold' },
        2: { halign: 'center', cellWidth: 46, textColor: [185, 28, 28], fontStyle: 'bold' },
        3: { halign: 'center', cellWidth: 38 },
        4: { halign: 'center', cellWidth: 26, textColor: [185, 28, 28], fontStyle: 'bold' }
      }
    });

    currentY = (doc as any).lastAutoTable.finalY + 4;

    // 6. Sección: 5. DESCRIPCIÓN DE LOS HECHOS Y HALLAZGO
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('5. DESCRIPCIÓN CIRCUNSTANCIADA DE LOS HECHOS Y HALLAZGO SST', margin + 3, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.setFillColor(255, 255, 255);
    doc.rect(margin, currentY, contentWidth, 15, 'FD');
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'normal');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    const hechosLines = doc.splitTextToSize(infraccion.descripcionHechos || 'Sin detalle registrado.', contentWidth - 6);
    doc.text(hechosLines, margin + 3, currentY + 4.5);

    currentY += 18;

    // 7. Sección: 6. DESCARGO DEL TRABAJADOR Y MEDIDA CORRECTIVA
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, currentY, contentWidth, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(7.5);
    doc.text('6. MANIFESTACIÓN / DESCARGO DEL TRABAJADOR Y MEDIDA CORRECTIVA INMEDIATA', margin + 3, currentY + 3.6);

    currentY += 5;
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.rect(margin, currentY, contentWidth, 18);
    doc.line(margin, currentY + 9, margin + contentWidth, currentY + 9);

    // Descargo
    doc.setFontSize(6.2);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
    doc.text('DESCARGO DEL TRABAJADOR:', margin + 3, currentY + 3.5);
    doc.setFont(fontFamilia, 'normal');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    const descargoLines = doc.splitTextToSize(infraccion.justificacionTrabajador || 'El trabajador no presentó descargo inmediato.', contentWidth - 6);
    doc.text(descargoLines, margin + 3, currentY + 6.8);

    // Medida Correctiva
    doc.setFontSize(6.2);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('MEDIDA CORRECTIVA INMEDIATA APLICADA:', margin + 3, currentY + 12.5);
    doc.setFont(fontFamilia, 'normal');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    const medidaLines = doc.splitTextToSize(infraccion.medidaCorrectivaInmediata || 'Se ordenó paralización hasta subsanar uso de EPP.', contentWidth - 6);
    doc.text(medidaLines, margin + 3, currentY + 15.8);

    currentY += 21;

    // 8. Base Legal (Opcional según inhabilitar)
    const mostrarDirectiva = !plantilla?.inhabilitarDeclaracionCompromiso && Boolean(plantilla?.declaracionCompromiso && plantilla.declaracionCompromiso.trim().length > 0);
    const mostrarMarcoLegal = !plantilla?.inhabilitarReferenciaNormativa || mostrarDirectiva;

    if (mostrarMarcoLegal) {
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
      const alturaMarcoLegal = mostrarDirectiva ? 14 : 10;
      doc.rect(margin, currentY, contentWidth, alturaMarcoLegal, 'FD');
      doc.setFontSize(5.8);
      doc.setFont(fontFamilia, 'bold');
      doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
      doc.text('MARCO LEGAL Y DISCIPLINARIO APLICABLE:', margin + 3, currentY + 3.5);
      doc.setFont(fontFamilia, 'normal');
      doc.text('• Ley N° 29783 Art. 79 Inciso b): "Obligación de usar adecuadamente los instrumentos y materiales de trabajo, así como los equipos de protección personal y colectiva".', margin + 3, currentY + 6.2);
      doc.text('• Reglamento Interno de SST: Todo incumplimiento genera reporte formal y constancia en legajo laboral para fines disciplinarios pertinentes.', margin + 3, currentY + 8.5);
      if (mostrarDirectiva) {
        const compromisoText = doc.splitTextToSize(`• Directiva interna: ${plantilla!.declaracionCompromiso}`, contentWidth - 6);
        doc.text(compromisoText, margin + 3, currentY + 11.2);
      }

      currentY += alturaMarcoLegal + 3;
    } else {
      currentY += 2;
    }

    // 9. Firmas (Inspector SSOMA, Trabajador Infractor / Constancia de Negativa con Testigo)
    const firmaW = (contentWidth - 4) / 2;
    const firmaH = 26;

    // Recuadro 1: Supervisor SSOMA
    doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
    doc.rect(margin, currentY, firmaW, firmaH);
    doc.line(margin + 6, currentY + 18, margin + firmaW - 6, currentY + 18);

    if (infraccion.firmaSupervisor) {
      try {
        doc.addImage(infraccion.firmaSupervisor, 'PNG', margin + 12, currentY + 2, firmaW - 24, 15);
      } catch (e) {
        console.warn('Firma supervisor error:', e);
      }
    }
    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    if (!plantilla?.inhabilitarCargoResponsable) {
      const cargoInf = plantilla?.cargoResponsablePorDefecto || 'INSPECTOR / SUPERVISOR SSOMA';
      doc.text(cargoInf, margin + firmaW / 2, currentY + 20.5, { align: 'center' });
    }
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.8);
    doc.text(infraccion.supervisorReporta, margin + firmaW / 2, currentY + 23.5, { align: 'center' });
    if (!plantilla?.inhabilitarCargoResponsable) {
      doc.text(infraccion.cargoSupervisor, margin + firmaW / 2, currentY + 25.5, { align: 'center' });
    }

    // Recuadro 2: Trabajador / Constancia
    const r2x = margin + firmaW + 4;
    doc.rect(r2x, currentY, firmaW, firmaH);
    doc.line(r2x + 6, currentY + 18, r2x + firmaW - 6, currentY + 18);

    if (infraccion.seNegoAFirmar) {
      doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.rect(r2x + 1, currentY + 1, firmaW - 2, 16, 'F');
      doc.setFontSize(6.8);
      doc.setFont(fontFamilia, 'bold');
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.text('CONSTANCIA: TRABAJADOR SE NEGÓ A FIRMAR', r2x + firmaW / 2, currentY + 7, { align: 'center' });
      doc.setFontSize(5.8);
      doc.setFont(fontFamilia, 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text(`Testigo presencial: ${infraccion.testigoNombre || 'Víctor Cárdenas'}`, r2x + firmaW / 2, currentY + 11.5, { align: 'center' });
      doc.text(`DNI Testigo: ${infraccion.testigoDni || '43981245'}`, r2x + firmaW / 2, currentY + 14.5, { align: 'center' });
    } else if (infraccion.firmaTrabajador) {
      try {
        doc.addImage(infraccion.firmaTrabajador, 'PNG', r2x + 12, currentY + 2, firmaW - 24, 15);
      } catch (e) {
        console.warn('Firma trabajador infractor error:', e);
      }
    }

    doc.setFontSize(6.5);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.text(infraccion.seNegoAFirmar ? 'FIRMA TESTIGO DE NEGATIVA' : 'FIRMA DEL TRABAJADOR NOTIFICADO', r2x + firmaW / 2, currentY + 20.5, { align: 'center' });
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.8);
    doc.text(infraccion.seNegoAFirmar ? `DNI Testigo: ${infraccion.testigoDni || '43981245'}` : `DNI: ${infraccion.dni} · ${infraccion.trabajadorNombre}`, r2x + firmaW / 2, currentY + 24, { align: 'center' });

    currentY += firmaH + 4;

    // 10. Pie con QR y sellos
    doc.addImage(qrDataUrl, 'PNG', margin + contentWidth - 16, currentY, 16, 16);
    doc.setFontSize(6);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(71, 85, 105);
    let metaY = currentY + 4;
    if (!plantilla?.inhabilitarLemaPiePagina) {
      const lemaPieInf = plantilla?.lemaPiePagina || 'SISTEMA DIGITAL DE GESTIÓN SSOMA · REPORTE FORMAL DE INFRACCIÓN LABORAL';
      doc.text(lemaPieInf, margin, currentY + 4);
      metaY = currentY + 8;
    }
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(5.5);
    doc.setTextColor(textMeta[0], textMeta[1], textMeta[2]);
    doc.text(`Identificador de Acta: ${infraccion.id} · Estado: ${infraccion.estado}`, margin, metaY);
    doc.text('Copia remitida a Jefatura de Recursos Humanos para incorporación en legajo personal.', margin, metaY + 4);

    const arrayBuffer = doc.output('arraybuffer');
    const pdfBlob = doc.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const fileName = infraccion.pdfFileName || `REPORTE_INFRACCION_${infraccion.numeroReporte}_${infraccion.ruc}_${infraccion.dni}_${infraccion.fechaHora.slice(0, 10).replace(/-/g, '')}.pdf`;

    return {
      blob: pdfBlob,
      blobUrl,
      arrayBuffer,
      fileName
    };
  }

export const generarPDFInfraccion = generarReporteInfraccionPDF;
