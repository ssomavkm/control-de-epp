import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';
import { LiquidacionEPP, PlantillaFormato } from '../../types';
import { storageService } from '../storageService';
import { PDFResult, getThemeColors, blindarDocPDF } from './utils/pdfStyles';
import { dibujarLogoEnCabecera } from './utils/pdfHeaders';

export async function generarDocumentoLiquidacionPDF(
  liquidacion: LiquidacionEPP,
  plantilla?: PlantillaFormato
): Promise<PDFResult> {
  if (!plantilla) {
    plantilla =
      storageService.getPlantillaPorCodigo(liquidacion.codigoPlantilla || 'FO-SST-LIQ-001') ||
      storageService.getPlantillas().find((p) => p.codigo === 'FO-SST-LIQ-001');
  }

  const doc = blindarDocPDF(new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  }));

  const {
    isPerpol,
    primaryColor,
    secondaryColor,
    darkSlate,
    slateLabel,
    grayBorder,
    textMuted,
    fontFamilia
  } = getThemeColors(liquidacion.empresaId, plantilla);

  const codigoPlantillaOficial = String(plantilla?.codigo || liquidacion.codigoPlantilla || 'FO-SST-LIQ-001');
  const versionPlantillaOficial = String(plantilla?.version || liquidacion.versionPlantilla || '01');
  const fechaAprobacionOficial = String(plantilla?.fechaAprobacion || liquidacion.fechaLiquidacion || '02/01/2026');
  const tituloPrincipal = String(plantilla?.nombre || 'ACTA DE LIQUIDACIÓN DE EPP POR CESE LABORAL');

  // Código QR de trazabilidad oficial
  const netoMonto = Number(liquidacion.montoNetoALiquidar) || 0;
  const qrData = `SSOMA-LIQ|${codigoPlantillaOficial}|${liquidacion.numeroRegistro}|${liquidacion.ruc}|${liquidacion.dni}|NETO:S/${netoMonto.toFixed(2)}|${liquidacion.fechaLiquidacion}`;
  const qrDataUrl = await QRCode.toDataURL(qrData, { width: 120, margin: 1 });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 12;
  const contentWidth = pageWidth - margin * 2;

  // 1. Encabezado Tripartito Oficial ISO / SST
  doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
  doc.setLineWidth(0.4);
  doc.rect(margin, margin, contentWidth, 24);

  // Columna 1: Logo
  doc.line(margin + 48, margin, margin + 48, margin + 24);
  dibujarLogoEnCabecera(doc, liquidacion.empresaId, margin, margin, 48, 24, plantilla);

  // Columna 2: Título Oficial
  const col2Start = margin + 48;
  const col2Width = contentWidth - 48 - 42;
  doc.line(col2Start + col2Width, margin, col2Start + col2Width, margin + 24);

  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  const lineasTitulo = doc.splitTextToSize(tituloPrincipal.toUpperCase(), col2Width - 6);
  if (lineasTitulo.length === 1) {
    doc.text(lineasTitulo[0], col2Start + col2Width / 2, margin + 14, { align: 'center' });
  } else {
    doc.text(lineasTitulo[0], col2Start + col2Width / 2, margin + 11.5, { align: 'center' });
    doc.text(lineasTitulo[1], col2Start + col2Width / 2, margin + 16.5, { align: 'center' });
  }

  // Columna 3: Control Documentario
  const col3Start = col2Start + col2Width;
  for (let i = 1; i < 4; i++) {
    doc.line(col3Start, margin + i * 6, margin + contentWidth, margin + i * 6);
  }
  doc.setFontSize(7);
  doc.setTextColor(71, 85, 105);
  doc.setFont(fontFamilia, 'bold');
  doc.text('CÓDIGO:', col3Start + 2, margin + 4.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(codigoPlantillaOficial, col3Start + 17, margin + 4.2);

  doc.setFont(fontFamilia, 'bold');
  doc.text('VERSIÓN:', col3Start + 2, margin + 10.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(versionPlantillaOficial, col3Start + 17, margin + 10.2);

  doc.setFont(fontFamilia, 'bold');
  doc.text('F. EMISIÓN:', col3Start + 2, margin + 16.2);
  doc.setFont(fontFamilia, 'normal');
  doc.text(fechaAprobacionOficial, col3Start + 17, margin + 16.2);

  doc.setFont(fontFamilia, 'bold');
  doc.text('N° REG:', col3Start + 2, margin + 22.2);
  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(liquidacion.numeroRegistro, col3Start + 17, margin + 22.2);

  let currentY = margin + 27;

  // 2. Ficha del Trabajador y Datos de Separación Laboral
  doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.rect(margin, currentY, contentWidth, 5.5, 'FD');
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. INFORMACIÓN DEL TRABAJADOR Y MOTIVO DE CESE LABORAL', margin + 3, currentY + 4);

  currentY += 5.5;

  doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
  doc.setFillColor(255, 255, 255);
  doc.rect(margin, currentY, contentWidth, 23, 'FD');

  const halfWidth = contentWidth / 2;

  // Lado Izquierdo
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(7);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Trabajador Cesante:', margin + 3, currentY + 4.5);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(liquidacion.trabajadorNombre, margin + 36, currentY + 4.5);

  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('DNI / C.E.:', margin + 3, currentY + 9);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(liquidacion.dni, margin + 36, currentY + 9);

  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Empresa / Razón Social:', margin + 3, currentY + 13.5);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`${liquidacion.empresaNombre} (RUC ${liquidacion.ruc})`, margin + 36, currentY + 13.5);

  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Área / Puesto:', margin + 3, currentY + 18);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`${liquidacion.area}  /  ${liquidacion.cargo}`, margin + 36, currentY + 18);

  // Lado Derecho
  const rightX = margin + halfWidth + 2;
  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Fecha de Ingreso:', rightX, currentY + 4.5);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(liquidacion.fechaIngreso || 'No registrada', rightX + 32, currentY + 4.5);

  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Fecha Efectiva de Cese:', rightX, currentY + 9);
  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(185, 28, 28); // Rojo oscuro
  doc.text(liquidacion.fechaCese, rightX + 32, currentY + 9);

  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Motivo de Extinción:', rightX, currentY + 13.5);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(liquidacion.motivoCese || 'Término de Contrato', rightX + 32, currentY + 13.5);

  doc.setFont(fontFamilia, 'bold');
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Fecha de Liquidación SST:', rightX, currentY + 18);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(liquidacion.fechaLiquidacion, rightX + 32, currentY + 18);

  currentY += 26;

  // 3. Resumen Cuantitativo y Reglas de Liquidación (Banner Informativo)
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
  doc.roundedRect(margin, currentY, contentWidth, 12, 1.5, 1.5, 'FD');

  const cardW = contentWidth / 4;
  // Card 1: Total Entregados
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('TOTAL EPP ENTREGADOS', margin + cardW * 0.5, currentY + 4.5, { align: 'center' });
  doc.setFontSize(9);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text(`${liquidacion.totalItemsEntregados} uds (S/ ${liquidacion.montoTotalEntregado.toFixed(2)})`, margin + cardW * 0.5, currentY + 9.5, { align: 'center' });

  // Card 2: Vencidos / Amortizados
  doc.setFontSize(6.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('VENCIDOS (AMORTIZADOS)', margin + cardW * 1.5, currentY + 4.5, { align: 'center' });
  doc.setFontSize(9);
  doc.setTextColor(5, 150, 105);
  doc.text(`${liquidacion.totalItemsVencidos} uds (Desc. S/ 0.00)`, margin + cardW * 1.5, currentY + 9.5, { align: 'center' });

  // Card 3: Devueltos Físicamente
  doc.setFontSize(6.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('DEVUELTOS A ALMACÉN', margin + cardW * 2.5, currentY + 4.5, { align: 'center' });
  doc.setFontSize(9);
  doc.setTextColor(37, 99, 235);
  doc.text(`${liquidacion.totalItemsDevueltos} uds (Desc. S/ 0.00)`, margin + cardW * 2.5, currentY + 9.5, { align: 'center' });

  // Card 4: Total a Descontar
  doc.setFontSize(6.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('CARGO A LIQUIDACIÓN', margin + cardW * 3.5, currentY + 4.5, { align: 'center' });
  doc.setFontSize(9.5);
  doc.setTextColor(liquidacion.montoNetoALiquidar > 0 ? 225 : 5, liquidacion.montoNetoALiquidar > 0 ? 29 : 150, liquidacion.montoNetoALiquidar > 0 ? 72 : 105);
  doc.text(`S/ ${liquidacion.montoNetoALiquidar.toFixed(2)}`, margin + cardW * 3.5, currentY + 9.5, { align: 'center' });

  currentY += 15;

  // 4. Tabla de Auditoría Detallada de Equipos Entregados
  doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.rect(margin, currentY, contentWidth, 5.5, 'FD');
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('2. AUDITORÍA DETALLADA DE EQUIPOS ENTREGADOS Y CONDICIÓN EN CESE', margin + 3, currentY + 4);

  currentY += 5.5;

  const tableBody = (liquidacion.items || []).map((it, idx) => {
    let estadoLabel: string = String(it.estadoItem || '');
    if (it.estadoItem === 'Vencido') estadoLabel = 'Vencido (Amortizado)';
    if (it.estadoItem === 'Devuelto') estadoLabel = 'Devuelto a Almacén';
    if (it.estadoItem === 'Pendiente') estadoLabel = 'No Devuelto (A cobrar)';
    if (it.estadoItem === 'Exonerado') estadoLabel = 'Exonerado SSOMA';

    const costoU = Number(it.costoUnitario) || 0;
    const montoLiq = Number(it.montoALiquidar) || 0;

    return [
      String(idx + 1),
      String(it.fechaEntrega || '-'),
      String(it.articulo || '-'),
      String(it.talla || 'Estándar'),
      `${it.cantidadEntregada ?? 1} ${it.unidad || 'und'}`,
      String(it.fechaVencimiento || '-'),
      String(estadoLabel || '-'),
      `S/ ${costoU.toFixed(2)}`,
      montoLiq > 0 ? `S/ ${montoLiq.toFixed(2)}` : 'S/ 0.00'
    ];
  });

  autoTable(doc, {
    startY: currentY,
    margin: { left: margin, right: margin },
    head: [[
      'N°',
      'F. Entrega',
      'Artículo / EPP / Ropa',
      'Talla',
      'Cant.',
      'F. Vencim.',
      'Condición en Cese',
      'P. Unit.',
      'A Deducir'
    ]],
    body: tableBody,
    theme: 'grid',
    headStyles: {
      fillColor: [primaryColor[0], primaryColor[1], primaryColor[2]],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 6.5,
      halign: 'center',
      valign: 'middle',
      cellPadding: 1.5
    },
    bodyStyles: {
      fontSize: 6.5,
      textColor: [darkSlate[0], darkSlate[1], darkSlate[2]],
      cellPadding: 1.5,
      valign: 'middle'
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 7 },
      1: { halign: 'center', cellWidth: 16 },
      2: { cellWidth: 52 },
      3: { halign: 'center', cellWidth: 12 },
      4: { halign: 'center', cellWidth: 14 },
      5: { halign: 'center', cellWidth: 16 },
      6: { halign: 'center', cellWidth: 33 },
      7: { halign: 'right', cellWidth: 16 },
      8: { halign: 'right', cellWidth: 20, fontStyle: 'bold' }
    },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 6) {
        const text = String(data.cell.raw);
        if (text.includes('No Devuelto')) {
          data.cell.styles.textColor = [185, 28, 28]; // Rojo
          data.cell.styles.fontStyle = 'bold';
        } else if (text.includes('Devuelto')) {
          data.cell.styles.textColor = [37, 99, 235]; // Azul
        } else if (text.includes('Vencido')) {
          data.cell.styles.textColor = [5, 150, 105]; // Verde
        }
      }
      if (data.section === 'body' && data.column.index === 8) {
        const text = String(data.cell.raw);
        if (text !== 'S/ 0.00') {
          data.cell.styles.textColor = [185, 28, 28];
        } else {
          data.cell.styles.textColor = [100, 116, 139];
        }
      }
    }
  });

  const finalY = (doc as any).lastAutoTable.finalY || currentY + 30;
  let nextY = finalY + 4;

  // 5. Liquidación Financiera Consolidada
  const boxHeight = 16;
  doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(margin, nextY, contentWidth, boxHeight, 1.5, 1.5, 'FD');

  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(7);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('Total Entregado:', margin + 4, nextY + 5.5);
  doc.setFont(fontFamilia, 'normal');
  doc.text(`S/ ${liquidacion.montoTotalEntregado.toFixed(2)}`, margin + 30, nextY + 5.5);

  doc.setFont(fontFamilia, 'bold');
  doc.text('Descargo por Vencimiento / Devolución:', margin + 4, nextY + 11.5);
  doc.setFont(fontFamilia, 'normal');
  doc.setTextColor(5, 150, 105);
  doc.text(`- S/ ${liquidacion.montoDescontadoVencidosYDevueltos.toFixed(2)}`, margin + 62, nextY + 11.5);

  // Recuadro Destacado de Saldo Neto a Descontar
  const netoBoxW = 75;
  const netoBoxX = margin + contentWidth - netoBoxW - 2;
  doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.roundedRect(netoBoxX, nextY + 2, netoBoxW, boxHeight - 4, 1, 1, 'FD');

  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('MONTO NETO A DESCONTAR:', netoBoxX + 3, nextY + 7.5);

  doc.setFontSize(11);
  doc.setTextColor(liquidacion.montoNetoALiquidar > 0 ? 185 : 5, liquidacion.montoNetoALiquidar > 0 ? 28 : 150, liquidacion.montoNetoALiquidar > 0 ? 28 : 105);
  doc.text(`S/ ${liquidacion.montoNetoALiquidar.toFixed(2)}`, netoBoxX + netoBoxW - 4, nextY + 11.5, { align: 'right' });

  nextY += boxHeight + 4;

  // 6. Cláusula Legal de Conformidad y Descargo
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text('CLÁUSULA DE CONFORMIDAD Y LIQUIDACIÓN DEFINITIVA:', margin, nextY);
  nextY += 3.2;

  const textoClausula = plantilla?.declaracionCompromiso ||
    'De conformidad con la Ley N° 29783, su Reglamento D.S. N° 005-2012-TR y el Reglamento Interno de SST, se efectúa la liquidación de los equipos entregados para el desempeño de funciones. Los EPP devueltos y amortizados por tiempo reglamentario quedan debidamente descargados. El trabajador presta su plena conformidad al presente balance y autoriza a la empresa a deducir el importe neto valorizado de la Liquidación Final de Beneficios Sociales.';

  doc.setFont(fontFamilia, 'normal');
  doc.setFontSize(5.8);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  const lineasClausula = doc.splitTextToSize(textoClausula, contentWidth);
  doc.text(lineasClausula, margin, nextY);

  nextY += lineasClausula.length * 2.8 + 4;

  // 7. Firmas Tripartitas (Trabajador Cesante, Supervisor SSOMA/Almacén, Recursos Humanos)
  const firmaBoxW = (contentWidth - 8) / 3;
  const firmaBoxH = 24;

  // Firma 1: Trabajador Cesante
  const f1X = margin;
  doc.setDrawColor(grayBorder[0], grayBorder[1], grayBorder[2]);
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(f1X, nextY, firmaBoxW, firmaBoxH, 1, 1, 'FD');
  doc.line(f1X + 4, nextY + firmaBoxH - 8, f1X + firmaBoxW - 4, nextY + firmaBoxH - 8);
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(6);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('FIRMA DEL TRABAJADOR CESANTE', f1X + firmaBoxW / 2, nextY + firmaBoxH - 5, { align: 'center' });
  doc.setFont(fontFamilia, 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text(`DNI / C.E.: ${liquidacion.dni}`, f1X + firmaBoxW / 2, nextY + firmaBoxH - 2, { align: 'center' });

  // Firma 2: Supervisor SSOMA / Almacén
  const f2X = margin + firmaBoxW + 4;
  doc.roundedRect(f2X, nextY, firmaBoxW, firmaBoxH, 1, 1, 'FD');
  doc.line(f2X + 4, nextY + firmaBoxH - 8, f2X + firmaBoxW - 4, nextY + firmaBoxH - 8);
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(6);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('SUPERVISOR SSOMA / ALMACÉN', f2X + firmaBoxW / 2, nextY + firmaBoxH - 5, { align: 'center' });
  doc.setFont(fontFamilia, 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  doc.text(liquidacion.supervisorResponsable || 'Responsable SST', f2X + firmaBoxW / 2, nextY + firmaBoxH - 2, { align: 'center' });

  // Firma 3: Recursos Humanos / Administración
  const f3X = f2X + firmaBoxW + 4;
  doc.roundedRect(f3X, nextY, firmaBoxW, firmaBoxH, 1, 1, 'FD');
  doc.line(f3X + 4, nextY + firmaBoxH - 8, f3X + firmaBoxW - 4, nextY + firmaBoxH - 8);
  doc.setFont(fontFamilia, 'bold');
  doc.setFontSize(6);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  doc.text('V°B° RECURSOS HUMANOS / ADMINISTRACIÓN', f3X + firmaBoxW / 2, nextY + firmaBoxH - 5, { align: 'center' });
  doc.setFont(fontFamilia, 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(slateLabel[0], slateLabel[1], slateLabel[2]);
  const textoRRHH = [liquidacion.responsableRRHH, liquidacion.areaRRHH].filter(Boolean).join(' - ');
  doc.text(textoRRHH || liquidacion.responsableRRHH || 'Para Aplicación en Planilla', f3X + firmaBoxW / 2, nextY + firmaBoxH - 2, { align: 'center' });

  // QR Code en esquina inferior derecha si queda espacio
  try {
    doc.addImage(qrDataUrl, 'PNG', pageWidth - margin - 15, pageHeight - 17, 13, 13);
  } catch {}

  // Pie de Página Institucional
  doc.setFont(fontFamilia, 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  doc.text(
    `Documento Oficial SST | FO-SST-LIQ-001 | Sistema SSOMA ${liquidacion.empresaNombre} | Emitido: ${liquidacion.fechaLiquidacion}`,
    margin,
    pageHeight - 6
  );

  const arrayBuffer = doc.output('arraybuffer');
  const pdfBlob = doc.output('blob');
  const blobUrl = URL.createObjectURL(pdfBlob);
  const fileName = `LIQUIDACION_EPP_${liquidacion.numeroRegistro}_${liquidacion.dni}.pdf`;

  return {
    blob: pdfBlob,
    blobUrl,
    arrayBuffer,
    fileName
  };
}
