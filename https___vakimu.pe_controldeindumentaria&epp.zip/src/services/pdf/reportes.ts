import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Trabajador } from '../../types';
import { PDFResult, blindarDocPDF } from './utils/pdfStyles';

export async function generarPadronTrabajadoresPDF(trabajadores: Trabajador[], empresaFiltro: string): Promise<PDFResult> {
    const doc = blindarDocPDF(new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    }));

    const isPerpol = empresaFiltro === 'EMP-PERPOL';
    const isTr3 = empresaFiltro === 'EMP-TR3';
    const primaryColor = isPerpol ? [22, 101, 52] : isTr3 ? [30, 64, 175] : [15, 23, 42];

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 10;
    const contentWidth = pageWidth - margin * 2;

    const fontFamilia = 'helvetica';
    // Encabezado
    doc.setDrawColor(203, 213, 225);
    doc.rect(margin, margin, contentWidth, 18);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(12);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('PADRÓN GENERAL DE TRABAJADORES', margin + contentWidth / 2, margin + 7, { align: 'center' });
    
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    const nombreEmpresa = isPerpol ? 'PERPOL IDEAS S.A.C.' : isTr3 ? 'TR3 ALIMENTOS S.A.C.' : 'CONSOLIDADO GENERAL';
    doc.text(`Empresa: ${nombreEmpresa} | Total Registros: ${trabajadores.length} | Fecha de Emisión: ${new Date().toLocaleDateString('es-PE')}`, margin + contentWidth / 2, margin + 13, { align: 'center' });

    const bodyRows = trabajadores.map((t) => {
      const docClean = String(t.dni || '').trim();
      const tipo = docClean.length > 8 ? 'C.E.' : 'DNI';
      let edadStr = '-';
      if (t.edad !== undefined && t.edad !== null && t.edad !== '') {
        edadStr = `${t.edad} a.`;
      } else if (t.fechaNacimiento) {
        const b = new Date(t.fechaNacimiento);
        if (!isNaN(b.getTime())) {
          const now = new Date();
          let age = now.getFullYear() - b.getFullYear();
          const m = now.getMonth() - b.getMonth();
          if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age--;
          if (age >= 0 && age < 120) edadStr = `${age} a.`;
        }
      }

      return [
        `${t.dni} (${tipo})`,
        t.nombreCompleto || (t as any).apellidosNombres || '-',
        t.empresaId === 'EMP-PERPOL' ? 'PERPOL IDEAS' : 'TR3 ALIMENTOS',
        t.cargo || (t as any).puesto || '-',
        t.area || '-',
        t.estado || (t as any).condicion || 'Activo',
        t.sexo || 'M',
        t.fechaNacimiento ? t.fechaNacimiento.slice(0, 10) : '-',
        edadStr,
        t.fechaIngreso ? t.fechaIngreso.slice(0, 10) : '-',
        t.telefono || '-',
        t.email || (t as any).correo || '-'
      ];
    });

    autoTable(doc, {
      startY: margin + 22,
      margin: { left: margin, right: margin },
      head: [['DNI / C.E.', 'APELLIDOS Y NOMBRES', 'EMPRESA', 'PUESTO / CARGO', 'ÁREA', 'CONDICIÓN', 'SEXO', 'F. NACIMIENTO', 'EDAD', 'F. INGRESO', 'TELÉFONO', 'CORREO']],
      body: bodyRows,
      theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2, lineColor: [226, 232, 240] },
      headStyles: { fillColor: primaryColor as [number, number, number], textColor: [255, 255, 255] }
    });

    const arrayBuffer = doc.output('arraybuffer');
    const pdfBlob = doc.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const fileName = `PADRON_TRABAJADORES_${empresaFiltro}_${new Date().toISOString().slice(0, 10)}.pdf`;

    return {
      blob: pdfBlob,
      blobUrl,
      arrayBuffer,
      fileName
    };
  }

export const generarPDFReportes = generarPadronTrabajadoresPDF;
