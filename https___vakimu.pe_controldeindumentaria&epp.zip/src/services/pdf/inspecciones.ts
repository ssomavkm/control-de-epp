import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { InspeccionEPP } from '../../types';
import { PDFResult, blindarDocPDF } from './utils/pdfStyles';

export async function generarActaInspeccionPDF(inspeccion: InspeccionEPP): Promise<PDFResult> {
    const doc = blindarDocPDF(new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    }));

    const isPerpol = inspeccion.empresaId === 'EMP-PERPOL';
    const primaryColor = isPerpol ? [22, 101, 52] : [30, 64, 175];
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 12;
    const contentWidth = pageWidth - margin * 2;

    const fontFamilia = 'helvetica';
    // Encabezado
    doc.setDrawColor(203, 213, 225);
    doc.rect(margin, margin, contentWidth, 20);
    doc.setFont(fontFamilia, 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('INFORME DE INSPECCIÓN PERIÓDICA DE EPP POR PUESTO DE TRABAJO', margin + contentWidth / 2, margin + 8, { align: 'center' });
    
    doc.setFont(fontFamilia, 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(`${inspeccion.empresaNombre} - CÓDIGO INSP: ${inspeccion.numeroInspeccion} | Fecha: ${inspeccion.fechaHora}`, margin + contentWidth / 2, margin + 14, { align: 'center' });

    let currentY = margin + 24;

    // Datos del trabajador evaluado
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, currentY, contentWidth, 14, 'F');
    doc.setFontSize(7.5);
    doc.setFont(fontFamilia, 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(`TRABAJADOR: ${inspeccion.trabajadorNombre} (DNI: ${inspeccion.dni})`, margin + 3, currentY + 4.5);
    doc.text(`ÁREA: ${inspeccion.area} | CARGO: ${inspeccion.cargo}`, margin + 3, currentY + 8.5);
    doc.text(`INSPECTOR: ${inspeccion.inspectorResponsable} | LUGAR: ${inspeccion.lugarInspeccion}`, margin + 3, currentY + 12.5);

    currentY += 18;

    // Tabla de EPP evaluados
    const bodyRows = (inspeccion.detalles || []).map((det, i) => [
      String(i + 1),
      det.codigoEPP,
      det.articulo,
      det.resultado,
      det.hallazgo,
      det.accion,
      det.estadoAccion
    ]);

    autoTable(doc, {
      startY: currentY,
      margin: { left: margin, right: margin },
      head: [['#', 'CÓDIGO', 'ARTÍCULO EPP', 'ESTADO FÍSICO', 'HALLAZGO OBSERVADO', 'ACCIÓN REQUERIDA', 'ESTADO']],
      body: bodyRows,
      theme: 'grid',
      styles: { fontSize: 7, cellPadding: 2, lineColor: [203, 213, 225] },
      headStyles: { fillColor: primaryColor as [number, number, number], textColor: [255, 255, 255] }
    });

    const arrayBuffer = doc.output('arraybuffer');
    const pdfBlob = doc.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const fileName = `INSPECCION_EPP_${inspeccion.numeroInspeccion}_${inspeccion.dni}.pdf`;

    return {
      blob: pdfBlob,
      blobUrl,
      arrayBuffer,
      fileName
    };
  }

export const generarPDFInspeccion = generarActaInspeccionPDF;
