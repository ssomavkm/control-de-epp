import { EstadoConexion } from '../types';
import { OFICIAL_SPREADSHEET_ID } from '../data/seeds/config';

export interface PingResult {
  estado: 'ok' | 'error';
  latenciaMs: number;
  mensaje: string;
  estadoConexion: EstadoConexion;
}

export interface RetryConfig {
  maxRetries?: number;
  initialDelayMs?: number;
  maxDelayMs?: number;
  jitter?: boolean;
  timeoutMs?: number;
}

export interface MutationMeta {
  tipo?: 'entrega' | 'inspeccion' | 'descuento' | 'infraccion' | 'trabajador' | 'epp' | 'plantilla' | 'generico';
  descripcion?: string;
}

type EnqueueFallbackHandler = (payload: any, meta?: MutationMeta) => void;

/**
 * Extrae el ID de una hoja de cálculo de Google Sheets si el usuario ingresa una URL completa o el ID directo.
 */
export function extraerSpreadsheetId(valor?: string): string {
  if (!valor) return '';
  const val = valor.trim();
  const matchSheet = val.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
  if (matchSheet && matchSheet[1]) return matchSheet[1];
  const matchId = val.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (matchId && matchId[1]) return matchId[1];
  return val.split('?')[0].split('#')[0].replace(/\/+$/, '');
}

export class GasService {
  private static enqueueFallback: EnqueueFallbackHandler | null = null;

  /**
   * Registra el manejador de cola offline desacoplado para evitar dependencias circulares
   */
  public static registerQueueFallback(handler: EnqueueFallbackHandler): void {
    this.enqueueFallback = handler;
  }

  /**
   * Ejecuta fetch con reintentos automáticos, backoff exponencial, jitter aleatorio
   * y gestión de timeout independiente por intento (evita reusar señales abortadas).
   */
  public static async fetchConReintentos(
    url: string,
    options: RequestInit,
    retryConfig: RetryConfig = {}
  ): Promise<Response> {
    const maxRetries = retryConfig.maxRetries ?? 2; // Hasta 3 intentos en total
    const initialDelayMs = retryConfig.initialDelayMs ?? 1000;
    const maxDelayMs = retryConfig.maxDelayMs ?? 5000;
    const useJitter = retryConfig.jitter ?? true;
    const timeoutMs = retryConfig.timeoutMs ?? 35000;

    let attempt = 0;

    while (true) {
      // Detección reactiva previa: si el navegador reporta estar offline, abortar de inmediato sin demoras
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        throw new Error('Sin conexión a internet (modo local offline activado)');
      }

      // Si el llamador proporcionó un signal y ya fue abortado voluntariamente
      if (options.signal && options.signal.aborted) {
        throw (options.signal as any).reason || new DOMException('Solicitud cancelada por el usuario', 'AbortError');
      }

      // Controlador y timer independientes para este intento particular
      const attemptController = new AbortController();
      let attemptTimedOut = false;
      const attemptTimer = setTimeout(() => {
        attemptTimedOut = true;
        try {
          attemptController.abort(new Error(`Tiempo de espera agotado (${timeoutMs} ms)`));
        } catch {
          attemptController.abort();
        }
      }, timeoutMs);

      const callerSignal = options.signal;
      const onCallerAbort = () => {
        try {
          attemptController.abort((callerSignal as any)?.reason);
        } catch {
          attemptController.abort();
        }
      };
      if (callerSignal) {
        callerSignal.addEventListener('abort', onCallerAbort, { once: true });
      }

      const mergedOptions: RequestInit = {
        ...options,
        signal: attemptController.signal
      };

      try {
        const response = await fetch(url, mergedOptions);
        clearTimeout(attemptTimer);
        if (callerSignal) callerSignal.removeEventListener('abort', onCallerAbort);

        // Errores HTTP transitorios (429: Too Many Requests / Cuotas GAS, 500/502/503/504: Sobrecarga temporal)
        const isTransientHttp = [429, 500, 502, 503, 504].includes(response.status);
        if (isTransientHttp && attempt < maxRetries) {
          attempt++;
          const jitter = useJitter ? Math.floor(Math.random() * 400) : 0;
          const delay = Math.min(initialDelayMs * Math.pow(2, attempt - 1) + jitter, maxDelayMs);
          await new Promise(res => setTimeout(res, delay));
          continue;
        }

        return response;
      } catch (err: any) {
        clearTimeout(attemptTimer);
        if (callerSignal) callerSignal.removeEventListener('abort', onCallerAbort);

        // Si fue el caller quien abortó intencionalmente, salir sin reintentar
        if (callerSignal && callerSignal.aborted) {
          throw err;
        }

        const isTimeout = attemptTimedOut || String(err.message).toLowerCase().includes('tiempo de espera');
        const isNetworkFailure = 
          isTimeout ||
          err.name === 'TypeError' || 
          err.name === 'AbortError' || 
          String(err.message).toLowerCase().includes('failed to fetch') ||
          String(err.message).toLowerCase().includes('network') ||
          String(err.message).toLowerCase().includes('aborted');

        // Si fue un fallo de red o timeout y aún hay conexión, reintentar con backoff silencioso
        const stillOnline = typeof navigator === 'undefined' || navigator.onLine;
        if (isNetworkFailure && stillOnline && attempt < maxRetries) {
          attempt++;
          const jitter = useJitter ? Math.floor(Math.random() * 400) : 0;
          const delay = Math.min(initialDelayMs * Math.pow(2, attempt - 1) + jitter, maxDelayMs);
          await new Promise(res => setTimeout(res, delay));
          continue;
        }

        throw err;
      }
    }
  }

  /**
   * Valida la conexión con la URL de Google Apps Script Web App midiendo tiempo de respuesta
   */
  static async probarConexion(url: string, spreadsheetId?: string): Promise<PingResult> {
    if (!url || !url.trim().startsWith('http')) {
      return {
        estado: 'error',
        latenciaMs: 0,
        mensaje: 'La URL proporcionada no es válida. Debe comenzar con https://script.google.com/macros/s/...',
        estadoConexion: 'error'
      };
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return {
        estado: 'error',
        latenciaMs: 0,
        mensaje: 'Sin conexión a internet detectada en el dispositivo.',
        estadoConexion: 'desconectado'
      };
    }

    const t0 = performance.now();
    try {
      const cleanSheetId = extraerSpreadsheetId(spreadsheetId) || OFICIAL_SPREADSHEET_ID;
      let pingUrl = url.includes('?') 
        ? `${url}&action=ping&_t=${Date.now()}` 
        : `${url}?action=ping&_t=${Date.now()}`;
      if (cleanSheetId) {
        pingUrl += `&spreadsheetId=${encodeURIComponent(cleanSheetId)}`;
      }

      const response = await this.fetchConReintentos(pingUrl, {
        method: 'GET',
        redirect: 'follow'
      }, { maxRetries: 2, initialDelayMs: 800, timeoutMs: 20000 });

      const t1 = performance.now();
      const latenciaMs = Math.round(t1 - t0);

      if (!response.ok) {
        return {
          estado: 'error',
          latenciaMs,
          mensaje: `El servidor respondió con código HTTP ${response.status}: ${response.statusText}`,
          estadoConexion: 'error'
        };
      }

      const json = await response.json();
      if (json && json.estado === 'ok') {
        // Calibración para Google Apps Script: los arranques en frío e invocaciones serverless de GAS
        // operan saludablemente entre 1000 y 6000 ms. Se marca lento solo si supera los 6000 ms.
        const estadoConexion: EstadoConexion = latenciaMs > 6000 ? 'lento' : 'conectado';
        const msgExtra = cleanSheetId ? ` (Hoja: ${cleanSheetId.slice(0, 8)}...)` : '';
        return {
          estado: 'ok',
          latenciaMs,
          mensaje: `Conexión verificada con Google Sheets${msgExtra}. Tiempo de respuesta: ${latenciaMs} ms`,
          estadoConexion
        };
      } else {
        return {
          estado: 'error',
          latenciaMs,
          mensaje: json.mensaje || 'Respuesta inesperada de Google Apps Script.',
          estadoConexion: 'error'
        };
      }
    } catch (err: any) {
      const t1 = performance.now();
      const latenciaMs = Math.round(t1 - t0);
      let errorMsg = err.message || 'Error de red o CORS al conectar con Google Apps Script.';
      if (err.name === 'AbortError' || String(err.message).includes('agotado')) {
        errorMsg = 'Tiempo de espera agotado (timeout > 20s).';
      }
      return {
        estado: 'error',
        latenciaMs,
        mensaje: errorMsg,
        estadoConexion: typeof navigator !== 'undefined' && !navigator.onLine ? 'desconectado' : 'error'
      };
    }
  }

  /**
   * Consulta todos los datos desde Google Sheets vía Google Apps Script Web App con reintentos
   */
  static async obtenerDatosCompletos(url: string, spreadsheetId?: string): Promise<any> {
    if (!url || !url.trim().startsWith('http')) {
      throw new Error('URL de Google Apps Script no configurada');
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      throw new Error('Dispositivo en modo fuera de línea');
    }

    const cleanSheetId = extraerSpreadsheetId(spreadsheetId) || OFICIAL_SPREADSHEET_ID;
    let getAllUrl = url.includes('?') 
      ? `${url}&action=getAll&_t=${Date.now()}` 
      : `${url}?action=getAll&_t=${Date.now()}`;
    if (cleanSheetId) {
      getAllUrl += `&spreadsheetId=${encodeURIComponent(cleanSheetId)}`;
    }

    const response = await this.fetchConReintentos(getAllUrl, {
      method: 'GET',
      redirect: 'follow'
    }, { maxRetries: 2, initialDelayMs: 1200, timeoutMs: 35000 });

    if (!response.ok) {
      throw new Error(`Error HTTP ${response.status}: ${response.statusText}`);
    }

    const json = await response.json();
    if (json.estado !== 'ok') {
      throw new Error(json.mensaje || 'Error al obtener datos desde Google Sheets');
    }

    return json.datos;
  }

  /**
   * Envía una solicitud POST directa con reintentos (usado internamente por la cola y por enviarPost)
   */
  static async enviarPostDirecto(url: string, payload: any): Promise<any> {
    if (!url || !url.trim().startsWith('http')) {
      throw new Error('URL de Google Apps Script no configurada');
    }

    let payloadFinal = payload;
    try {
      if (payload && typeof payload === 'object') {
        let sheetId = payload.spreadsheetId ? String(payload.spreadsheetId).trim() : '';
        if (!sheetId) {
          const cfgStorage = localStorage.getItem('ssoma_config_v2');
          if (cfgStorage) {
            try {
              const parsed = JSON.parse(cfgStorage);
              if (parsed.spreadsheetId) {
                sheetId = String(parsed.spreadsheetId).trim();
              }
            } catch {}
          }
        }
        if (!sheetId) {
          sheetId = OFICIAL_SPREADSHEET_ID;
        }
        payloadFinal = { ...payload, spreadsheetId: sheetId };
      }
    } catch {}

    const response = await this.fetchConReintentos(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8'
      },
      body: JSON.stringify(payloadFinal)
    }, { maxRetries: 2, initialDelayMs: 1000, timeoutMs: 30000 });

    if (!response.ok) {
      throw new Error(`Error en servidor GAS HTTP ${response.status}: ${response.statusText}`);
    }

    let json: any;
    try {
      json = await response.json();
    } catch {
      throw new Error('Google Apps Script respondió con HTML en lugar de JSON (verifica que hayas creado una Nueva Versión en Implementar > Administrar implementaciones)');
    }

    if (json.estado !== 'ok' && !json.success) {
      throw new Error(json.mensaje || json.error || 'Error devuelto por Google Apps Script');
    }

    return json;
  }

  /**
   * Envía una solicitud POST a Google Apps Script Web App.
   * Si el dispositivo está fuera de línea o la transmisión remota falla por red,
   * automáticamente resguarda la mutación en la cola offline para sincronización garantizada.
   */
  static async enviarPost(url: string, payload: any, meta?: MutationMeta): Promise<any> {
    const estaOffline = typeof navigator !== 'undefined' && !navigator.onLine;

    if (estaOffline) {
      if (this.enqueueFallback) {
        this.enqueueFallback(payload, meta);
        console.info('[GasService] Operación resguardada en cola offline debido a falta de conexión.');
        return { estado: 'ok', encolado: true, mensaje: 'Guardado localmente en cola offline.' };
      }
      throw new Error('Sin conexión a internet. La operación no pudo ser transmitida.');
    }

    try {
      return await this.enviarPostDirecto(url, payload);
    } catch (err: any) {
      if (this.enqueueFallback) {
        this.enqueueFallback(payload, meta);
        return { estado: 'ok', encolado: true, mensaje: 'Operación guardada localmente por inestabilidad de red. Se sincronizará en segundo plano.' };
      }
      throw err;
    }
  }

  /**
   * Guarda un archivo o imagen en Google Drive a través del backend Google Apps Script (Desactivado según preferencia de usuario)
   */
  static async guardarArchivoEnDrive(
    _url: string,
    params: {
      nombreArchivo: string;
      mimeType: string;
      base64Data: string;
      subcarpeta?: string;
      descripcion?: string;
    }
  ): Promise<any> {
    // Almacenamiento en Drive desactivado: los documentos se descargan y gestionan localmente
    return {
      success: true,
      estado: 'ok',
      mensaje: `Almacenamiento remoto en Drive omitido para ${params.nombreArchivo}`
    };
  }
}
