export type EmpresaId = 'EMP-PERPOL' | 'EMP-TR3' | 'PERPOL' | 'TR3';

export interface Empresa {
  id: EmpresaId;
  ruc: string;
  razonSocial: string;
  direccion: string;
  actividadEconomica: string;
  logoUrl?: string;
  codigoPlantilla: string;
  versionPlantilla: string;
  fechaEmisionPlantilla: string;
  estado: 'Activo' | 'Inactivo';
}

export type EstadoTrabajador = 'Activo' | 'Inactivo' | 'Cesado';

export interface Trabajador {
  codigo: string;
  dni: string;
  nombreCompleto: string;
  apellidosNombres?: string; // Columna en Google Sheets: apellidosNombres
  empresaId: EmpresaId;
  empresaNombre: string;
  empresa?: string; // Columna en Google Sheets: empresa
  area: string;
  cargo: string;
  puesto?: string; // Columna en Google Sheets: puesto
  fechaIngreso: string;
  fechaNacimiento?: string;
  edad?: number | string;
  sexo?: 'M' | 'F';
  estado: EstadoTrabajador;
  condicion?: EstadoTrabajador | string; // Columna en Google Sheets: condicion
  telefono?: string;
  email?: string;
  correo?: string; // Columna en Google Sheets: correo
}

export type CategoriaEPP = 
  | 'Protección Craneal'
  | 'Protección Ocular y Facial'
  | 'Protección Auditiva'
  | 'Protección Respiratoria'
  | 'Protección Manual'
  | 'Calzado de Seguridad'
  | 'Protección Contra Caídas'
  | 'Ropa de Trabajo y Uniforme';

export type TipoArticulo = 'EPP' | 'Uniforme';

export interface EPPItem {
  codigo: string;
  articulo: string;
  categoria: CategoriaEPP;
  tipo: TipoArticulo;
  marca: string;
  modelo: string;
  norma: string;
  talla: string;
  unidad: string;
  vidaUtilDias: number;
  costoUnitario: number;
  stockActual: number;
  stockMinimo: number;
  estado: 'Disponible' | 'Stock Crítico' | 'Agotado' | 'Inactivo';
}

export type MotivoEntrega = 
  | 'Entrega inicial'
  | 'Reposición'
  | 'Desgaste'
  | 'Deterioro'
  | 'Pérdida'
  | 'Nuevo ingreso'
  | 'Renovación';

export interface DetalleEntrega {
  idDetalle: string;
  idEntrega?: string;
  codigoEPP: string;
  articulo: string;
  categoria?: CategoriaEPP;
  tipo: TipoArticulo;
  talla: string;
  unidad: string;
  cantidad: number;
  costoUnitario: number;
  importe: number;
  motivo: MotivoEntrega;
  fechaRenovacion: string;
  observaciones?: string;
  norma?: string;
}

// --- Tipos para Control de Kardex e Inventario de EPP ---
export type TipoMovimientoStock = 'ENTRADA' | 'SALIDA' | 'AJUSTE';

export interface ItemIngresoStock {
  idItem?: string;
  codigoEPP: string;
  articulo: string;
  cantidad: number;
  costoUnitario: number;
}

export interface IngresoStock {
  id: string; // ej: ING-2026-0001
  numeroComprobante: string; // Guía de Remisión o Factura
  fechaIngreso: string; // YYYY-MM-DD
  items: ItemIngresoStock[];
  totalUnidades: number;
  totalImporte: number;
  fechaCreacion: string;
}

export interface MovimientoKardex {
  id: string;
  fechaHora: string;
  tipo: TipoMovimientoStock; // 'ENTRADA' | 'SALIDA'
  codigoEPP: string;
  articulo: string;
  documentoReferencia: string; // N° Guía/Factura (para Entrada) o N° Acta REG-XXXX (para Salida)
  trabajadorNombre?: string; // Trabajador (en salidas por entrega)
  cantidad: number; // Siempre positivo para display
  stockAnterior: number;
  stockResultante: number;
  costoUnitario?: number;
  importeTotal?: number;
}

export interface EntregaEPP {
  id: string; // e.g. ENT-2026-0001
  numeroRegistro: string; // e.g. REG-0001
  fechaEntrega: string;
  codigoTrabajador: string;
  dni: string;
  trabajadorNombre: string;
  empresa?: string;
  empresaId: EmpresaId;
  razonSocial: string;
  ruc: string;
  direccion: string;
  actividadEconomica: string;
  area: string;
  cargo: string;
  numTrabajadoresActivosCalculado: number;
  fechaHoraCalculoTrabajadores: string;
  responsableEntrega: string;
  tipoEntregaGeneral: MotivoEntrega;
  observacionesGenerales: string;
  totalUnidades: number;
  importeTotal: number;
  detalles: DetalleEntrega[];
  firmaTrabajador?: string; // base64 / dataURL
  firmaResponsable?: string; // base64 / dataURL
  estado: 'Confirmada' | 'Pendiente de Firma' | 'Anulada';
  codigoPlantilla: string;
  versionPlantilla: string;
  pdfFileName?: string;
  pdfBlobUrl?: string;
  driveUrl?: string;
  fechaCreacion: string;
  operationId: string;
}

export type EstadoRenovacion = 'Vencido' | 'Próximo a vencer' | 'Vigente';

export interface ItemRenovacion {
  idDetalle: string;
  idEntrega: string;
  numeroRegistro: string;
  codigoTrabajador: string;
  trabajadorNombre: string;
  dni: string;
  empresaId: EmpresaId;
  empresaNombre: string;
  area: string;
  cargo: string;
  codigoEPP: string;
  articulo: string;
  tipo: TipoArticulo;
  talla: string;
  cantidad: number;
  fechaEntrega: string;
  fechaRenovacion: string;
  diasRestantes: number;
  estadoRenovacion: EstadoRenovacion;
}

export type ResultadoInspeccion = 
  | 'Buen estado'
  | 'Desgastado'
  | 'Deteriorado o dañado'
  | 'No presentado'
  | 'EPP Extraviado/ A Descontar';

export type AccionInspeccion = 
  | 'Sin acción requerida'
  | 'Limpieza o mantenimiento'
  | 'Evaluación adicional'
  | 'Reposición'
  | 'Retiro de uso';

export type EstadoAccionInspeccion = 'No aplica' | 'Pendiente' | 'En proceso' | 'Cerrada';

export interface DesgloseUnidadInspeccion {
  id: string;
  resultado: ResultadoInspeccion;
  cantidad: number;
  hallazgo: string;
  accion: AccionInspeccion;
}

export interface DetalleInspeccion {
  idDetalle: string;
  idInspeccion: string;
  codigoEPP: string;
  articulo: string;
  talla: string;
  idEntregaOrigen: string;
  idDetalleEntregaOrigen: string;
  fechaEntregaReferencia: string;
  cantidadReferencia: number;
  fechaRenovacionReferencia: string;
  resultado: ResultadoInspeccion;
  hallazgo: string;
  accion: AccionInspeccion;
  responsableAccion?: string;
  fechaLimiteAccion?: string;
  estadoAccion: EstadoAccionInspeccion;
  observaciones?: string;
  evidenciaFotografica?: string;
  desgloseUnidades?: DesgloseUnidadInspeccion[];
}

export interface InspeccionEPP {
  id: string;
  numeroInspeccion: string;
  fechaHora: string;
  codigoTrabajador: string;
  dni: string;
  trabajadorNombre: string;
  empresaId: EmpresaId;
  empresaNombre: string;
  area: string;
  cargo: string;
  inspectorResponsable: string;
  lugarInspeccion: string;
  observacionesGenerales: string;
  estado: 'Confirmado' | 'Borrador' | 'Anulado';
  detalles: DetalleInspeccion[];
  pdfFileName?: string;
  pdfBlobUrl?: string;
  driveUrl?: string;
  fechaCreacion: string;
  operationId: string;
}

export type TipoFuentePDF = 'helvetica' | 'times' | 'courier';

export interface PlantillaFormato {
  id: string;
  codigo: string; // FO-SST-GEN-050
  version: string; // 02
  nombre: string;
  fechaAprobacion: string;
  estado: 'Activa' | 'Histórica';
  descripcion: string;
  referenciaNormativa?: string;
  declaracionCompromiso?: string;
  tipoDocumento?: 'Dotación' | 'Descuento' | 'Disciplina' | 'Inspección' | 'Liquidación';
  tituloSistemaGestion?: string; // ej: SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA
  // Opciones de diseño y maquetación
  logoPersonalizado?: string; // Data URL o URL del logo (fallback general)
  logoPerpol?: string; // Data URL o URL del logo oficial para PERPOL IDEAS S.A.C.
  logoTr3?: string; // Data URL o URL del logo oficial para TR3 ALIMENTOS S.A.C.
  textoSubtituloMembrete?: string; // ej: DIVISIÓN INDUSTRIAL
  colorPrimarioHex?: string; // ej: #166534
  tipografia?: TipoFuentePDF; // 'helvetica' | 'times' | 'courier'
  tamanoFuenteBase?: 'normal' | 'compacto' | 'grande';
  maxItemsPorPagina?: number; // ej: 8, 10, 12
  mostrarPreciosValores?: boolean; // mostrar/ocultar importes
  mostrarColumnaTalla?: boolean; // mostrar columna de tallas
  mostrarFechaRenovacion?: boolean; // mostrar fecha estimada de cambio
  mostrarCodigoQR?: boolean; // incluir código QR
  orientacionPagina?: 'portrait' | 'landscape';
  lemaPiePagina?: string; // lema de pie de página
  cargoResponsablePorDefecto?: string;
  // Opciones para inhabilitar u ocultar textos específicos en la plantilla oficial
  inhabilitarTituloSistemaGestion?: boolean; // Inhabilitar texto superior del encabezado
  inhabilitarSubtituloMembrete?: boolean;    // Inhabilitar subtítulo / división en logo/membrete
  inhabilitarReferenciaNormativa?: boolean;  // Inhabilitar referencia legal/normativa bajo el título
  inhabilitarDeclaracionCompromiso?: boolean;// Inhabilitar cláusula de compromiso / declaración jurada
  inhabilitarLemaPiePagina?: boolean;        // Inhabilitar lema institucional de pie de página
  inhabilitarCargoResponsable?: boolean;     // Inhabilitar cargo por defecto del emisor
}

export interface DocumentoEmitido {
  id: string;
  idEntrega: string;
  numeroRegistro: string;
  codigoTrabajador: string;
  dni: string;
  trabajador: string;
  empresaId: EmpresaId;
  empresaNombre: string;
  ruc: string;
  codigoPlantilla: string;
  versionPlantilla: string;
  versionDocumento: string;
  fechaHoraEmision: string;
  responsable: string;
  estadoDocumental: 'Emitido' | 'Pendiente de Firma' | 'Anulado';
  fileName: string;
  pdfDataUri?: string;
}

export type EstadoConexion = 'conectado' | 'lento' | 'error' | 'desconectado';

// --- Tipos para Documentos de Descuento por Pérdida / Reposición de EPP ---
export type MotivoDescuento = 
  | 'Pérdida en planta' 
  | 'Extravío fuera de planta' 
  | 'Deterioro por uso indebido' 
  | 'No devolución al cese' 
  | 'Negligencia o descuido';

export type ModalidadPagoDescuento = 
  | '1 cuota fin de mes' 
  | '2 cuotas quincenales' 
  | '1 cuota en quincena' 
  | '3 cuotas mensuales';

export type EstadoDescuento = 'Pendiente' | 'Autorizado' | 'Aplicado en Planilla' | 'Anulado';

export interface ItemDescuentoEPP {
  idItem: string;
  codigoEPP: string;
  articulo: string;
  categoria?: CategoriaEPP;
  marca: string;
  talla: string;
  unidad: string;
  cantidadPerdida: number;
  costoUnitario: number;
  importeTotal: number;
  fechaEntregaOriginal?: string;
}

export interface DescuentoEPP {
  id: string; // e.g. DESC-2026-0001
  numeroRegistro: string; // e.g. AUT-DESC-0001
  codigoPlantilla: string; // FO-SST-DES-001
  versionPlantilla: string; // 01
  fechaSolicitud: string; // YYYY-MM-DD
  fechaIncidente: string; // YYYY-MM-DD
  codigoTrabajador: string;
  dni: string;
  trabajadorNombre: string;
  empresaId: EmpresaId;
  empresaNombre: string;
  ruc: string;
  area: string;
  cargo: string;
  fechaIngreso?: string;
  motivoDescuento: MotivoDescuento;
  descripcionHechos: string;
  items: ItemDescuentoEPP[];
  montoTotalDescuento: number;
  modalidadPago: ModalidadPagoDescuento;
  cuotas: number;
  montoPorCuota: number;
  autorizaDescuento: boolean; // Consentimiento expreso
  firmaTrabajador?: string; // Data URL / Base64
  firmaResponsable?: string; // Data URL / Base64
  responsableNombre: string;
  responsableCargo: string;
  estado: EstadoDescuento;
  reponerInmediatamente: boolean; // Disparar reposición automática
  idEntregaReposicion?: string; // ID de la entrega generada si aplica
  idInspeccionOrigen?: string; // Trazabilidad con inspección
  numeroInspeccionOrigen?: string; // Ej: INS-0001
  pdfFileName?: string;
  pdfBlobUrl?: string;
  driveUrl?: string;
  fechaCreacion: string;
  observaciones?: string;
}

// --- Tipos para Reportes de Infracción por No Portar / Usar EPP ---
export type GravedadInfraccion = 'Leve' | 'Grave' | 'Muy Grave';

export type TipoSancionInfraccion = 
  | 'Amonestación Verbal' 
  | 'Amonestación Escrita' 
  | 'Suspensión Temporal' 
  | 'Reporte a Recursos Humanos';

export type NivelReincidencia = 
  | 'Primera vez' 
  | 'Segunda vez (Reiterativa)' 
  | 'Tercera vez o más (Grave)';

export type EstadoInfraccion = 'Registrada' | 'Enviada a RRHH' | 'Cerrada' | 'Anulada';

export interface InfraccionEPP {
  id: string; // e.g. INF-2026-0001
  numeroReporte: string; // e.g. REP-INF-0001
  codigoPlantilla: string; // FO-SST-INF-001
  versionPlantilla: string; // 01
  fechaHora: string; // YYYY-MM-DDTHH:mm
  codigoTrabajador: string;
  dni: string;
  trabajadorNombre: string;
  empresaId: EmpresaId;
  empresaNombre: string;
  ruc: string;
  area: string;
  cargo: string;
  lugarZona: string; // Ubicación exacta en planta
  eppsOmitidos: string[]; // Lista de EPPs no portados
  gravedad: GravedadInfraccion;
  tipoSancion: TipoSancionInfraccion;
  reincidencia: NivelReincidencia;
  descripcionHechos: string;
  justificacionTrabajador?: string;
  medidaCorrectivaInmediata: string;
  supervisorReporta: string;
  cargoSupervisor: string;
  testigoNombre?: string;
  testigoDni?: string;
  firmaTrabajador?: string;
  firmaSupervisor?: string;
  seNegoAFirmar: boolean;
  estado: EstadoInfraccion;
  idInspeccionOrigen?: string; // Trazabilidad con inspección
  numeroInspeccionOrigen?: string; // Ej: INS-0001
  pdfFileName?: string;
  pdfBlobUrl?: string;
  driveUrl?: string;
  evidenciasUrls?: string[];
  fechaCreacion: string;
  observaciones?: string;
}

export interface DatosPreseleccionadosInfraccion {
  codigoTrabajador?: string;
  eppsOmitidos?: string[];
  lugarZona?: string;
  fechaHora?: string;
  supervisorReporta?: string;
  descripcionHechos?: string;
  idInspeccionOrigen?: string;
  numeroInspeccionOrigen?: string;
}

export interface DatosPreseleccionadosDescuento {
  codigoTrabajador?: string;
  codigoEPP?: string;
  idInspeccionOrigen?: string;
  numeroInspeccionOrigen?: string;
  descripcionHechos?: string;
  motivoDescuento?: MotivoDescuento;
}

// --- Tipos para Liquidación de EPP por Cese Laboral (FO-SST-LIQ-001) ---
export type EstadoItemLiquidacion = 'Devuelto' | 'Vencido' | 'Pendiente' | 'Exonerado';

export type EstadoLiquidacion = 'Borrador' | 'Emitida' | 'Enviada a RRHH' | 'Liquidada en Planilla' | 'Anulada';

export interface ItemLiquidacionEPP {
  idItem: string;
  idEntregaOrigen: string;
  numeroRegistroOrigen: string;
  fechaEntrega: string;
  codigoEPP: string;
  articulo: string;
  categoria?: CategoriaEPP;
  tipo: TipoArticulo;
  talla: string;
  unidad: string;
  cantidadEntregada: number;
  cantidadDevuelta: number;
  cantidadVencida: number;
  cantidadALiquidar: number;
  costoUnitario: number;
  importeTotalEntregado: number;
  montoALiquidar: number;
  vidaUtilDias: number;
  fechaVencimiento: string;
  estadoItem: EstadoItemLiquidacion;
  motivoExoneracion?: string;
  observaciones?: string;
}

export interface LiquidacionEPP {
  id: string; // e.g. LIQ-2026-0001
  numeroRegistro: string; // e.g. ACTA-LIQ-0001
  codigoPlantilla: string; // FO-SST-LIQ-001
  versionPlantilla: string; // 01
  fechaLiquidacion: string; // YYYY-MM-DD
  fechaCese: string; // YYYY-MM-DD
  motivoCese?: string; // e.g. 'Renuncia Voluntaria', 'Término de Contrato', 'Mutuo Disenso', 'Despido'
  codigoTrabajador: string;
  dni: string;
  trabajadorNombre: string;
  empresaId: EmpresaId;
  empresaNombre: string;
  ruc: string;
  area: string;
  cargo: string;
  fechaIngreso?: string;
  items: ItemLiquidacionEPP[];
  totalItemsEntregados: number;
  totalItemsDevueltos: number;
  totalItemsVencidos: number;
  totalItemsALiquidar: number;
  montoTotalEntregado: number;
  montoDescontadoVencidosYDevueltos: number;
  montoNetoALiquidar: number;
  observacionesGenerales?: string;
  supervisorResponsable: string;
  cargoSupervisor: string;
  responsableRRHH?: string;
  cargoRRHH?: string;
  areaRRHH?: string;
  firmaTrabajador?: string;
  firmaSupervisor?: string;
  firmaRRHH?: string;
  estado: EstadoLiquidacion;
  pdfFileName?: string;
  pdfBlobUrl?: string;
  driveUrl?: string;
  fechaCreacion: string;
}

export interface DatosPreseleccionadosLiquidacion {
  codigoTrabajador?: string;
  fechaCese?: string;
  motivoCese?: string;
}

export interface ConfiguracionApp {
  gasWebAppUrl: string;
  spreadsheetId?: string; // ID o URL del libro de Google Sheets
  driveFolderId?: string; // ID de carpeta de Google Drive para almacenamiento de evidencias y respaldos
  intervaloActualizacionSegundos: number; // 30, 60, 120
  actualizacionAutomaticaActiva: boolean;
  ultimaActualizacion?: string;
  estadoConexion: EstadoConexion;
  latenciaMs?: number;
  formatoActivo: {
    codigo: string;
    version: string;
    fechaEmision: string;
    tamanoPagina: 'A4';
    orientacion: 'portrait';
  };
}

export interface ResponsableSSTOption {
  valor: string;
  nombre: string;
  cargo: string;
}

export const RESPONSABLES_SST_OPCIONES: ResponsableSSTOption[] = [
  {
    valor: 'Ing. Jhon Rojas (Supervisor SSOMA)',
    nombre: 'Ing. Jhon Rojas',
    cargo: 'Supervisor SSOMA',
  },
  {
    valor: 'Ronny Revollas (Auxiliar SSOMA)',
    nombre: 'Ronny Revollas',
    cargo: 'Auxiliar SSOMA',
  },
];
