/**
 * Utilidades Centralizadas de Formateo y Normalización SSOMA
 * Empresas: PERPOL IDEAS S.A.C. | TR3 ALIMENTOS S.A.C.
 */

/**
 * Formatea un valor numérico a moneda oficial peruana (Soles)
 * Ejemplo: formatMoneda(125.5) -> "S/ 125.50"
 */
export const formatMoneda = (valor?: number | null): string => {
  const num = typeof valor === 'number' && !isNaN(valor) ? valor : 0;
  return `S/ ${num.toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

/**
 * Formatea una fecha ISO o string (YYYY-MM-DD o ISO completo) a formato visual peruano DD/MM/YYYY
 * Ejemplo: formatFecha("2026-03-15") -> "15/03/2026"
 */
export const formatFecha = (fechaStr?: string | null): string => {
  if (!fechaStr) return '-';
  try {
    const soloFecha = fechaStr.includes('T') ? fechaStr.split('T')[0] : fechaStr.split(' ')[0];
    const partes = soloFecha.split('-');
    if (partes.length === 3) {
      const [anio, mes, dia] = partes;
      return `${dia.padStart(2, '0')}/${mes.padStart(2, '0')}/${anio}`;
    }
    const d = new Date(fechaStr);
    if (isNaN(d.getTime())) return fechaStr;
    const dia = String(d.getDate()).padStart(2, '0');
    const mes = String(d.getMonth() + 1).padStart(2, '0');
    const anio = d.getFullYear();
    return `${dia}/${mes}/${anio}`;
  } catch {
    return fechaStr || '-';
  }
};

/**
 * Formatea una fecha y hora a formato visual peruano DD/MM/YYYY HH:mm
 * Ejemplo: formatFechaHora("2026-03-15T08:30:00") -> "15/03/2026 08:30"
 */
export const formatFechaHora = (fechaHoraStr?: string | null): string => {
  if (!fechaHoraStr) return '-';
  try {
    const d = new Date(fechaHoraStr.replace(' ', 'T'));
    if (isNaN(d.getTime())) return fechaHoraStr;
    const dia = String(d.getDate()).padStart(2, '0');
    const mes = String(d.getMonth() + 1).padStart(2, '0');
    const anio = d.getFullYear();
    const horas = String(d.getHours()).padStart(2, '0');
    const minutos = String(d.getMinutes()).padStart(2, '0');
    return `${dia}/${mes}/${anio} ${horas}:${minutos}`;
  } catch {
    return fechaHoraStr || '-';
  }
};

/**
 * Determina el tipo de documento de identidad oficial:
 * - DNI: 8 dígitos numéricos
 * - C.E. (Carné de Extranjería): más de 8 caracteres (hasta 12)
 */
export const getTipoDocumento = (doc?: string | null): 'DNI' | 'C.E.' => {
  const clean = String(doc || '').trim();
  return clean.length > 8 ? 'C.E.' : 'DNI';
};

/**
 * Calcula la edad en años a partir de una fecha de nacimiento
 */
export const calcularEdad = (fechaNac?: string | null): number | null => {
  if (!fechaNac) return null;
  const birth = new Date(fechaNac);
  if (isNaN(birth.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age >= 0 && age < 120 ? age : null;
};

/**
 * Convierte cualquier formato de fecha estándar (YYYY-MM-DD, YYYY-MM-DD HH:mm:ss, DD/MM/YYYY, ISO)
 * a timestamp numérico en milisegundos para ordenamientos fiables.
 */
export const parseFechaMs = (f?: string | null): number => {
  if (!f) return 0;
  const str = String(f).trim();
  if (!str) return 0;

  // Manejo de formatos peruanos DD/MM/YYYY o DD-MM-YYYY
  const m = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (m) {
    const [, d, mo, y, h, min, s] = m;
    const date = new Date(
      Number(y),
      Number(mo) - 1,
      Number(d),
      Number(h || 0),
      Number(min || 0),
      Number(s || 0)
    );
    const ms = date.getTime();
    return isNaN(ms) ? 0 : ms;
  }

  // Formato ISO estándar o YYYY-MM-DD
  const normalizado = str.includes(' ') && !str.includes('T') ? str.replace(' ', 'T') : str;
  const parsed = new Date(normalizado).getTime();
  return isNaN(parsed) ? 0 : parsed;
};

/**
 * Función comparadora para ordenar cronológicamente de forma descendente (el más reciente primero).
 * Si las fechas coinciden, desempata con un correlativo secundario (ej. REG-0050 antes de REG-0049).
 */
export const compararFechasDesc = (
  fechaA?: string | null,
  fechaB?: string | null,
  correlativoA?: string | null,
  correlativoB?: string | null
): number => {
  const timeA = parseFechaMs(fechaA);
  const timeB = parseFechaMs(fechaB);

  if (timeB !== timeA) {
    return timeB - timeA; // Más reciente primero
  }

  // Criterio de desempate secundario por correlativo o número de registro descendente
  if (correlativoA && correlativoB) {
    return String(correlativoB).localeCompare(String(correlativoA), undefined, { numeric: true });
  }

  return 0;
};
