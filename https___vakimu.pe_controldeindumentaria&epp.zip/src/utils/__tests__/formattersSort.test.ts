import { describe, it, expect } from 'vitest';
import { parseFechaMs, compararFechasDesc } from '../formatters';

describe('compararFechasDesc & parseFechaMs', () => {
  it('parses various date formats to timestamp correctly', () => {
    const iso = parseFechaMs('2026-10-22');
    const isoTime = parseFechaMs('2026-10-22T15:30:00');
    const spaceTime = parseFechaMs('2026-10-22 15:30:00');
    const peruano = parseFechaMs('22/10/2026');

    expect(iso).toBeGreaterThan(0);
    expect(isoTime).toBeGreaterThan(0);
    expect(spaceTime).toBeGreaterThan(0);
    expect(peruano).toBeGreaterThan(0);
  });

  it('sorts recent dates before older dates', () => {
    const fechas = [
      { id: '1', fecha: '2026-01-10', reg: 'REG-0001' },
      { id: '2', fecha: '2026-10-22', reg: 'REG-0050' },
      { id: '3', fecha: '2026-05-15', reg: 'REG-0020' },
      { id: '4', fecha: '2026-10-22', reg: 'REG-0051' },
    ];

    const sorted = [...fechas].sort((a, b) =>
      compararFechasDesc(a.fecha, b.fecha, a.reg, b.reg)
    );

    // REG-0051 on 2026-10-22 is latest with higher correlativo
    expect(sorted[0].reg).toBe('REG-0051');
    expect(sorted[1].reg).toBe('REG-0050');
    expect(sorted[2].reg).toBe('REG-0020');
    expect(sorted[3].reg).toBe('REG-0001');
  });

  it('handles numeric DNI safely without throwing TypeError', () => {
    const entregas = [
      { numeroRegistro: 'REG-0001', trabajadorNombre: 'Juan Perez', dni: 45678901 as any },
      { numeroRegistro: 'REG-0002', trabajadorNombre: 'Maria Lopez', dni: '76543210' },
      { numeroRegistro: 'REG-0003', trabajadorNombre: 'Carlos Ruiz', dni: null as any }
    ];

    const q = '4567';
    const filtrados = entregas.filter(e =>
      String(e.numeroRegistro || '').toLowerCase().includes(q) ||
      String(e.trabajadorNombre || '').toLowerCase().includes(q) ||
      String(e.dni || '').includes(q)
    );

    expect(filtrados.length).toBe(1);
    expect(filtrados[0].numeroRegistro).toBe('REG-0001');
  });
});
