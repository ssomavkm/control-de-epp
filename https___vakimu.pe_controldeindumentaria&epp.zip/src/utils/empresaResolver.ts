import { Empresa, EmpresaId } from '../types';
import { EMPRESAS_SEED } from '../data/seeds/empresas';

export const RUC_PERPOL = '20392729977';
export const RUC_TR3 = '20550842891';
export const RAZON_SOCIAL_PERPOL = 'PERPOL IDEAS S.A.C.';
export const RAZON_SOCIAL_TR3 = 'TR3 ALIMENTOS S.A.C.';

/**
 * Normaliza y deduce con alta precisión el EmpresaId ('PERPOL' o 'TR3')
 * analizando cualquier combinación de ID, RUC o Nombre/Razón Social provenientes
 * de Google Sheets o entradas de usuario.
 */
export function normalizarEmpresaId(
  input?: {
    empresaId?: string | null;
    empresa?: string | null;
    empresaNombre?: string | null;
    razonSocial?: string | null;
    ruc?: string | null;
  } | string | null
): EmpresaId {
  if (!input) return 'EMP-PERPOL';

  let raw = '';
  if (typeof input === 'string') {
    raw = input;
  } else {
    raw = [
      input.empresaId,
      input.ruc,
      input.empresa,
      input.empresaNombre,
      input.razonSocial
    ].filter(Boolean).join(' ');
  }

  const str = raw.toUpperCase().trim();

  // 1. Análisis directo de RUC oficial
  if (str.includes(RUC_PERPOL)) return 'EMP-PERPOL';
  if (str.includes(RUC_TR3)) return 'EMP-TR3';

  // 2. Análisis por ID oficial
  if (str.includes('EMP-PERPOL') || str.includes('PERPOL')) return 'EMP-PERPOL';
  if (str.includes('EMP-TR3') || str.includes('TR3')) return 'EMP-TR3';

  // 3. Coincidencias fonéticas o parciales en texto
  if (/PER\s*POL/i.test(str)) return 'EMP-PERPOL';
  if (/TR\s*3/i.test(str) || /TRES\s*ALIMENTOS/i.test(str)) return 'EMP-TR3';

  // Fallback seguro a EMP-PERPOL
  return 'EMP-PERPOL';
}

/**
 * Retorna el identificador canónico para Google Sheets ('PERPOL' o 'TR3')
 * garantizando que en todas las hojas la columna empresaId contenga estrictamente
 * 'PERPOL' o 'TR3' (sin prefijo 'EMP-').
 */
export function normalizarEmpresaIdParaSheets(
  input?: {
    empresaId?: string | null;
    empresa?: string | null;
    empresaNombre?: string | null;
    razonSocial?: string | null;
    ruc?: string | null;
  } | string | null
): 'PERPOL' | 'TR3' {
  const norm = normalizarEmpresaId(input);
  return norm === 'EMP-PERPOL' || norm === 'PERPOL' ? 'PERPOL' : 'TR3';
}

/**
 * Obtiene los datos canónicos completos de la razón social (RUC, dirección, plantilla, etc.)
 * a partir de cualquier dato parcial o lista de empresas disponibles.
 */
export function obtenerEmpresaCanonica(
  empresaIdOTexto?: any,
  empresasDisponibles?: Empresa[]
): Empresa {
  const targetId = normalizarEmpresaId(empresaIdOTexto);

  // Buscar en empresas disponibles si se proporcionaron
  if (Array.isArray(empresasDisponibles) && empresasDisponibles.length > 0) {
    const encontrada = empresasDisponibles.find(e => {
      if (e.id === targetId) return true;
      const eIdNorm = normalizarEmpresaId(e);
      return eIdNorm === targetId;
    });
    if (encontrada) {
      // Garantizar que tenga los datos mínimos oficiales
      const seed = EMPRESAS_SEED.find(s => s.id === targetId) || EMPRESAS_SEED[0];
      return {
        ...seed,
        ...encontrada,
        id: targetId,
        ruc: encontrada.ruc || seed.ruc,
        razonSocial: encontrada.razonSocial || seed.razonSocial
      };
    }
  }

  // Retornar directamente de la semilla canónica homologada
  return EMPRESAS_SEED.find(s => s.id === targetId) || EMPRESAS_SEED[0];
}
