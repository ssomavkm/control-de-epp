import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { storageService } from '../services/storageService';
import {
  Empresa,
  Trabajador,
  EPPItem,
  EntregaEPP,
  InspeccionEPP,
  PlantillaFormato,
  DocumentoEmitido,
  ConfiguracionApp,
  ItemRenovacion,
  DescuentoEPP,
  InfraccionEPP,
  DatosPreseleccionadosInfraccion,
  DatosPreseleccionadosDescuento,
  LiquidacionEPP,
  DatosPreseleccionadosLiquidacion,
  MovimientoKardex,
  IngresoStock
} from '../types';

export interface EPPStoreState {
  // --- Datos del Negocio ---
  empresas: Empresa[];
  trabajadores: Trabajador[];
  catalogoEPP: EPPItem[];
  entregas: EntregaEPP[];
  inspecciones: InspeccionEPP[];
  plantillas: PlantillaFormato[];
  documentos: DocumentoEmitido[];
  renovaciones: ItemRenovacion[];
  descuentos: DescuentoEPP[];
  infracciones: InfraccionEPP[];
  liquidaciones: LiquidacionEPP[];
  movimientosKardex: MovimientoKardex[];
  ingresosStock: IngresoStock[];
  config: ConfiguracionApp;

  // --- Estado de UI y Navegación ---
  currentTab: string;
  empresaFiltro: string;
  sincronizando: boolean;
  sidebarAbierto: boolean;

  // --- Parámetros de enlace contextual entre módulos ---
  trabajadorPreseleccionado?: string;
  eppPreseleccionado?: string;
  datosInfraccionPreseleccionados: DatosPreseleccionadosInfraccion | null;
  datosDescuentoPreseleccionados: DatosPreseleccionadosDescuento | null;
  datosLiquidacionPreseleccionados: DatosPreseleccionadosLiquidacion | null;

  // --- Mutaciones de Estado ---
  setEmpresas: (empresas: Empresa[]) => void;
  setTrabajadores: (trabajadores: Trabajador[]) => void;
  setCatalogoEPP: (catalogoEPP: EPPItem[]) => void;
  setEntregas: (entregas: EntregaEPP[]) => void;
  setInspecciones: (inspecciones: InspeccionEPP[]) => void;
  setPlantillas: (plantillas: PlantillaFormato[]) => void;
  setDocumentos: (documentos: DocumentoEmitido[]) => void;
  setRenovaciones: (renovaciones: ItemRenovacion[]) => void;
  setDescuentos: (descuentos: DescuentoEPP[]) => void;
  setInfracciones: (infracciones: InfraccionEPP[]) => void;
  setLiquidaciones: (liquidaciones: LiquidacionEPP[]) => void;
  setMovimientosKardex: (movimientos: MovimientoKardex[]) => void;
  setIngresosStock: (ingresos: IngresoStock[]) => void;
  setConfig: (config: ConfiguracionApp) => void;

  setCurrentTab: (tab: string) => void;
  setEmpresaFiltro: (empresa: string) => void;
  setSincronizando: (sincronizando: boolean) => void;
  setSidebarAbierto: (abierto: boolean) => void;
  toggleSidebar: () => void;

  setTrabajadorPreseleccionado: (codigo?: string) => void;
  setEppPreseleccionado: (codigo?: string) => void;
  setDatosInfraccionPreseleccionados: (datos: DatosPreseleccionadosInfraccion | null) => void;
  setDatosDescuentoPreseleccionados: (datos: DatosPreseleccionadosDescuento | null) => void;
  setDatosLiquidacionPreseleccionados: (datos: DatosPreseleccionadosLiquidacion | null) => void;

  // --- Acciones de Negocio & Mutaciones directas ---
  addEntrega: (entrega: EntregaEPP) => void;
  updateInspeccion: (id: string, data: Partial<InspeccionEPP>) => void;
  addDescuento: (descuento: DescuentoEPP) => void;
  addInfraccion: (infraccion: InfraccionEPP) => void;

  // --- Sincronización e Integración con storageService ---
  refrescarDesdeStorage: () => void;
  sincronizarConGoogleSheets: () => Promise<void>;
  guardarTrabajador: (trabajador: Trabajador) => Promise<void>;
  eliminarTrabajador: (codigo: string) => Promise<void>;
  guardarEPP: (epp: EPPItem) => Promise<void>;
  guardarPlantilla: (plantilla: PlantillaFormato) => void;
  guardarConfig: (nueva: Partial<ConfiguracionApp>) => void;
  restablecerDatosFabrica: () => void;
  registrarEntrega: (entrega: EntregaEPP) => Promise<{ success: boolean; mensaje: string }>;
  registrarInspeccion: (inspeccion: InspeccionEPP) => Promise<{ success: boolean; mensaje: string }>;
  eliminarInspeccion: (idOrNumero: string) => Promise<{ success: boolean; mensaje: string }>;
  registrarDescuento: (descuento: DescuentoEPP, reponerInmediato?: boolean) => Promise<{ success: boolean; mensaje: string; entregaReposicionId?: string }>;
  registrarInfraccion: (infraccion: InfraccionEPP) => Promise<{ success: boolean; mensaje: string }>;
  registrarLiquidacion: (liquidacion: LiquidacionEPP) => Promise<{ success: boolean; mensaje: string }>;
  actualizarEstadoLiquidacion: (id: string, nuevoEstado: LiquidacionEPP['estado']) => void;
  eliminarLiquidacion: (id: string) => void;
  registrarIngresoStock: (ingreso: IngresoStock) => Promise<{ success: boolean; mensaje: string }>;

  // --- Flujos Parametrizados de Navegación ---
  iniciarNuevaEntrega: () => void;
  iniciarEntregaParametrizada: (codTrabajador?: string, codEPP?: string) => void;
  iniciarDescuentoParametrizado: (codTrabajador?: string, codEPP?: string, datos?: DatosPreseleccionadosDescuento) => void;
  iniciarInfraccionParametrizada: (codTrabajador?: string, datos?: DatosPreseleccionadosInfraccion) => void;
  iniciarLiquidacionParametrizada: (codTrabajador?: string, datos?: DatosPreseleccionadosLiquidacion) => void;
  colocarInfraccionDesdeInspeccion: (datos: DatosPreseleccionadosInfraccion) => void;

  // --- Helpers y Consultas ---
  getTrabajadoresPorEmpresa: (empresaId?: string) => Trabajador[];
  getEntregasPorEmpresa: (empresaId?: string) => EntregaEPP[];
  getTrabajadorPorCodigo: (codigo: string) => Trabajador | undefined;
  getEPPPorCodigo: (codigo: string) => EPPItem | undefined;
  getEntregasVencidas: () => ItemRenovacion[];
  getEntregasProximas: () => ItemRenovacion[];
}

export const useEPPStore = create<EPPStoreState>()(
  persist(
    (set, get) => ({
      // --- Estado Inicial ---
      empresas: storageService.getEmpresas(),
      trabajadores: storageService.getTrabajadores(),
      catalogoEPP: storageService.getCatalogoEPP(),
      entregas: storageService.getEntregas(),
      inspecciones: storageService.getInspecciones(),
      plantillas: storageService.getPlantillas(),
      documentos: storageService.getDocumentos(),
      renovaciones: storageService.getItemsRenovacion(),
      descuentos: storageService.getDescuentos(),
      infracciones: storageService.getInfracciones(),
      liquidaciones: storageService.getLiquidaciones(),
      movimientosKardex: storageService.getMovimientosKardex(),
      ingresosStock: storageService.getIngresosStock(),
      config: storageService.getConfig(),

      // UI
      currentTab: 'dashboard',
      empresaFiltro: 'TODAS',
      sincronizando: false,
      sidebarAbierto: true,

      // Parámetros
      trabajadorPreseleccionado: undefined,
      eppPreseleccionado: undefined,
      datosInfraccionPreseleccionados: null,
      datosDescuentoPreseleccionados: null,
      datosLiquidacionPreseleccionados: null,

      // --- Mutaciones de Estado Simples ---
      setEmpresas: (empresas) => set({ empresas }),
      setTrabajadores: (trabajadores) => set({ trabajadores }),
      setCatalogoEPP: (catalogoEPP) => set({ catalogoEPP }),
      setEntregas: (entregas) => set({ entregas }),
      setInspecciones: (inspecciones) => set({ inspecciones }),
      setPlantillas: (plantillas) => set({ plantillas }),
      setDocumentos: (documentos) => set({ documentos }),
      setRenovaciones: (renovaciones) => set({ renovaciones }),
      setDescuentos: (descuentos) => set({ descuentos }),
      setInfracciones: (infracciones) => set({ infracciones }),
      setLiquidaciones: (liquidaciones) => set({ liquidaciones }),
      setMovimientosKardex: (movimientosKardex) => set({ movimientosKardex }),
      setIngresosStock: (ingresosStock) => set({ ingresosStock }),
      setConfig: (config) => set({ config }),

      setCurrentTab: (tab) => set({ currentTab: tab }),
      setEmpresaFiltro: (empresaFiltro) => set({ empresaFiltro }),
      setSincronizando: (sincronizando) => set({ sincronizando }),
      setSidebarAbierto: (sidebarAbierto) => set({ sidebarAbierto }),
      toggleSidebar: () => set((state) => ({ sidebarAbierto: !state.sidebarAbierto })),

      setTrabajadorPreseleccionado: (cod) => set({ trabajadorPreseleccionado: cod }),
      setEppPreseleccionado: (cod) => set({ eppPreseleccionado: cod }),
      setDatosInfraccionPreseleccionados: (datos) => set({ datosInfraccionPreseleccionados: datos }),
      setDatosDescuentoPreseleccionados: (datos) => set({ datosDescuentoPreseleccionados: datos }),
      setDatosLiquidacionPreseleccionados: (datos) => set({ datosLiquidacionPreseleccionados: datos }),

      // Mutaciones directas de colecciones
      addEntrega: (entrega) =>
        set((state) => ({
          entregas: [entrega, ...state.entregas]
        })),

      updateInspeccion: (id, data) =>
        set((state) => ({
          inspecciones: state.inspecciones.map((i) => (i.id === id ? { ...i, ...data } : i))
        })),

      addDescuento: (descuento) =>
        set((state) => ({
          descuentos: [descuento, ...state.descuentos]
        })),

      addInfraccion: (infraccion) =>
        set((state) => ({
          infracciones: [infraccion, ...state.infracciones]
        })),

      // --- Sincronización e Integración con storageService ---
      refrescarDesdeStorage: () => {
        set({
          empresas: storageService.getEmpresas(),
          trabajadores: storageService.getTrabajadores(),
          catalogoEPP: storageService.getCatalogoEPP(),
          entregas: storageService.getEntregas(),
          inspecciones: storageService.getInspecciones(),
          plantillas: storageService.getPlantillas(),
          documentos: storageService.getDocumentos(),
          renovaciones: storageService.getItemsRenovacion(),
          descuentos: storageService.getDescuentos(),
          infracciones: storageService.getInfracciones(),
          liquidaciones: storageService.getLiquidaciones(),
          movimientosKardex: storageService.getMovimientosKardex(),
          ingresosStock: storageService.getIngresosStock(),
          config: storageService.getConfig()
        });
      },

      sincronizarConGoogleSheets: async () => {
        if (get().sincronizando) {
          return;
        }
        set({ sincronizando: true });
        try {
          await storageService.sincronizarConGoogleSheets();
          get().refrescarDesdeStorage();
        } finally {
          set({ sincronizando: false });
        }
      },

      guardarTrabajador: async (trabajador) => {
        await storageService.guardarTrabajador(trabajador);
        get().refrescarDesdeStorage();
      },

      eliminarTrabajador: async (codigo) => {
        await storageService.eliminarTrabajador(codigo);
        get().refrescarDesdeStorage();
      },

      guardarEPP: async (epp) => {
        await storageService.guardarEPP(epp);
        get().refrescarDesdeStorage();
      },

      guardarPlantilla: (plantilla) => {
        storageService.guardarPlantilla(plantilla);
        get().refrescarDesdeStorage();
      },

      guardarConfig: (nueva) => {
        storageService.guardarConfig(nueva);
        get().refrescarDesdeStorage();
      },

      restablecerDatosFabrica: () => {
        storageService.restablecerDatosFabrica();
        get().refrescarDesdeStorage();
      },

      registrarEntrega: async (entrega) => {
        const res = await storageService.registrarEntrega(entrega);
        get().refrescarDesdeStorage();
        return res;
      },

      registrarInspeccion: async (inspeccion) => {
        const res = await storageService.registrarInspeccion(inspeccion);
        get().refrescarDesdeStorage();
        return res;
      },

      eliminarInspeccion: async (idOrNumero) => {
        const res = await storageService.eliminarInspeccion(idOrNumero);
        get().refrescarDesdeStorage();
        return res;
      },

      registrarDescuento: async (descuento, reponerInmediato) => {
        const res = await storageService.registrarDescuento(descuento, reponerInmediato);
        get().refrescarDesdeStorage();
        return res;
      },

      registrarInfraccion: async (infraccion) => {
        const res = await storageService.registrarInfraccion(infraccion);
        get().refrescarDesdeStorage();
        return res;
      },

      registrarLiquidacion: async (liquidacion) => {
        const res = await storageService.registrarLiquidacion(liquidacion);
        get().refrescarDesdeStorage();
        return res;
      },

      actualizarEstadoLiquidacion: (id, nuevoEstado) => {
        storageService.actualizarEstadoLiquidacion(id, nuevoEstado);
        get().refrescarDesdeStorage();
      },

      eliminarLiquidacion: (id) => {
        storageService.eliminarLiquidacion(id);
        get().refrescarDesdeStorage();
      },

      registrarIngresoStock: async (ingreso) => {
        const res = await storageService.registrarIngresoStock(ingreso);
        get().refrescarDesdeStorage();
        return res;
      },

      // --- Flujos Parametrizados de Navegación ---
      iniciarNuevaEntrega: () => {
        set({
          trabajadorPreseleccionado: undefined,
          eppPreseleccionado: undefined,
          currentTab: 'nueva-entrega'
        });
      },

      iniciarEntregaParametrizada: (codTrabajador, codEPP) => {
        set({
          trabajadorPreseleccionado: codTrabajador,
          eppPreseleccionado: codEPP,
          currentTab: 'nueva-entrega'
        });
      },

      iniciarDescuentoParametrizado: (codTrabajador, codEPP, datos) => {
        set({
          trabajadorPreseleccionado: codTrabajador,
          eppPreseleccionado: codEPP,
          datosDescuentoPreseleccionados: datos || (codTrabajador ? { codigoTrabajador: codTrabajador, codigoEPP: codEPP } : null),
          currentTab: 'descuentos'
        });
      },

      iniciarInfraccionParametrizada: (codTrabajador, datos) => {
        set({
          trabajadorPreseleccionado: codTrabajador,
          datosInfraccionPreseleccionados: datos || (codTrabajador ? { codigoTrabajador: codTrabajador } : null),
          currentTab: 'infracciones'
        });
      },

      iniciarLiquidacionParametrizada: (codTrabajador, datos) => {
        set({
          trabajadorPreseleccionado: codTrabajador,
          datosLiquidacionPreseleccionados: datos || (codTrabajador ? { codigoTrabajador: codTrabajador } : null),
          currentTab: 'liquidaciones'
        });
      },

      colocarInfraccionDesdeInspeccion: (datos) => {
        set({
          datosInfraccionPreseleccionados: datos,
          trabajadorPreseleccionado: datos.codigoTrabajador,
          currentTab: 'infracciones'
        });
      },

      // --- Helpers y Consultas ---
      getTrabajadoresPorEmpresa: (empresaId) => {
        const trs = get().trabajadores;
        if (!empresaId || empresaId === 'TODAS') return trs;
        return trs.filter((t) => t.empresaId === empresaId || t.empresa === empresaId);
      },

      getEntregasPorEmpresa: (empresaId) => {
        const ents = get().entregas;
        if (!empresaId || empresaId === 'TODAS') return ents;
        return ents.filter((e) => e.empresaId === empresaId);
      },

      getTrabajadorPorCodigo: (codigo) => {
        return get().trabajadores.find((t) => t.codigo === codigo);
      },

      getEPPPorCodigo: (codigo) => {
        return get().catalogoEPP.find((e) => e.codigo === codigo);
      },

      getEntregasVencidas: () => {
        return get().renovaciones.filter((r) => r.estadoRenovacion === 'Vencido');
      },

      getEntregasProximas: () => {
        return get().renovaciones.filter((r) => r.estadoRenovacion === 'Próximo a vencer');
      }
    }),
    {
      name: 'epp-store',
      version: 1,
      // Solo persistir configuraciones de UI y filtros en zustand local para no interferir con la sincronización directa de datos
      partialize: (state) => ({
        empresaFiltro: state.empresaFiltro,
        currentTab: state.currentTab,
        sidebarAbierto: state.sidebarAbierto
      })
    }
  )
);

// Suscripción automática: cada vez que storageService notifique cambios, el store se actualiza de inmediato
storageService.suscribir(() => {
  useEPPStore.getState().refrescarDesdeStorage();
});
