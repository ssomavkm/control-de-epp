import { describe, it, expect } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';

describe('App Component', () => {
  it('renders without crashing and mounts the header and dashboard', () => {
    const { container } = render(<App />);
    expect(container).toBeTruthy();
  });

  it('permite alternar el estado del menú al pulsar el botón de navegación', () => {
    render(<App />);

    const toggleBtn = screen.getByLabelText(/Toggle Navigation/i);
    expect(toggleBtn).toBeInTheDocument();

    // Inicialmente el sidebar está visible
    expect(screen.getAllByText('Operaciones EPP').length).toBeGreaterThan(0);

    // Al pulsar el botón, el menú se contrae
    fireEvent.click(toggleBtn);
    expect(screen.queryByText('Operaciones EPP')).not.toBeInTheDocument();

    // Al pulsar nuevamente, el menú se vuelve a abrir
    fireEvent.click(toggleBtn);
    expect(screen.getAllByText('Operaciones EPP').length).toBeGreaterThan(0);
  });
});
