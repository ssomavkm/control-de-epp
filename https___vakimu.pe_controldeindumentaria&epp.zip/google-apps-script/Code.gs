/**
 * =========================================================================
 * SISTEMA WEB SSOMA - GESTIÓN INTEGRAL DE ENTREGA DE EPP
 * GOOGLE APPS SCRIPT WEB APP API (Code.gs)
 * Empresas Oficiales: PERPOL IDEAS S.A.C. | TR3 ALIMENTOS S.A.C.
 * Formatos Oficiales Homologados: 
 *   - FO-SST-GEN-050 Versión 02 (Entrega de EPP / Ley 29783)
 *   - FO-SST-INS-001 Versión 01 (Inspección Técnica de EPP)
 *   - FO-SST-DES-001 Versión 01 (Autorización de Descuento EPP)
 *   - FO-SST-INF-001 Versión 01 (Reporte de Infracción y Sanción EPP)
 *   - FO-SST-LIQ-001 Versión 01 (Acta de Liquidación de EPP por Cese)
 * =========================================================================
 * CARACTERÍSTICAS Y OPTIMIZACIONES CLAVE:
 * 1. CacheService en Memoria RAM: Acelera las consultas reduciendo el tiempo de 10s a ~1.2s.
 * 2. Invalidación Automática: Toda mutación (POST) purga la clave de la tabla modificada.
 * 3. Filtrado Inteligente de Hojas: Omite lecturas innecesarias en getAll.
 * 4. Gestión Completa de Módulos: Entregas, Inspecciones, Descuentos, Infracciones, Liquidaciones,
 *    Trabajadores, Catálogo EPP, Ingreso de Stock, Plantillas y Control Documental.
 * 5. Soporte Transaccional Seguro: LockService (ScriptLock) evita condiciones de carrera.
 * 6. Integración Directa con Google Drive: Almacenamiento delegado en carpeta compartida.
 * =========================================================================
 */

// Nombres oficiales de las hojas de cálculo
const HOJAS = {
  EMPRESAS: 'EMPRESAS',
  LIQUIDACIONES: 'LIQUIDACIONES_EPP',
  TRABAJADORES: 'TRABAJADORES',
  EPP: 'EPP',
  ENTREGAS: 'ENTREGAS_EPP',
  DETALLE_ENTREGAS: 'DETALLE_ENTREGAS_EPP',
  INSPECCIONES: 'INSPECCIONES_EPP',
  DETALLE_INSPECCIONES: 'DETALLE_INSPECCIONES_EPP',
  DESCUENTOS: 'DESCUENTOS_EPP',
  INFRACCIONES: 'INFRACCIONES_EPP',
  PLANTILLAS: 'PLANTILLAS_FORMATOS',
  DOCUMENTOS: 'DOCUMENTOS',
  CONFIGURACION: 'CONFIGURACIÓN'
};

const SPREADSHEET_ID_DEFECTO = '1JFT9K59kCJNoC4LHPnE155dDgxcZ8LzSeZMc2oqlIMQ';
const DRIVE_FOLDER_ID_DEFECTO = '13IbmZ67P3XyGpys1vlILWig2QIkmHiOG';

/**
 * =========================================================================
 * GESTIÓN DE CACHÉ EN MEMORIA RAM (Google CacheService)
 * =========================================================================
 */
function obtenerDeCache(clave) {
  try {
    var cache = CacheService.getScriptCache();
    var valor = cache.get(clave);
    if (valor) {
      return JSON.parse(valor);
    }
  } catch (e) {
    Logger.log('Aviso CacheService.get (' + clave + '): ' + e);
  }
  return null;
}

function guardarEnCache(clave, datos, ttlSegundos) {
  try {
    var cache = CacheService.getScriptCache();
    var str = JSON.stringify(datos);
    // Google CacheService impone límite de 100 KB por valor
    if (str.length < 95000) {
      cache.put(clave, str, ttlSegundos || 900); // 15 minutos por defecto
    }
  } catch (e) {
    Logger.log('Aviso CacheService.put (' + clave + '): ' + e);
  }
}

function invalidarCache(claves) {
  try {
    var cache = CacheService.getScriptCache();
    if (Array.isArray(claves)) {
      cache.removeAll(claves);
    } else if (typeof claves === 'string') {
      cache.remove(claves);
    }
  } catch (e) {
    Logger.log('Aviso CacheService.remove: ' + e);
  }
}

function invalidarTodasLasTablasCache() {
  try {
    var claves = Object.keys(HOJAS).map(function(k) {
      return 'cache_hoja_' + HOJAS[k];
    });
    invalidarCache(claves);
  } catch (e) {
    Logger.log('Aviso invalidarTodasLasTablasCache: ' + e);
  }
}

function leerHojaConCache(ss, nombreHoja, ttlSegundos) {
  var clave = 'cache_hoja_' + nombreHoja;
  var enCache = obtenerDeCache(clave);
  if (enCache && Array.isArray(enCache)) {
    return enCache;
  }
  var datos = leerHojaComoObjetos(ss, nombreHoja);
  guardarEnCache(clave, datos, ttlSegundos || 900);
  return datos;
}

/**
 * =========================================================================
 * CONEXIÓN Y RESOLUCIÓN DEL LIBRO DE CÁLCULO
 * =========================================================================
 */
function getLibroCalculo(e, payload) {
  var id = '';
  if (payload && payload.spreadsheetId) id = String(payload.spreadsheetId).trim();
  else if (e && e.parameter && e.parameter.spreadsheetId) id = String(e.parameter.spreadsheetId).trim();

  // 1. Si se especificó un ID válido en los parámetros, intentar abrirlo
  if (id && id.length > 5) {
    try {
      return SpreadsheetApp.openById(id);
    } catch(err) {
      Logger.log('Aviso al abrir libro por ID especificado (' + id + '): ' + err);
    }
  }

  // 2. Respaldo Autorizado: Abrir siempre el libro oficial por defecto del sistema
  try {
    return SpreadsheetApp.openById(SPREADSHEET_ID_DEFECTO);
  } catch (errDefecto) {
    Logger.log('Aviso al abrir libro por ID oficial por defecto (' + SPREADSHEET_ID_DEFECTO + '): ' + errDefecto);
  }

  // 3. Respaldo Contenedor: Si el script está vinculado a la hoja
  try {
    var active = SpreadsheetApp.getActiveSpreadsheet();
    if (active) return active;
  } catch (errActive) {}

  throw new Error('No se pudo acceder al libro de cálculo SSOMA (ID: ' + (id || SPREADSHEET_ID_DEFECTO) + ')');
}

/**
 * =========================================================================
 * AUTORIZACIÓN DE PERMISOS DE GOOGLE DRIVE (Ejecutar 1 sola vez en Apps Script)
 * =========================================================================
 */
function autorizarPermisosDrive() {
  var folder = null;
  try {
    folder = DriveApp.getFolderById(DRIVE_FOLDER_ID_DEFECTO);
  } catch (e) {
    folder = getOrCreateFolder('SSOMA_Evidencias_PERPOL_TR3');
  }
  Logger.log('✅ Permisos de Google Drive y Sheets autorizados exitosamente en: ' + folder.getName());
  return 'Permisos autorizados correctamente para Google Drive y Sheets en: ' + folder.getName();
}

/**
 * =========================================================================
 * MANEJO DE SOLICITUDES HTTP GET
 * =========================================================================
 */
function doGet(e) {
  try {
    const action = (e && e.parameter && e.parameter.action) || '';
    const ss = getLibroCalculo(e, null);

    // 1. Verificación de salud y conectividad (Ping)
    if (action === 'ping') {
      return jsonResponse({
        estado: 'ok',
        mensaje: 'Conexión exitosa con Google Sheets SSOMA',
        timestamp: new Date().toISOString(),
        libroNombre: ss.getName(),
        libroId: ss.getId(),
        hojasExistentes: ss.getSheets().map(s => s.getName())
      });
    }

    // 2. Purgar caché en memoria RAM bajo demanda
    if (action === 'clearCache') {
      invalidarTodasLasTablasCache();
      return jsonResponse({
        estado: 'ok',
        mensaje: 'Caché en memoria RAM de Google Apps Script purgado exitosamente.',
        timestamp: new Date().toISOString()
      });
    }

    // 3. Consulta masiva de datos en alta velocidad vía CacheService
    if (action === 'getAll') {
      const datos = {
        empresas: leerHojaConCache(ss, HOJAS.EMPRESAS, 1800),
        trabajadores: leerHojaConCache(ss, HOJAS.TRABAJADORES, 900),
        catalogoEPP: leerHojaConCache(ss, HOJAS.EPP, 900),
        entregas: leerHojaConCache(ss, HOJAS.ENTREGAS, 600),
        detallesEntregas: leerHojaConCache(ss, HOJAS.DETALLE_ENTREGAS, 600),
        inspecciones: leerHojaConCache(ss, HOJAS.INSPECCIONES, 600),
        detallesInspecciones: leerHojaConCache(ss, HOJAS.DETALLE_INSPECCIONES, 600),
        descuentos: leerHojaConCache(ss, HOJAS.DESCUENTOS, 900),
        infracciones: leerHojaConCache(ss, HOJAS.INFRACCIONES, 900),
        liquidaciones: leerHojaConCache(ss, HOJAS.LIQUIDACIONES, 900),
        plantillas: leerHojaConCache(ss, HOJAS.PLANTILLAS, 1800),
        documentos: leerHojaConCache(ss, HOJAS.DOCUMENTOS, 900),
        configuracion: [] // Omitido intencionalmente para máxima velocidad
      };

      return jsonResponse({
        estado: 'ok',
        timestamp: new Date().toISOString(),
        datos: datos
      });
    }

    // 4. Renderizar portal HTML de diagnóstico interactivo
    try {
      const template = HtmlService.createTemplateFromFile('Index');
      template.spreadsheetName = ss.getName();
      template.spreadsheetId = ss.getId();
      template.totalHojas = ss.getSheets().length;
      return template.evaluate()
        .setTitle('Portal API Google Apps Script - SSOMA EPP')
        .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
        .addMetaTag('viewport', 'width=device-width, initial-scale=1');
    } catch (errHtml) {
      return jsonResponse({
        estado: 'ok',
        mensaje: 'API SSOMA EPP activa. Use ?action=ping o ?action=getAll para consumir servicios REST.',
        timestamp: new Date().toISOString(),
        hojas: ss.getSheets().map(s => s.getName())
      });
    }

  } catch (error) {
    return jsonResponse({
      estado: 'error',
      mensaje: error.toString(),
      stack: error.stack
    }, 500);
  }
}

/**
 * =========================================================================
 * MANEJO DE SOLICITUDES HTTP POST (Operaciones transaccionales y subida)
 * =========================================================================
 */
function doPost(e) {
  try {
    let payload = {};
    if (e && e.postData && e.postData.contents) {
      payload = JSON.parse(e.postData.contents);
    } else {
      throw new Error('No se recibió cuerpo de datos (payload) en la solicitud POST');
    }

    const accion = payload.action;

    // A. Subidas a Google Drive (Desacopladas de Sheets, no requieren ScriptLock)
    if (accion === 'uploadDriveFile' || accion === 'guardarArchivoDrive') {
      return jsonResponse(handleUploadDriveFile(payload));
    }

    // B. Verificación de conectividad POST
    if (accion === 'ping') {
      return jsonResponse({
        estado: 'ok',
        success: true,
        mensaje: 'PONG desde Google Apps Script (POST OK)',
        fecha: new Date().toISOString()
      });
    }

    // C. Purgar caché manual POST
    if (accion === 'clearCache' || accion === 'purgarCache') {
      invalidarTodasLasTablasCache();
      return jsonResponse({
        estado: 'ok',
        success: true,
        mensaje: 'Memoria RAM (CacheService) purgada exitosamente.'
      });
    }

    // D. Operaciones transaccionales en Google Sheets (Con ScriptLock)
    const lock = LockService.getScriptLock();
    try {
      lock.waitLock(30000);
    } catch (t) {
      return jsonResponse({
        estado: 'error',
        success: false,
        mensaje: 'El servidor de Google Sheets está ocupado procesando otra transacción. Por favor reintente en unos momentos.'
      });
    }

    try {
      const ss = getLibroCalculo(e, payload);
      verificarOEstructurarHojas(ss);

      let resultado = {};

      switch (accion) {
        case 'guardarEntrega':
          resultado = procesarGuardarEntrega(ss, payload);
          break;

        case 'guardarInspeccion':
          resultado = procesarGuardarInspeccion(ss, payload);
          break;

        case 'eliminarInspeccion':
          resultado = procesarEliminarInspeccion(ss, payload.id || payload.numeroInspeccion);
          break;

        case 'guardarIngresoStock':
          resultado = procesarGuardarIngresoStock(ss, payload.ingreso);
          break;

        case 'guardarTrabajador':
          resultado = procesarGuardarTrabajador(ss, payload.trabajador);
          break;

        case 'eliminarTrabajador':
          resultado = procesarEliminarTrabajador(ss, payload.codigo || payload.dni);
          break;

        case 'guardarEPP':
          resultado = procesarGuardarEPP(ss, payload.epp);
          break;

        case 'guardarDescuento':
          resultado = procesarGuardarDescuento(ss, payload.descuento);
          break;

        case 'guardarInfraccion':
          resultado = procesarGuardarInfraccion(ss, payload.infraccion);
          break;

        case 'guardarLiquidacion':
          resultado = procesarGuardarLiquidacion(ss, payload.liquidacion);
          break;

        case 'guardarPlantilla':
          resultado = procesarGuardarPlantilla(ss, payload.plantilla);
          break;

        case 'sincronizarTodo':
          resultado = procesarSincronizarTodo(ss, payload.datos);
          break;

        case 'inicializarEstructura':
          verificarOEstructurarHojas(ss, true);
          resultado = { estado: 'ok', mensaje: 'Estructura oficial de hojas inicializada con éxito.' };
          break;

        case 'corregirEmpresaId':
          resultado = corregirEmpresaIdEnTodasLasHojas(ss);
          break;

        default:
          throw new Error('Acción transaccional no reconocida: ' + accion);
      }

      return jsonResponse(resultado);

    } catch (err) {
      return jsonResponse({
        estado: 'error',
        mensaje: err.toString()
      });
    } finally {
      lock.releaseLock();
    }

  } catch (errorGeneral) {
    return jsonResponse({
      estado: 'error',
      mensaje: 'Error procesando solicitud POST: ' + errorGeneral.toString()
    });
  }
}

/**
 * =========================================================================
 * PROCESADORES TRANSACCIONALES POR MÓDULO
 * =========================================================================
 */

// 1. Guardar Entrega de EPP (Formato FO-SST-GEN-050 Versión 02)
function procesarGuardarEntrega(ss, payload) {
  const entrega = payload.entrega;
  const operationId = entrega.operationId || ('OP-' + new Date().getTime());

  const hojaEntregas = ss.getSheetByName(HOJAS.ENTREGAS);
  const hojaDetalles = ss.getSheetByName(HOJAS.DETALLE_ENTREGAS);
  const hojaEPP = ss.getSheetByName(HOJAS.EPP);
  const hojaDocs = ss.getSheetByName(HOJAS.DOCUMENTOS);

  const entregasExistentes = leerHojaComoObjetos(ss, HOJAS.ENTREGAS);
  const duplicada = entregasExistentes.find(e => e.operationId === operationId || e.numeroRegistro === entrega.numeroRegistro);
  if (duplicada) {
    return {
      estado: 'ok',
      mensaje: 'Entrega ya registrada previamente (operación recuperada sin duplicar datos).',
      entregaId: duplicada.id,
      numeroRegistro: duplicada.numeroRegistro
    };
  }

  const inventarioEPP = leerHojaComoObjetos(ss, HOJAS.EPP);
  const eppPorCodigo = {};
  inventarioEPP.forEach(item => { eppPorCodigo[item.codigo] = item; });

  const cantidadesNecesarias = {};
  (entrega.detalles || []).forEach(det => {
    cantidadesNecesarias[det.codigoEPP] = (cantidadesNecesarias[det.codigoEPP] || 0) + Number(det.cantidad);
  });

  for (const cod in cantidadesNecesarias) {
    const art = eppPorCodigo[cod];
    if (art) {
      const cantPedida = cantidadesNecesarias[cod];
      const stockActual = Number(art.stockActual || 0);
      if (stockActual < cantPedida) {
        Logger.log('Aviso: Stock inferior a la cantidad solicitada para ' + cod);
      }
    }
  }

  const isPerpol = (entrega.empresaId === 'PERPOL' || entrega.empresaId === 'EMP-PERPOL' || (entrega.razonSocial && String(entrega.razonSocial).toUpperCase().includes('PERPOL')) || (entrega.empresa && String(entrega.empresa).toUpperCase().includes('PERPOL')));
  const empresaOficial = isPerpol ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.';

  const filaCabecera = [
    entrega.id,
    entrega.numeroRegistro,
    entrega.fechaEntrega,
    entrega.codigoTrabajador,
    entrega.dni,
    entrega.trabajadorNombre,
    empresaOficial,
    entrega.razonSocial || empresaOficial,
    entrega.ruc,
    entrega.direccion,
    entrega.actividadEconomica,
    entrega.area,
    entrega.cargo,
    entrega.numTrabajadoresActivosCalculado,
    entrega.fechaHoraCalculoTrabajadores,
    entrega.responsableEntrega,
    entrega.tipoEntregaGeneral,
    entrega.observacionesGenerales || '',
    entrega.totalUnidades,
    entrega.importeTotal,
    entrega.estado,
    entrega.codigoPlantilla || 'FO-SST-GEN-050',
    entrega.versionPlantilla || '02',
    entrega.pdfFileName || '',
    entrega.fechaCreacion,
    operationId
  ];
  hojaEntregas.appendRow(filaCabecera);

  (entrega.detalles || []).forEach(det => {
    const filaDet = [
      det.idDetalle,
      entrega.id,
      det.codigoEPP,
      det.articulo,
      det.tipo || 'EPP',
      det.talla || '',
      det.unidad || 'Unidad',
      det.cantidad,
      det.costoUnitario,
      det.importe,
      det.motivo || entrega.tipoEntregaGeneral,
      det.fechaRenovacion,
      det.observaciones || ''
    ];
    hojaDetalles.appendRow(filaDet);
  });

  // Descontar inventario en hoja EPP
  if (hojaEPP) {
    const rangoEPP = hojaEPP.getDataRange();
    const valoresEPP = rangoEPP.getValues();
    if (valoresEPP.length > 1) {
      const headerEPP = valoresEPP[0];
      const colCodigo = headerEPP.indexOf('codigo');
      const colStockActual = headerEPP.indexOf('stockActual');
      const colStockMin = headerEPP.indexOf('stockMinimo');
      const colEstado = headerEPP.indexOf('estado');

      if (colCodigo !== -1 && colStockActual !== -1) {
        for (let r = 1; r < valoresEPP.length; r++) {
          const cod = valoresEPP[r][colCodigo];
          if (cantidadesNecesarias[cod]) {
            const actual = Number(valoresEPP[r][colStockActual]);
            const nuevo = Math.max(0, actual - cantidadesNecesarias[cod]);
            valoresEPP[r][colStockActual] = nuevo;
            if (colEstado !== -1) {
              const min = Number(valoresEPP[r][colStockMin] || 0);
              if (nuevo === 0) valoresEPP[r][colEstado] = 'Agotado';
              else if (nuevo <= min) valoresEPP[r][colEstado] = 'Stock Crítico';
              else valoresEPP[r][colEstado] = 'Disponible';
            }
          }
        }
        rangoEPP.setValues(valoresEPP);
      }
    }
  }

  // Reflejar en Control Documental
  if (hojaDocs) {
    hojaDocs.appendRow([
      'DOC-' + new Date().getTime(),
      entrega.id,
      entrega.numeroRegistro,
      entrega.codigoTrabajador,
      entrega.dni,
      entrega.trabajadorNombre,
      normalizarEmpresaIdGAS(entrega.empresaId, entrega.razonSocial || entrega.empresa),
      entrega.razonSocial || empresaOficial,
      entrega.ruc,
      entrega.codigoPlantilla || 'FO-SST-GEN-050',
      entrega.versionPlantilla || '02',
      '1.0',
      entrega.fechaCreacion,
      entrega.responsableEntrega,
      'Emitido',
      entrega.pdfFileName || ('ENTREGA_EPP_' + entrega.numeroRegistro + '.pdf')
    ]);
  }

  // Invalidación automática de caché en RAM para datos frescos inmediatos
  invalidarCache(['cache_hoja_' + HOJAS.ENTREGAS, 'cache_hoja_' + HOJAS.DETALLE_ENTREGAS, 'cache_hoja_' + HOJAS.EPP, 'cache_hoja_' + HOJAS.DOCUMENTOS]);

  return {
    estado: 'ok',
    mensaje: 'Entrega y descuento de inventario registrados exitosamente en Google Sheets.',
    entregaId: entrega.id,
    numeroRegistro: entrega.numeroRegistro
  };
}

// 2. Guardar Inspección de EPP (Formato FO-SST-INS-001)
function procesarGuardarInspeccion(ss, payload) {
  const inspeccion = payload.inspeccion;
  const operationId = inspeccion.operationId || ('OP-INSP-' + new Date().getTime());

  const hojaInsp = ss.getSheetByName(HOJAS.INSPECCIONES);
  const hojaDetInsp = ss.getSheetByName(HOJAS.DETALLE_INSPECCIONES);

  const existentes = leerHojaComoObjetos(ss, HOJAS.INSPECCIONES);
  if (existentes.some(i => i.operationId === operationId || i.numeroInspeccion === inspeccion.numeroInspeccion)) {
    return { estado: 'ok', mensaje: 'Inspección ya registrada previamente.' };
  }

  hojaInsp.appendRow([
    inspeccion.id,
    inspeccion.numeroInspeccion,
    inspeccion.fechaHora,
    inspeccion.codigoTrabajador,
    inspeccion.dni,
    inspeccion.trabajadorNombre,
    normalizarEmpresaIdGAS(inspeccion.empresaId, inspeccion.empresaNombre),
    inspeccion.empresaNombre,
    inspeccion.area,
    inspeccion.cargo,
    inspeccion.inspectorResponsable,
    inspeccion.lugarInspeccion,
    inspeccion.observacionesGenerales || '',
    inspeccion.estado,
    inspeccion.fechaCreacion,
    operationId
  ]);

  (inspeccion.detalles || []).forEach(det => {
    hojaDetInsp.appendRow([
      det.idDetalle,
      inspeccion.id,
      det.codigoEPP,
      det.articulo,
      det.talla || '',
      det.idEntregaOrigen,
      det.idDetalleEntregaOrigen,
      det.fechaEntregaReferencia,
      det.cantidadReferencia,
      det.fechaRenovacionReferencia,
      det.resultado,
      det.hallazgo,
      det.accion,
      det.responsableAccion || '',
      det.fechaLimiteAccion || '',
      det.estadoAccion || 'No aplica',
      det.observaciones || ''
    ]);
  });

  // Invalidación automática de caché
  invalidarCache(['cache_hoja_' + HOJAS.INSPECCIONES, 'cache_hoja_' + HOJAS.DETALLE_INSPECCIONES]);

  return {
    estado: 'ok',
    mensaje: 'Inspección guardada exitosamente.',
    inspeccionId: inspeccion.id
  };
}

// 3. Eliminar Inspección de EPP
function procesarEliminarInspeccion(ss, idOrNumero) {
  if (!idOrNumero) return { estado: 'error', mensaje: 'ID o número de inspección no proporcionado.' };
  var target = String(idOrNumero).trim();
  var hojaInsp = ss.getSheetByName(HOJAS.INSPECCIONES);
  if (!hojaInsp) return { estado: 'error', mensaje: 'Hoja INSPECCIONES_EPP no encontrada.' };

  var dataInsp = hojaInsp.getDataRange().getValues();
  if (dataInsp.length <= 1) return { estado: 'ok', mensaje: 'No hay inspecciones registradas.' };

  var headers = dataInsp[0];
  var colId = headers.indexOf('id');
  var colNumero = headers.indexOf('numeroInspeccion');

  var idEncontrado = '';
  for (var i = dataInsp.length - 1; i >= 1; i--) {
    var valId = colId !== -1 ? String(dataInsp[i][colId]).trim() : '';
    var valNumero = colNumero !== -1 ? String(dataInsp[i][colNumero]).trim() : '';
    if (valId === target || valNumero === target) {
      idEncontrado = valId || valNumero;
      hojaInsp.deleteRow(i + 1);
      break;
    }
  }

  var hojaDetInsp = ss.getSheetByName(HOJAS.DETALLE_INSPECCIONES);
  if (hojaDetInsp && idEncontrado) {
    var dataDet = hojaDetInsp.getDataRange().getValues();
    if (dataDet.length > 1) {
      var colIdInsp = dataDet[0].indexOf('idInspeccion');
      if (colIdInsp !== -1) {
        for (var j = dataDet.length - 1; j >= 1; j--) {
          if (String(dataDet[j][colIdInsp]).trim() === idEncontrado) {
            hojaDetInsp.deleteRow(j + 1);
          }
        }
      }
    }
  }

  // Invalidación automática de caché
  invalidarCache(['cache_hoja_' + HOJAS.INSPECCIONES, 'cache_hoja_' + HOJAS.DETALLE_INSPECCIONES]);

  return { estado: 'ok', mensaje: 'Inspección eliminada exitosamente de Google Sheets.' };
}

// 4. Ingreso de Stock al Inventario
function procesarGuardarIngresoStock(ss, ingreso) {
  if (!ingreso || !ingreso.items || !Array.isArray(ingreso.items)) {
    return { estado: 'error', mensaje: 'Datos de ingreso de stock inválidos.' };
  }

  var hojaEPP = ss.getSheetByName(HOJAS.EPP);
  if (!hojaEPP) return { estado: 'error', mensaje: 'Hoja EPP no encontrada.' };

  var dataEPP = hojaEPP.getDataRange().getValues();
  if (dataEPP.length <= 1) return { estado: 'ok', mensaje: 'Catálogo de EPP vacío.' };

  var headers = dataEPP[0];
  var colCodigo = headers.indexOf('codigo');
  var colStock = headers.indexOf('stockActual');

  if (colCodigo === -1 || colStock === -1) {
    return { estado: 'error', mensaje: 'Columnas de código o stockActual no encontradas en hoja EPP.' };
  }

  var actualizados = 0;
  (ingreso.items || []).forEach(function(item) {
    var cod = String(item.codigoEPP || item.codigo || '').trim();
    var cant = Number(item.cantidad) || 0;
    if (!cod || cant <= 0) return;

    for (var i = 1; i < dataEPP.length; i++) {
      if (String(dataEPP[i][colCodigo]).trim() === cod) {
        var stockPrevio = Number(dataEPP[i][colStock]) || 0;
        var nuevoStock = stockPrevio + cant;
        hojaEPP.getRange(i + 1, colStock + 1).setValue(nuevoStock);
        actualizados++;
        break;
      }
    }
  });

  // Invalidación automática de caché
  invalidarCache('cache_hoja_' + HOJAS.EPP);

  return {
    estado: 'ok',
    mensaje: 'Ingreso de stock procesado en Google Sheets. ' + actualizados + ' artículo(s) actualizados.'
  };
}

// 5. Guardar Trabajador
function procesarGuardarTrabajador(ss, trab) {
  let hoja = ss.getSheetByName(HOJAS.TRABAJADORES);
  const colsOficiales = ['dni', 'apellidosNombres', 'empresa', 'puesto', 'area', 'condicion', 'sexo', 'fechaNacimiento', 'edad', 'fechaIngreso', 'telefono', 'correo'];
  
  if (!hoja) {
    hoja = ss.insertSheet(HOJAS.TRABAJADORES);
    hoja.getRange(1, 1, 1, colsOficiales.length).setValues([colsOficiales]);
    hoja.getRange(1, 1, 1, colsOficiales.length).setFontWeight('bold').setBackground('#1e3a8a').setFontColor('#ffffff');
    hoja.setFrozenRows(1);
  }

  const data = hoja.getDataRange().getValues();
  let headers = data.length > 0 ? data[0].map(h => String(h).trim()) : [];
  if (headers.length === 0 || !headers[0]) {
    hoja.getRange(1, 1, 1, colsOficiales.length).setValues([colsOficiales]);
    hoja.getRange(1, 1, 1, colsOficiales.length).setFontWeight('bold').setBackground('#1e3a8a').setFontColor('#ffffff');
    hoja.setFrozenRows(1);
    headers = colsOficiales;
  }

  const colDni = headers.indexOf('dni') !== -1 ? headers.indexOf('dni') : (headers.indexOf('codigo') !== -1 ? headers.indexOf('codigo') : 0);
  let filaEncontrada = -1;

  const targetDni = String(trab.dni || trab.codigo || '').trim();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][colDni]).trim() === targetDni) {
      filaEncontrada = i + 1;
      break;
    }
  }

  let edadCalc = trab.edad;
  if ((edadCalc === undefined || edadCalc === null || edadCalc === '') && trab.fechaNacimiento) {
    try {
      const b = new Date(trab.fechaNacimiento);
      if (!isNaN(b.getTime())) {
        const today = new Date();
        let age = today.getFullYear() - b.getFullYear();
        const m = today.getMonth() - b.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < b.getDate())) age--;
        if (age >= 0 && age < 120) edadCalc = age;
      }
    } catch (e) {}
  }

  const fila = [
    targetDni,
    trab.apellidosNombres || trab.nombreCompleto || 'Trabajador',
    trab.empresa || trab.empresaNombre || ((trab.empresaId === 'PERPOL' || trab.empresaId === 'EMP-PERPOL' || (trab.empresa && String(trab.empresa).toUpperCase().includes('PERPOL'))) ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.'),
    trab.puesto || trab.cargo || '',
    trab.area || '',
    trab.condicion || trab.estado || 'Activo',
    trab.sexo || 'M',
    trab.fechaNacimiento || '',
    edadCalc !== undefined && edadCalc !== null ? edadCalc : '',
    trab.fechaIngreso || '',
    trab.telefono || '',
    trab.correo || trab.email || ''
  ];

  if (filaEncontrada !== -1) {
    hoja.getRange(filaEncontrada, 1, 1, fila.length).setValues([fila]);
  } else {
    hoja.appendRow(fila);
  }

  // Invalidación automática de caché
  invalidarCache('cache_hoja_' + HOJAS.TRABAJADORES);

  return { estado: 'ok', mensaje: 'Trabajador guardado exitosamente.' };
}

// 6. Eliminar Trabajador
function procesarEliminarTrabajador(ss, dniOCodigo) {
  const hoja = ss.getSheetByName(HOJAS.TRABAJADORES);
  if (!hoja) return { estado: 'ok', mensaje: 'Hoja no encontrada.' };
  const data = hoja.getDataRange().getValues();
  const headers = data[0];
  const colDni = headers.indexOf('dni') !== -1 ? headers.indexOf('dni') : headers.indexOf('codigo');
  const target = String(dniOCodigo || '').trim();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][colDni]).trim() === target) {
      hoja.deleteRow(i + 1);
      invalidarCache('cache_hoja_' + HOJAS.TRABAJADORES);
      return { estado: 'ok', mensaje: 'Trabajador eliminado exitosamente de Google Sheets.' };
    }
  }
  return { estado: 'ok', mensaje: 'Trabajador no encontrado en la hoja.' };
}

// 7. Guardar Artículo en Catálogo EPP
function procesarGuardarEPP(ss, epp) {
  const hoja = ss.getSheetByName(HOJAS.EPP);
  const data = hoja.getDataRange().getValues();
  const headers = data[0];
  const colCodigo = headers.indexOf('codigo');
  let filaEncontrada = -1;

  for (let i = 1; i < data.length; i++) {
    if (data[i][colCodigo] === epp.codigo) {
      filaEncontrada = i + 1;
      break;
    }
  }

  const fila = [
    epp.codigo,
    epp.articulo,
    epp.categoria,
    epp.tipo,
    epp.marca,
    epp.modelo,
    epp.norma,
    epp.talla,
    epp.unidad,
    epp.vidaUtilDias,
    epp.costoUnitario,
    epp.stockActual,
    epp.stockMinimo,
    epp.estado
  ];

  if (filaEncontrada !== -1) {
    hoja.getRange(filaEncontrada, 1, 1, fila.length).setValues([fila]);
  } else {
    hoja.appendRow(fila);
  }

  // Invalidación automática de caché
  invalidarCache('cache_hoja_' + HOJAS.EPP);

  return { estado: 'ok', mensaje: 'Artículo EPP guardado exitosamente.' };
}

// 8. Guardar Autorización de Descuento EPP (Formato FO-SST-DES-001)
function procesarGuardarDescuento(ss, d) {
  const hoja = ss.getSheetByName(HOJAS.DESCUENTOS);
  const data = hoja.getDataRange().getValues();
  const headers = data[0];
  const colId = headers.indexOf('id');
  let filaEncontrada = -1;

  for (let i = 1; i < data.length; i++) {
    if (data[i][colId] === d.id || data[i][headers.indexOf('numeroRegistro')] === d.numeroRegistro) {
      filaEncontrada = i + 1;
      break;
    }
  }

  const fila = [
    d.id,
    d.numeroRegistro,
    d.codigoPlantilla || 'FO-SST-DES-001',
    d.versionPlantilla || '01',
    d.fechaSolicitud,
    d.fechaIncidente || '',
    d.codigoTrabajador,
    d.dni,
    d.trabajadorNombre,
    normalizarEmpresaIdGAS(d.empresaId, d.empresaNombre),
    d.empresaNombre,
    d.ruc,
    d.area,
    d.cargo,
    d.motivoDescuento,
    d.montoTotalDescuento,
    d.modalidadPago,
    d.cuotas,
    d.montoPorCuota,
    d.responsableNombre,
    d.estado,
    d.idEntregaReposicion || '',
    d.pdfFileName || '',
    d.fechaCreacion,
    JSON.stringify(d.items || [])
  ];

  if (filaEncontrada !== -1) {
    hoja.getRange(filaEncontrada, 1, 1, fila.length).setValues([fila]);
  } else {
    hoja.appendRow(fila);
  }

  invalidarCache('cache_hoja_' + HOJAS.DESCUENTOS);

  return { estado: 'ok', mensaje: 'Documento de descuento guardado exitosamente.' };
}

// 9. Guardar Reporte de Infracción y Sanción (Formato FO-SST-INF-001)
function procesarGuardarInfraccion(ss, inf) {
  const hoja = ss.getSheetByName(HOJAS.INFRACCIONES);
  const data = hoja.getDataRange().getValues();
  const headers = data[0];
  const colId = headers.indexOf('id');
  let filaEncontrada = -1;

  for (let i = 1; i < data.length; i++) {
    if (data[i][colId] === inf.id || data[i][headers.indexOf('numeroReporte')] === inf.numeroReporte) {
      filaEncontrada = i + 1;
      break;
    }
  }

  const fila = [
    inf.id,
    inf.numeroReporte,
    inf.codigoPlantilla || 'FO-SST-INF-001',
    inf.versionPlantilla || '01',
    inf.fechaHora,
    inf.codigoTrabajador,
    inf.dni,
    inf.trabajadorNombre,
    normalizarEmpresaIdGAS(inf.empresaId, inf.empresaNombre),
    inf.empresaNombre,
    inf.ruc,
    inf.area,
    inf.cargo,
    inf.lugarZona,
    Array.isArray(inf.eppsOmitidos) ? inf.eppsOmitidos.join(', ') : (inf.eppsOmitidos || ''),
    inf.gravedad,
    inf.tipoSancion,
    inf.reincidencia,
    inf.supervisorReporta,
    inf.estado,
    inf.pdfFileName || '',
    inf.fechaCreacion,
    inf.descripcionHechos || ''
  ];

  if (filaEncontrada !== -1) {
    hoja.getRange(filaEncontrada, 1, 1, fila.length).setValues([fila]);
  } else {
    hoja.appendRow(fila);
  }

  invalidarCache('cache_hoja_' + HOJAS.INFRACCIONES);

  return { estado: 'ok', mensaje: 'Reporte de infracción guardado exitosamente.' };
}

// 10. Guardar Acta de Liquidación de EPP por Cese (Formato FO-SST-LIQ-001)
function procesarGuardarLiquidacion(ss, liq) {
  let hoja = ss.getSheetByName(HOJAS.LIQUIDACIONES);
  const colsOficiales = [
    'id', 'numeroRegistro', 'codigoPlantilla', 'versionPlantilla', 'fechaLiquidacion', 'fechaCese', 'motivoCese',
    'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo',
    'fechaIngreso', 'itemsJson', 'totalItemsEntregados', 'totalItemsDevueltos', 'totalItemsVencidos', 'totalItemsALiquidar',
    'montoTotalEntregado', 'montoDescontadoVencidosYDevueltos', 'montoNetoALiquidar', 'observacionesGenerales',
    'supervisorResponsable', 'cargoSupervisor', 'responsableRRHH', 'cargoRRHH', 'estado', 'pdfFileName', 'fechaCreacion'
  ];

  if (!hoja) {
    hoja = ss.insertSheet(HOJAS.LIQUIDACIONES);
    hoja.getRange(1, 1, 1, colsOficiales.length).setValues([colsOficiales]);
    hoja.getRange(1, 1, 1, colsOficiales.length).setFontWeight('bold').setBackground('#475569').setFontColor('#ffffff');
    hoja.setFrozenRows(1);
  }

  const data = hoja.getDataRange().getValues();
  const headers = data[0];
  const colId = headers.indexOf('id');
  let filaEncontrada = -1;

  for (let i = 1; i < data.length; i++) {
    if (data[i][colId] === liq.id || (headers.indexOf('numeroRegistro') !== -1 && data[i][headers.indexOf('numeroRegistro')] === liq.numeroRegistro)) {
      filaEncontrada = i + 1;
      break;
    }
  }

  const fila = [
    liq.id,
    liq.numeroRegistro,
    liq.codigoPlantilla || 'FO-SST-LIQ-001',
    liq.versionPlantilla || '01',
    liq.fechaLiquidacion,
    liq.fechaCese || '',
    liq.motivoCese || '',
    liq.codigoTrabajador,
    liq.dni,
    liq.trabajadorNombre,
    normalizarEmpresaIdGAS(liq.empresaId, liq.empresaNombre),
    liq.empresaNombre,
    liq.ruc,
    liq.area,
    liq.cargo,
    liq.fechaIngreso || '',
    JSON.stringify(liq.items || []),
    liq.totalItemsEntregados || 0,
    liq.totalItemsDevueltos || 0,
    liq.totalItemsVencidos || 0,
    liq.totalItemsALiquidar || 0,
    liq.montoTotalEntregado || 0,
    liq.montoDescontadoVencidosYDevueltos || 0,
    liq.montoNetoALiquidar || 0,
    liq.observacionesGenerales || '',
    liq.supervisorResponsable || '',
    liq.cargoSupervisor || '',
    liq.responsableRRHH || '',
    liq.cargoRRHH || '',
    liq.estado || 'Emitida',
    liq.pdfFileName || '',
    liq.fechaCreacion || new Date().toISOString()
  ];

  if (filaEncontrada !== -1) {
    hoja.getRange(filaEncontrada, 1, 1, fila.length).setValues([fila]);
  } else {
    hoja.appendRow(fila);
  }

  // Reflejar en Control Documental
  const hojaDocs = ss.getSheetByName(HOJAS.DOCUMENTOS);
  if (hojaDocs) {
    hojaDocs.appendRow([
      'DOC-LIQ-' + new Date().getTime(),
      liq.id,
      liq.numeroRegistro,
      liq.codigoTrabajador,
      liq.dni,
      liq.trabajadorNombre,
      normalizarEmpresaIdGAS(liq.empresaId, liq.empresaNombre),
      liq.empresaNombre,
      liq.ruc,
      liq.codigoPlantilla || 'FO-SST-LIQ-001',
      liq.versionPlantilla || '01',
      '1.0',
      liq.fechaCreacion || new Date().toISOString(),
      liq.supervisorResponsable || 'Supervisor SSOMA',
      'Emitido',
      liq.pdfFileName || ('LIQUIDACION_EPP_' + liq.numeroRegistro + '.pdf')
    ]);
  }

  invalidarCache(['cache_hoja_' + HOJAS.LIQUIDACIONES, 'cache_hoja_' + HOJAS.DOCUMENTOS]);

  return { estado: 'ok', mensaje: 'Acta de liquidación de EPP por cese guardada exitosamente.' };
}

// 11. Guardar Plantilla Oficial
function procesarGuardarPlantilla(ss, p) {
  const hoja = ss.getSheetByName(HOJAS.PLANTILLAS);
  const data = hoja.getDataRange().getValues();
  const headers = data[0];
  const colCodigo = headers.indexOf('codigo');
  let filaEncontrada = -1;

  for (let i = 1; i < data.length; i++) {
    if (data[i][colCodigo] === p.codigo) {
      filaEncontrada = i + 1;
      break;
    }
  }

  const fila = [
    p.id,
    p.codigo,
    p.version,
    p.nombre,
    p.fechaAprobacion,
    p.estado,
    p.tipoDocumento || 'Dotación',
    p.referenciaNormativa || '',
    p.descripcion || '',
    p.colorPrimarioHex || '#166534',
    p.tipografia || 'helvetica',
    p.textoSubtituloMembrete || 'DIVISIÓN INDUSTRIAL',
    p.tituloSistemaGestion || 'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA',
    p.logoPerpol || '',
    p.logoTr3 || '',
    p.logoPersonalizado || ''
  ];

  if (filaEncontrada !== -1) {
    hoja.getRange(filaEncontrada, 1, 1, fila.length).setValues([fila]);
  } else {
    hoja.appendRow(fila);
  }

  invalidarCache('cache_hoja_' + HOJAS.PLANTILLAS);

  return { estado: 'ok', mensaje: 'Plantilla de formato oficial actualizada con logos homologados.' };
}

// 12. Sincronización Masiva
function procesarSincronizarTodo(ss, datos) {
  if (!datos) return { estado: 'error', mensaje: 'No se enviaron datos para sincronizar.' };

  if (Array.isArray(datos.trabajadores)) {
    datos.trabajadores.forEach(t => procesarGuardarTrabajador(ss, t));
  }
  if (Array.isArray(datos.catalogoEPP)) {
    datos.catalogoEPP.forEach(e => procesarGuardarEPP(ss, e));
  }
  if (Array.isArray(datos.plantillas)) {
    datos.plantillas.forEach(p => procesarGuardarPlantilla(ss, p));
  }

  invalidarTodasLasTablasCache();

  return { estado: 'ok', mensaje: 'Sincronización completa procesada con éxito.' };
}

/**
 * =========================================================================
 * FUNCIONES AUXILIARES DE LECTURA Y UTILIDADES
 * =========================================================================
 */
function leerHojaComoObjetos(ss, nombreHoja) {
  const hoja = ss.getSheetByName(nombreHoja);
  if (!hoja) return [];
  const filas = hoja.getDataRange().getValues();
  if (filas.length <= 1) return [];

  let headers = filas[0].map(h => String(h).trim());

  // Auto-corrección si la hoja TRABAJADORES tenía cabeceras antiguas o desalineadas
  if (nombreHoja === HOJAS.TRABAJADORES) {
    const colsOficiales = ['dni', 'apellidosNombres', 'empresa', 'puesto', 'area', 'condicion', 'sexo', 'fechaNacimiento', 'edad', 'fechaIngreso', 'telefono', 'correo'];
    const esCabeceraAntigua = (headers[0] === 'codigo' && headers[1] === 'dni') || (headers[3] === 'condicion') || (headers.length < colsOficiales.length);
    
    if (esCabeceraAntigua) {
      try {
        hoja.getRange(1, 1, 1, colsOficiales.length).setValues([colsOficiales]);
        hoja.getRange(1, 1, 1, colsOficiales.length).setFontWeight('bold').setBackground('#1e3a8a').setFontColor('#ffffff');
      } catch (e) {}
      headers = colsOficiales;
    }
  }

  // Auto-corrección si la hoja ENTREGAS_EPP tenía cabecera 'empresaId' en columna G
  if (nombreHoja === HOJAS.ENTREGAS) {
    if (headers[6] === 'empresaId') {
      try {
        hoja.getRange(1, 7).setValue('empresa');
        headers[6] = 'empresa';
      } catch (e) {}
    }
  }

  const objetos = [];

  for (let i = 1; i < filas.length; i++) {
    const fila = filas[i];
    const obj = {};
    let vacia = true;
    for (let c = 0; c < headers.length; c++) {
      let valor = fila[c];
      if (valor !== '' && valor !== null && valor !== undefined) {
        vacia = false;
      }
      if (valor instanceof Date) {
        try {
          const y = valor.getFullYear();
          const m = String(valor.getMonth() + 1).padStart(2, '0');
          const d = String(valor.getDate()).padStart(2, '0');
          valor = y + '-' + m + '-' + d;
        } catch (e) {}
      }
      obj[headers[c]] = valor;
    }
    if (!vacia) {
      if (nombreHoja === HOJAS.ENTREGAS) {
        if (!obj.empresa && obj.empresaId) {
          obj.empresa = String(obj.empresaId).includes('PERPOL') ? 'PERPOL IDEAS S.A.C.' : 'TR3 ALIMENTOS S.A.C.';
        }
        if (!obj.empresaId && obj.empresa) {
          obj.empresaId = String(obj.empresa).toUpperCase().includes('PERPOL') ? 'PERPOL' : 'TR3';
        }
        if (!obj.razonSocial && obj.empresa) {
          obj.razonSocial = obj.empresa;
        }
      }
      if (nombreHoja === HOJAS.TRABAJADORES) {
        if (obj.empresa) {
          const empMayus = String(obj.empresa).toUpperCase();
          if (empMayus.includes('PERPOL')) {
            obj.empresaId = 'PERPOL';
            obj.empresaNombre = 'PERPOL IDEAS S.A.C.';
          } else if (empMayus.includes('TR3')) {
            obj.empresaId = 'TR3';
            obj.empresaNombre = 'TR3 ALIMENTOS S.A.C.';
          }
        }
      }
      if (nombreHoja === HOJAS.LIQUIDACIONES) {
        if (obj.itemsJson && typeof obj.itemsJson === 'string') {
          try {
            obj.items = JSON.parse(obj.itemsJson);
          } catch(e) {
            obj.items = [];
          }
        }
      }
      if (nombreHoja === HOJAS.DESCUENTOS) {
        if (obj.itemsJson && typeof obj.itemsJson === 'string') {
          try {
            obj.items = JSON.parse(obj.itemsJson);
          } catch(e) {
            obj.items = [];
          }
        }
      }
      objetos.push(obj);
    }
  }

  return objetos;
}

/**
 * Normaliza empresaId a estrictamente 'PERPOL' o 'TR3'
 */
function normalizarEmpresaIdGAS(empId, empNombre) {
  const str = (String(empId || '') + ' ' + String(empNombre || '')).toUpperCase();
  if (str.includes('PERPOL') || str.includes('20392729977')) {
    return 'PERPOL';
  }
  return 'TR3';
}

/**
 * Recorre y corrige cualquier discrepancia de empresaId ('EMP-PERPOL' -> 'PERPOL', etc.)
 */
function corregirEmpresaIdEnTodasLasHojas(ss) {
  if (!ss) ss = SpreadsheetApp.getActiveSpreadsheet();
  const hojas = ss.getSheets();
  let celdasCorregidas = 0;
  const detalleHojas = [];

  for (let h = 0; h < hojas.length; h++) {
    const hoja = hojas[h];
    const nombre = hoja.getName();
    const dataRange = hoja.getDataRange();
    const valores = dataRange.getValues();
    if (valores.length <= 1) continue;

    const headers = valores[0].map(function(hdr) { return String(hdr || '').trim(); });
    const indicesAExaminar = [];
    headers.forEach(function(hdr, idx) {
      const hdrLower = hdr.toLowerCase();
      if (hdrLower === 'empresaid' || hdrLower === 'empresa_id' || (nombre === 'EMPRESAS' && hdrLower === 'id')) {
        indicesAExaminar.push(idx);
      }
    });

    if (indicesAExaminar.length === 0) continue;

    let cambiosEnHoja = 0;
    for (let r = 1; r < valores.length; r++) {
      for (let k = 0; k < indicesAExaminar.length; k++) {
        const colIdx = indicesAExaminar[k];
        const valActual = String(valores[r][colIdx] || '').trim();
        if (valActual === 'EMP-PERPOL') {
          valores[r][colIdx] = 'PERPOL';
          cambiosEnHoja++;
          celdasCorregidas++;
        } else if (valActual === 'EMP-TR3') {
          valores[r][colIdx] = 'TR3';
          cambiosEnHoja++;
          celdasCorregidas++;
        }
      }
    }

    if (cambiosEnHoja > 0) {
      dataRange.setValues(valores);
      detalleHojas.push(nombre + ': ' + cambiosEnHoja + ' celdas');
    }
  }

  invalidarTodasLasTablasCache();

  return {
    estado: 'ok',
    success: true,
    celdasCorregidas: celdasCorregidas,
    detalleHojas: detalleHojas,
    mensaje: celdasCorregidas > 0
      ? 'Se normalizaron ' + celdasCorregidas + ' registros a "PERPOL" y "TR3".'
      : 'Todas las hojas ya cuentan con los IDs de empresa normalizados.'
  };
}

/**
 * =========================================================================
 * SUBIDA Y GESTIÓN DE ARCHIVOS EN GOOGLE DRIVE
 * =========================================================================
 */
function handleUploadDriveFile(payload) {
  try {
    const fileData = (payload && payload.fileData) ? payload.fileData : (payload || {});
    const nombreArchivo = fileData.fileName || fileData.nombreArchivo || payload.nombreArchivo || payload.fileName || payload.filename || ('Evidencia_SSOMA_' + Date.now() + '.pdf');
    const mimeType = fileData.mimeType || payload.mimeType || 'application/pdf';
    const base64Data = fileData.base64Data || fileData.base64 || payload.base64Data || payload.base64;
    const subcarpeta = payload.subcarpeta || fileData.modulo || fileData.subcarpeta || '01_Actas_Entrega';
    const folderIdSolicitado = payload.driveFolderId || payload.folderId || fileData.driveFolderId || fileData.folderId || DRIVE_FOLDER_ID_DEFECTO;

    if (!base64Data) {
      throw new Error('No se recibieron datos base64 para el archivo.');
    }

    let carpetaDestino = null;
    try {
      carpetaDestino = DriveApp.getFolderById(folderIdSolicitado);
    } catch(e) {
      try {
        carpetaDestino = DriveApp.getFolderById(DRIVE_FOLDER_ID_DEFECTO);
      } catch (e2) {
        carpetaDestino = getOrCreateFolder('SSOMA_Evidencias_PERPOL_TR3');
      }
    }

    let subFolder = getOrCreateFolder(subcarpeta, carpetaDestino);
    const decodedBytes = Utilities.base64Decode(base64Data);
    const blob = Utilities.newBlob(decodedBytes, mimeType, nombreArchivo);
    const file = subFolder.createFile(blob);

    try {
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    } catch (shareErr) {}

    return {
      estado: 'ok',
      success: true,
      fileId: file.getId(),
      fileName: file.getName(),
      fileUrl: file.getUrl(),
      viewUrl: file.getUrl(),
      downloadUrl: file.getDownloadUrl(),
      directUrl: 'https://drive.google.com/uc?id=' + file.getId() + '&export=view',
      folderName: subFolder.getName(),
      archivo: {
        id: file.getId(),
        name: file.getName(),
        webViewLink: file.getUrl(),
        folderName: subFolder.getName()
      }
    };
  } catch (error) {
    return {
      estado: 'error',
      success: false,
      mensaje: 'Error subiendo archivo a Google Drive: ' + error.toString()
    };
  }
}

function getOrCreateFolder(nombreCarpeta, parentFolder) {
  const root = parentFolder || DriveApp.getRootFolder();
  const iterador = root.getFoldersByName(nombreCarpeta);
  if (iterador.hasNext()) {
    return iterador.next();
  }
  return root.createFolder(nombreCarpeta);
}

/**
 * =========================================================================
 * VERIFICACIÓN Y ESTRUCTURACIÓN OFICIAL DE HOJAS
 * =========================================================================
 */
function verificarOEstructurarHojas(ss, forzar) {
  const estructuras = {
    'EMPRESAS': {
      color: '#166534',
      cols: ['id', 'ruc', 'razonSocial', 'direccion', 'actividadEconomica', 'codigoPlantilla', 'versionPlantilla', 'fechaEmisionPlantilla', 'logoUrl', 'estado']
    },
    'TRABAJADORES': {
      color: '#1e3a8a',
      cols: ['dni', 'apellidosNombres', 'empresa', 'puesto', 'area', 'condicion', 'sexo', 'fechaNacimiento', 'edad', 'fechaIngreso', 'telefono', 'correo']
    },
    'EPP': {
      color: '#0f766e',
      cols: ['codigo', 'articulo', 'categoria', 'tipo', 'marca', 'modelo', 'norma', 'talla', 'unidad', 'vidaUtilDias', 'costoUnitario', 'stockActual', 'stockMinimo', 'estado']
    },
    'ENTREGAS_EPP': {
      color: '#1e293b',
      cols: ['id', 'numeroRegistro', 'fechaEntrega', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresa', 'razonSocial', 'ruc', 'direccion', 'actividadEconomica', 'area', 'cargo', 'numTrabajadoresActivosCalculado', 'fechaHoraCalculoTrabajadores', 'responsableEntrega', 'tipoEntregaGeneral', 'observacionesGenerales', 'totalUnidades', 'importeTotal', 'estado', 'codigoPlantilla', 'versionPlantilla', 'pdfFileName', 'fechaCreacion', 'operationId']
    },
    'DETALLE_ENTREGAS_EPP': {
      color: '#334155',
      cols: ['idDetalle', 'idEntrega', 'codigoEPP', 'articulo', 'tipo', 'talla', 'unidad', 'cantidad', 'costoUnitario', 'importe', 'motivo', 'fechaRenovacion', 'observaciones']
    },
    'INSPECCIONES_EPP': {
      color: '#475569',
      cols: ['id', 'numeroInspeccion', 'fechaHora', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'area', 'cargo', 'inspectorResponsable', 'lugarInspeccion', 'observacionesGenerales', 'estado', 'fechaCreacion', 'operationId']
    },
    'DETALLE_INSPECCIONES_EPP': {
      color: '#64748b',
      cols: ['idDetalle', 'idInspeccion', 'codigoEPP', 'articulo', 'talla', 'idEntregaOrigen', 'idDetalleEntregaOrigen', 'fechaEntregaReferencia', 'cantidadReferencia', 'fechaRenovacionReferencia', 'resultado', 'hallazgo', 'accion', 'responsableAccion', 'fechaLimiteAccion', 'estadoAccion', 'observaciones']
    },
    'DESCUENTOS_EPP': {
      color: '#b91c1c',
      cols: ['id', 'numeroRegistro', 'codigoPlantilla', 'versionPlantilla', 'fechaSolicitud', 'fechaIncidente', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo', 'motivoDescuento', 'montoTotalDescuento', 'modalidadPago', 'cuotas', 'montoPorCuota', 'responsableNombre', 'estado', 'idEntregaReposicion', 'pdfFileName', 'fechaCreacion', 'itemsJson']
    },
    'INFRACCIONES_EPP': {
      color: '#c2410c',
      cols: ['id', 'numeroReporte', 'codigoPlantilla', 'versionPlantilla', 'fechaHora', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo', 'lugarZona', 'eppsOmitidos', 'gravedad', 'tipoSancion', 'reincidencia', 'supervisorReporta', 'estado', 'pdfFileName', 'fechaCreacion', 'descripcionHechos']
    },
    'LIQUIDACIONES_EPP': {
      color: '#475569',
      cols: ['id', 'numeroRegistro', 'codigoPlantilla', 'versionPlantilla', 'fechaLiquidacion', 'fechaCese', 'motivoCese', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo', 'fechaIngreso', 'itemsJson', 'totalItemsEntregados', 'totalItemsDevueltos', 'totalItemsVencidos', 'totalItemsALiquidar', 'montoTotalEntregado', 'montoDescontadoVencidosYDevueltos', 'montoNetoALiquidar', 'observacionesGenerales', 'supervisorResponsable', 'cargoSupervisor', 'responsableRRHH', 'cargoRRHH', 'estado', 'pdfFileName', 'fechaCreacion']
    },
    'PLANTILLAS_FORMATOS': {
      color: '#15803d',
      cols: ['id', 'codigo', 'version', 'nombre', 'fechaAprobacion', 'estado', 'tipoDocumento', 'referenciaNormativa', 'descripcion', 'colorPrimarioHex', 'tipografia', 'textoSubtituloMembrete', 'tituloSistemaGestion', 'logoPerpol', 'logoTr3', 'logoPersonalizado']
    },
    'DOCUMENTOS': {
      color: '#0369a1',
      cols: ['id', 'idEntrega', 'numeroRegistro', 'codigoTrabajador', 'dni', 'trabajador', 'empresaId', 'empresaNombre', 'ruc', 'codigoPlantilla', 'versionPlantilla', 'versionDocumento', 'fechaHoraEmision', 'responsable', 'estadoDocumental', 'fileName']
    }
  };

  for (const nombre in estructuras) {
    const config = estructuras[nombre];
    let hoja = ss.getSheetByName(nombre);
    if (!hoja) {
      hoja = ss.insertSheet(nombre);
      hoja.getRange(1, 1, 1, config.cols.length).setValues([config.cols]);
      hoja.getRange(1, 1, 1, config.cols.length).setFontWeight('bold').setBackground(config.color).setFontColor('#ffffff').setFontSize(10);
      hoja.setFrozenRows(1);
    } else if (forzar) {
      const rangoHeader = hoja.getRange(1, 1, 1, config.cols.length);
      const valores = rangoHeader.getValues()[0];
      if (!valores[0]) {
        rangoHeader.setValues([config.cols]);
        rangoHeader.setFontWeight('bold').setBackground(config.color).setFontColor('#ffffff');
        hoja.setFrozenRows(1);
      }
    }
  }
}

/**
 * =========================================================================
 * RESPUESTA JSON ESTÁNDAR
 * =========================================================================
 */
function jsonResponse(data, statusCode) {
  const output = ContentService.createTextOutput(JSON.stringify(data));
  output.setMimeType(ContentService.MimeType.JSON);
  return output;
}
