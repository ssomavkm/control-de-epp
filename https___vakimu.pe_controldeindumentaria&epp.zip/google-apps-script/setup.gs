/**
 * =========================================================================
 * SISTEMA WEB SSOMA - SCRIPT DE INSTALACIÓN Y CONFIGURACIÓN (setup.gs)
 * Empresas: PERPOL IDEAS S.A.C. | TR3 ALIMENTOS S.A.C.
 * Formatos Oficiales Homologados:
 *   - FO-SST-GEN-050 Versión 02 (Entrega de EPP / Ley 29783)
 *   - FO-SST-INS-001 Versión 01 (Inspección Técnica de EPP)
 *   - FO-SST-DES-001 Versión 01 (Autorización de Descuento EPP)
 *   - FO-SST-INF-001 Versión 01 (Reporte de Infracción y Sanción EPP)
 *   - FO-SST-LIQ-001 Versión 01 (Acta de Liquidación de EPP por Cese)
 * =========================================================================
 * Este script administra la estructura de base de datos en Google Sheets,
 * inicializa las 13 hojas oficiales, puebla datos maestros y provee un menú
 * interactivo para los administradores y prevencionistas de SSOMA.
 * =========================================================================
 */

/**
 * Menú interactivo en la barra superior de Google Sheets al abrir el archivo
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('🛡️ Portal SSOMA')
    .addItem('⚙️ Inicializar / Estructurar Hojas Oficiales', 'menuSetupSpreadsheet')
    .addItem('📊 Cargar Datos Maestros (PERPOL y TR3)', 'menuPoblarDatosIniciales')
    .addItem('📋 Cargar Plantillas Homologadas (GEN, INS, DES, INF, LIQ)', 'menuPoblarPlantillas')
    .addSeparator()
    .addItem('⚡ Purgar Memoria Caché en RAM (Google CacheService)', 'menuPurgarCacheRAM')
    .addItem('📂 Configurar Carpetas en Google Drive', 'autorizarPermisosDrive')
    .addItem('🏢 Corregir empresaId a PERPOL / TR3 en todas las hojas', 'menuCorregirEmpresaId')
    .addItem('🔍 Verificar Integridad de Columnas del Sistema', 'menuVerificarIntegridad')
    .addItem('🎨 Aplicar Formato Estilizado y Autoajuste', 'menuFormatearHojasSSOMA')
    .addSeparator()
    .addItem('🧪 Diagnóstico y Estado de la API Web App', 'menuProbarEstado')
    .addToUi();
}

/**
 * Diálogo interactivo para inicializar estructura
 */
function menuSetupSpreadsheet() {
  const ui = SpreadsheetApp.getUi();
  const resp = ui.alert(
    'Inicializar Estructura SSOMA',
    '¿Desea crear y verificar las 13 hojas oficiales requeridas para la gestión integral de EPP?',
    ui.ButtonSet.YES_NO
  );

  if (resp === ui.Button.YES) {
    const res = setupSpreadsheet();
    ui.alert('Resultado', res.mensaje, ui.ButtonSet.OK);
  }
}

/**
 * Inicializa y configura todas las hojas necesarias con sus encabezados oficiales
 */
function setupSpreadsheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  const estructuras = {
    'EMPRESAS': {
      color: '#166534',
      cols: ['id', 'ruc', 'razonSocial', 'direccion', 'actividadEconomica', 'codigoPlantilla', 'versionPlantilla', 'fechaEmisionPlantilla', 'logoUrl', 'estado']
    },
    'TRABAJADORES': {
      color: '#1e3a8a',
      cols: ['dni', 'apellidosNombres', 'empresa', 'puesto', 'area', 'condicion', 'sexo', 'fechaNacimiento', 'edad', 'fechaIngreso', 'telefono', 'correo']
    },
    'EPP': {
      color: '#0f766e',
      cols: ['codigo', 'articulo', 'categoria', 'tipo', 'marca', 'modelo', 'norma', 'talla', 'unidad', 'vidaUtilDias', 'costoUnitario', 'stockActual', 'stockMinimo', 'estado']
    },
    'ENTREGAS_EPP': {
      color: '#1e293b',
      cols: ['id', 'numeroRegistro', 'fechaEntrega', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresa', 'razonSocial', 'ruc', 'direccion', 'actividadEconomica', 'area', 'cargo', 'numTrabajadoresActivosCalculado', 'fechaHoraCalculoTrabajadores', 'responsableEntrega', 'tipoEntregaGeneral', 'observacionesGenerales', 'totalUnidades', 'importeTotal', 'estado', 'codigoPlantilla', 'versionPlantilla', 'pdfFileName', 'fechaCreacion', 'operationId']
    },
    'DETALLE_ENTREGAS_EPP': {
      color: '#334155',
      cols: ['idDetalle', 'idEntrega', 'codigoEPP', 'articulo', 'tipo', 'talla', 'unidad', 'cantidad', 'costoUnitario', 'importe', 'motivo', 'fechaRenovacion', 'observaciones']
    },
    'INSPECCIONES_EPP': {
      color: '#475569',
      cols: ['id', 'numeroInspeccion', 'fechaHora', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'area', 'cargo', 'inspectorResponsable', 'lugarInspeccion', 'observacionesGenerales', 'estado', 'fechaCreacion', 'operationId']
    },
    'DETALLE_INSPECCIONES_EPP': {
      color: '#64748b',
      cols: ['idDetalle', 'idInspeccion', 'codigoEPP', 'articulo', 'talla', 'idEntregaOrigen', 'idDetalleEntregaOrigen', 'fechaEntregaReferencia', 'cantidadReferencia', 'fechaRenovacionReferencia', 'resultado', 'hallazgo', 'accion', 'responsableAccion', 'fechaLimiteAccion', 'estadoAccion', 'observaciones']
    },
    'DESCUENTOS_EPP': {
      color: '#b91c1c',
      cols: ['id', 'numeroRegistro', 'codigoPlantilla', 'versionPlantilla', 'fechaSolicitud', 'fechaIncidente', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo', 'motivoDescuento', 'montoTotalDescuento', 'modalidadPago', 'cuotas', 'montoPorCuota', 'responsableNombre', 'estado', 'idEntregaReposicion', 'pdfFileName', 'fechaCreacion', 'itemsJson']
    },
    'INFRACCIONES_EPP': {
      color: '#c2410c',
      cols: ['id', 'numeroReporte', 'codigoPlantilla', 'versionPlantilla', 'fechaHora', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo', 'lugarZona', 'eppsOmitidos', 'gravedad', 'tipoSancion', 'reincidencia', 'supervisorReporta', 'estado', 'pdfFileName', 'fechaCreacion', 'descripcionHechos']
    },
    'LIQUIDACIONES_EPP': {
      color: '#475569',
      cols: ['id', 'numeroRegistro', 'codigoPlantilla', 'versionPlantilla', 'fechaLiquidacion', 'fechaCese', 'motivoCese', 'codigoTrabajador', 'dni', 'trabajadorNombre', 'empresaId', 'empresaNombre', 'ruc', 'area', 'cargo', 'fechaIngreso', 'itemsJson', 'totalItemsEntregados', 'totalItemsDevueltos', 'totalItemsVencidos', 'totalItemsALiquidar', 'montoTotalEntregado', 'montoDescontadoVencidosYDevueltos', 'montoNetoALiquidar', 'observacionesGenerales', 'supervisorResponsable', 'cargoSupervisor', 'responsableRRHH', 'cargoRRHH', 'estado', 'pdfFileName', 'fechaCreacion']
    },
    'PLANTILLAS_FORMATOS': {
      color: '#15803d',
      cols: ['id', 'codigo', 'version', 'nombre', 'fechaAprobacion', 'estado', 'tipoDocumento', 'referenciaNormativa', 'descripcion', 'colorPrimarioHex', 'tipografia', 'textoSubtituloMembrete', 'tituloSistemaGestion', 'logoPerpol', 'logoTr3', 'logoPersonalizado']
    },
    'DOCUMENTOS': {
      color: '#0369a1',
      cols: ['id', 'idEntrega', 'numeroRegistro', 'codigoTrabajador', 'dni', 'trabajador', 'empresaId', 'empresaNombre', 'ruc', 'codigoPlantilla', 'versionPlantilla', 'versionDocumento', 'fechaHoraEmision', 'responsable', 'estadoDocumental', 'fileName']
    },
    'CONFIGURACIÓN': {
      color: '#374151',
      cols: ['parametro', 'valor', 'descripcion']
    }
  };

  let creadas = 0;
  let existentes = 0;

  for (const nombre in estructuras) {
    const config = estructuras[nombre];
    let hoja = ss.getSheetByName(nombre);
    if (!hoja) {
      hoja = ss.insertSheet(nombre);
      hoja.getRange(1, 1, 1, config.cols.length).setValues([config.cols]);
      hoja.getRange(1, 1, 1, config.cols.length)
        .setFontWeight('bold')
        .setBackground(config.color)
        .setFontColor('#ffffff')
        .setFontSize(10);
      hoja.setFrozenRows(1);
      creadas++;
    } else {
      existentes++;
      const rangoHeader = hoja.getRange(1, 1, 1, config.cols.length);
      const valores = rangoHeader.getValues()[0];
      if (!valores[0]) {
        rangoHeader.setValues([config.cols]);
        rangoHeader.setFontWeight('bold').setBackground(config.color).setFontColor('#ffffff');
        hoja.setFrozenRows(1);
      }
    }
  }

  // Purgar caché en memoria
  try {
    CacheService.getScriptCache().removeAll(Object.keys(estructuras).map(k => 'cache_hoja_' + k));
  } catch(e) {}

  return {
    estado: 'ok',
    mensaje: 'Estructura completada con éxito. ' + creadas + ' hojas nuevas creadas, ' + existentes + ' verificadas.'
  };
}

/**
 * Purgar la memoria RAM del CacheService directamente desde el menú
 */
function menuPurgarCacheRAM() {
  try {
    const cache = CacheService.getScriptCache();
    const hojasNombres = [
      'EMPRESAS', 'TRABAJADORES', 'EPP', 'ENTREGAS_EPP', 'DETALLE_ENTREGAS_EPP',
      'INSPECCIONES_EPP', 'DETALLE_INSPECCIONES_EPP', 'DESCUENTOS_EPP', 'INFRACCIONES_EPP',
      'LIQUIDACIONES_EPP', 'PLANTILLAS_FORMATOS', 'DOCUMENTOS', 'CONFIGURACIÓN'
    ];
    cache.removeAll(hojasNombres.map(n => 'cache_hoja_' + n));
    SpreadsheetApp.getUi().alert('Caché Purgado', 'Se ha vaciado la memoria RAM (CacheService). Las próximas consultas leerán datos frescos directamente de Google Sheets.', SpreadsheetApp.getUi().ButtonSet.OK);
  } catch (e) {
    SpreadsheetApp.getUi().alert('Aviso', 'Error al purgar caché: ' + e.toString(), SpreadsheetApp.getUi().ButtonSet.OK);
  }
}

/**
 * Carga los datos maestros oficiales de PERPOL y TR3
 */
function menuPoblarDatosIniciales() {
  const ui = SpreadsheetApp.getUi();
  const resp = ui.alert(
    'Cargar Datos Maestros',
    '¿Desea registrar las razones sociales de PERPOL y TR3, catálogo EPP y padrón de trabajadores oficial?',
    ui.ButtonSet.YES_NO
  );

  if (resp !== ui.Button.YES) return;

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  setupSpreadsheet();

  // 1. Cargar Empresas
  const hojaEmp = ss.getSheetByName('EMPRESAS');
  if (hojaEmp && hojaEmp.getLastRow() <= 1) {
    hojaEmp.appendRow([
      'PERPOL',
      '20392729977',
      'PERPOL IDEAS S.A.C.',
      'CAL.LOS BRILLANTES NRO. 096 FND. PARCELACION RUSTICA Y SEMIRUSTICA LA CAPITANA-SANTA MARIA DE HUACHIPA - LIMA – LURIGANCHO',
      'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
      'FO-SST-GEN-050',
      '02',
      '02/01/2026',
      '',
      'Activo'
    ]);
    hojaEmp.appendRow([
      'TR3',
      '20550842891',
      'TR3 ALIMENTOS S.A.C.',
      'LOS BRILLANTES MZA. B1 LOTE. 11B PARCELA LA CAPITANA DEL FUNDO DE HUACHIPA - LIMA - LURIGANCHO',
      'ELABORACIÓN DE PRODUCTOS LÁCTEOS',
      'FO-SST-GEN-050',
      '02',
      '02/01/2026',
      '',
      'Activo'
    ]);
  }

  // 2. Cargar Plantillas Homologadas
  poblarTodasLasPlantillasFormatos(ss);

  // 3. Cargar Catálogo Maestro de EPP
  const hojaEPP = ss.getSheetByName('EPP');
  if (hojaEPP && hojaEPP.getLastRow() <= 1) {
    const catalogoInicial = [
      ['EPP-CAS-01', 'Casco de Seguridad Industrial Tipo I Clase E c/ Barbiquejo 3 Puntas', 'Protección Craneal', 'EPP', '3M', 'H-700 Series', 'ANSI/ISEA Z89.1-2014 Tipo 1 Clase E', 'Ajustable (53-62 cm)', 'Unidad', 365, 48.50, 38, 10, 'Disponible'],
      ['EPP-LEN-01', 'Lentes de Seguridad Anti-empañante Claros con Protección UV400', 'Protección Ocular y Facial', 'EPP', 'Steelpro', 'Nitro HC/AF', 'ANSI Z87.1-2020 / EN 166', 'Estándar', 'Unidad', 90, 14.20, 65, 15, 'Disponible'],
      ['EPP-LEN-02', 'Antiparras de Seguridad Herméticas Resistentes a Salpicaduras Químicas', 'Protección Ocular y Facial', 'EPP', '3M', 'Goggle Gear 500', 'ANSI Z87.1-2020 / D3 D4', 'Estándar', 'Unidad', 120, 38.00, 24, 8, 'Disponible'],
      ['EPP-AUD-01', 'Tapones Auditivos Reutilizables con Cordón en Estuche NRR 25dB', 'Protección Auditiva', 'EPP', '3M', '1270 Tri-Flange', 'ANSI S3.19-1974', 'Estándar', 'Par', 60, 6.80, 110, 25, 'Disponible'],
      ['EPP-AUD-02', 'Orejeras Protectoras Adosables al Casco NRR 27dB', 'Protección Auditiva', 'EPP', '3M Peltor', 'Optime 101 H7P3E', 'ANSI S3.19-1974', 'Estándar', 'Unidad', 365, 89.00, 16, 5, 'Disponible'],
      ['EPP-RES-01', 'Respirador Media Cara de Silicona c/ Doble Filtro Químico y Partículas', 'Protección Respiratoria', 'EPP', '3M', '7502 Serie 7500', 'NIOSH 42 CFR 84', 'M', 'Unidad', 180, 125.00, 19, 6, 'Disponible'],
      ['EPP-RES-02', 'Filtro para Partículas P100 contra Polvos, Humos y Neblinas Lácteas', 'Protección Respiratoria', 'EPP', '3M', '2091 P100', 'NIOSH P100', 'Estándar', 'Par', 45, 34.50, 42, 12, 'Disponible'],
      ['EPP-GUA-01', 'Guantes de Nitrilo Verde Extra Resistentes a Grasas y Sustancias Químicas', 'Protección de Manos', 'EPP', 'Ansell', 'Solvex 37-175', 'EN 388:4101X / EN ISO 374-1', 'Talla 8 (M)', 'Par', 45, 18.90, 85, 20, 'Disponible'],
      ['EPP-GUA-02', 'Guantes Térmicos de Nitrilo Foam con Aislamiento para Cámara de Congelado', 'Protección de Manos', 'EPP', 'Ninja', 'Ice HPT', 'EN 511:02X / EN 388:3231', 'Talla 9 (L)', 'Par', 90, 42.00, 28, 8, 'Disponible'],
      ['EPP-CAL-01', 'Botas de Seguridad de PVC Blanca con Puntera de Acero para Alimentos', 'Protección de Pies', 'EPP', 'Segusa', 'Sanitaria Blanca', 'NTP-ISO 20345:2017 S4 SRC', '41', 'Par', 180, 78.50, 32, 10, 'Disponible'],
      ['EPP-CAL-02', 'Zapatos de Seguridad de Cuero Hidrófugo c/ Puntera Composite Dieléctrica', 'Protección de Pies', 'EPP', 'Bata Industrials', 'Bickz 204', 'ASTM F2413-18 / EN ISO 20345', '42', 'Par', 270, 165.00, 22, 6, 'Disponible'],
      ['EPP-ROP-01', 'Chaqueta Térmica Impermeable para Cámara de Congelado (-25°C)', 'Ropa de Trabajo', 'Ropa de Trabajo', 'RefrigiWear', 'Iron-Tuff Polar', 'EN 342:2017 Clase 3', 'L', 'Unidad', 365, 320.00, 12, 4, 'Disponible'],
      ['EPP-ROP-02', 'Pantalón Overol Térmico con Tirantes para Trabajo en Cámara Fría', 'Ropa de Trabajo', 'Ropa de Trabajo', 'RefrigiWear', 'Iron-Tuff Bib', 'EN 342:2017 Clase 3', 'L', 'Unidad', 365, 280.00, 10, 4, 'Disponible']
    ];
    catalogoInicial.forEach(fila => hojaEPP.appendRow(fila));
  }

  // 4. Cargar Trabajadores Iniciales
  const hojaTrab = ss.getSheetByName('TRABAJADORES');
  if (hojaTrab && hojaTrab.getLastRow() <= 1) {
    const trabajadoresIniciales = [
      ['45892134', 'Juan Carlos Pérez García', 'PERPOL IDEAS S.A.C.', 'Operario de Pasteurización', 'Producción', 'Activo', 'M', '1989-05-12', 36, '2023-03-15', '984512345', 'jperez@perpolideas.com'],
      ['70234561', 'María Elena Quispe Huamán', 'PERPOL IDEAS S.A.C.', 'Supervisora de Aseguramiento de Calidad', 'Control de Calidad', 'Activo', 'F', '1995-08-23', 30, '2023-06-01', '976543210', 'mquispe@perpolideas.com'],
      ['47890123', 'Luis Alberto Gómez Sánchez', 'PERPOL IDEAS S.A.C.', 'Técnico Electromecánico de Mantenimiento', 'Mantenimiento', 'Activo', 'M', '1991-03-17', 35, '2022-11-20', '981234567', 'lgomez@perpolideas.com'],
      ['46781290', 'Carlos Eduardo Benítez Rojas', 'TR3 ALIMENTOS S.A.C.', 'Jefe de Turno de Derivados Lácteos', 'Producción', 'Activo', 'M', '1987-10-28', 38, '2023-01-16', '987123456', 'cbenitez@tr3alimentos.com'],
      ['72349012', 'Ana Patricia Salazar Ortiz', 'TR3 ALIMENTOS S.A.C.', 'Operaria de Empaque Automatizado', 'Envasado', 'Activo', 'F', '1996-03-22', 30, '2023-09-01', '978234561', 'asalazar@tr3alimentos.com'],
      ['43901234', 'Jorge Fernando Morales Vera', 'TR3 ALIMENTOS S.A.C.', 'Técnico de Refrigeración Industrial', 'Mantenimiento', 'Activo', 'M', '1985-07-19', 40, '2023-04-18', '991234509', 'jmorales@tr3alimentos.com']
    ];
    trabajadoresIniciales.forEach(fila => hojaTrab.appendRow(fila));
  }

  // 5. Cargar Parámetros de Configuración
  poblarConfiguracion(ss);

  menuPurgarCacheRAM();
  ui.alert('Éxito', 'Datos maestros de empresas, plantillas, catálogo de EPP, trabajadores y configuración cargados correctamente.', ui.ButtonSet.OK);
}

function menuPoblarPlantillas() {
  poblarTodasLasPlantillasFormatos();
}

/**
 * Carga o actualiza las 5 plantillas oficiales homologadas
 */
function poblarTodasLasPlantillasFormatos(ssParam) {
  const ss = ssParam || SpreadsheetApp.getActiveSpreadsheet();
  let hojaPlant = ss.getSheetByName('PLANTILLAS_FORMATOS');
  if (!hojaPlant) {
    setupSpreadsheet();
    hojaPlant = ss.getSheetByName('PLANTILLAS_FORMATOS');
  }

  const plantillas = [
    [
      'PLANT-FO-SST-GEN-050-V02',
      'FO-SST-GEN-050',
      '02',
      'REGISTRO DE ENTREGA DE EQUIPOS DE PROTECCIÓN PERSONAL (EPP) Y ROPA DE TRABAJO',
      '02/01/2026',
      'Activa',
      'Dotación',
      'Conforme a la Ley N° 29783, D.S. N° 005-2012-TR y R.M. N° 050-2013-TR',
      'Formato corporativo oficial de entrega obligatoria de EPP con firmas digitales para PERPOL IDEAS S.A.C. y TR3 ALIMENTOS S.A.C.',
      '#166534',
      'helvetica',
      'DIVISIÓN INDUSTRIAL',
      'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA',
      '',
      '',
      ''
    ],
    [
      'PLANT-FO-SST-INS-001-V01',
      'FO-SST-INS-001',
      '01',
      'REGISTRO DE INSPECCIÓN TÉCNICA Y MONITOREO DE EPP EN PUESTO DE TRABAJO',
      '02/01/2026',
      'Activa',
      'Inspección',
      'Conforme a la Ley N° 29783 Art. 60 y D.S. N° 005-2012-TR Art. 97',
      'Monitoreo periódico del estado físico, higiene, funcionalidad y uso correcto de EPP en áreas operativas.',
      '#1e3a8a',
      'helvetica',
      'SUPERVISIÓN SSOMA',
      'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA',
      '',
      '',
      ''
    ],
    [
      'PLANT-FO-SST-DES-001-V01',
      'FO-SST-DES-001',
      '01',
      'AUTORIZACIÓN EXPRESA DE DESCUENTO POR PÉRDIDA O DETERIORO DE EPP',
      '02/01/2026',
      'Activa',
      'Descuento',
      'Ley N° 29783 Art. 79 y D.S. N° 003-97-TR (TUO del D.Leg. 728)',
      'Autorización expresa y voluntaria del trabajador para deducción en planilla de cuotas y reposición inmediata en almacén.',
      '#b91c1c',
      'helvetica',
      'GESTIÓN DE RECURSOS HUMANOS',
      'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA',
      '',
      '',
      ''
    ],
    [
      'PLANT-FO-SST-INF-001-V01',
      'FO-SST-INF-001',
      '01',
      'REPORTE DE INFRACCIÓN Y SANCIÓN DISCIPLINARIA POR NO USO DE EPP',
      '02/01/2026',
      'Activa',
      'Infracción',
      'Reglamento Interno de Seguridad y Salud en el Trabajo (RISST) y Ley N° 29783 Art. 79',
      'Reporte de acto subestándar por omisión de EPP, medidas disciplinarias y constancia de negativa con firma de testigo.',
      '#c2410c',
      'helvetica',
      'COMITÉ DE SEGURIDAD Y SALUD EN EL TRABAJO',
      'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA',
      '',
      '',
      ''
    ],
    [
      'PLANT-FO-SST-LIQ-001-V01',
      'FO-SST-LIQ-001',
      '01',
      'ACTA DE LIQUIDACIÓN DE EPP POR CESE LABORAL',
      '02/01/2026',
      'Activa',
      'Liquidación',
      'Ley N° 29783, D.S. N° 005-2012-TR y Procedimiento Interno de Desvinculación SSOMA',
      'Conciliación de equipos entregados vs devueltos y descargos por cumplimiento de vida útil al momento del cese.',
      '#475569',
      'helvetica',
      'ADMINISTRACIÓN Y RELACIONES LABORALES',
      'SISTEMA INTEGRADO DE GESTIÓN SST / SSOMA',
      '',
      '',
      ''
    ]
  ];

  if (hojaPlant.getLastRow() > 1) {
    hojaPlant.getRange(2, 1, hojaPlant.getLastRow() - 1, hojaPlant.getLastColumn()).clearContent();
  }

  hojaPlant.getRange(2, 1, plantillas.length, plantillas[0].length).setValues(plantillas);
  hojaPlant.autoResizeColumns(1, plantillas[0].length);

  try {
    CacheService.getScriptCache().remove('cache_hoja_PLANTILLAS_FORMATOS');
  } catch(e) {}

  if (!ssParam) {
    try {
      SpreadsheetApp.getUi().alert('Plantillas Actualizadas', 'Se registraron exitosamente las ' + plantillas.length + ' plantillas oficiales del Sistema SSOMA.', SpreadsheetApp.getUi().ButtonSet.OK);
    } catch (e) {}
  }
}

/**
 * Carga o actualiza los parámetros en la hoja CONFIGURACIÓN
 */
function poblarConfiguracion(ssParam) {
  const ss = ssParam || SpreadsheetApp.getActiveSpreadsheet();
  let hojaCfg = ss.getSheetByName('CONFIGURACIÓN');
  if (!hojaCfg) {
    setupSpreadsheet();
    hojaCfg = ss.getSheetByName('CONFIGURACIÓN');
  }

  const configuraciones = [
    ['driveFolderId', '13IbmZ67P3XyGpys1vlILWig2QIkmHiOG', 'ID oficial de la carpeta de Google Drive para almacenamiento de actas PDF y fotos de evidencia.'],
    ['driveFolderUrl', 'https://drive.google.com/drive/folders/13IbmZ67P3XyGpys1vlILWig2QIkmHiOG', 'Enlace directo a la carpeta principal en Google Drive.'],
    ['gasWebAppUrl', 'https://script.google.com/macros/s/AKfycbwr5Fj-UtlVwG39BpDP0vOW3aajj1vddHf9lncxkoD3OH1tc6C5j0zaARodvGXi-fA-/exec', 'URL del Web App de Google Apps Script para sincronización y almacenamiento automático.'],
    ['empresaPorDefecto', 'PERPOL', 'Empresa seleccionada por defecto al abrir el sistema (PERPOL o TR3).'],
    ['formatoActivoCodigo', 'FO-SST-GEN-050', 'Código del formato oficial de entrega de EPP (Ley N° 29783 y R.M. 050-2013-TR).'],
    ['formatoActivoVersion', '02', 'Versión aprobada vigente del formato corporativo homologado FO-SST-GEN-050.'],
    ['formatoFechaEmision', '02/01/2026', 'Fecha oficial de entrada en vigencia del formato corporativo homologado.'],
    ['intervaloActualizacionSegundos', '240', 'Frecuencia de sincronización manual sugerida.'],
    ['sistemaNombre', 'Sistema de Gestión de EPP - SSOMA', 'Nombre comercial del sistema corporativo para PERPOL y TR3.'],
    ['sistemaVersion', '2.5.0', 'Versión de la plataforma web SSOMA con soporte Google Drive, CacheService y Liquidaciones.'],
    ['tamanoPaginaPDF', 'A4', 'Tamaño estándar de página para la generación de documentos oficiales en PDF.'],
    ['orientacionPaginaPDF', 'portrait', 'Orientación vertical (portrait) homologada según la R.M. 050-2013-TR.']
  ];

  if (hojaCfg.getLastRow() > 1) {
    hojaCfg.getRange(2, 1, hojaCfg.getLastRow() - 1, hojaCfg.getLastColumn()).clearContent();
  }

  hojaCfg.getRange(2, 1, configuraciones.length, configuraciones[0].length).setValues(configuraciones);
  hojaCfg.autoResizeColumns(1, configuraciones[0].length);
}

/**
 * Normaliza empresaId en todas las hojas
 */
function menuCorregirEmpresaId() {
  const ui = SpreadsheetApp.getUi();
  const resp = ui.alert(
    'Corregir empresaId a PERPOL / TR3',
    '¿Desea normalizar automáticamente las celdas de empresaId en todas las hojas para cambiar "EMP-PERPOL" por "PERPOL" y "EMP-TR3" por "TR3"?',
    ui.ButtonSet.YES_NO
  );

  if (resp !== ui.Button.YES) return;

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const res = corregirEmpresaIdEnTodasLasHojas(ss);
  ui.alert('Resultado de Corrección', res.mensaje, ui.ButtonSet.OK);
}

/**
 * Valida la existencia de las 13 hojas oficiales
 */
function menuVerificarIntegridad() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const hojas = ss.getSheets();
  const nombres = hojas.map(h => h.getName());
  const requeridas = [
    'EMPRESAS', 'TRABAJADORES', 'EPP', 'ENTREGAS_EPP', 'DETALLE_ENTREGAS_EPP',
    'INSPECCIONES_EPP', 'DETALLE_INSPECCIONES_EPP', 'DESCUENTOS_EPP', 'INFRACCIONES_EPP',
    'LIQUIDACIONES_EPP', 'PLANTILLAS_FORMATOS', 'DOCUMENTOS', 'CONFIGURACIÓN'
  ];

  const faltantes = requeridas.filter(r => !nombres.includes(r));
  const ui = SpreadsheetApp.getUi();

  if (faltantes.length > 0) {
    ui.alert('Atención', 'Faltan las siguientes hojas: ' + faltantes.join(', ') + '. Use la opción "Inicializar Estructura".', ui.ButtonSet.OK);
  } else {
    ui.alert('Integridad Correcta', 'Todas las 13 hojas oficiales del Sistema SSOMA están presentes y operativas.', ui.ButtonSet.OK);
  }
}

/**
 * Aplica estilos y autoajuste a todas las columnas
 */
function menuFormatearHojasSSOMA() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const hojas = ss.getSheets();

  hojas.forEach(hoja => {
    if (hoja.getLastRow() > 0 && hoja.getLastColumn() > 0) {
      hoja.autoResizeColumns(1, Math.min(25, hoja.getLastColumn()));
    }
  });

  SpreadsheetApp.getUi().alert('Formato Aplicado', 'Las columnas de todas las hojas han sido autoajustadas.', SpreadsheetApp.getUi().ButtonSet.OK);
}

/**
 * Muestra el estado del libro de cálculo y parámetros activos
 */
function menuProbarEstado() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const totalHojas = ss.getSheets().length;
  const msg = 'Hoja de Cálculo Activa: ' + ss.getName() + '\n' +
              'ID: ' + ss.getId() + '\n' +
              'Total de Hojas SSOMA: ' + totalHojas + '\n' +
              'Carpeta Google Drive: 13IbmZ67P3XyGpys1vlILWig2QIkmHiOG\n\n' +
              'Para obtener la URL de conexión, recuerde implementar el script como "Aplicación web" con acceso para "Cualquier usuario".';

  SpreadsheetApp.getUi().alert('Estado del Sistema SSOMA', msg, SpreadsheetApp.getUi().ButtonSet.OK);
}

/**
 * Autoriza permisos de Google Drive y crea subcarpetas
 */
function autorizarPermisosDrive() {
  const CARPETA_RAIZ_ID = '13IbmZ67P3XyGpys1vlILWig2QIkmHiOG';
  let carpeta;
  try {
    carpeta = DriveApp.getFolderById(CARPETA_RAIZ_ID);
  } catch (e) {
    let carpetas = DriveApp.getFoldersByName('SSOMA_Evidencias_PERPOL_TR3');
    if (carpetas.hasNext()) {
      carpeta = carpetas.next();
    } else {
      carpeta = DriveApp.createFolder('SSOMA_Evidencias_PERPOL_TR3');
    }
  }

  const subcarpetas = [
    '01_Actas_Entrega',
    '02_Inspecciones_EPP',
    '03_Descuentos_EPP',
    '04_Infracciones_Evidencias',
    '05_Liquidaciones_EPP',
    '06_Imagenes_Fotos_Firmas'
  ];

  subcarpetas.forEach(sub => {
    let subs = carpeta.getFoldersByName(sub);
    if (!subs.hasNext()) {
      carpeta.createFolder(sub);
    }
  });

  const mensaje = '¡Permisos de Google Drive concedidos y subcarpetas listas en ' + carpeta.getName() + '!';
  Logger.log(mensaje);
  try {
    SpreadsheetApp.getUi().alert('Google Drive SSOMA', mensaje, SpreadsheetApp.getUi().ButtonSet.OK);
  } catch (uiErr) {}
  return mensaje;
}
