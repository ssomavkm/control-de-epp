#!/usr/bin/env node

/**
 * =========================================================================
 * SCRIPT DE BACKUP Y RESPALDO AUTOMATIZADO - GOOGLE APPS SCRIPT SSOMA EPP
 * =========================================================================
 * 
 * Uso:
 *   node scripts/backup-gas.js [URL_WEB_APP] [--output ./backups]
 *   npm run backup:gas
 * 
 * Si no se especifica URL_WEB_APP, toma VITE_GAS_WEB_APP_URL del entorno (.env)
 * o la URL predeterminada oficial de producción.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// URL por defecto del Web App desplegado
const DEFAULT_URL = 'https://script.google.com/macros/s/AKfycbwr5Fj-UtlVwG39BpDP0vOW3aajj1vddHf9lncxkoD3OH1tc6C5j0zaARodvGXi-fA-/exec';

// Cargar variables de entorno si existen en .env
function loadEnv() {
  const envPath = path.resolve(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf8').split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const [key, ...vals] = trimmed.split('=');
      if (key && vals.length > 0) {
        process.env[key.trim()] = vals.join('=').trim().replace(/^["']|["']$/g, '');
      }
    }
  }
}

loadEnv();

// Argumentos de CLI
const args = process.argv.slice(2);
let targetUrl = process.env.VITE_GAS_WEB_APP_URL || DEFAULT_URL;
let outDir = path.resolve(process.cwd(), 'backups');

for (let i = 0; i < args.length; i++) {
  if (args[i].startsWith('http://') || args[i].startsWith('https://')) {
    targetUrl = args[i];
  } else if (args[i] === '--output' || args[i] === '-o') {
    if (args[i + 1]) {
      outDir = path.resolve(process.cwd(), args[i + 1]);
      i++;
    }
  }
}

async function performBackup() {
  console.log('====================================================');
  console.log('🛡️  SSOMA EPP - Respaldo de Base de Datos Google Sheets');
  console.log('====================================================');
  console.log(`📡 URL Objetivo: ${targetUrl}`);
  console.log(`📁 Directorio de salida: ${outDir}\n`);

  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFileName = `backup-ssoma-epp-${timestamp}.json`;
  const backupFilePath = path.join(outDir, backupFileName);
  const latestFilePath = path.join(outDir, 'backup-ssoma-epp-latest.json');

  console.log('⏳ Conectando con Google Apps Script API...');

  try {
    // 1. Ping test
    const pingUrl = `${targetUrl}?action=ping`;
    const pingResp = await fetch(pingUrl);
    if (!pingResp.ok) {
      throw new Error(`Error HTTP al realizar ping: ${pingResp.status} ${pingResp.statusText}`);
    }
    const pingData = await pingResp.json();
    console.log(`✅ Conectividad verificada: ${pingData.mensaje || 'OK'}`);

    // 2. Extracción completa (getAll)
    const getUrl = `${targetUrl}?action=getAll`;
    console.log('📥 Descargando todas las colecciones (getAll)...');
    const startTime = Date.now();
    const resp = await fetch(getUrl);
    
    if (!resp.ok) {
      throw new Error(`Error HTTP en getAll: ${resp.status} ${resp.statusText}`);
    }

    const json = await resp.json();
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    if (json.estado !== 'ok' && !json.datos) {
      throw new Error(`Respuesta de la API con estado no satisfactorio: ${JSON.stringify(json)}`);
    }

    const payload = {
      backupMeta: {
        timestamp: new Date().toISOString(),
        url: targetUrl,
        durationSeconds: duration,
        resumenColecciones: {}
      },
      ...json
    };

    if (json.datos) {
      for (const [colName, items] of Object.entries(json.datos)) {
        payload.backupMeta.resumenColecciones[colName] = Array.isArray(items) ? items.length : typeof items;
      }
    }

    // Guardar archivo timestamped
    fs.writeFileSync(backupFilePath, JSON.stringify(payload, null, 2), 'utf8');
    // Guardar copia latest
    fs.writeFileSync(latestFilePath, JSON.stringify(payload, null, 2), 'utf8');

    console.log(`\n🎉 Respaldo completado con éxito en ${duration}s!`);
    console.log(`📦 Archivo creado: ${backupFilePath}`);
    console.log(`🔗 Copia última:   ${latestFilePath}`);
    console.log('\n📊 Resumen de registros respaldados:');
    if (payload.backupMeta.resumenColecciones) {
      for (const [col, count] of Object.entries(payload.backupMeta.resumenColecciones)) {
        console.log(`   - ${col.padEnd(22)}: ${count} registros`);
      }
    }
    console.log('\n====================================================\n');
  } catch (err) {
    console.error('\n❌ ERROR DURANTE EL RESPALDO:');
    console.error(err.message || err);
    console.error('\nSugerencia: Verifique que la URL del Apps Script esté implementada con acceso público ("Anyone / Cualquier usuario").\n');
    process.exit(1);
  }
}

performBackup();
