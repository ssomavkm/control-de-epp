# Sistema de Gestión de Equipos de Protección Personal (EPP)

> **Plataforma Integral de Seguridad, Salud Ocupacional y Medio Ambiente (SSOMA)**  
> Diseñada para empresas industriales y de manufactura (**PERPOL IDEAS S.A.C.** y **TR3 ALIMENTOS S.A.C.**) para el control estricto de entregas, inspecciones técnicas, ciclo de vida, trazabilidad documental y cumplimiento normativo (Ley N° 29783 / OHSAS / ISO 45001).

---

## 🚀 Tecnologías y Stack Técnico

- **Frontend Core**: [React 19](https://react.dev/) + [TypeScript](https://www.typescriptlang.org/) (Tipado estricto)
- **Empaquetador & Build**: [Vite 8](https://vitejs.dev/)
- **Estilos & UI**: [Tailwind CSS v4](https://tailwindcss.com/) + [Lucide React Icons](https://lucide.dev/) + [Motion](https://motion.dev/)
- **Gestión de Estado Global**: [Zustand](https://github.com/pmndrs/zustand) con persistencia local (`localStorage`)
- **Enrutamiento SPA**: [React Router v7](https://reactrouter.com/)
- **Validación de Datos**: [Zod](https://zod.dev/) con esquemas estrictos para DNI (8 dígitos), RUC (11 dígitos), stock y contratos
- **Motor de PDF**: [jsPDF](https://github.com/parallax/jsPDF) + [jsPDF-AutoTable](https://github.com/simonbengtsson/jsPDF-AutoTable)
- **Generación de QR**: [qrcode](https://www.npmjs.com/package/qrcode) (incrustación directa en cabeceras de documentos)
- **Visualizador de PDF en el navegador**: [pdfjs-dist](https://mozilla.github.io/pdf.js/)
- **Backend & Almacenamiento Remoto**: [Google Apps Script (GAS)](https://developers.google.com/apps-script) + [Google Sheets](https://www.google.com/sheets/about/)
- **Testing & Cobertura**: [Vitest](https://vitest.dev/) + [Testing Library](https://testing-library.com/) (React, Jest-DOM, User-Event) + JSDOM

---

## ✨ Características Principales

- **Gestión de Catálogo de EPP**: Maestro unificado de equipos de seguridad con codificación técnica, categorías de riesgo, norma técnica aplicable, costos unitarios en Soles (PEN), niveles de stock actual y umbrales mínimos de reposición.
- **Registro Oficial de Entregas (Formato FO-SST-GEN-050)**:
  - Formulario multipropósito con validación reactiva en tiempo real.
  - Firma digital en pantalla para el trabajador y el responsable SST vía canvas táctil.
  - Cálculo instantáneo de fechas límite de renovación según vida útil por cargo.
  - Descuento automático de inventario con bloqueo por stock insuficiente.
- **Inspecciones Técnicas de EPP**:
  - Evaluación de estado físico (Bueno, Regular, Deteriorado o dañado, Extraviado / A Descontar, No presentado).
  - Derivación automática a flujo de **Reposición Inmediata** o emisión de **Autorización de Descuento**.
- **Control Documental y Auditoría ISO**:
  - Generación de actas foliadas oficiales con diseño tripartito ISO (Logotipo corporativo, código y versión de plantilla, folio único correlativo).
  - Incrustación de código QR verificable con metadatos de emisión.
  - Previsualizador PDF embebido y descarga directa en alta definición.
- **Descuentos por Pérdida / Deterioro (Formato FO-SST-DES-001)**:
  - Registro de incidentes, sustento de reposición y compromiso firmado de descuento por planilla.
- **Infracciones y Sanciones Disciplinarias (Formato FO-SST-INF-001)**:
  - Tipificación de faltas leves, graves y muy graves con escala de amonestaciones.
- **Sincronización Bidireccional con Google Sheets**:
  - Transmisión en tiempo real vía Google Apps Script Web App (POST / GET).
  - Arquitectura *Offline-First* con almacenamiento local y reconciliación resiliente de fallos de red.
- **Cuadro de Mando Analítico (Dashboard SST)**:
  - KPIs en vivo: Cobertura de dotación, presupuesto ejecutado en Soles (PEN), conteo de ítems vencidos y por vencer (15 días).
  - Gráficos de distribución de consumo por área operativa y clasificación EPP vs. Uniformes de trabajo.
  - Exportación de auditoría en formato CSV tabular.

---

## 🏛️ Arquitectura del Sistema

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CAPA DE PRESENTACIÓN (UI)                       │
│  React 19 · React Router v7 · Tailwind CSS · Lucide Icons · Canvas Web │
│  [Dashboard] [Entregas] [Inspecciones] [Documental] [Catálogo] ...     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                       CAPA DE ESTADO & SERVICIOS                       │
│  Zustand Global Store (`useEPPStore`)                                  │
│  ├── data/validation/       -> Schemas Zod (DNI, RUC, entregas, epp)   │
│  ├── services/storage/      -> Módulos desacoplados de persistencia   │
│  │   ├── entregasStorage    ├── inspeccionesStorage                    │
│  │   ├── trabajadoresStorage ├── eppItemsStorage                       │
│  │   └── syncManager        └── eventEmitter (Pub/Sub)                 │
│  └── services/pdf/          -> Generadores especializados de PDF      │
│      ├── utils/             -> Estilos ISO, colores corporativos, QR  │
│      ├── entregas.ts        ├── inspecciones.ts                        │
│      ├── reportes.ts        └── descuentos.ts / infracciones.ts       │
└──────────────────┬─────────────────────────────────┬───────────────────┘
                   │                                 │
┌──────────────────▼──────────────┐   ┌──────────────▼───────────────────┐
│       ALMACENAMIENTO LOCAL      │   │         BACKEND EN LA NUBE        │
│       localStorage Browser      │   │  Google Apps Script Web App URL  │
│  (Persistencia offline-first)   │   │  Google Sheets (Base de Datos)   │
└─────────────────────────────────┘   └──────────────────────────────────┘
```

---

## 📁 Estructura del Código

```
src/
├── components/                 # Componentes de interfaz de usuario
│   ├── common/                 # Header, Sidebar, Toast, FirmaModal
│   ├── dashboard/              # KPIs analíticos, métricas y filtros
│   ├── entregas/               # NuevaEntregaForm, HistorialEntregas, EntregasTable
│   ├── inspecciones/           # InspeccionesModule y formularios técnicos
│   ├── documental/             # ControlDocumentalModule y visor PDF embebido
│   ├── trabajadores/           # Padrón de colaboradores, altas y edición
│   ├── catalogo/               # Maestro de EPPs y control de existencias
│   ├── descuentos/             # DescuentosModule (FO-SST-DES-001)
│   ├── infracciones/           # InfraccionesModule (FO-SST-INF-001)
│   └── configuracion/          # Parámetros, endpoints GAS y sincronización
├── data/                       # Semillas maestras y esquemas de validación
│   ├── seedData.ts             # Datos iniciales PERPOL IDEAS y TR3 ALIMENTOS
│   └── validation/             # Validación tipada con Zod
│       ├── schemas.ts          # Validadores de DNI, RUC, cantidades, fechas
│       └── validators.ts       # Funciones utilitarias para formularios
├── services/
│   ├── gasService.ts           # Cliente HTTP para Google Apps Script
│   ├── gasScriptCode.ts        # Código fuente exportable para Apps Script
│   ├── storage/                # Almacenamiento modular desacoplado
│   │   ├── entregasStorage.ts
│   │   ├── trabajadoresStorage.ts
│   │   ├── eppItemsStorage.ts
│   │   ├── inspeccionesStorage.ts
│   │   ├── renovacionesStorage.ts
│   │   └── sync/               # Reconciliación con Google Sheets
│   └── pdf/                    # Motor modular de generación de PDFs
│       ├── index.ts            # Punto de entrada y compatibilidad
│       ├── entregas.ts         # Acta oficial FO-SST-GEN-050
│       ├── inspecciones.ts     # Acta técnica de inspección
│       ├── reportes.ts         # Listados y padrones apaisados
│       ├── descuentos.ts       # Autorización de descuento FO-SST-DES-001
│       ├── infracciones.ts     # Reporte disciplinario FO-SST-INF-001
│       └── utils/              # Paletas cromáticas ISO, encabezados y formato
├── store/
│   └── useEPPStore.ts          # Store central reactivo Zustand
├── types/
│   └── index.ts                # Contratos TypeScript de todo el dominio
└── test/
    └── setup.ts                # Configuración global del entorno Vitest y DOM
```

---

## 📦 Módulos del Sistema

1. **Dashboard SST**: Visualización ejecutiva de índices de cobertura, valorización total de entregas en Soles, alertas de equipos vencidos o por vencer en 15 días, y distribución de consumo por centros de costo.
2. **Entregas de EPP**:
   - Registro de nuevas dotaciones individuales y masivas.
   - Captura de firma autógrafa digital sobre pantalla táctil o ratón.
   - Generación instantánea del documento oficial **FO-SST-GEN-050**.
   - Historial filtrable por empresa, área, estado y rango de fechas.
3. **Inspecciones de EPP**: Auditorías periódicas a campo del estado de conservación de los equipos de protección, con identificación de desgaste o extravío.
4. **Control Documental**: Repositorio centralizado de actas emitidas con número de folio correlativo, visor de PDF integrado y control de estatus de firma.
5. **Padrón de Trabajadores**: Gestión de personal por empresa (**PERPOL IDEAS** / **TR3 ALIMENTOS**), asignación de cargos, tallas de indumentaria y áreas operativas.
6. **Catálogo de EPP**: Catálogo maestro de equipos con control de stock de almacén, unidad de medida, costos unitarios y periodicidad de renovación sugerida.
7. **Autorizaciones de Descuento**: Emisión formal del documento **FO-SST-DES-001** para casos de pérdida o deterioro injustificado de equipos.
8. **Infracciones Disciplinarias**: Registro de incumplimientos a la normativa de seguridad con tipificación de faltas y medidas correctivas (**FO-SST-INF-001**).
9. **Configuración del Sistema**: Conexión con Google Apps Script, parámetros de sincronización automática (30s / 60s / 120s), exportación a CSV y copia de seguridad de datos.

---

## 🛠️ Instalación y Puesta en Marcha

### Prerrequisitos
- **Node.js**: Versión 18.x o superior
- **npm**: Versión 9.x o superior

### 1. Clonar el repositorio e instalar dependencias
```bash
git clone <URL_DEL_REPOSITORIO>
cd gestion-epps
npm install
```

### 2. Iniciar el entorno de desarrollo
```bash
npm run dev
```
La aplicación estará disponible localmente en: `http://localhost:3000`

### 3. Compilación para producción
```bash
npm run build
```
Genera los archivos optimizados listos para despliegue en la carpeta `dist/`.

---

## 🧪 Pruebas Automatizadas

El proyecto cuenta con una suite completa de pruebas unitarias y de integración utilizando **Vitest** y **Testing Library**:

```bash
# Ejecutar todas las pruebas en modo único
npm test

# Ejecutar las pruebas en modo interactivo (watch)
npm run test:watch
```

### Cobertura de pruebas implementada:
- **Validación de Datos (`src/data/validation/__tests__/schemas.test.ts`)**: Validación de esquemas Zod (formatos de DNI, RUC de 11 dígitos, stock positivo y fechas válidas).
- **Almacenamiento y Transacciones (`src/services/storage/__tests__/entregasStorage.test.ts`)**: Adición de entregas, descuento reactivo de inventario y control de errores por stock insuficiente.
- **Entidades de Negocio (`src/services/storage/__tests__/entidadesStorage.test.ts`)**: Operaciones CRUD en empresas, colaboradores y catálogo de EPP.
- **Motor de PDF (`src/services/pdf/__tests__/pdfUtils.test.ts`)**: Validación de paletas de color corporativas (PERPOL vs TR3), formateadores de moneda (PEN), fechas ISO y nombres de archivo.
- **Componentes React (`src/components/common/__tests__/Header.test.tsx`, `DashboardModule.test.tsx`)**: Renderizado de componentes, navegación y reactividad ante eventos de usuario.

---

## ☁️ Integración con Google Sheets & Google Apps Script

El aplicativo puede operar de forma totalmente local (*offline*) o sincronizado con una hoja de cálculo corporativa de Google Sheets mediante Google Apps Script.

1. Abra una hoja de cálculo en [Google Sheets](https://sheets.google.com).
2. Diríjase a **Extensiones > Apps Script**.
3. Copie el código fuente ubicado en `src/services/gasScriptCode.ts` (o utilice el asistente disponible dentro del módulo de **Configuración** del aplicativo).
4. Guarde y seleccione **Implementar > Nueva implementación**.
5. Tipo: **Aplicación web**.
   - **Ejecutar como**: `Yo (tu cuenta)`.
   - **Quién tiene acceso**: `Cualquier usuario` (*Anyone*).
6. Copie la **URL de la aplicación web** resultante y péguela en el módulo de **Configuración** de la aplicación.
7. Haga clic en **Probar Conexión** y luego en **Sincronizar Datos**.

---

## 📄 Licencia y Derechos

Desarrollado para la gestión y control de Seguridad y Salud en el Trabajo (SSOMA) de **PERPOL IDEAS S.A.C.** y **TR3 ALIMENTOS S.A.C.** Todos los derechos reservados.
